# M00–M03 supporting books and labs

The daily study route is ../00_STUDY_MODULES/M00 through M03. Each module has separate revision, test and protected answers. This folder shares the early data files and SQL setup so later lessons can reuse the same tables.

Use books/SQL_Desk_Setup.pdf before the first runnable M02 SQL lesson. It prepares the database, connection and fixture. M00 and M01 do not require SQL.

After M01 take ../09_GATES/G01. After M03 take ../09_GATES/G02. Both follow Gate A -> Protected Review A -> fresh Gate B -> Protected Review B. Reviews are opened only after saved attempts.

M00–M01 practice review: books/M00_M01_Explained_Reviews.pdf. M02–M03 practice review: books/M02_M03_Explained_Reviews.pdf.
