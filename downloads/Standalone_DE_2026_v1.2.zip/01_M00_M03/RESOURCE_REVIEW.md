# Resource shortlist review

The external resource shortlist covers useful areas and names several plausible teaching sources. It is a resource shortlist rather than the self-sufficient beginner book you requested. It leaves lesson selection, prerequisite repair, exact watch ranges, connected exercises and assessment to the learner. We can use selected resources inside the existing standalone sequence without restarting the course.

## Corrections checked on 13 September 2026
The [official Data Engineering Zoomcamp repository](https://github.com/DataTalksClub/data-engineering-zoomcamp) describes a free nine-week course and expects basic coding experience and some SQL familiarity. Its current orchestration module uses Kestra; the syllabus also includes Bruin, along with Docker/Terraform, warehousing, dbt, Spark and streaming. The supplied description of its orchestration teaching as Airflow is outdated. Use a versioned syllabus when mapping lectures; do not combine chapter assumptions from different years.

[SQLBolt](https://sqlbolt.com/) is useful for introductory interactive SQL and some intermediate topics. Its published index does not make it a complete advanced engineering-SQL curriculum. In our standalone sequence, it is a candidate reinforcement source for M02; joins, windows, database behaviour and engineering validation still need explicit teaching and practice.

Free learning material does not make every cloud lab permanently free. The [Redshift trial](https://aws.amazon.com/redshift/free-trial/) currently gives eligible new Redshift Serverless users a $300 credit usable within 90 days; AWS says this trial is separate from its general Free Tier. The [BigQuery sandbox](https://docs.cloud.google.com/bigquery/docs/sandbox) has limited capabilities, quotas and automatic expiry of tables, views and partitions after 60 days. It does not support streaming, DML or the Data Transfer Service. A course must choose exercises that actually fit the selected access mode.

## What I would retain in our plan
Keep Python, SQL, command-line use, Git, modelling, transformation tests, orchestration, storage, distributed processing and a capstone. Add them in prerequisite order. For your 8 GB laptop and cost constraints, begin with small local examples; introduce one primary cloud route later, with an explicit cost/access decision and suitable alternatives. The existing standalone roadmap includes Azure/Fabric; this shortlist is not a reason to switch every module to GCP or AWS now.

A reliable small pipeline is already data engineering. Spark and Airflow do not define the starting line. Before increasing scale, a learner should understand how to keep source data, avoid duplicate loads, recover from failure, verify outputs and explain a result's grain. The phrase "true data engineering happens" in the big-data phase understates those earlier engineering skills.

The capstone idea is useful, but the diagram needs operational details: an input contract, saved raw data, repeatable loads, failure handling, checks, documentation and a reproducible run. Also distinguish workflows: dbt commonly transforms data already loaded in a warehouse, whereas a PySpark transformation may happen before a warehouse load. "Transform with dbt or PySpark, then load" is not one interchangeable instruction for both tools.

The remaining named providers in the supplied shortlist have not all been audited in this batch. Kaggle/Corey Schafer, Missing Semester, Kimball, dbt Learn and Astronomer remain candidate sources for the appropriate later stages, not automatically approved lesson assignments. No claim is made here that every course, exercise, API or cloud service they mention is free without limits.

## What this changes now
It adds useful candidates to the later source-selection work. It does not replace the supplied M00-M03 or make the unbuilt later modules complete. The current delivery can be judged directly: read the learner books, perform a fresh task and check whether the explanations and review let you recover without searching for another textbook. I will not claim this material is better merely because its index is longer.

## The additional suggestions in your checkpoint

A 45-day roadmap can be a schedule, but it cannot establish job readiness for an absolute beginner. The [official Zoomcamp prerequisites](https://github.com/DataTalksClub/data-engineering-zoomcamp) already expect basic coding and some SQL. We therefore retain your computer, data and SQL foundations before that level of engineering work.

The [OSSU organisation](https://github.com/ossu) publishes learning paths including computer science, data science and mathematics; no official Data Engineering path was found among its published repositories during this check. Do not label an invented DE index as an OSSU course.

[DataNerd](https://datanerd.tech/about) can help explore the job postings represented in its dataset. Its published method uses Google Jobs through SerpAPI; that is a sample of advertised vacancies, not a complete census of Indian fresher hiring. Check the location, role and experience filters before drawing conclusions. We will use actual vacancies during career preparation, rather than claiming a skill is universally unnecessary from a broad chart.

These sources inform later choices. They do not remove the existing standalone modules or promise that a BA applicant will receive an interview or an offer in a fixed period.
