# Your SQL practice files

Start with books/SQL_Desk_Setup.pdf. Create your own local PostgreSQL database named standalone_de, open pgAdmin Query Tool connected to it, and load 00_load_course.sql, followed by 01_load_assessments.sql. The setup guide explains every action and its expected result. Do not load the assessment answers.

The two load files create original fictional inputs. They intentionally do not DROP an existing schema or silently replace saved work. If you already loaded them, use the setup check instead of loading again. 99_optional_reset_course.sql is an optional destructive reset of this personal course schema, not an ordinary first step. Save your own evidence before considering it.

## Which folder now?

| Folder | Open when | What to do |
| --- | --- | --- |
| guided | At Follow with me once | Open the exact lesson ID and body block number, compare it with the printed code, then execute that block |
| attempt_templates | At Your independent practice | Copy the blank template into your own work folder and write your solution |
| answers_after_attempt | After saving your genuine attempt | Open the matching lesson's review block; compare reasons in the review PDF as well as numbers |

## A block is not a whole lesson

The books explain a sequence. Run numbered blocks in order in the same pgAdmin Query Tool session when temporary tables or views depend on earlier blocks. Do not select every file and execute it as one huge script. Opening a new connection loses temporary objects. Some guided blocks intentionally change temporary state, so rereading the lesson is necessary before rerunning them.

Use one Query Tool tab/session per lesson; load fixtures once in the persistent course schema. For a fresh rerun of a temporary-table exercise, close that lesson session and open a new Query Tool. The source tables remain available. Start from its first guided block again. A SQL file on disk is text; opening it is not executing it.

DE03-12 contains one deliberately invalid constraint example in the book. It is marked sql-error and is not exported as an ordinary guided script. Read its recovery explanation before trying it. The execution check also verifies this expected failure separately.

The supplied SQL files contain original course teaching, not copied instructor code. Instructor videos use different data. Review material is separated for learning discipline, not encrypted or technically locked; honour the save-before-review rule yourself.

## Dataset map

| Tables | Used in | Meaning |
| --- | --- | --- |
| course.sales | M02 guided examples | One simplified order with one item per row; 8 rows |
| course.practice_sales | M02 first independent tasks | 4 changed source records |
| course.retry_sales | M02 changed retries | 4 further changed records |
| course.customers, orders, order_items | M03 guided examples | Separate customer, order and line grains |
| course.raw_labels, events | M03 cleaning and time analysis | Deliberately awkward labels and boundary timestamps |
| course.challenge_customers, challenge_orders, challenge_items | DE03-15/16 independent practice | A new fixture, not the guided answers |
| course.challenge_retry_customers, challenge_retry_orders, challenge_retry_items | DE03-15/16 changed retry | Further changed inputs |
| course.g02_customers, g02_orders, g02_items | G02-A | Independent checkpoint inputs |
| course.g02_repair_customers, g02_repair_orders, g02_repair_items | G02 targeted repair | Changed micro-task inputs; not a full Gate B or C |

Each fixture is visible in the two load files. The learner books explain column meanings as each table is introduced. Preserve leading zeros in text identifiers; money uses fixed-precision numeric columns. SQL NULL means missing/unknown under the stated data contract, not the text 'NULL' or zero.

## Save useful evidence

Keep your .sql, exported results or a clear screenshot, row/amount checks and a short plain-language explanation in your own work folder. Keep first attempt and changed retry separate. The course's expected results are not your evidence until you have actually produced them.

## Validation and limits

The published SQL teaching and answer blocks were executed in PostgreSQL 18.3 through PGlite 0.5.8. This checks SQL semantics and expected outcomes in that engine. It does not test the Windows installer, pgAdmin buttons, server networking, concurrent sessions or native machine performance. Your EXPLAIN output can differ without being wrong; interpret the actual plan.
