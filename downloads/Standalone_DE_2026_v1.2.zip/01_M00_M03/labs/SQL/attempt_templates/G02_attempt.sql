-- G02-A. Read the eight tasks and rubric in the checkpoint PDF.
-- Database: standalone_de. Tables: course.g02_customers, g02_orders, g02_items.
-- Save query + actual output + reasoning for EACH task below.
-- Do not open answers_after_attempt until the first attempt is saved.

-- Task 1
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 2
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 3
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 4
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 5
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 6
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 7
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation:

-- Task 8
-- Input grain:
-- Output grain:
-- Query:

-- Evidence:
-- Explanation: