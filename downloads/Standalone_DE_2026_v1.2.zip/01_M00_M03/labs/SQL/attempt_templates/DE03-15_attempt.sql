-- DE03-15 | Integrated unseen SQL challenge
-- Copy this file into your own work folder. Write your own SQL below.
-- Task: see Your independent practice in the learner book.
-- My input grain:
-- My intended output grain:
-- My query:


-- Actual result (paste or save export; do not invent):
-- Row count / total / missing-value checks:
-- My explanation:
-- Help used:
-- Retry: save a different file after review.
