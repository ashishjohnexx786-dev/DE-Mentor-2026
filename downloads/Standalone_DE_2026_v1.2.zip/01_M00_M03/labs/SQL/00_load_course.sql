-- Run only in your own standalone_de practice database.
-- Initial load is non-destructive: existing table names cause an error.
-- The separate reset script is optional and explicitly destructive to course.
BEGIN;
CREATE SCHEMA IF NOT EXISTS course;
CREATE TABLE course.sales (
  order_id text PRIMARY KEY,
  customer_id text,
  item text NOT NULL,
  category text NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price numeric(10,2) NOT NULL CHECK (unit_price >= 0),
  ordered_on date NOT NULL,
  is_paid boolean,
  discount_pct numeric(4,2)
    CHECK (discount_pct BETWEEN 0 AND 1)
);
INSERT INTO course.sales VALUES
('0007','C01','Notebook','Paper',2,49.50,'2026-09-01',true,0.10),
('0008','C02','Pen','Writing',3,10.00,'2026-09-01',false,0),
('0009','C01','Folder','Paper',1,25.00,'2026-09-02',true,NULL),
('0010','C03','Marker','Writing',2,30.00,'2026-09-02',NULL,0),
('0011','C02','Notebook','Paper',1,60.00,'2026-09-03',true,0.05),
('0012','C04','Pen','Writing',4,12.50,'2026-09-03',false,0),
('0013','C03','Ruler','Tools',2,20.00,'2026-09-04',NULL,0.10),
('0014',NULL,'Bag','Bags',1,250.00,'2026-09-04',true,0);
CREATE TABLE course.practice_sales
  (LIKE course.sales INCLUDING ALL);
INSERT INTO course.practice_sales VALUES
('P101','C10','Pen','Writing',2,9,'2026-10-01',true,0),
('P102','C11','Notebook','Paper',2,40,'2026-10-01',true,0.10),
('P103','C10','Folder','Paper',1,30,'2026-10-02',false,NULL),
('P104',NULL,'Bag','Bags',1,120,'2026-10-03',NULL,0.05);
CREATE TABLE course.retry_sales
  (LIKE course.sales INCLUDING ALL);
INSERT INTO course.retry_sales VALUES
('R201','C20','Notebook','Paper',3,25,'2026-11-01',true,0.10),
('R202','C21','Pen','Writing',2,10,'2026-11-01',false,0),
('R203','C20','Folder','Paper',3,25,'2026-11-02',true,NULL),
('R204',NULL,'Ruler','Tools',2,15,'2026-11-03',NULL,0);
CREATE TABLE course.customers (
 customer_id text PRIMARY KEY,
 customer_name text NOT NULL,
 region text NOT NULL
);
INSERT INTO course.customers VALUES
('C01','Asha','East'),('C02','Ravi','East'),
('C03','Mina','West'),('C04','Iqbal','North'),
('C05','Tara','South');
CREATE TABLE course.orders (
 order_id text PRIMARY KEY,
 customer_id text REFERENCES course.customers,
 ordered_on date NOT NULL,
 shipping_fee numeric(10,2) NOT NULL CHECK (shipping_fee>=0),
 is_paid boolean
);
INSERT INTO course.orders VALUES
('O101','C01','2026-09-01',20,true),
('O102','C02','2026-09-01',10,false),
('O103','C01','2026-09-02',0,true),
('O104','C03','2026-09-03',15,NULL),
('O105','C04','2026-09-03',5,true),
('O106',NULL,'2026-09-04',0,false);
CREATE TABLE course.order_items (
 order_id text REFERENCES course.orders,
 line_no integer CHECK (line_no>0),
 item text NOT NULL,
 quantity integer NOT NULL CHECK (quantity>0),
 unit_price numeric(10,2) NOT NULL CHECK (unit_price>=0),
 PRIMARY KEY (order_id,line_no)
);
INSERT INTO course.order_items VALUES
('O101',1,'Notebook',2,49.50),('O101',2,'Pen',3,10),
('O102',1,'Folder',1,25),
('O103',1,'Marker',2,30),('O103',2,'Ruler',2,20),
('O104',1,'Bag',1,250),
('O105',1,'Notebook',1,60),('O105',2,'Pen',4,12.50);
CREATE TABLE course.raw_labels (source_id text, item_raw text);
INSERT INTO course.raw_labels VALUES
('A','  pen '),('B','PEN'),('C',''),('D',NULL),
('E',' Note book '),('F','Pen  blue');
CREATE TABLE course.events (
 event_id text PRIMARY KEY,
 happened_at timestamptz NOT NULL
);
INSERT INTO course.events VALUES
('T1','2026-08-31 18:30:00+00'),
('T2','2026-09-01 18:29:59+00'),
('T3','2026-09-01 18:30:00+00');
COMMIT;
-- Display only; no answer to an independent exercise.
SELECT 'sales' AS dataset, COUNT(*) AS rows FROM course.sales
UNION ALL
SELECT 'practice_sales', COUNT(*) FROM course.practice_sales
UNION ALL
SELECT 'retry_sales', COUNT(*) FROM course.retry_sales
UNION ALL
SELECT 'customers', COUNT(*) FROM course.customers
UNION ALL
SELECT 'orders', COUNT(*) FROM course.orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM course.order_items;
