-- DE02-05 | ORDER BY, DISTINCT and result inspection
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT DISTINCT item
FROM course.sales
ORDER BY item;
