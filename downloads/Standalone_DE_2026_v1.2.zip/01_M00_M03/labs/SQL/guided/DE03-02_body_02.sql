-- DE03-02 | Cardinality, row multiplication and join validation
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS joined_rows,
       COUNT(DISTINCT o.order_id) AS represented_orders,
       SUM(o.shipping_fee) AS repeated_fees
FROM course.orders AS o
JOIN course.order_items AS i
  ON o.order_id = i.order_id;

SELECT COUNT(*) AS source_orders,
       SUM(shipping_fee) AS source_fees
FROM course.orders;
