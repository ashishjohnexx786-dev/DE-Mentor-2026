-- DE02-11 | CASE for business categories
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id,
       CASE
         WHEN is_paid = TRUE THEN 'Paid'
         WHEN is_paid = FALSE THEN 'Unpaid'
         ELSE 'Unknown'
       END AS payment_group,
       quantity * unit_price AS gross_amount
FROM course.sales
ORDER BY order_id;
