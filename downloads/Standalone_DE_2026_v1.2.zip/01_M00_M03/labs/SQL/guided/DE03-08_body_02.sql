-- DE03-08 | Window functions and PARTITION BY
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id,
       ROUND(100.0 * quantity * unit_price
         / NULLIF(SUM(quantity * unit_price)
             OVER (PARTITION BY category), 0), 2)
         AS pct_of_category
FROM course.sales
WHERE category = 'Paper'
ORDER BY order_id;
