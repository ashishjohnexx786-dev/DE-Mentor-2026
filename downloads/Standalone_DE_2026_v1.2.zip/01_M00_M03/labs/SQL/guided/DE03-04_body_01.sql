-- DE03-04 | String functions for cleaning and standardization
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT source_id, item_raw,
       LENGTH(item_raw) AS raw_length,
       NULLIF(LOWER(TRIM(item_raw)), '') AS item_clean
FROM course.raw_labels
ORDER BY source_id;
