-- DE02-01 | Database, table, row, column and query mental model
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, item, quantity, unit_price
FROM course.sales
ORDER BY order_id;
