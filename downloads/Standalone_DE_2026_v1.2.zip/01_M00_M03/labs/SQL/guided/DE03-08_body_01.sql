-- DE03-08 | Window functions and PARTITION BY
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, category,
       quantity * unit_price AS gross_amount,
       SUM(quantity * unit_price)
         OVER (PARTITION BY category) AS category_gross
FROM course.sales
ORDER BY category, order_id;
