-- DE02-07 | Arithmetic expressions and safe calculations
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id,
       quantity * unit_price AS gross_amount,
       quantity * unit_price
         * (1 - COALESCE(discount_pct, 0)) AS estimated_net
FROM course.sales
WHERE order_id IN ('0007', '0009')
ORDER BY order_id;
