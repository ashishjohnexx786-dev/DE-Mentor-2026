-- DE03-04 | String functions for cleaning and standardization
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS raw_rows,
       COUNT(item_raw) AS raw_non_null,
       COUNT(NULLIF(LOWER(TRIM(item_raw)), ''))
         AS usable_clean_labels
FROM course.raw_labels;
