-- DE03-13 | Indexes and EXPLAIN basics
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

EXPLAIN SELECT order_no, amount
FROM plan_orders WHERE order_no >= 1;
