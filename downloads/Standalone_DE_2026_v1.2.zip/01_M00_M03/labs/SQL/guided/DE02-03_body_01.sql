-- DE02-03 | WHERE and comparison operators
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, item, unit_price
FROM course.sales
WHERE unit_price >= 30
ORDER BY order_id;
