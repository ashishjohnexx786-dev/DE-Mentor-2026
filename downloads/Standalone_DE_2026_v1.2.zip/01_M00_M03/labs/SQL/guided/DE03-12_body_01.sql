-- DE03-12 | Constraints and transactions
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE TEMP TABLE stock_contract (
 product_id text PRIMARY KEY,
 units integer NOT NULL CHECK (units >= 0)
);
INSERT INTO stock_contract VALUES ('PEN', 10), ('BAG', 4);
SELECT * FROM stock_contract ORDER BY product_id;
