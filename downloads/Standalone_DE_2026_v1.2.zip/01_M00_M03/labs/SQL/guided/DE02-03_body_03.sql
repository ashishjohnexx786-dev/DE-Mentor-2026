-- DE02-03 | WHERE and comparison operators
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, ordered_on
FROM course.sales
WHERE ordered_on >= DATE '2026-09-03'
ORDER BY order_id;
