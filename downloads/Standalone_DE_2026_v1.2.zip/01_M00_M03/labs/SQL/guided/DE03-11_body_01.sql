-- DE03-11 | PostgreSQL setup, schemas and dialect awareness
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT current_database() AS database_name,
       current_user AS role_name,
       current_schema() AS default_schema;
SHOW server_version;
SHOW search_path;
