-- DE03-05 | Dates, timestamps and time analysis
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT
 (happened_at AT TIME ZONE 'Asia/Kolkata')::date AS day,
 COUNT(*) AS events
FROM course.events
GROUP BY (happened_at AT TIME ZONE 'Asia/Kolkata')::date
ORDER BY day;
