-- DE02-12 | String and date basics
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, ordered_on,
       EXTRACT(YEAR FROM ordered_on) AS year_number,
       EXTRACT(MONTH FROM ordered_on) AS month_number,
       ordered_on + 7 AS follow_up_date
FROM course.sales
WHERE order_id = '0007';
