-- DE03-09 | ROW_NUMBER, ranking and LAG/LEAD
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH ranked AS (
 SELECT order_id, category, quantity * unit_price AS amount,
        ROW_NUMBER() OVER (
          PARTITION BY category
          ORDER BY quantity * unit_price DESC, order_id
        ) AS rn
 FROM course.sales
)
SELECT order_id, category, amount
FROM ranked WHERE rn = 1
ORDER BY category;
