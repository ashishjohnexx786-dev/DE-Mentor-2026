-- DE03-07 | CTEs and readable multi-step SQL
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH item_totals AS (
  SELECT order_id,
         SUM(quantity * unit_price) AS item_gross
  FROM course.order_items
  GROUP BY order_id
)
SELECT * FROM item_totals ORDER BY order_id;
