-- DE03-14 | Views and reusable database logic
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS orders,
       COUNT(DISTINCT order_id) AS distinct_orders,
       SUM(order_gross) AS gross
FROM order_totals_view;
