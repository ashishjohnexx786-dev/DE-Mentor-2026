-- DE03-08 | Window functions and PARTITION BY
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, ordered_on,
       quantity * unit_price AS gross_amount,
       SUM(quantity * unit_price) OVER (
         ORDER BY ordered_on, order_id
         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS running_gross
FROM course.sales
ORDER BY ordered_on, order_id;
