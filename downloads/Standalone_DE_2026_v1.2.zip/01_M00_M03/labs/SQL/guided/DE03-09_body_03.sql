-- DE03-09 | ROW_NUMBER, ranking and LAG/LEAD
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, ordered_on,
       quantity * unit_price AS amount,
       LAG(quantity * unit_price) OVER (
         ORDER BY ordered_on, order_id
       ) AS previous_amount,
       LEAD(quantity * unit_price) OVER (
         ORDER BY ordered_on, order_id
       ) AS next_amount
FROM course.practice_sales
ORDER BY ordered_on, order_id;
