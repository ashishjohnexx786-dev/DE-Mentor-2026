-- DE02-08 | Aggregate functions
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS rows_found,
       SUM(quantity * unit_price) AS gross_total
FROM course.sales
WHERE item = 'Laptop';
