-- DE02-09 | GROUP BY and grouped grain
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category,
       COUNT(*) AS sale_rows,
       SUM(quantity * unit_price) AS gross_total
FROM course.sales
GROUP BY category
ORDER BY category;
