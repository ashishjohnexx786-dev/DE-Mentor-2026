-- DE03-14 | Views and reusable database logic
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE TEMP TABLE view_source (code text, units integer);
INSERT INTO view_source VALUES ('A', 2);
CREATE TEMP VIEW view_demo AS
SELECT code, units, units * 10 AS value FROM view_source;
SELECT * FROM view_demo;
UPDATE view_source SET units = 3 WHERE code = 'A';
SELECT * FROM view_demo;
