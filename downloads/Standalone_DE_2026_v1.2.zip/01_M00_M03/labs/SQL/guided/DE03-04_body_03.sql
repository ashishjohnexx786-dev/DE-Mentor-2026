-- DE03-04 | String functions for cleaning and standardization
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT source_id, item_raw
FROM course.raw_labels
WHERE LOWER(TRIM(item_raw)) LIKE 'pen%'
ORDER BY source_id;
