-- DE02-13 | Simple subqueries and IN/EXISTS awareness
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, category
FROM course.sales
WHERE category IN ('Paper', 'Tools')
ORDER BY order_id;
