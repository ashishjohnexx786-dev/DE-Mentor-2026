-- DE03-03 | UNION and UNION ALL
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category FROM course.sales
WHERE ordered_on = DATE '2026-09-01'
UNION
SELECT category FROM course.sales
WHERE ordered_on = DATE '2026-09-02'
ORDER BY category;
