-- DE03-11 | PostgreSQL setup, schemas and dialect awareness
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE TEMP TABLE desk_note (
  note_id text PRIMARY KEY,
  note_text text NOT NULL
);
INSERT INTO desk_note (note_id, note_text)
VALUES ('N01', 'A SQL file is saved text.');
SELECT note_id, note_text FROM desk_note;
