-- DE03-01 | INNER JOIN and LEFT JOIN
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT o.order_id, o.customer_id, c.customer_name
FROM course.orders AS o
LEFT JOIN course.customers AS c
  ON o.customer_id = c.customer_id
ORDER BY o.order_id;
