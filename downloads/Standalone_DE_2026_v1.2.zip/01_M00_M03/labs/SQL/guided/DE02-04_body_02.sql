-- DE02-04 | AND, OR, NOT and parentheses
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, category, quantity
FROM course.sales
WHERE category = 'Paper'
   OR category = 'Writing' AND quantity >= 2
ORDER BY order_id;
