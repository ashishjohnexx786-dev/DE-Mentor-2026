-- DE02-14 | Debugging and validation workflow
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category,
       SUM(quantity * unit_price) AS paid_gross
FROM course.sales
WHERE is_paid = TRUE
GROUP BY category
HAVING SUM(quantity * unit_price) >= 100
ORDER BY category;
