-- DE03-02 | Cardinality, row multiplication and join validation
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT o.order_id, o.shipping_fee,
       (SELECT SUM(i.quantity * i.unit_price)
        FROM course.order_items AS i
        WHERE i.order_id = o.order_id) AS item_total
FROM course.orders AS o
WHERE o.order_id = 'O101';
