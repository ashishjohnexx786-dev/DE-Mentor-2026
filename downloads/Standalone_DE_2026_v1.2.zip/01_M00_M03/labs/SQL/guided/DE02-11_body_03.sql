-- DE02-11 | CASE for business categories
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id,
       CASE
         WHEN quantity * unit_price >= 100 THEN 'Large'
         WHEN quantity * unit_price >= 50 THEN 'Medium'
         ELSE 'Small'
       END AS size_group
FROM course.sales
ORDER BY order_id;
