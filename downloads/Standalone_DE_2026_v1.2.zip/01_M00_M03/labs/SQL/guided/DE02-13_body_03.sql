-- DE02-13 | Simple subqueries and IN/EXISTS awareness
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT EXISTS (
  SELECT 1 FROM course.sales WHERE is_paid IS NULL
) AS has_unknown_payment;
