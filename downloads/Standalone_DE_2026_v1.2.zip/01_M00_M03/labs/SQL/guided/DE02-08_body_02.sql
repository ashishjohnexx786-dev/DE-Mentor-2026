-- DE02-08 | Aggregate functions
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS paid_rows,
       SUM(quantity * unit_price) AS paid_gross
FROM course.sales
WHERE is_paid = TRUE;
