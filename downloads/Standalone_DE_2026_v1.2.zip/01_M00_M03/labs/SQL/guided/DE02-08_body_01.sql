-- DE02-08 | Aggregate functions
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS sale_rows,
       COUNT(is_paid) AS known_payment_rows,
       SUM(quantity * unit_price) AS gross_total,
       AVG(quantity * unit_price) AS mean_sale_amount,
       MIN(unit_price) AS lowest_unit_price,
       MAX(unit_price) AS highest_unit_price
FROM course.sales;
