-- DE03-13 | Indexes and EXPLAIN basics
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE INDEX plan_orders_order_no_idx ON plan_orders(order_no);
ANALYZE plan_orders;
EXPLAIN (ANALYZE, BUFFERS)
SELECT order_no, amount
FROM plan_orders WHERE order_no = 8765;
