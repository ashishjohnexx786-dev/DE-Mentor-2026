-- DE03-02 | Cardinality, row multiplication and join validation
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT o.order_id, i.line_no,
       i.quantity * i.unit_price AS item_amount,
       o.shipping_fee
FROM course.orders AS o
JOIN course.order_items AS i
  ON o.order_id = i.order_id
ORDER BY o.order_id, i.line_no;
