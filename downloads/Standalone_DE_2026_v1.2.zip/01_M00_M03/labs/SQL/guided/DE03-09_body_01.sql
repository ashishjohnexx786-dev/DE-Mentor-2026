-- DE03-09 | ROW_NUMBER, ranking and LAG/LEAD
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, quantity * unit_price AS gross_amount,
       ROW_NUMBER() OVER (
         ORDER BY quantity * unit_price DESC, order_id
       ) AS row_position,
       RANK() OVER (
         ORDER BY quantity * unit_price DESC
       ) AS amount_rank,
       DENSE_RANK() OVER (
         ORDER BY quantity * unit_price DESC
       ) AS dense_amount_rank
FROM course.retry_sales
ORDER BY gross_amount DESC, order_id;
