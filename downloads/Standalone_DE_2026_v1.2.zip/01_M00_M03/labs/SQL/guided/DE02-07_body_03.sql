-- DE02-07 | Arithmetic expressions and safe calculations
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT 1 / 2 AS integer_result,
       1.0 / 2 AS fractional_result,
       1.0 / NULLIF(0, 0) AS undefined_ratio;
