-- DE02-06 | NULL, IS NULL and COALESCE
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, item, is_paid
FROM course.sales
WHERE is_paid IS NULL
ORDER BY order_id;
