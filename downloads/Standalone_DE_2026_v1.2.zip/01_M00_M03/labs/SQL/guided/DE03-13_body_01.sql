-- DE03-13 | Indexes and EXPLAIN basics
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE TEMP TABLE plan_orders AS
SELECT n AS order_no,
       n % 100 AS customer_no,
       n * 1.0 AS amount
FROM generate_series(1, 10000) AS g(n);
ANALYZE plan_orders;
EXPLAIN SELECT order_no, amount
FROM plan_orders WHERE order_no = 8765;
