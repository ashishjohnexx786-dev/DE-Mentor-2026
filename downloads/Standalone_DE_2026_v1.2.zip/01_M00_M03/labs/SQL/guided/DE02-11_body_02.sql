-- DE02-11 | CASE for business categories
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT SUM(CASE WHEN is_paid = TRUE THEN 1 ELSE 0 END)
         AS paid_rows,
       SUM(CASE WHEN is_paid = FALSE THEN 1 ELSE 0 END)
         AS unpaid_rows,
       SUM(CASE WHEN is_paid IS NULL THEN 1 ELSE 0 END)
         AS unknown_rows,
       COUNT(*) AS all_rows
FROM course.sales;
