-- DE02-06 | NULL, IS NULL and COALESCE
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, discount_pct,
       COALESCE(discount_pct, 0) AS estimated_discount_pct
FROM course.sales
WHERE order_id = '0009';
