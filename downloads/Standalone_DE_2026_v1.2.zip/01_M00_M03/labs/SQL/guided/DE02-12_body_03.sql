-- DE02-12 | String and date basics
-- body block 3. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, ordered_on
FROM course.sales
WHERE ordered_on >= DATE '2026-09-01'
  AND ordered_on < DATE '2026-10-01'
ORDER BY order_id;
