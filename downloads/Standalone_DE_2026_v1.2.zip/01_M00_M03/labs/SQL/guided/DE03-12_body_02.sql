-- DE03-12 | Constraints and transactions
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

BEGIN;
UPDATE stock_contract SET units = units - 2
WHERE product_id = 'PEN';
SELECT * FROM stock_contract WHERE product_id = 'PEN';
ROLLBACK;
SELECT * FROM stock_contract WHERE product_id = 'PEN';
