-- DE02-06 | NULL, IS NULL and COALESCE
-- body block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id
FROM course.sales
WHERE is_paid = FALSE
ORDER BY order_id;

SELECT order_id
FROM course.sales
WHERE NOT is_paid
ORDER BY order_id;
