-- DE03-05 | Dates, timestamps and time analysis
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT event_id,
       happened_at AT TIME ZONE 'UTC' AS utc_clock,
       happened_at AT TIME ZONE 'Asia/Kolkata' AS india_clock,
       (happened_at AT TIME ZONE 'Asia/Kolkata')::date
         AS india_date
FROM course.events
ORDER BY happened_at;
