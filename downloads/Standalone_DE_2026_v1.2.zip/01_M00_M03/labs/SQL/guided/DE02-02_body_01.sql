-- DE02-02 | SELECT, aliases and LIMIT
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id AS sale_id, item AS product
FROM course.sales
ORDER BY order_id
LIMIT 3;
