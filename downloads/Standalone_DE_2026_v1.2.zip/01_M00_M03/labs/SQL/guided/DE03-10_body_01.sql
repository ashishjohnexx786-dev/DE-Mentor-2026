-- DE03-10 | Advanced aggregation and multi-grain reasoning
-- body block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH item_totals AS (
 SELECT order_id, SUM(quantity * unit_price) AS item_gross
 FROM course.order_items GROUP BY order_id
), order_totals AS (
 SELECT o.order_id, c.region,
        COALESCE(i.item_gross, 0) AS item_gross,
        o.shipping_fee,
        COALESCE(i.item_gross, 0) + o.shipping_fee AS order_gross
 FROM course.orders AS o
 LEFT JOIN item_totals AS i ON o.order_id = i.order_id
 LEFT JOIN course.customers AS c ON o.customer_id = c.customer_id
)
SELECT COALESCE(region, 'Unknown') AS region_group,
       COUNT(*) AS order_count,
       SUM(item_gross) AS item_gross,
       SUM(shipping_fee) AS shipping_fees,
       SUM(order_gross) AS order_gross,
       ROUND(AVG(order_gross), 2) AS avg_order_gross
FROM order_totals
GROUP BY region
ORDER BY region_group;
