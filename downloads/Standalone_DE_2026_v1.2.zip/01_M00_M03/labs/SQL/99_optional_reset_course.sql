-- OPTIONAL RESET: deletes ALL objects and changes in the course schema.
-- First save your SQL attempts and export any results you need.
-- Use ONLY in your personal standalone_de practice database.
-- Do not run automatically between lessons. Close unsaved transactions first.
BEGIN;
DROP SCHEMA IF EXISTS course CASCADE;
COMMIT;
-- Next run 00_load_course.sql to restore the original fictional datasets.
