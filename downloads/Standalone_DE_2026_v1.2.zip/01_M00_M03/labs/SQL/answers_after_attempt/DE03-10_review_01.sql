-- DE03-10 | Advanced aggregation and multi-grain reasoning
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH item_totals AS (
 SELECT order_id, SUM(quantity * unit_price) AS item_gross
 FROM course.order_items GROUP BY order_id
), prepared AS (
 SELECT o.order_id,
        CASE WHEN o.is_paid = TRUE THEN 'Paid'
             WHEN o.is_paid = FALSE THEN 'Unpaid'
             ELSE 'Unknown' END AS payment_group,
        COALESCE(i.item_gross, 0) + o.shipping_fee AS order_gross
 FROM course.orders AS o
 LEFT JOIN item_totals AS i ON o.order_id = i.order_id
)
SELECT payment_group, COUNT(*) AS order_count,
       SUM(order_gross) AS order_gross
FROM prepared GROUP BY payment_group ORDER BY payment_group;
