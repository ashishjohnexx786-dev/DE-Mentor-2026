-- DE02-13 | Simple subqueries and IN/EXISTS awareness
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, quantity * unit_price AS gross_amount
FROM course.practice_sales
WHERE quantity * unit_price > (
 SELECT AVG(quantity * unit_price)
 FROM course.practice_sales
)
ORDER BY order_id;

SELECT EXISTS (
 SELECT 1 FROM course.practice_sales
 WHERE customer_id IS NULL
) AS has_missing_customer;
