-- DE03-15 | Integrated unseen SQL challenge
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH items AS (
 SELECT order_id, SUM(quantity * unit_price) AS amount
 FROM course.challenge_retry_items GROUP BY order_id
), prepared AS (
 SELECT o.order_id, c.region,
        COALESCE(i.amount, 0) + o.shipping_fee AS order_gross
 FROM course.challenge_retry_orders AS o
 LEFT JOIN items AS i ON o.order_id = i.order_id
 LEFT JOIN course.challenge_retry_customers AS c
   ON o.customer_id = c.customer_id
)
SELECT COALESCE(region, 'Unknown') AS region_group,
       COUNT(*) AS orders, SUM(order_gross) AS gross
FROM prepared GROUP BY region ORDER BY region_group;
