-- DE02-05 | ORDER BY, DISTINCT and result inspection
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT DISTINCT category
FROM course.practice_sales
ORDER BY category;

SELECT order_id, unit_price
FROM course.practice_sales
ORDER BY unit_price DESC, order_id
LIMIT 2;
