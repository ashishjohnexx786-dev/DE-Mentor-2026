-- DE03-11 | PostgreSQL setup, schemas and dialect awareness
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'course' AND table_name = 'order_items'
ORDER BY ordinal_position;
