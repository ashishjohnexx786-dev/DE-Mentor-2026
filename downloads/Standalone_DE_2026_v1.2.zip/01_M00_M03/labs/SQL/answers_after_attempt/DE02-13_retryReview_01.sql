-- DE02-13 | Simple subqueries and IN/EXISTS awareness
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, quantity * unit_price AS gross_amount
FROM course.retry_sales
WHERE quantity * unit_price >= (
 SELECT AVG(quantity * unit_price) FROM course.retry_sales
)
ORDER BY order_id;
