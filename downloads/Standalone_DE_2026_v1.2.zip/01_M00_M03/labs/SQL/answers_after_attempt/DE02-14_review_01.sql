-- DE02-14 | Debugging and validation workflow
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category,
       SUM(quantity * unit_price) AS gross_total
FROM course.practice_sales
WHERE ordered_on >= DATE '2026-10-01'
  AND ordered_on < DATE '2026-10-03'
GROUP BY category
HAVING SUM(quantity * unit_price) >= 30
ORDER BY category;

SELECT COUNT(*) AS selected_rows,
       SUM(quantity * unit_price) AS selected_gross
FROM course.practice_sales
WHERE ordered_on >= DATE '2026-10-01'
  AND ordered_on < DATE '2026-10-03';
