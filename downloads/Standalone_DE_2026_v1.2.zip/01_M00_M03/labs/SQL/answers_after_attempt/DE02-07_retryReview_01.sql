-- DE02-07 | Arithmetic expressions and safe calculations
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, quantity * unit_price AS gross_amount
FROM course.retry_sales ORDER BY order_id;

SELECT 3.0 / NULLIF(0, 0) AS return_rate;
