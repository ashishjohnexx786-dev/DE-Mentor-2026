-- DE02-07 | Arithmetic expressions and safe calculations
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, quantity * unit_price AS gross_amount
FROM course.practice_sales ORDER BY order_id;

SELECT order_id,
       quantity * unit_price * (1 - discount_pct) AS net
FROM course.practice_sales
WHERE order_id = 'P102';
