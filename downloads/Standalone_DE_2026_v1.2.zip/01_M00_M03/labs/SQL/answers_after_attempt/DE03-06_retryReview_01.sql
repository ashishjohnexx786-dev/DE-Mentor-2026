-- DE03-06 | Subqueries and nested logic
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT c.customer_id, c.customer_name
FROM course.customers AS c
WHERE (
 SELECT COUNT(*) FROM course.orders AS o
 WHERE o.customer_id = c.customer_id
) >= 2
ORDER BY c.customer_id;
