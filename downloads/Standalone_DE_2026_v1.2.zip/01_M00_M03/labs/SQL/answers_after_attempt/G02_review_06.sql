-- G02 review: open only after saving your independent attempt.
SELECT customer_id FROM course.g02_orders
WHERE is_paid = TRUE
UNION ALL
SELECT customer_id FROM course.g02_orders
WHERE is_paid IS NULL
ORDER BY customer_id;

SELECT customer_id FROM course.g02_orders
WHERE is_paid = TRUE
UNION
SELECT customer_id FROM course.g02_orders
WHERE is_paid IS NULL
ORDER BY customer_id;

SELECT c.customer_id
FROM course.g02_customers AS c
WHERE NOT EXISTS (
 SELECT 1 FROM course.g02_orders AS o
 WHERE o.customer_id = c.customer_id
)
ORDER BY c.customer_id;
