-- DE02-09 | GROUP BY and grouped grain
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT ordered_on, COUNT(*) AS sale_rows,
       SUM(quantity) AS units,
       SUM(quantity * unit_price) AS gross_total
FROM course.retry_sales
GROUP BY ordered_on
ORDER BY ordered_on;
