-- DE03-09 | ROW_NUMBER, ranking and LAG/LEAD
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH previous AS (
 SELECT order_id, ordered_on, quantity * unit_price AS amount,
        LAG(quantity * unit_price) OVER (
          ORDER BY ordered_on, order_id
        ) AS previous_amount
 FROM course.retry_sales
)
SELECT order_id, amount, previous_amount,
       amount - previous_amount AS change_from_previous
FROM previous ORDER BY ordered_on, order_id;
