-- DE02-12 | String and date basics
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT item, UPPER(item) AS item_upper,
       EXTRACT(MONTH FROM ordered_on) AS month_number,
       ordered_on + 7 AS follow_up_date
FROM course.retry_sales
WHERE order_id = 'R203';
