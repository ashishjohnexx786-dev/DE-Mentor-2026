-- DE02-06 | NULL, IS NULL and COALESCE
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id FROM course.practice_sales
WHERE is_paid IS NULL ORDER BY order_id;

SELECT order_id FROM course.practice_sales
WHERE is_paid = FALSE ORDER BY order_id;

SELECT order_id, discount_pct,
       COALESCE(discount_pct, 0) AS estimated_discount_pct
FROM course.practice_sales
WHERE discount_pct IS NULL;
