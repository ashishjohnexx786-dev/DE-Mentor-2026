-- DE03-11 | PostgreSQL setup, schemas and dialect awareness
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE TEMP TABLE desk_retry (
 reference text PRIMARY KEY,
 units integer NOT NULL
);
INSERT INTO desk_retry (reference, units) VALUES ('X01', 3);
SELECT reference, units FROM desk_retry;
