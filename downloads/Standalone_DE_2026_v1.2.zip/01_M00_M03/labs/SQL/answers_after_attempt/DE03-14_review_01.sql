-- DE03-14 | Views and reusable database logic
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, order_gross
FROM order_totals_view WHERE is_paid = FALSE
ORDER BY order_id;

SELECT COUNT(*) AS unpaid_orders,
       SUM(order_gross) AS unpaid_gross
FROM order_totals_view WHERE is_paid = FALSE;
