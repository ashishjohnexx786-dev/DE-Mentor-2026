-- DE02-06 | NULL, IS NULL and COALESCE
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id FROM course.retry_sales
WHERE customer_id IS NULL ORDER BY order_id;

SELECT order_id FROM course.retry_sales
WHERE discount_pct IS NULL ORDER BY order_id;
