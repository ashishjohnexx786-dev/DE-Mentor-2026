-- DE03-03 | UNION and UNION ALL
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category FROM course.practice_sales
WHERE ordered_on = DATE '2026-10-01'
UNION ALL
SELECT category FROM course.practice_sales
WHERE ordered_on = DATE '2026-10-02'
ORDER BY category;

SELECT category FROM course.practice_sales
WHERE ordered_on = DATE '2026-10-01'
UNION
SELECT category FROM course.practice_sales
WHERE ordered_on = DATE '2026-10-02'
ORDER BY category;
