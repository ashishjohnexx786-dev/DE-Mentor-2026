-- DE03-08 | Window functions and PARTITION BY
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id,
       SUM(quantity * unit_price) OVER (
         ORDER BY ordered_on, order_id
         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS running_gross
FROM course.retry_sales ORDER BY ordered_on, order_id;
