-- DE02-04 | AND, OR, NOT and parentheses
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, category, quantity
FROM course.practice_sales
WHERE (category = 'Paper' OR category = 'Bags')
  AND quantity = 1
ORDER BY order_id;
