-- DE03-01 | INNER JOIN and LEFT JOIN
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT c.customer_id, c.customer_name, o.order_id
FROM course.customers AS c
LEFT JOIN course.orders AS o
  ON c.customer_id = o.customer_id
ORDER BY c.customer_id, o.order_id;
