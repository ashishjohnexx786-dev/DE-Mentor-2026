-- G02 review: open only after saving your independent attempt.
WITH ranked AS (
 SELECT *, ROW_NUMBER() OVER (
   PARTITION BY customer_id
   ORDER BY order_gross DESC, order_id
 ) AS rn
 FROM g02_order_result WHERE customer_id IS NOT NULL
)
SELECT customer_id, order_id, order_gross
FROM ranked WHERE rn = 1 ORDER BY customer_id;

WITH ranked AS (
 SELECT *, ROW_NUMBER() OVER (
   PARTITION BY customer_id
   ORDER BY ordered_on DESC, order_id DESC
 ) AS rn
 FROM g02_order_result WHERE customer_id IS NOT NULL
)
SELECT customer_id, order_id, ordered_on
FROM ranked WHERE rn = 1 ORDER BY customer_id;
