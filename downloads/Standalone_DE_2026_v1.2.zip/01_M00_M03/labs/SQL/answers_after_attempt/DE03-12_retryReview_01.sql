-- DE03-12 | Constraints and transactions
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

CREATE TEMP TABLE stock_retry (
 product_id text PRIMARY KEY,
 units integer NOT NULL CHECK (units >= 0)
);
INSERT INTO stock_retry VALUES ('ONE', 5);
BEGIN;
UPDATE stock_retry SET units = 4 WHERE product_id = 'ONE';
COMMIT;
SELECT * FROM stock_retry;
