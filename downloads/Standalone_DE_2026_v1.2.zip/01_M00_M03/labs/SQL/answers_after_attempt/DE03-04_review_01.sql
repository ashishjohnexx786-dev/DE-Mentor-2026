-- DE03-04 | String functions for cleaning and standardization
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT source_id, item_raw
FROM course.raw_labels
WHERE NULLIF(LOWER(TRIM(item_raw)), '') IS NULL
ORDER BY source_id;

SELECT COUNT(DISTINCT NULLIF(LOWER(TRIM(item_raw)), ''))
         AS distinct_clean_labels
FROM course.raw_labels;
