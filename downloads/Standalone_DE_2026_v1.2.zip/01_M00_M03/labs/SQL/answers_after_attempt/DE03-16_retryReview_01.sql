-- DE03-16 | Timed SQL interview set and explanation
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH ranked AS (
 SELECT order_id, category, quantity * unit_price AS gross,
        ROW_NUMBER() OVER (
          PARTITION BY category
          ORDER BY quantity * unit_price DESC, order_id
        ) AS rn
 FROM course.practice_sales
)
SELECT order_id, category, gross
FROM ranked WHERE rn = 1 ORDER BY category;

SELECT category,
       SUM(quantity * unit_price) AS paid_gross
FROM course.practice_sales WHERE is_paid = TRUE
GROUP BY category
HAVING SUM(quantity * unit_price) > 50
ORDER BY category;
