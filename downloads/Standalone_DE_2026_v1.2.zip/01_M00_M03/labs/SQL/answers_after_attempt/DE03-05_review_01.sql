-- DE03-05 | Dates, timestamps and time analysis
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT event_id FROM course.events
WHERE happened_at >= TIMESTAMPTZ '2026-09-02 00:00:00+05:30'
  AND happened_at < TIMESTAMPTZ '2026-09-03 00:00:00+05:30'
ORDER BY happened_at;
