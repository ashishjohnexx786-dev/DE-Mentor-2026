-- DE03-16 | Timed SQL interview set and explanation
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH ranked AS (
 SELECT customer_id, order_id, ordered_on,
        ROW_NUMBER() OVER (
          PARTITION BY customer_id
          ORDER BY ordered_on DESC, order_id DESC
        ) AS rn
 FROM course.sales WHERE customer_id IS NOT NULL
)
SELECT customer_id, order_id, ordered_on
FROM ranked WHERE rn = 1 ORDER BY customer_id;
