-- G02 review: open only after saving your independent attempt.
CREATE TEMP VIEW g02_order_result AS
WITH items AS (
 SELECT order_id, SUM(quantity * unit_price) AS item_gross
 FROM course.g02_items GROUP BY order_id
)
SELECT o.order_id, o.customer_id, o.ordered_on,
       COALESCE(c.region, 'Unknown') AS region_group,
       CASE WHEN o.is_paid = TRUE THEN 'Paid'
            WHEN o.is_paid = FALSE THEN 'Unpaid'
            ELSE 'Unknown' END AS payment_group,
       COALESCE(i.item_gross, 0) AS item_gross,
       o.shipping_fee,
       COALESCE(i.item_gross, 0) + o.shipping_fee AS order_gross
FROM course.g02_orders AS o
LEFT JOIN items AS i ON o.order_id = i.order_id
LEFT JOIN course.g02_customers AS c
  ON o.customer_id = c.customer_id;

SELECT * FROM g02_order_result ORDER BY order_id;
SELECT COUNT(*) AS rows, COUNT(DISTINCT order_id) AS ids,
       SUM(item_gross) AS items, SUM(shipping_fee) AS fees,
       SUM(order_gross) AS total
FROM g02_order_result;
