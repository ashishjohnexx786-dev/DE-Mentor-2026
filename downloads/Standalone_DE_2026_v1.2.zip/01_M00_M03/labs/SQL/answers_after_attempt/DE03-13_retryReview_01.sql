-- DE03-13 | Indexes and EXPLAIN basics
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS matches
FROM plan_orders WHERE customer_no = 21;
EXPLAIN SELECT order_no
FROM plan_orders WHERE customer_no = 21;
