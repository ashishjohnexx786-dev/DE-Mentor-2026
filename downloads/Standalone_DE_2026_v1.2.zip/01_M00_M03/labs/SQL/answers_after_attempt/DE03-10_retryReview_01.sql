-- DE03-10 | Advanced aggregation and multi-grain reasoning
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH item_totals AS (
 SELECT order_id, SUM(quantity * unit_price) AS item_gross
 FROM course.order_items GROUP BY order_id
)
SELECT COUNT(*) AS nonempty_orders,
       SUM(i.item_gross + o.shipping_fee) AS total_gross,
       ROUND(AVG(i.item_gross + o.shipping_fee), 2) AS avg_gross
FROM course.orders AS o
JOIN item_totals AS i ON o.order_id = i.order_id;
