-- DE03-16 | Timed SQL interview set and explanation
-- review block 2. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category, COUNT(*) AS sale_rows,
       SUM(quantity * unit_price) AS gross_total
FROM course.sales GROUP BY category
HAVING COUNT(*) >= 2 AND SUM(quantity * unit_price) > 150
ORDER BY category;
