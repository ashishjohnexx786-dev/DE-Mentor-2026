-- DE02-14 | Debugging and validation workflow
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT
 CASE WHEN is_paid = TRUE THEN 'Paid'
      WHEN is_paid = FALSE THEN 'Unpaid'
      ELSE 'Unknown' END AS payment_group,
 COUNT(*) AS sale_rows,
 SUM(quantity * unit_price) AS gross_total
FROM course.retry_sales
GROUP BY
 CASE WHEN is_paid = TRUE THEN 'Paid'
      WHEN is_paid = FALSE THEN 'Unpaid'
      ELSE 'Unknown' END
ORDER BY payment_group;
