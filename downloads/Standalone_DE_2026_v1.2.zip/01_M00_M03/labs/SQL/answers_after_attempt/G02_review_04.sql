-- G02 review: open only after saving your independent attempt.
SELECT COUNT(*) AS joined_rows,
       COUNT(DISTINCT o.order_id) AS represented_orders,
       SUM(o.shipping_fee) AS repeated_fees
FROM course.g02_orders AS o
JOIN course.g02_items AS i ON o.order_id = i.order_id;

SELECT SUM(DISTINCT shipping_fee) AS wrong_distinct_fee_sum
FROM course.g02_orders;
