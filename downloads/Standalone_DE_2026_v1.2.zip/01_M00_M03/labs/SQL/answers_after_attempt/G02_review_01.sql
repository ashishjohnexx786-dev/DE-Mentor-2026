-- G02 review: open only after saving your independent attempt.
SELECT COUNT(*) AS orders, SUM(shipping_fee) AS fees
FROM course.g02_orders;
SELECT COUNT(*) AS lines,
       SUM(quantity * unit_price) AS item_gross
FROM course.g02_items;
