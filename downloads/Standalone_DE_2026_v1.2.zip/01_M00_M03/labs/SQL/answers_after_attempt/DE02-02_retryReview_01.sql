-- DE02-02 | SELECT, aliases and LIMIT
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id AS reference, item
FROM course.retry_sales
ORDER BY order_id DESC
LIMIT 2;
