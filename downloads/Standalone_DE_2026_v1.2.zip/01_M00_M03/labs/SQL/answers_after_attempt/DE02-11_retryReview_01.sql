-- DE02-11 | CASE for business categories
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id,
       CASE WHEN quantity * unit_price >= 75 THEN 'High'
            WHEN quantity * unit_price >= 30 THEN 'Mid'
            ELSE 'Low' END AS amount_group
FROM course.retry_sales ORDER BY order_id;
