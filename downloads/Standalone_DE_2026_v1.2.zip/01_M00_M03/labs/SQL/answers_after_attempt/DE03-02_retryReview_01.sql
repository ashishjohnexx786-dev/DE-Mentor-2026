-- DE03-02 | Cardinality, row multiplication and join validation
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT COUNT(*) AS result_rows,
       COUNT(i.line_no) AS matched_item_lines,
       COUNT(DISTINCT o.order_id) AS represented_orders
FROM course.orders AS o
LEFT JOIN course.order_items AS i ON o.order_id = i.order_id;
