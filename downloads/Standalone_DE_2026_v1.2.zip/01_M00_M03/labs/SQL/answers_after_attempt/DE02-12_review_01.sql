-- DE02-12 | String and date basics
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, LOWER(item) AS item_lower,
       ordered_on + 3 AS follow_up_date
FROM course.practice_sales ORDER BY order_id;

SELECT order_id FROM course.practice_sales
WHERE ordered_on >= DATE '2026-10-01'
  AND ordered_on < DATE '2026-10-02'
ORDER BY order_id;
