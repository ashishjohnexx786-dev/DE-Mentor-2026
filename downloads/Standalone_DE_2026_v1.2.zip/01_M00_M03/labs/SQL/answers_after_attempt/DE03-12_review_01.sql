-- DE03-12 | Constraints and transactions
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

BEGIN;
CREATE TEMP TABLE payment_contract (
 payment_id text PRIMARY KEY,
 amount numeric(10,2) NOT NULL CHECK (amount >= 0)
);
INSERT INTO payment_contract VALUES ('PAY1', 50);
COMMIT;
BEGIN;
UPDATE payment_contract SET amount = 60
WHERE payment_id = 'PAY1';
SELECT amount FROM payment_contract WHERE payment_id = 'PAY1';
ROLLBACK;
SELECT amount FROM payment_contract WHERE payment_id = 'PAY1';
