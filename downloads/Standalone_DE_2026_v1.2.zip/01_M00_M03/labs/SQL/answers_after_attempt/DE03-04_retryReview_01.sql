-- DE03-04 | String functions for cleaning and standardization
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT '  Bag ' AS raw_value,
       NULLIF(LOWER(TRIM('  Bag ')), '') AS clean_value,
       LENGTH(NULLIF(LOWER(TRIM('  Bag ')), '')) AS clean_length
UNION ALL
SELECT 'BAG', NULLIF(LOWER(TRIM('BAG')), ''),
       LENGTH(NULLIF(LOWER(TRIM('BAG')), ''))
UNION ALL
SELECT '   ', NULLIF(LOWER(TRIM('   ')), ''),
       LENGTH(NULLIF(LOWER(TRIM('   ')), ''));
