-- DE02-04 | AND, OR, NOT and parentheses
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT order_id, category, quantity
FROM course.retry_sales
WHERE NOT (category = 'Paper')
  AND quantity >= 2
ORDER BY order_id;
