-- DE03-14 | Views and reusable database logic
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

BEGIN;
UPDATE view_source SET units = 4 WHERE code = 'A';
SELECT * FROM view_demo;
ROLLBACK;
SELECT * FROM view_demo;
