-- DE03-03 | UNION and UNION ALL
-- retryReview block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT category FROM course.retry_sales
WHERE ordered_on = DATE '2026-11-01'
INTERSECT
SELECT category FROM course.retry_sales
WHERE ordered_on = DATE '2026-11-02';

SELECT category FROM course.retry_sales
WHERE ordered_on = DATE '2026-11-01'
EXCEPT
SELECT category FROM course.retry_sales
WHERE ordered_on = DATE '2026-11-02';
