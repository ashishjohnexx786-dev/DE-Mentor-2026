-- G02 review: open only after saving your independent attempt.
SELECT region_group, COUNT(*) AS orders,
       SUM(item_gross) AS items, SUM(shipping_fee) AS fees,
       SUM(order_gross) AS gross,
       ROUND(AVG(order_gross), 2) AS avg_order_gross
FROM g02_order_result
GROUP BY region_group ORDER BY region_group;

SELECT region_group, SUM(order_gross) AS gross
FROM g02_order_result GROUP BY region_group
HAVING SUM(order_gross) >= 100
ORDER BY region_group;
