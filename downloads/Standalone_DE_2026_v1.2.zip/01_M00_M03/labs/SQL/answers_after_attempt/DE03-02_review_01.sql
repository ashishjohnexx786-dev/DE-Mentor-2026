-- DE03-02 | Cardinality, row multiplication and join validation
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

SELECT SUM(i.quantity * i.unit_price) AS item_total,
       SUM(i.quantity * i.unit_price + o.shipping_fee)
         AS wrong_order_total
FROM course.orders AS o
JOIN course.order_items AS i ON o.order_id = i.order_id
WHERE o.order_id = 'O105';
