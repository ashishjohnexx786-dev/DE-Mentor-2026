-- DE03-15 | Integrated unseen SQL challenge
-- review block 1. Read the matching book section first.
-- Run this block deliberately, in the SAME Query Tool session as prior blocks
-- from this lesson when temporary tables or views are involved.
-- This file is not a complete lesson or a fresh-session standalone script.

WITH items AS (
 SELECT order_id, SUM(quantity * unit_price) AS item_gross
 FROM course.challenge_items GROUP BY order_id
)
SELECT o.order_id, o.customer_id, o.is_paid,
       COALESCE(i.item_gross, 0) AS item_gross,
       o.shipping_fee,
       COALESCE(i.item_gross, 0) + o.shipping_fee AS order_gross
FROM course.challenge_orders AS o
LEFT JOIN items AS i ON o.order_id = i.order_id
ORDER BY o.order_id;
