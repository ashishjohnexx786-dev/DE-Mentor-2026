-- Original fictional assessment inputs. No solutions in this file.
-- Run once in standalone_de after 00_load_course.sql.
BEGIN;
CREATE TABLE course.challenge_customers (
 customer_id text PRIMARY KEY, region text NOT NULL);
CREATE TABLE course.challenge_orders (
 order_id text PRIMARY KEY, customer_id text REFERENCES course.challenge_customers,
 ordered_on date NOT NULL, shipping_fee numeric(10,2) NOT NULL CHECK (shipping_fee>=0), is_paid boolean);
CREATE TABLE course.challenge_items (
 order_id text REFERENCES course.challenge_orders, line_no integer,
 quantity integer NOT NULL CHECK (quantity>0), unit_price numeric(10,2) NOT NULL CHECK (unit_price>=0),
 PRIMARY KEY(order_id,line_no));
INSERT INTO course.challenge_customers VALUES
('C10','East'),
('C11','West'),
('C12','South');
INSERT INTO course.challenge_orders VALUES
('Q301','C10','2026-10-01',10,TRUE),
('Q302','C11','2026-10-01',10,FALSE),
('Q303','C10','2026-10-02',0,NULL),
('Q304',NULL,'2026-10-03',5,TRUE);
INSERT INTO course.challenge_items VALUES
('Q301',1,1,50),
('Q301',2,2,10),
('Q302',1,1,30),
('Q303',1,2,40);
CREATE TABLE course.challenge_retry_customers (
 customer_id text PRIMARY KEY, region text NOT NULL);
CREATE TABLE course.challenge_retry_orders (
 order_id text PRIMARY KEY, customer_id text REFERENCES course.challenge_retry_customers,
 ordered_on date NOT NULL, shipping_fee numeric(10,2) NOT NULL CHECK (shipping_fee>=0), is_paid boolean);
CREATE TABLE course.challenge_retry_items (
 order_id text REFERENCES course.challenge_retry_orders, line_no integer,
 quantity integer NOT NULL CHECK (quantity>0), unit_price numeric(10,2) NOT NULL CHECK (unit_price>=0),
 PRIMARY KEY(order_id,line_no));
INSERT INTO course.challenge_retry_customers VALUES
('D10','East'),
('D11','West'),
('D12','North');
INSERT INTO course.challenge_retry_orders VALUES
('R401','D10','2026-11-01',6,TRUE),
('R402','D10','2026-11-02',6,FALSE),
('R403',NULL,'2026-11-03',0,NULL);
INSERT INTO course.challenge_retry_items VALUES
('R401',1,3,12),
('R401',2,1,4),
('R402',1,2,25);
CREATE TABLE course.g02_customers (
 customer_id text PRIMARY KEY, region text NOT NULL);
CREATE TABLE course.g02_orders (
 order_id text PRIMARY KEY, customer_id text REFERENCES course.g02_customers,
 ordered_on date NOT NULL, shipping_fee numeric(10,2) NOT NULL CHECK (shipping_fee>=0), is_paid boolean);
CREATE TABLE course.g02_items (
 order_id text REFERENCES course.g02_orders, line_no integer,
 quantity integer NOT NULL CHECK (quantity>0), unit_price numeric(10,2) NOT NULL CHECK (unit_price>=0),
 PRIMARY KEY(order_id,line_no));
INSERT INTO course.g02_customers VALUES
('K01','East'),
('K02','West'),
('K03','North'),
('K04','South');
INSERT INTO course.g02_orders VALUES
('G501','K01','2026-12-01',12,TRUE),
('G502','K02','2026-12-01',12,FALSE),
('G503','K01','2026-12-02',0,NULL),
('G504','K03','2026-12-03',8,TRUE),
('G505',NULL,'2026-12-03',0,FALSE);
INSERT INTO course.g02_items VALUES
('G501',1,2,30),
('G501',2,3,10),
('G502',1,1,80),
('G503',1,2,25),
('G504',1,1,100),
('G504',2,2,15);
CREATE TABLE course.g02_repair_customers (
 customer_id text PRIMARY KEY, region text NOT NULL);
CREATE TABLE course.g02_repair_orders (
 order_id text PRIMARY KEY, customer_id text REFERENCES course.g02_repair_customers,
 ordered_on date NOT NULL, shipping_fee numeric(10,2) NOT NULL CHECK (shipping_fee>=0), is_paid boolean);
CREATE TABLE course.g02_repair_items (
 order_id text REFERENCES course.g02_repair_orders, line_no integer,
 quantity integer NOT NULL CHECK (quantity>0), unit_price numeric(10,2) NOT NULL CHECK (unit_price>=0),
 PRIMARY KEY(order_id,line_no));
INSERT INTO course.g02_repair_customers VALUES
('J01','East'),
('J02','West'),
('J03','North');
INSERT INTO course.g02_repair_orders VALUES
('H601','J01','2027-01-01',7,TRUE),
('H602','J02','2027-01-02',7,NULL),
('H603',NULL,'2027-01-03',0,FALSE);
INSERT INTO course.g02_repair_items VALUES
('H601',1,1,25),
('H601',2,1,5),
('H602',1,2,20);
COMMIT;
-- Inspect Messages for successful completion.
