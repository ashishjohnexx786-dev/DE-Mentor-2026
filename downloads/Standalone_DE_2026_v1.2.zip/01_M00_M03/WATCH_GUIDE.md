# M00–M03 visuals

Use the module-specific WATCH_GUIDE.md files under ../00_STUDY_MODULES/M00 through M03. Their assignments match the rebuilt books.
