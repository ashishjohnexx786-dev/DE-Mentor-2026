# M06 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE06-01 — Verify WSL2 and choose a safe Linux workspace

- [MIT Missing Semester - Course overview and the shell (embedded lecture)](https://missing.csail.mit.edu/2020/course-shell/) — Optional visual - no verified bounded range. Use the shell navigation and permissions demonstrations. WSL installation itself follows the Windows setup instructions in this lesson.

## DE06-02 — Linux navigation and safe file operations

- [freeCodeCamp - Command Line Basics for Beginners (2026)](https://www.youtube.com/watch?v=mABpAI-pCw0) — 02:56-30:18: command line mental model, ls, navigation, touch/rm, mkdir/rmdir.

## DE06-03 — Pipes, redirection, command history and inspection

- [freeCodeCamp - Command Line Basics for Beginners (2026)](https://www.youtube.com/watch?v=mABpAI-pCw0) — 30:18-43:32: echo/cat and file inspection. Course adds pipes, stderr, grep, wc, head/tail and validation.

## DE06-04 — Permissions, packages, sudo and command safety

- [MIT Missing Semester - Course overview and the shell (embedded lecture)](https://missing.csail.mit.edu/2020/course-shell/) — Optional visual - no verified bounded range. Use the shell navigation and permissions demonstrations. WSL installation itself follows the Windows setup instructions in this lesson.

## DE06-05 — Git state: init, status, add, commit, diff and log

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded mental-model visual only. Git command practice is taught by the learner book/lab.

## DE06-06 — Branches, merges and real conflict resolution

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 40:58-52:13: branches, checkout, merge and merge-conflict resolution.

## DE06-07 — GitHub remotes: push, fetch, pull and tracking

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 55:50-1:00:24 - bounded push/fetch/pull visual. Local-vs-remote reasoning is taught by the learner book/lab.

## DE06-08 — Pull requests and review workflow

- [MIT Missing Semester - Version control (Git), embedded lecture](https://missing.csail.mit.edu/2020/version-control/) — Optional visual - no verified bounded range. Focus on repositories, commits, branches and remotes. Pause to inspect your own Git history; practise destructive-looking recovery examples only in the disposable course repository.

## DE06-09 — Python virtual environments inside a repository

- [Corey Schafer - Virtual environments for Mac and Linux](https://www.youtube.com/watch?v=Kg1Yvry_Ydk) — Optional visual - no verified bounded range. Use the Linux commands inside WSL. Activate the repository environment before installing or running Python dependencies.

## DE06-10 — .gitignore, secrets and repository hygiene

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — OPTIONAL visual - no verified bounded range. Use only for Git status/tracking/removal context; learner book owns .gitignore and secret-response policy.

## DE06-11 — restore, revert, reflog and safe history repair

- [MIT Missing Semester - Version control (Git), embedded lecture](https://missing.csail.mit.edu/2020/version-control/) — Optional visual - no verified bounded range. Focus on repositories, commits, branches and remotes. Pause to inspect your own Git history; practise destructive-looking recovery examples only in the disposable course repository.

## DE06-12 — Shell scripts, exit codes and environment-driven commands

- [freeCodeCamp - Bash Scripting Tutorial for Beginners](https://www.youtube.com/watch?v=tK9Oc6AEnR4) — OPTIONAL visual - no verified bounded range. Use only for Bash scripting context; learner book + shell lab are required.

## DE06-13 — Repository handoff and clean-clone reproducibility

- [MIT Missing Semester - Version control (Git), embedded lecture](https://missing.csail.mit.edu/2020/version-control/) — Optional visual - no verified bounded range. Focus on repositories, commits, branches and remotes. Pause to inspect your own Git history; practise destructive-looking recovery examples only in the disposable course repository.