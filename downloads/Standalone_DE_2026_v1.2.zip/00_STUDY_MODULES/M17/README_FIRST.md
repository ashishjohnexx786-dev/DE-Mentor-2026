# M17 — Architecture and engineering decisions

First read ../../00_START_HERE/HOW_TO_STUDY.pdf if this is your first session.

1. Open M17_Learner_Book.pdf and study DE17-01 -> DE17-10 in order.
2. Use the named input under the course-root folder **16_M17/practice**. Keep its folder structure and read the setup instructions before running commands.
3. Reproduce each worked example, then save the independent task before its explained review.
4. Use M17_Quick_Revision_Book.pdf, then M17_Module_Revision_Test.pdf.
5. After your saved test, open PROTECTED_OPEN_AFTER_ATTEMPT/M17_Module_Revision_Test_Answers.pdf.
6. Practice solutions: PROTECTED_OPEN_AFTER_ATTEMPT/M17_Explained_Reviews.pdf.

Planning allowance: 8–10 study days at six focused hours/day, including module review and test. Then take G06 through A -> Review A -> fresh B -> Review B.

WATCH_GUIDE.md lists the same instructor sources and scope as the learner book. Videos may support only part of a lesson; the printed example and task complete it.
