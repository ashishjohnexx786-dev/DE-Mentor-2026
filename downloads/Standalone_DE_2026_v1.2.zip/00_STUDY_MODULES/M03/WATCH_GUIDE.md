# M03 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE03-01 — INNER JOIN and LEFT JOIN

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=12570s) — 03:29:30-03:40:53

## DE03-02 — Cardinality, row multiplication and join validation

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=3070s) — 51:10-01:08:04

## DE03-03 — UNION and UNION ALL

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=4084s) — 01:08:04-01:15:10

## DE03-04 — String functions for cleaning and standardization

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=4510s) — 01:15:10-01:26:39

## DE03-05 — Dates, timestamps and time analysis

- [SQL for Data Analytics - Learn SQL in 4 Hours](https://www.youtube.com/watch?v=7mz73uXD9DA&t=7802s) — 02:10:02-02:20:26

## DE03-06 — Subqueries and nested logic

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=5716s) — 01:35:16-01:45:58

## DE03-07 — CTEs and readable multi-step SQL

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=7135s) — 01:58:55-02:09:07

## DE03-08 — Window functions and PARTITION BY

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=6358s) — 01:45:58-01:58:55

## DE03-09 — ROW_NUMBER, ranking and LAG/LEAD

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=6358s) — 01:45:58-01:58:55

## DE03-10 — Advanced aggregation and multi-grain reasoning

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=6190s) — 01:43:10-01:52:08

## DE03-11 — PostgreSQL setup, schemas and dialect awareness

- [SQL for Data Analytics - Learn SQL in 4 Hours](https://www.youtube.com/watch?v=7mz73uXD9DA&t=5178s) — 01:26:18-01:32:48

## DE03-12 — Constraints and transactions

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=8964s) — 02:29:24-02:36:26
- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=9655s) — 02:40:55-02:54:45
- [PostgreSQL Demonstration: Transactions](https://www.youtube.com/watch?v=f4eJGQ6bV0E) — 00:00-19:35

## DE03-13 — Indexes and EXPLAIN basics

- [Lesson 3, PostgreSQL Indexes and B-Trees (and an introduction to EXPLAIN)](https://www.youtube.com/watch?v=YZSHpDn7GP4&t=610s) — 10:10-18:00
- [Lesson 3, PostgreSQL Indexes and B-Trees (and an introduction to EXPLAIN)](https://www.youtube.com/watch?v=YZSHpDn7GP4&t=1778s) — 29:38-34:18

## DE03-14 — Views and reusable database logic

- [PostgreSQL Tutorial Full Course 2022](https://www.youtube.com/watch?v=85pG_pDkITY&t=5662s) — 01:34:22-01:45:01

## DE03-15 — Integrated unseen SQL challenge

- [Learn PostgreSQL - complete beginner course](https://www.youtube.com/watch?v=qw--VYLpxG4) — Optional visual - no verified bounded range. Use this as a SQL and database workflow refresher. COPY and backup/restore commands follow the current PostgreSQL instructions printed in the lesson. For a cold assessment, revisit after your first attempt.

## DE03-16 — Timed SQL interview set and explanation

- [Learn PostgreSQL - complete beginner course](https://www.youtube.com/watch?v=qw--VYLpxG4) — Optional visual - no verified bounded range. Use this as a SQL and database workflow refresher. COPY and backup/restore commands follow the current PostgreSQL instructions printed in the lesson. For a cold assessment, revisit after your first attempt.