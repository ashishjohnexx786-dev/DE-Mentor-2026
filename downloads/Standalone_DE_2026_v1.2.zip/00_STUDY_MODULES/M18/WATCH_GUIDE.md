# M18 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## P01-01 — Read the batch-pipeline brief and define business questions

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## P01-02 — Profile every source; state grain, keys and defects

- [Python for Data Analytics - profiling with pandas](https://www.youtube.com/watch?v=wUSDVGivd-8) — Optional visual - no verified bounded range. Focus on DataFrame inspection, nulls, duplicates and grouped counts. Then profile the project files, not the instructor dataset.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P01-03 — Draw architecture and create the repository scaffold

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs
- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## P01-04 — Preserve raw landing evidence and source/run metadata

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Use the ingestion demonstration for acquisition and validation context; implement the project-specific quarantine, identity and recovery rules below.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P01-05 — Build ingestion with validation and quarantine

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Use the ingestion demonstration for acquisition and validation context; implement the project-specific quarantine, identity and recovery rules below.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P01-06 — Add incremental state and rerun-safe identity

- [M09 retained visual - incremental processing](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range
- [Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Optional visual - no verified bounded range

## P01-07 — Build trusted PostgreSQL/dbt-style transformations

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P01-08 — Add tests and source-to-target reconciliation

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range
- [M09 retained visual - dbt tests/key integrity](https://www.youtube.com/watch?v=bvZ-rJm7uMU) — Optional visual - no verified bounded range

## P01-09 — Automate the repeatable run/orchestration path

- [Airflow 3 visual retained from M10](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range

## P01-10 — Inject failure, diagnose, repair and prove recovery

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Use the ingestion demonstration for acquisition and validation context; implement the project-specific quarantine, identity and recovery rules below.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P01-11 — Finish README, runbook, architecture and evidence index

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs
- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## P01-12 — Clean-clone rerun and project defense

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs
- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## P02-01 — Read the analytics-engineering brief and define outputs

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## P02-02 — Profile billing/customer sources and state grains

- [Python for Data Analytics - profiling with pandas](https://www.youtube.com/watch?v=wUSDVGivd-8) — Optional visual - no verified bounded range. Focus on DataFrame inspection, nulls, duplicates and grouped counts. Then profile the project files, not the instructor dataset.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P02-03 — Design facts, dimensions, keys and serving grain

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P02-04 — Create dbt project, sources and dependency graph

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P02-05 — Build thin staging models with explicit contracts

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P02-06 — Build dimensional marts without fan-out

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P02-07 — Add data tests and critical quality gates

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range
- [M09 retained visual - dbt tests/key integrity](https://www.youtube.com/watch?v=bvZ-rJm7uMU) — Optional visual - no verified bounded range

## P02-08 — Implement incremental model/update behavior

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range
- [M09 retained visual - incremental processing](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range
- [Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Optional visual - no verified bounded range

## P02-09 — Preserve history with snapshot/SCD reasoning

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P02-10 — Add orchestration and reproducible run order

- [Airflow 3 visual retained from M10](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range

## P02-11 — Inject duplicate/relationship/partial-run failures

- [M09 retained visual - dbt tests/key integrity](https://www.youtube.com/watch?v=bvZ-rJm7uMU) — Optional visual - no verified bounded range

## P02-12 — Document lineage, runbook, limitations and evidence

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## P02-13 — Clean-clone build and analytics-platform defense

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs
- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## P03-01 — Read the scalable-lakehouse brief and define scale risks

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range
- [Databricks - Medallion Architecture: Bronze, Silver, Gold](https://www.youtube.com/watch?v=cyDLRr24mBs) — Optional visual with publisher chapter markers; use matching Bronze/Silver/Gold chapter

## P03-02 — Profile event schema, grain, keys and timestamps

- [Spark transformations and data processing](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range. Focus on explicit schemas, joins and transformations, then apply the supplied event contract. Course failure fixtures determine correctness.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P03-03 — Create Spark environment and explicit schemas

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range

## P03-04 — Build deterministic distributed transformations

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range

## P03-05 — Join reference data and validate cardinality

- [Spark transformations and data processing](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range. Focus on explicit schemas, joins and transformations, then apply the supplied event contract. Course failure fixtures determine correctness.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P03-06 — Reason about partitions, shuffle and skew

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range

## P03-07 — Write Parquet with justified partition strategy

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range

## P03-08 — Apply Delta-style incremental merge/idempotency

- [M09 retained visual - incremental processing](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range
- [Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Optional visual - no verified bounded range
- [Databricks - Medallion Architecture: Bronze, Silver, Gold](https://www.youtube.com/watch?v=cyDLRr24mBs) — Optional visual with publisher chapter markers; use matching Bronze/Silver/Gold chapter

## P03-09 — Define Bronze/Silver/Gold lakehouse contracts

- [Databricks - Medallion Architecture: Bronze, Silver, Gold](https://www.youtube.com/watch?v=cyDLRr24mBs) — Optional visual with publisher chapter markers; use matching Bronze/Silver/Gold chapter
- [Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Optional visual - no verified bounded range

## P03-10 — Handle schema evolution and supplied failure cases

- [Spark transformations and data processing](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range. Focus on explicit schemas, joins and transformations, then apply the supplied event contract. Course failure fixtures determine correctness.
- [freeCodeCamp - Git & GitHub Crash Course for Beginners [2026]](https://www.youtube.com/watch?v=mAFoROnOfHs) — 01:04-05:41 - bounded Git mental-model visual; project commands are in the course labs

## P03-11 — Inspect plans/performance and prove equivalent results

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range

## P03-12 — Map the design to Fabric/cloud deployment

- [Aleksi Partanen - Learn Microsoft Fabric Data Pipelines in 2026](https://www.youtube.com/watch?v=1PGE9bWqY2g) — 04:49-27:35 - pipeline overview and Copy Data activity

## P03-13 — Clean rerun, reconcile outputs and defend trade-offs

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## CAP-01 — Read capstone requirements and write source contracts

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## CAP-02 — Design architecture and record major ADRs

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## CAP-03 — Build multi-source ingestion and raw evidence

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## CAP-04 — Implement critical quality, quarantine and reconciliation

- [M09 retained visual - dbt tests/key integrity](https://www.youtube.com/watch?v=bvZ-rJm7uMU) — Optional visual - no verified bounded range

## CAP-05 — Build trusted warehouse/dbt serving layer

- [M09 retained visual - dbt model/project structure](https://www.youtube.com/watch?v=2dYDS4OQbT0) — Optional visual - no verified bounded range

## CAP-06 — Orchestrate dependencies, retries and bounded backfills

- [Airflow 3 visual retained from M10](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range

## CAP-07 — Use Spark/Delta where scale justifies it

- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Optional visual - no verified bounded range
- [DataTalksClub - Apache Spark / PySpark](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Optional visual - no verified bounded range
- [Databricks - Medallion Architecture: Bronze, Silver, Gold](https://www.youtube.com/watch?v=cyDLRr24mBs) — Optional visual with publisher chapter markers; use matching Bronze/Silver/Gold chapter

## CAP-08 — Design Fabric deployment, access and secret boundaries

- [Aleksi Partanen - Learn Microsoft Fabric Data Pipelines in 2026](https://www.youtube.com/watch?v=1PGE9bWqY2g) — 04:49-27:35 - pipeline overview and Copy Data activity

## CAP-09 — Add CI/CD, monitoring, alerts and runbook

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.
- [Monte Carlo - Data Observability](https://www.youtube.com/watch?v=Lt8_s8ywEAA) — Optional visual - no verified bounded range

## CAP-10 — Open incident pack, diagnose and recover safely

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## CAP-11 — Reproduce from clean state and freeze evidence bundle

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## CAP-12 — Final technical defense and Gate 7 readiness

- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations