# M04 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE04-01 — Python setup and first program

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 00:08:42-00:18:52

## DE04-02 — Variables, data types and operators

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 00:18:52-00:48:41

## DE04-03 — Strings and formatting

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 00:48:41-01:15:10

## DE04-04 — Conditions and boolean logic

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 01:26:20-01:34:24

## DE04-05 — Lists, tuples, sets and dictionaries

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 01:34:24-02:12:26

## DE04-06 — Loops and iteration

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 02:21:06-02:44:16

## DE04-07 — Functions and scope

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 02:52:12-03:12:46

## DE04-08 — Modules, imports and project structure

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 03:12:46-03:40:05

## DE04-09 — Exceptions and debugging basics

- [Corey Schafer - Try/Except Blocks](https://www.youtube.com/watch?v=NIWwJbo-9_8) — OPTIONAL visual - no verified bounded range. Use only for try/except demonstration; learner book + practice are required.

## DE04-10 — Files, paths, CSV and JSON I/O

- [Corey Schafer - File Objects](https://www.youtube.com/watch?v=Uh2ebFW8OYM) — OPTIONAL visual - no verified bounded range. Use only for file-object context; learner book + pathlib/CSV/JSON practice are required.

## DE04-11 — pandas foundations: load, inspect, filter and aggregate

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 04:22:56-05:08:26

## DE04-12 — Practical Big-O intuition

- [freeCodeCamp - Data Structures and Algorithms in Python](https://www.youtube.com/watch?v=pkYVOmU3MgA) — 00:50:52-01:24:57 - Complexity and Big O notation

## DE04-13 — Coding drills: lists and strings

- [Data structures and algorithms in Python - beginner course](https://www.youtube.com/watch?v=pkYVOmU3MgA) — Optional visual - no verified bounded range. Use the lists, strings and dictionary demonstrations as preparation. Save your independent checkpoint attempt before returning to worked solutions.

## DE04-14 — Coding drills: dictionaries and sets

- [Data structures and algorithms in Python - beginner course](https://www.youtube.com/watch?v=pkYVOmU3MgA) — Optional visual - no verified bounded range. Use the lists, strings and dictionary demonstrations as preparation. Save your independent checkpoint attempt before returning to worked solutions.

## DE04-15 — Stack, queue, search and sort basics

- [freeCodeCamp - Data Structures and Algorithms in Python](https://www.youtube.com/watch?v=pkYVOmU3MgA) — REQUIRED 01:24:57-01:31:40 - Binary vs Linear Search; OPTIONAL 05:16:47-06:48:53 - Sorting Algorithms and Divide & Conquer

## DE04-16 — Integrated Python checkpoint and reproducible script habits

- [Data structures and algorithms in Python - beginner course](https://www.youtube.com/watch?v=pkYVOmU3MgA) — Optional visual - no verified bounded range. Use the lists, strings and dictionary demonstrations as preparation. Save your independent checkpoint attempt before returning to worked solutions.