# M04 — Python foundations

First read ../../00_START_HERE/HOW_TO_STUDY.pdf if this is your first session.

1. Open M04_Learner_Book.pdf and study DE04-01 -> DE04-16 in order.
2. Use the named input under the course-root folder **02_M04/practice**. Keep its folder structure and read the setup instructions before running commands.
3. Reproduce each worked example, then save the independent task before its explained review.
4. Use M04_Quick_Revision_Book.pdf, then M04_Module_Revision_Test.pdf.
5. After your saved test, open PROTECTED_OPEN_AFTER_ATTEMPT/M04_Module_Revision_Test_Answers.pdf.
6. Practice solutions: PROTECTED_OPEN_AFTER_ATTEMPT/M04_Explained_Reviews.pdf.

Planning allowance: 14–18 study days at six focused hours/day, including module review and test. Continue to the next module after its success criteria are met.

WATCH_GUIDE.md lists the same instructor sources and scope as the learner book. Videos may support only part of a lesson; the printed example and task complete it.
