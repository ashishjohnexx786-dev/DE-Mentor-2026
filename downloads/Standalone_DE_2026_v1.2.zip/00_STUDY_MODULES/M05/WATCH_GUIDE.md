# M05 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE05-01 — CSV properly: parse, inspect, preserve raw

- [Corey Schafer - Python Tutorial: CSV Module - How to Read, Parse, and Write CSV Files](https://www.youtube.com/watch?v=q5uM4VKywbA) — OPTIONAL visual - no verified bounded range. Use only for CSV/DictReader context; learner book + lab are required.

## DE05-02 — JSON and JSONL from zero

- [Corey Schafer - Python Tutorial: Working with JSON Data using the json Module](https://www.youtube.com/watch?v=9N6a-VLBa2I) — OPTIONAL visual - no verified bounded range. Use only for JSON load/dump context; learner book + lab are required.

## DE05-03 — Paths, folders and deterministic batch files

- [Corey Schafer - Python Tutorial: Pathlib - The Modern Way to Handle File Paths](https://www.youtube.com/watch?v=yxa-DJuuTBI) — OPTIONAL visual - no verified bounded range. Use only for Pathlib context; learner book + lab are required.

## DE05-04 — pandas profiling before transformation

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 4:22:56-5:08:26 - pandas intro, inspection, cleaning and analysis. Stop before copying an answer.

## DE05-05 — Cleaning with pandas and rejected rows

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 4:22:56-5:08:26 - pandas mechanics refresher; course rejected-row design is deeper than the video.

## DE05-06 — pandas merge, cardinality and aggregation

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — OPTIONAL visual - no verified bounded range. Use only for pandas merge context; learner book owns cardinality/reconciliation.

## DE05-07 — Data validation: record, batch and relationship rules

- [Corey Schafer - Python Pydantic Tutorial: Complete Data Validation Course](https://www.youtube.com/watch?v=M81pfi64eeM) — OPTIONAL visual - no verified bounded range. Use only for Pydantic validation context; learner book + validation lab are required.

## DE05-08 — HTTP and REST APIs from zero

- [Corey Schafer - Python Requests tutorial](https://www.youtube.com/watch?v=tb8gHvYlCFs) — Optional visual - no verified bounded range. Focus on HTTP requests, response status, JSON and authentication. Practise retries and pagination with the supplied local service; this recording does not replace those controls.
- [DataTalksClub - Docker for Data Engineering: Postgres, Docker Compose, and Real-World Workflows](https://www.youtube.com/watch?v=lP8xXebHmuE) — Supplementary Docker/PostgreSQL workflow context. For HTTP requests, start with the Requests video above. Optional visual - no verified bounded range.

## DE05-09 — Calling APIs safely with requests

- [Corey Schafer - Python Requests tutorial](https://www.youtube.com/watch?v=tb8gHvYlCFs) — Optional visual - no verified bounded range. Focus on HTTP requests, response status, JSON and authentication. Practise retries and pagination with the supplied local service; this recording does not replace those controls.

## DE05-10 — Pagination and authentication without leaking secrets

- [Using Python to consume an API with pagination - Renato Coelho](https://www.youtube.com/watch?v=Vx6pmmRqCxI) — 04:50-13:40 - Coding API pagination; stop at Final explanation chapter boundary. Use course local API for auth/completeness evidence.

## DE05-11 — Retries, rate limits and partial failure

- [Corey Schafer - Python Requests tutorial](https://www.youtube.com/watch?v=tb8gHvYlCFs) — Optional visual - no verified bounded range. Focus on HTTP requests, response status, JSON and authentication. Practise retries and pagination with the supplied local service; this recording does not replace those controls.

## DE05-12 — Python + PostgreSQL with SQLAlchemy

- [Mike Bayer - SQLAlchemy 2.0 getting started (embedded instructor video)](https://www.sqlalchemy.org/library.html) — Optional visual - no verified bounded range. Play the first tutorial, SQLAlchemy 2.0 - The One-Point-Four-Ening. Focus on engine, connection, SELECT and transaction boundaries. The course examples use explicit transactions.

## DE05-13 — Configuration, environment variables and secret hygiene

- [Luke Barousse - Python for Data Analytics](https://www.youtube.com/watch?v=wUSDVGivd-8) — 5:50:56-6:27:15 - environment/project setup context; secrets policy comes from this course.

## DE05-14 — Logging, testing and reusable pipeline code

- [PyCon US 2025 - Building Resilient Data Pipelines: The Power of Idempotency](https://www.youtube.com/watch?v=kT8YWX4NE2o) — OPTIONAL visual - no verified bounded range. Use only for idempotency/testing context; learner book + tests are required.

## DE05-15 — Integrated Python data-engineering pipeline

- [DataTalksClub - Docker for Data Engineering: Postgres, Docker Compose, and Real-World Workflows](https://www.youtube.com/watch?v=lP8xXebHmuE) — OPTIONAL visual - no verified bounded range. Use only for end-to-end workflow context; integrated course checkpoint is required.