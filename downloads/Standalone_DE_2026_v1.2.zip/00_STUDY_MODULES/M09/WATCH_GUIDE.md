# M09 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE09-01 — ETL vs ELT and transformation boundaries

- [ETL vs ELT and transformation boundaries - retained visual](https://www.youtube.com/watch?v=HxMIsPrIyGQ) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-02 — Raw, staging, clean/intermediate and serving contracts

- [Raw, staging, clean/intermediate and serving contracts - retained visual](https://www.youtube.com/watch?v=2dYDS4OQbT0) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-03 — Deterministic transformations and production SQL style

- [Deterministic transformations and production SQL style - retained visual](https://www.youtube.com/watch?v=JQYz-8sl1aQ) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-04 — Deduplication and key integrity

- [Deduplication and key integrity - retained visual](https://www.youtube.com/watch?v=bvZ-rJm7uMU) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-05 — Schema checks and data contracts

- [Schema checks and data contracts - retained visual](https://www.youtube.com/watch?v=ZIJB8cs-cJU) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-06 — Source-to-target reconciliation

- [Source-to-target reconciliation - retained visual](https://www.youtube.com/watch?v=7CrrXazV_8k) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-07 — Incremental processing and safe reruns

- [Incremental processing and safe reruns - retained visual](https://www.youtube.com/watch?v=5eMytPBgmVs) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-08 — Failure behavior, retries, quarantine and atomic state

- [Failure behavior, retries, quarantine and atomic state - retained visual](https://www.youtube.com/watch?v=t4OeWHW3SsA) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-09 — Lineage, run metadata and auditability

- [Lineage, run metadata and auditability - retained visual](https://www.youtube.com/watch?v=UqoWyMjcqrA) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-10 — Build and defend a reliable batch pipeline

- [Build and defend a reliable batch pipeline - retained visual](https://www.youtube.com/watch?v=2dYDS4OQbT0) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-11 — dbt-style project anatomy, sources and dependency graph

- [dbt-style project anatomy, sources and dependency graph - retained visual](https://www.youtube.com/watch?v=2dYDS4OQbT0) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-12 — Executable data tests, quality severity and CI boundaries

- [Executable data tests, quality severity and CI boundaries - retained visual](https://www.youtube.com/watch?v=bvZ-rJm7uMU) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.

## DE09-13 — Incremental models, materialization, documentation and handoff

- [Incremental models, materialization, documentation and handoff - retained visual](https://www.youtube.com/watch?v=JQYz-8sl1aQ) — OPTIONAL visual support - no independently verified bounded range. Learner book + official reference + supplied project/lab are the required route.