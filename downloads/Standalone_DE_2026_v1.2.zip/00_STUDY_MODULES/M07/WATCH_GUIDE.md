# M07 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE07-01 — Verify PostgreSQL connection and database/schema context

- [freeCodeCamp - Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4) — 30:15-41:37 - create/connect databases and destructive-command caution

## DE07-02 — Tables, data types and explicit DDL

- [freeCodeCamp - Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4) — 41:37-55:55 - CREATE TABLE, columns and constraints

## DE07-03 — Primary keys, foreign keys and constraints

- [freeCodeCamp - Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4) — 2:29:24-2:49:15 + 3:16:41-3:25:04 - keys, UNIQUE/CHECK and foreign keys

## DE07-04 — Transactions, DML and UPSERT

- [freeCodeCamp - Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4) — 2:54:45-3:16:41 - DML, ON CONFLICT and UPSERT

## DE07-05 — Indexes and EXPLAIN evidence

- [Learn PostgreSQL - database foundations](https://www.youtube.com/watch?v=qw--VYLpxG4) — Optional visual - no verified bounded range. Review the table/key/query context before the EXPLAIN lab. Keep the dedicated query-optimization conference visual for the execution-plan explanation.
- [Postgres Conference - Query Optimizations and Where to Find Them: A Beginners Guide](https://postgresconf.org/conferences/SEA2024/program/proposals/query-optimizations-and-where-to-find-them-a-beginners-guide) — OPTIONAL visual - no verified bounded range. Use only for EXPLAIN/index context; PostgreSQL 18 docs + learner lab are required.

## DE07-06 — Operational vs analytical modeling and normalization

- [Decomplexify - Learn Database Normalization (1NF, 2NF, 3NF...)](https://www.youtube.com/watch?v=GFQaEYEc8_8) — 0:00-20:29 - why normalize, 1NF, 2NF and 3NF

## DE07-07 — Facts, dimensions and star-schema grain

- [TechLake - DWH Tutorial 6: Star Schema in Dimensional Modeling](https://www.youtube.com/watch?v=vdRMTa6t1dM) — OPTIONAL visual support - no independently verified bounded range. Use only to visualize star schema, facts and dimensions; the learner book + PostgreSQL lab are the required route.

## DE07-08 — Surrogate keys and referential integrity

- [freeCodeCamp - Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4) — 2:29:24-2:49:15 + 3:16:41-3:25:04 + 3:50:42-3:57:18 for Serial & Sequences

## DE07-09 — Slowly Changing Dimension Type 2 history

- [TechLake - DWH Tutorial 16: Slowly Changing Dimensions and Types](https://www.youtube.com/watch?v=-XjPvozl-So) — OPTIONAL visual support - no independently verified bounded range. Use only for SCD type concepts; the learner book owns the PostgreSQL SCD2 implementation.

## DE07-10 — Build and validate a small analytical database

- [Learn PostgreSQL - complete beginner course](https://www.youtube.com/watch?v=qw--VYLpxG4) — Optional visual - no verified bounded range. Use this as a SQL and database workflow refresher. COPY and backup/restore commands follow the current PostgreSQL instructions printed in the lesson. For a cold assessment, revisit after your first attempt.

## DE07-11 — Bulk loading with COPY / staging boundaries

No matching instructor video is assigned. Use the lesson explanation, diagram and worked example.

## DE07-12 — Schemas, roles and least-privilege boundaries

- [databasetorque - PostgreSQL roles, schema and security](https://www.youtube.com/watch?v=8YSp-wTELNs) — OPTIONAL visual - no verified bounded range. Use only for role/schema/security context; PostgreSQL 18 privilege docs + learner lab are required.

## DE07-13 — Schema change, backup/restore and handoff validation

No matching instructor video is assigned. Use the lesson explanation, diagram and worked example.