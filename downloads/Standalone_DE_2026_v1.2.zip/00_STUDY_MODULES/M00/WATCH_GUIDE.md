# M00 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE00-01 — Files, folders, drives and paths

- [Windows 11 File Explorer for Beginners](https://www.youtube.com/watch?v=LsHe9ivHSzo&t=386s) — 06:26-10:40
- [Windows 11 File Explorer for Beginners](https://www.youtube.com/watch?v=LsHe9ivHSzo&t=1662s) — 27:42-29:10

## DE00-02 — File extensions and common data files

- [Windows 11 File Explorer for Beginners](https://www.youtube.com/watch?v=LsHe9ivHSzo&t=640s) — 10:40-12:57

## DE00-03 — Download, ZIP, extract, copy, move and rename

- [Windows 11 File Explorer for Beginners](https://www.youtube.com/watch?v=LsHe9ivHSzo&t=1021s) — 17:01-24:25

## DE00-04 — Install only the software this stage needs

- [Python for Beginners Tutorial - VS Code installation segment](https://www.youtube.com/watch?v=b093aqAZiPU&t=719s) — 11:59-14:20

## DE00-05 — VS Code from zero

- [Learn Visual Studio Code in 15 minutes: 2026 Official Beginner Tutorial](https://www.youtube.com/watch?v=f8_uF_IDV50&t=28s) — 00:28-07:58

## DE00-06 — Terminal fundamentals

- [Microsoft PowerShell for Beginners - Video 1 Learn PowerShell](https://www.youtube.com/watch?v=IHrGresKu2w&t=160s) — 02:40-03:40
- [Microsoft PowerShell for Beginners - Video 1 Learn PowerShell](https://www.youtube.com/watch?v=IHrGresKu2w&t=390s) — 06:30-08:10

## DE00-07 — Read errors and repair one cause at a time

- [Microsoft PowerShell for Beginners - Video 1 Learn PowerShell](https://www.youtube.com/watch?v=IHrGresKu2w&t=625s) — 10:25-12:55

## DE00-08 — Study, evidence, attempts and review discipline

- [Windows 11 File Explorer for Beginners](https://www.youtube.com/watch?v=LsHe9ivHSzo&t=1134s) — 18:54-24:25