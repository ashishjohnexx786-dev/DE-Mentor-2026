# M00 — Computer and study foundations

First read ../../00_START_HERE/HOW_TO_STUDY.pdf if this is your first session.

1. Open M00_Learner_Book.pdf and study DE00-01 -> DE00-08 in order.
2. Use the named input under the course-root folder **01_M00_M03/labs**. Keep its folder structure and read the setup instructions before running commands.
3. Reproduce each worked example, then save the independent task before its explained review.
4. Use M00_Quick_Revision_Book.pdf, then M00_Module_Revision_Test.pdf.
5. After your saved test, open PROTECTED_OPEN_AFTER_ATTEMPT/M00_Module_Revision_Test_Answers.pdf.
6. Practice solutions: PROTECTED_OPEN_AFTER_ATTEMPT/M00_Explained_Reviews.pdf.

Planning allowance: 4–6 study days at six focused hours/day, including module review and test. Continue to the next module after its success criteria are met.

WATCH_GUIDE.md lists the same instructor sources and scope as the learner book. Videos may support only part of a lesson; the printed example and task complete it.
