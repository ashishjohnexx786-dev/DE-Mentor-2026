# Source scope

Use WATCH_GUIDE.md for the current assigned sources. Links may be main demonstrations, supporting explanations or earlier-topic refreshers. See ../../00_START_HERE/VERIFICATION.md for metadata lookup and playback limitations.
