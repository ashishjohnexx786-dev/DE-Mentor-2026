# M13 — Delta Lake and reliable tables

First read ../../00_START_HERE/HOW_TO_STUDY.pdf if this is your first session.

1. Open M13_Learner_Book.pdf and study DE13-01 -> DE13-11 in order.
2. Use the named input under the course-root folder **12_M13/practice**. Keep its folder structure and read the setup instructions before running commands.
3. Reproduce each worked example, then save the independent task before its explained review.
4. Use M13_Quick_Revision_Book.pdf, then M13_Module_Revision_Test.pdf.
5. After your saved test, open PROTECTED_OPEN_AFTER_ATTEMPT/M13_Module_Revision_Test_Answers.pdf.
6. Practice solutions: PROTECTED_OPEN_AFTER_ATTEMPT/M13_Explained_Reviews.pdf.

Planning allowance: 8–11 study days at six focused hours/day, including module review and test. Continue to the next module after its success criteria are met.

WATCH_GUIDE.md lists the same instructor sources and scope as the learner book. Videos may support only part of a lesson; the printed example and task complete it.
