# Standalone DE 2026 - final learner module route

Use these folders as your normal study route. Older numbered asset folders remain only so paths printed inside earlier books continue to work.

For every ordinary module: Learner Book -> Practice -> Quick Revision -> closed-book Module Test -> Protected Answers -> changed retry. Formal Gates remain separate stage assessments. M18 is project/capstone work rather than ordinary lessons.

## M00 - Computer, Setup & Learning Foundations
- Units: 8 lessons
- Learner folder: `00_STUDY_MODULES/M00`
- Practice: `01_M00_M03/labs/M00`
- Gate after module: `none`

## M01 - Data Foundations + Essential Excel
- Units: 15 lessons
- Learner folder: `00_STUDY_MODULES/M01`
- Practice: `01_M00_M03/labs/M01`
- Gate after module: `G01`

## M02 - SQL Foundations
- Units: 14 lessons
- Learner folder: `00_STUDY_MODULES/M02`
- Practice: `01_M00_M03/labs/SQL`
- Gate after module: `none`

## M03 - Advanced SQL + PostgreSQL / Database Thinking
- Units: 16 lessons
- Learner folder: `00_STUDY_MODULES/M03`
- Practice: `01_M00_M03/labs/SQL`
- Gate after module: `G02`

## M04 - Python Foundations
- Units: 16 lessons
- Learner folder: `00_STUDY_MODULES/M04`
- Practice: `02_M04/practice`
- Gate after module: `none`

## M05 - Python for Data Engineering
- Units: 15 lessons
- Learner folder: `00_STUDY_MODULES/M05`
- Practice: `03_M05/practice`
- Gate after module: `none`

## M06 - Git + GitHub + Linux/WSL Engineering Foundations
- Units: 13 lessons
- Learner folder: `00_STUDY_MODULES/M06`
- Practice: `04_M06/practice`
- Gate after module: `G03`

## M07 - PostgreSQL + Data Modeling
- Units: 13 lessons
- Learner folder: `00_STUDY_MODULES/M07`
- Practice: `05_M07/practice`
- Gate after module: `none`

## M08 - Files, APIs & Data Ingestion
- Units: 17 lessons
- Learner folder: `00_STUDY_MODULES/M08`
- Practice: `06_M08/practice`
- Gate after module: `none`

## M09 - ETL/ELT + Data Quality + Transformation Engineering
- Units: 13 lessons
- Learner folder: `00_STUDY_MODULES/M09`
- Practice: `07_M09/practice`
- Gate after module: `none`

## M10 - Docker + Airflow
- Units: 19 lessons
- Learner folder: `00_STUDY_MODULES/M10`
- Practice: `08_M10/practice`
- Gate after module: `G04`

## M11 - Storage & File Formats Foundations
- Units: 10 lessons
- Learner folder: `00_STUDY_MODULES/M11`
- Practice: `10_M11/practice`
- Gate after module: `none`

## M12 - Distributed Processing with Spark / PySpark
- Units: 18 lessons
- Learner folder: `00_STUDY_MODULES/M12`
- Practice: `11_M12/practice`
- Gate after module: `none`

## M13 - Delta Lake + Lakehouse
- Units: 11 lessons
- Learner folder: `00_STUDY_MODULES/M13`
- Practice: `12_M13/practice`
- Gate after module: `none`

## M14 - Kafka + Streaming Foundations
- Units: 12 lessons
- Learner folder: `00_STUDY_MODULES/M14`
- Practice: `13_M14/practice`
- Gate after module: `G05`

## M15 - Azure + Microsoft Fabric Data Engineering
- Units: 16 lessons
- Learner folder: `00_STUDY_MODULES/M15`
- Practice: `14_M15/practice`
- Gate after module: `none`

## M16 - DataOps, CI/CD, Security & Observability
- Units: 14 lessons
- Learner folder: `00_STUDY_MODULES/M16`
- Practice: `15_M16/practice`
- Gate after module: `none`

## M17 - Architecture + Promotion Foundations
- Units: 10 lessons
- Learner folder: `00_STUDY_MODULES/M17`
- Practice: `16_M17/practice`
- Gate after module: `G06`

## M18 - Portfolio Projects + Production Capstone
- Units: 50 phases
- Learner folder: `00_STUDY_MODULES/M18`
- Practice: `17_M18/practice`
- Gate after module: `none`

## M19 - Interview, Technical English & Job Launch
- Units: 14 lessons
- Learner folder: `00_STUDY_MODULES/M19`
- Practice: `18_M19/practice`
- Gate after module: `G07`

## Course-content status
**M00-M19 complete: 264 formal lessons + 50 M18 project/capstone phases = 314/314 controlled units.**

All seven Gate families G01-G07 are built. Mentor work remains separate from this course-content release.
