# M08 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE08-01 — Ingestion architecture: source -> landing -> staging

- [DataTalksClub DE Zoomcamp 2026 - From APIs to Warehouses with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — OPTIONAL visual support - no independently verified bounded range. Use only for architecture/ingestion context; learner book + official architecture reference + lab are required.

## DE08-02 — Defensive CSV ingestion

- [DataTalksClub DE Zoomcamp 2026 - From APIs to Warehouses with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — OPTIONAL visual support - no independently verified bounded range. Use only for file/CSV ingestion context; Python csv docs + learner book + lab are required.

## DE08-03 — JSON and nested-record ingestion

- [DataTalksClub DE Zoomcamp 2026 - From APIs to Warehouses with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — OPTIONAL visual support - no independently verified bounded range. Use only for nested-record normalization context; learner book + JSON lab are required.

## DE08-04 — Parquet ingestion and metadata inspection

- [DataTalksClub DE Zoomcamp 2026 - From APIs to Warehouses with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — OPTIONAL visual support - no independently verified bounded range. Use only for high-level file/Parquet context; Arrow docs + learner book + lab are required.

## DE08-05 — REST API contracts, status codes and timeouts

- [Corey Schafer - Python Requests tutorial](https://www.youtube.com/watch?v=tb8gHvYlCFs) — Optional visual - no verified bounded range. Focus on HTTP requests, response status, JSON and authentication. Practise retries and pagination with the supplied local service; this recording does not replace those controls.

## DE08-06 — API authentication, pagination and rate limits

- [Corey Schafer - Python Requests tutorial](https://www.youtube.com/watch?v=tb8gHvYlCFs) — Optional visual - no verified bounded range. Focus on HTTP requests, response status, JSON and authentication. Practise retries and pagination with the supplied local service; this recording does not replace those controls.

## DE08-07 — Retries, backoff, jitter and transient failures

- [Corey Schafer - Python Requests tutorial](https://www.youtube.com/watch?v=tb8gHvYlCFs) — Optional visual - no verified bounded range. Focus on HTTP requests, response status, JSON and authentication. Practise retries and pagination with the supplied local service; this recording does not replace those controls.

## DE08-08 — Database extraction and safe query boundaries

- [Mike Bayer - SQLAlchemy 2.0 getting started (embedded instructor video)](https://www.sqlalchemy.org/library.html) — Optional visual - no verified bounded range. Play the first tutorial, SQLAlchemy 2.0 - The One-Point-Four-Ening. Focus on engine, connection, SELECT and transaction boundaries. The course examples use explicit transactions.

## DE08-09 — Historical batch landing and raw metadata

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Focus on source acquisition, incremental loading and replay. The supplied exercises define their own raw identity and progress contracts.

## DE08-10 — Incremental loads and high-water marks

- [DataTalksClub - Docker/PostgreSQL data-engineering workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — OPTIONAL visual support - no independently verified bounded range. Use only for ingestion/database context; composite-watermark lab + database references are required.

## DE08-11 — CDC concepts and change-event semantics

- [Binod Suman Academy - Change Data Capture (CDC) | Why & How | Use case | System Design](https://www.youtube.com/watch?v=dN_11nBcv_A) — OPTIONAL visual support - no independently verified bounded range. Use only for CDC event/demo context; Debezium reference + learner book + CDC lab are required.

## DE08-12 — Schema drift, compatibility, time zones and quarantine

- [DataTalksClub DE Zoomcamp 2026 - From APIs to Warehouses with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — OPTIONAL visual support - no independently verified bounded range. Use only for schema-change context; learner book + datetime/schema-drift lab are required.

## DE08-13 — Checkpoint/state management and replay safety

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Focus on source acquisition, incremental loading and replay. The supplied exercises define their own raw identity and progress contracts.

## DE08-14 — Idempotent landing and content identity

- [PyCon US 2025 - Building Resilient Data Pipelines: The Power of Idempotency](https://www.youtube.com/watch?v=kT8YWX4NE2o) — OPTIONAL visual support - no independently verified bounded range. Use only for idempotency context; learner book + content-identity/replay lab are required.

## DE08-15 — Late-arriving data, event time and processing time

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Focus on source acquisition, incremental loading and replay. The supplied exercises define their own raw identity and progress contracts.

## DE08-16 — Ingestion observability: counts, latency and run metadata

- [MIT Missing Semester - Debugging and profiling, embedded lecture](https://missing.csail.mit.edu/2020/debugging-profiling/) — Optional visual - no verified bounded range. Focus on logging, timing and finding a failing operation. Relate these demonstrations to source counts, rejected rows and run metadata.

## DE08-17 — Ingestion integration, reconciliation and backfill proof

- [Data Engineering Zoomcamp - ingestion with dlt](https://www.youtube.com/watch?v=5eMytPBgmVs) — Optional visual - no verified bounded range. Focus on source acquisition, incremental loading and replay. The supplied exercises define their own raw identity and progress contracts.