# M16 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE16-01 — Production mindset

- [HashiCorp - Introduction to Terraform](https://www.youtube.com/watch?v=ZFLWA1kQ3ls) — 0:30-3:26 IaC/Terraform; 3:26-10:13 Day 0/1/2; 21:19-22:23 providers
- [Monte Carlo - Data Observability](https://www.youtube.com/watch?v=Lt8_s8ywEAA) — Optional visual - no verified bounded range

## DE16-02 — Testing strategy for data engineering

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [Great Expectations tutorial](https://www.youtube.com/watch?v=oxOj30rl_xs) — Optional visual - no verified bounded range
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.

## DE16-03 — Automated quality gates

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [Great Expectations tutorial](https://www.youtube.com/watch?v=oxOj30rl_xs) — Optional visual - no verified bounded range
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.

## DE16-04 — Continuous Integration fundamentals

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [GitHub - Beginner 2026 compilation](https://www.youtube.com/watch?v=zZuqjoLEYzo) — GitHub Actions 07:54-15:45; GitHub security 15:45-20:28 (publisher chapters)
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.

## DE16-05 — GitHub Actions for data projects

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [GitHub - Beginner 2026 compilation](https://www.youtube.com/watch?v=zZuqjoLEYzo) — GitHub Actions 07:54-15:45; GitHub security 15:45-20:28 (publisher chapters)
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.

## DE16-06 — Dev, test and prod environments

- [Fabric Git integration + Python CI/CD deployment](https://www.youtube.com/watch?v=dsEA4HG7TtI) — Optional visual - no verified bounded range
- [HashiCorp - Introduction to Terraform](https://www.youtube.com/watch?v=ZFLWA1kQ3ls) — 0:30-3:26 IaC/Terraform; 3:26-10:13 Day 0/1/2; 21:19-22:23 providers

## DE16-07 — Deployment and rollback

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [Fabric Git integration + Python CI/CD deployment](https://www.youtube.com/watch?v=dsEA4HG7TtI) — Optional visual - no verified bounded range
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.

## DE16-08 — Secrets and credential safety

- [TechWorld with Nana - GitHub Actions concepts and CI/CD with Docker](https://www.youtube.com/watch?v=R8_veQiYBjI) — Optional visual - no verified bounded range. English demonstration. Focus on workflow events, jobs, steps and seeing a failed check. Apply the course data-quality checks inside that workflow.
- [GitHub - Beginner 2026 compilation](https://www.youtube.com/watch?v=zZuqjoLEYzo) — GitHub Actions 07:54-15:45; GitHub security 15:45-20:28 (publisher chapters)
- [GitHub Actions desde cero - Spanish-language supplementary tutorial](https://www.youtube.com/watch?v=sIhm4YOMK6Q) — Optional Spanish-language visual - no verified bounded range. An English GitHub Actions demonstration is listed first.

## DE16-09 — RBAC and least privilege

- [Azure RBAC visual walkthrough](https://www.youtube.com/watch?v=c5u_AzSCsco) — 00:26-04:18 RBAC core through best practices
- [GitHub - Beginner 2026 compilation](https://www.youtube.com/watch?v=zZuqjoLEYzo) — GitHub Actions 07:54-15:45; GitHub security 15:45-20:28 (publisher chapters)

## DE16-10 — PII, encryption and masking

- [Microsoft Purview Learn Live](https://www.youtube.com/watch?v=Sb9uJLtXDGo) — 03:44-15:47 permissions; 40:21-52:44 lineage; 52:44-1:05:22 classification
- [Azure RBAC visual walkthrough](https://www.youtube.com/watch?v=c5u_AzSCsco) — 00:26-04:18 RBAC core through best practices

## DE16-11 — Metadata, lineage and governance

- [Microsoft Purview Learn Live](https://www.youtube.com/watch?v=Sb9uJLtXDGo) — 03:44-15:47 permissions; 40:21-52:44 lineage; 52:44-1:05:22 classification
- [Microsoft Purview lineage visual](https://www.youtube.com/watch?v=WxiDuiooF9g) — Optional visual - no verified bounded range

## DE16-12 — Observability for data pipelines

- [Monte Carlo - Data Observability](https://www.youtube.com/watch?v=Lt8_s8ywEAA) — Optional visual - no verified bounded range
- [Google Cloud Tech - OpenTelemetry](https://www.youtube.com/watch?v=RjX7t-b04hE) — Optional visual - no verified bounded range

## DE16-13 — Incidents, runbooks and root cause

- [Google Cloud Tech - OpenTelemetry](https://www.youtube.com/watch?v=RjX7t-b04hE) — Optional visual - no verified bounded range
- [Monte Carlo - Data Observability](https://www.youtube.com/watch?v=Lt8_s8ywEAA) — Optional visual - no verified bounded range

## DE16-14 — Terraform and IaC foundations

- [HashiCorp - Introduction to Terraform](https://www.youtube.com/watch?v=ZFLWA1kQ3ls) — 0:30-3:26 IaC/Terraform; 3:26-10:13 Day 0/1/2; 21:19-22:23 providers
- [HashiCorp - Getting into Terraform, Part 1 (2026)](https://www.youtube.com/watch?v=jT7X6-gjTU8) — Optional visual - no verified bounded range