# M01 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE01-01 — What data is: tables, records, fields and data types

- [What is Data? An Introduction to Data Terminology and Concepts](https://www.statcan.gc.ca/en/wtc/data-literacy/catalogue/892000062020006) — 00:00-06:38

## DE01-02 — Grain: what one row represents

- [What is Data? An Introduction to Data Terminology and Concepts](https://www.statcan.gc.ca/en/wtc/data-literacy/catalogue/892000062020006) — Reused visual from DE01-01: 00:00–06:38. Optional reminder about records and summaries. The book teaches the precise grain sentence and order-versus-line distinction.

## DE01-03 — Keys, duplicates and missing values

- [Data Accuracy and Validation: Methods to ensure quality](https://www.statcan.gc.ca/en/wtc/data-literacy/catalogue/892000062020008) — 00:00–10:29. Visual context for validity and missing values. The book adds candidate/composite keys, duplicates and missing-versus-zero reasoning.

## DE01-04 — Data quality and useful validation

- [Data Accuracy and Validation: Methods to ensure quality](https://www.statcan.gc.ca/en/wtc/data-literacy/catalogue/892000062020008) — Reused visual from DE01-03: 00:00–10:29. No second mandatory watch. The book teaches how to design and evaluate useful quality checks.

## DE01-05 — Meet Excel: workbook, worksheet, cells and formulas

- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=75s) — 01:15–04:09

## DE01-06 — Enter, save and structure tabular data safely

- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=249s) — 04:09–07:35

## DE01-07 — Sort and filter without damaging records

- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=697s) — 11:37–13:05
- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=837s) — 13:57–15:46

## DE01-08 — Basic formulas and essential functions

- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=946s) — 15:46–21:01
- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=1289s) — 21:29–22:39

## DE01-09 — Relative and absolute references

- [Excel Cell References: Relative, Absolute and Mixed](https://www.youtube.com/watch?v=4MVNjzsGokc) — 00:00-03:49
- [Excel Cell References: Relative, Absolute and Mixed](https://www.youtube.com/watch?v=4MVNjzsGokc&t=306s) — 05:06-06:57

## DE01-10 — Excel Tables and structured working habits

- [Excel Cell References: Relative, Absolute and Mixed](https://www.youtube.com/watch?v=4MVNjzsGokc&t=490s) — 08:10-09:55

## DE01-11 — Practical cleaning and exact lookups

- [How to use VLOOKUP in Excel](https://www.youtube.com/watch?v=8rtvDQVQaA0&t=80s) — 01:20-03:40

## DE01-12 — PivotTables and Power Query awareness

- [Excel Pivot Tables Tutorial for Beginners](https://www.youtube.com/watch?v=aofsdpjvK7w&t=84s) — 01:24-03:40
- [Excel Pivot Tables Tutorial for Beginners](https://www.youtube.com/watch?v=aofsdpjvK7w&t=555s) — 09:15-09:49

## DE01-13 — Chart choice and basic visual communication

- [Chandoo — Excel Tutorial for Beginners: Learn it FAST](https://www.youtube.com/watch?v=F7aPazuS8QY&t=1359s) — 22:39–27:27

## DE01-14 — Reconciliation, sanity checks and source preservation

- [Data Accuracy and Validation: Methods to ensure quality](https://www.statcan.gc.ca/en/wtc/data-literacy/catalogue/892000062020008) — 00:00-10:29

## DE01-15 — A complete small workflow: inspect, calculate, validate, explain and save

- [Data Journey: What you need to know for successful navigation](https://www.statcan.gc.ca/en/wtc/data-literacy/catalogue/892000062020007) — 00:00-04:37