# M14 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE14-01 — Batch vs streaming

- [Confluent Developer - Stream Processing | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=vF5y17Pypds) — Verified chapters 00:00-04:10: stream processing and batch/stream comparison

## DE14-02 — Events, brokers and topics

- [Confluent Developer - Topics | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=mAg9tCztTjc) — Verified chapters 00:00-09:50: log abstraction, messages, timestamps, retention
- [Confluent Developer - Brokers | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=LHvVH87Ny7E) — Verified chapters 00:00-03:12: brokers, clusters and KRaft

## DE14-03 — Producers and message keys

- [Confluent Developer - Partitions | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=8L-1HSTf97E) — Verified chapters 00:41-03:23: scaling and partition ordering

## DE14-04 — Consumers and safe processing

- [Confluent Developer - Consumers | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=mHaVGVLyfB4) — Verified chapters: 01:13-05:04 subscription/records/log; 05:04-06:31 commits; 06:31-08:04 groups/rebalancing

## DE14-05 — Partitions and ordering

- [Confluent Developer - Partitions | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=8L-1HSTf97E) — Verified chapters 00:41-03:23: scaling and partition ordering
- [Confluent Developer - Topics | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=mAg9tCztTjc) — Verified chapters 00:00-09:50: log abstraction, messages, timestamps, retention

## DE14-06 — Offsets, group position and replay

- [Confluent Developer - Consumers | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=mHaVGVLyfB4) — Verified chapters: 01:13-05:04 subscription/records/log; 05:04-06:31 commits; 06:31-08:04 groups/rebalancing

## DE14-07 — Consumer groups and scaling

- [Confluent Developer - Consumers | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=mHaVGVLyfB4) — Verified chapters: 01:13-05:04 subscription/records/log; 05:04-06:31 commits; 06:31-08:04 groups/rebalancing

## DE14-08 — Delivery semantics and idempotency

- [Confluent - Apache Kafka Transactions: Message Delivery and Exactly-Once Semantics](https://www.youtube.com/watch?v=Ki2D2o9aVl8) — Optional visual - no verified bounded range; Jun Rao explains transactions and caveats

## DE14-09 — Serialization, schemas and evolution

- [Confluent Developer - Confluent Schema Registry | Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=RgEoYw6u0sg) — Verified chapters 00:51-07:41: need, write/read, formats, compatibility motivation

## DE14-10 — Python producer and consumer workflow

- [Confluent - How to use Python with Apache Kafka](https://www.youtube.com/watch?v=GkpyIh5aWfU) — Verified chapters 01:09-20:35: clients, use cases, librdkafka, schemas, AdminClient

## DE14-11 — Spark Structured Streaming + Kafka

- [DataBeli - End-to-End Spark Streaming Project](https://www.youtube.com/watch?v=SsE5ZfxtiOI) — Verified chapters 32:29-57:42: Kafka connection and Spark Kafka consumption; vendor UI differs from local route
- [Confluent Developer - Stream Processing | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=vF5y17Pypds) — Verified chapters 00:00-04:10: stream processing and batch/stream comparison

## DE14-12 — Lag, failures and streaming operations

- [Confluent - Slow Consumers monitoring demo](https://www.youtube.com/watch?v=XOtY1uUaf_Y) — Optional visual - no verified bounded range; older UI but useful lag symptom visual