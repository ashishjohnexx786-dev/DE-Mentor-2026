# M19 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE19-01 — Truthful one-page Data Engineer resume

- [Indeed - Resume Writing: How to Create a Strong Resume](https://www.youtube.com/watch?v=LcohcyoCXn8) — 00:32-03:36 - bounded resume structure/credentials/digital-version route

## DE19-02 — GitHub and project portfolio final polish

- [freeCodeCamp - Git & GitHub Crash Course for Beginners [retained course visual]](https://www.youtube.com/watch?v=mAFoROnOfHs) — Optional visual - no verified bounded range for profile/portfolio polish

## DE19-03 — LinkedIn/professional profile without overclaiming

- [LinkedIn Complete Guide 2026 - Profile, Headline, About, Job Search](https://www.youtube.com/watch?v=wXQp9O3iQR8) — Optional visual - no verified bounded range

## DE19-04 — Degree-aware job targeting: apply/skip rules

- [Google India - organise job applications and prepare for interviews](https://www.youtube.com/watch?v=aHnGoMDUu8A) — Optional visual - no verified bounded range

## DE19-05 — SQL interview drills

- [Alex The Analyst - SQL Interview Questions and Answers for Beginners](https://www.youtube.com/watch?v=sua7xKN0cPc) — Optional visual - no verified bounded range
- [Alex The Analyst - Solving Easy SQL Interview Questions](https://www.youtube.com/watch?v=ZHaYOC0H5KE) — 02:33-06:57 first question; 06:58-11:43 second question
- [learn by doing it - Data Engineer Interview Prep: SQL, Python & PySpark](https://www.youtube.com/watch?v=Mbc-RkY5TB8) — SQL 00:43-01:15:36; Python 01:15:37-02:05:19; other topics optional/unbounded

## DE19-06 — Python interview drills

- [learn by doing it - Data Engineer Interview Prep: SQL, Python & PySpark](https://www.youtube.com/watch?v=Mbc-RkY5TB8) — SQL 00:43-01:15:36; Python 01:15:37-02:05:19; other topics optional/unbounded
- [freeCodeCamp - Data Structure Patterns for LeetCode Interviews](https://www.youtube.com/watch?v=Z_c4byLrNBU) — 00:00-03:10 arrays; 03:11-04:55 strings; 10:02-15:53 hashmap; 15:54-18:51 hashmap practice

## DE19-07 — Data-engineering concepts and troubleshooting drills

- [learn by doing it - Data Engineer Interview Prep: SQL, Python & PySpark](https://www.youtube.com/watch?v=Mbc-RkY5TB8) — SQL 00:43-01:15:36; Python 01:15:37-02:05:19; other topics optional/unbounded
- [Afaque Ahmad - How I Mastered Data Engineering System Design Interviews](https://www.youtube.com/watch?v=r58Cf_kc_bY) — 04:19-13:21 six-step framework; 13:22-27:32 requirements; 38:38-47:20 batch vs streaming; 01:29:02-01:37:36 quality/observability

## DE19-08 — Project walkthrough interview

- [Afaque Ahmad - How I Mastered Data Engineering System Design Interviews](https://www.youtube.com/watch?v=r58Cf_kc_bY) — 04:19-13:21 six-step framework; 13:22-27:32 requirements; 38:38-47:20 batch vs streaming; 01:29:02-01:37:36 quality/observability

## DE19-09 — Architecture/system-design defense for junior roles

- [Afaque Ahmad - How I Mastered Data Engineering System Design Interviews](https://www.youtube.com/watch?v=r58Cf_kc_bY) — 04:19-13:21 six-step framework; 13:22-27:32 requirements; 38:38-47:20 batch vs streaming; 01:29:02-01:37:36 quality/observability

## DE19-10 — Behavioral answers and career-transition story

- [Indeed - Behavioral Interview Questions and Answers: Use the STAR Technique](https://www.youtube.com/watch?v=zoGZQatkqKg) — 00:23-01:24 behavioral questions; 01:25-03:09 STAR structure; 05:04-06:09 worked difficult-problem answer; 06:10-08:24 best practices

## DE19-11 — Technical English: explain code, failures and decisions clearly

- [Indeed - Behavioral Interview Questions and Answers: Use the STAR Technique](https://www.youtube.com/watch?v=zoGZQatkqKg) — 00:23-01:24 behavioral questions; 01:25-03:09 STAR structure; 05:04-06:09 worked difficult-problem answer; 06:10-08:24 best practices

## DE19-12 — Application tracker, feedback loop and weekly repair cycle

- [Google India - organise job applications and prepare for interviews](https://www.youtube.com/watch?v=aHnGoMDUu8A) — Optional visual - no verified bounded range

## DE19-13 — Timed coding test: arrays, strings and hash-map problems

- [freeCodeCamp - Data Structure Patterns for LeetCode Interviews](https://www.youtube.com/watch?v=Z_c4byLrNBU) — 00:00-03:10 arrays; 03:11-04:55 strings; 10:02-15:53 hashmap; 15:54-18:51 hashmap practice

## DE19-14 — Combined SQL + Python interview simulation

- [Alex The Analyst - Solving Easy SQL Interview Questions](https://www.youtube.com/watch?v=ZHaYOC0H5KE) — 02:33-06:57 first question; 06:58-11:43 second question
- [freeCodeCamp - Data Structure Patterns for LeetCode Interviews](https://www.youtube.com/watch?v=Z_c4byLrNBU) — 00:00-03:10 arrays; 03:11-04:55 strings; 10:02-15:53 hashmap; 15:54-18:51 hashmap practice