# M10 — Docker and Apache Airflow

First read ../../00_START_HERE/HOW_TO_STUDY.pdf if this is your first session.

1. Open M10_Learner_Book.pdf and study DE10-01 -> DE10-19 in order.
2. Use the named input under the course-root folder **08_M10/practice**. Keep its folder structure and read the setup instructions before running commands.
3. Reproduce each worked example, then save the independent task before its explained review.
4. Use M10_Quick_Revision_Book.pdf, then M10_Module_Revision_Test.pdf.
5. After your saved test, open PROTECTED_OPEN_AFTER_ATTEMPT/M10_Module_Revision_Test_Answers.pdf.
6. Practice solutions: PROTECTED_OPEN_AFTER_ATTEMPT/M10_Explained_Reviews.pdf.

Planning allowance: 12–16 study days at six focused hours/day, including module review and test. Then take G04 through A -> Review A -> fresh B -> Review B.

WATCH_GUIDE.md lists the same instructor sources and scope as the learner book. Videos may support only part of a lesson; the printed example and task complete it.
