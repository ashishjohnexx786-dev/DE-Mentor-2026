# M10 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE10-01 — Why containers exist

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-02 — Images and containers

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-03 — Writing a Dockerfile

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-04 — Ports

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-05 — Volumes and persistence

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-06 — Networks and service communication

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-07 — Compose, configuration and secrets

- [DataTalksClub Docker/PostgreSQL workshop](https://www.youtube.com/watch?v=lP8xXebHmuE) — Optional visual - no verified bounded range

## DE10-08 — Why orchestration exists

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-09 — Airflow architecture and UI

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-10 — DAGs, tasks and dependencies

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-11 — TaskFlow, operators and task communication

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-12 — Scheduling and data intervals

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-13 — Retries, timeouts and failure behavior

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-14 — Parameters and task communication

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-15 — Connections, variables and secrets

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-16 — Sensors and waiting

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-17 — Logs and debugging

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-18 — Catchup, backfills and reprocessing

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority

## DE10-19 — Integration and production-style orchestration

- [DataTalksClub / Timothy Davis - How to write data pipelines with Apache Airflow 3.0](https://www.youtube.com/watch?v=v_jbmhVWBvM) — Optional visual - no verified bounded range
- [Astronomer - Airflow 101: Essential Tips for Beginners (retained from earlier route)](https://www.youtube.com/watch?v=5SFVDr6F4vg) — Optional visual - no verified bounded range; older visual, not current syntax authority