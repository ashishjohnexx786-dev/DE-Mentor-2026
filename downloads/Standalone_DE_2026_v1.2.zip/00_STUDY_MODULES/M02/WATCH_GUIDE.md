# M02 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE02-01 — Database, table, row, column and query mental model

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=196s) — 03:16-10:53

## DE02-02 — SELECT, aliases and LIMIT

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=4348s) — 01:12:28-01:15:18
- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=5375s) — 01:29:35-01:32:43
- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=7783s) — 02:09:43-02:12:32

## DE02-03 — WHERE and comparison operators

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=4919s) — 01:21:59-01:29:35

## DE02-04 — AND, OR, NOT and parentheses

- [PostgreSQL Tutorial Full Course 2022](https://www.youtube.com/watch?v=85pG_pDkITY&t=3348s) — 55:48-58:12

## DE02-05 — ORDER BY, DISTINCT and result inspection

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=4518s) — 01:15:18-01:21:59

## DE02-06 — NULL, IS NULL and COALESCE

- [SQL for Data Analytics - Learn SQL in 4 Hours](https://www.youtube.com/watch?v=7mz73uXD9DA&t=4125s) — 01:08:45-01:10:07
- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=7952s) — 02:12:32-02:16:15

## DE02-07 — Arithmetic expressions and safe calculations

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=7315s) — 02:01:55-02:09:43
- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=8175s) — 02:16:15-02:20:21

## DE02-08 — Aggregate functions

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=6940s) — 01:55:40-02:01:55

## DE02-09 — GROUP BY and grouped grain

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=6190s) — 01:43:10-01:46:41

## DE02-10 — HAVING after aggregation

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=6401s) — 01:46:41-01:52:08

## DE02-11 — CASE for business categories

- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=5199s) — 01:26:39-01:35:16

## DE02-12 — String and date basics

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=5865s) — 01:37:45-01:43:10
- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=8421s) — 02:20:21-02:27:28

## DE02-13 — Simple subqueries and IN/EXISTS awareness

- [Learn PostgreSQL Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=qw--VYLpxG4&t=5563s) — 01:32:43-01:35:43
- [Learn SQL Beginner to Advanced in Under 4 Hours](https://www.youtube.com/watch?v=OT1RErkfLNQ&t=5716s) — 01:35:16-01:45:58

## DE02-14 — Debugging and validation workflow

- [SQL for Data Analytics - Learn SQL in 4 Hours](https://www.youtube.com/watch?v=7mz73uXD9DA&t=4815s) — 01:20:15-01:22:35