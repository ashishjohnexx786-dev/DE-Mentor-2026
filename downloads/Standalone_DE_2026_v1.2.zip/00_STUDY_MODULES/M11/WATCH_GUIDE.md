# M11 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE11-01 — Row vs columnar storage; where Parquet fits

- [Visual: Data Mozart - Parquet File Format Explained](https://www.youtube.com/watch?v=5NA57Pfpdr4) — 03:06-05:43 row vs column + row groups

## DE11-02 — Parquet schema, row groups and metadata

- [Visual: Data Mozart - Parquet File Format Explained](https://www.youtube.com/watch?v=5NA57Pfpdr4) — 05:01-07:30 row groups + projection/predicate

## DE11-03 — Projection, predicates and analytical reads

- [Visual: Data Mozart - Parquet File Format Explained](https://www.youtube.com/watch?v=5NA57Pfpdr4) — 05:43-07:30 projection + predicates

## DE11-04 — Compression, small files and compaction

- [Visual: Data Mozart - Parquet File Format Explained](https://www.youtube.com/watch?v=5NA57Pfpdr4) — 07:30-10:04 file size + compression

## DE11-05 — Partitioning strategy and over-partitioning

- [Optional visual: Data Mozart - Parquet File Format Explained](https://www.youtube.com/watch?v=5NA57Pfpdr4) — 05:01-10:04 row groups/projection/file-size context; this video does NOT teach partition strategy. Official partition docs + book are required.

## DE11-06 — Lake vs warehouse vs lakehouse

- [Optional visual: Data Mozart - Parquet File Format Explained](https://www.youtube.com/watch?v=5NA57Pfpdr4) — 10:04-11:28 Delta-format introduction only; lakehouse architecture is taught by the book + current official docs.

## DE11-07 — Delta tables, transaction log and ACID concepts

- [Optional visual: Databricks - Diving into Delta Lake: Transaction Log](https://www.youtube.com/watch?v=lXlBJdehsdw) — No independently verified bounded chapter range assigned; book + current official Delta docs are required.

## DE11-08 — MERGE/upsert and current-state records

- [Optional visual: Databricks - Deep-Dive into Delta Lake](https://www.youtube.com/watch?v=de-6a6Bfw6E) — No independently verified bounded chapter range assigned; MERGE/source-key safety comes from the book + current official docs.

## DE11-09 — Schema enforcement, controlled evolution and compatibility

- [Optional visual: Databricks - Deep-Dive into Delta Lake](https://www.youtube.com/watch?v=de-6a6Bfw6E) — No independently verified bounded chapter range assigned; schema/evolution behavior comes from the book + current official docs.

## DE11-10 — Time travel, retention, VACUUM safety and medallion checkpoint

- [Optional visual: Databricks - Diving into Delta Lake: Transaction Log](https://www.youtube.com/watch?v=lXlBJdehsdw) — No independently verified bounded chapter range assigned; time-travel/history/VACUUM behavior comes from current official docs + book.