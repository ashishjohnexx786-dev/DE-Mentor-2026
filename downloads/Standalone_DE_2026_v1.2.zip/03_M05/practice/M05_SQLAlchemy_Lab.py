from __future__ import annotations
import os
from sqlalchemy import create_engine, text

url=os.getenv("M05_DATABASE_URL")
if not url:
    raise SystemExit("Set M05_DATABASE_URL. Use your M03 PostgreSQL URL for learner evidence; QA may use an isolated SQLite URL.")
engine=create_engine(url)
with engine.begin() as conn:
    conn.execute(text("CREATE TABLE IF NOT EXISTS m05_demo (order_id VARCHAR(20) PRIMARY KEY, amount NUMERIC NOT NULL)"))
    conn.execute(text("DELETE FROM m05_demo"))
    conn.execute(text("INSERT INTO m05_demo(order_id, amount) VALUES (:order_id,:amount)"),[
        {"order_id":"DB01","amount":1200},{"order_id":"DB02","amount":800}
    ])
with engine.connect() as conn:
    rows=conn.execute(text("SELECT order_id, amount FROM m05_demo WHERE amount >= :min_amount ORDER BY order_id"),{"min_amount":900}).mappings().all()
    print(rows)
