from __future__ import annotations
from datetime import date
from decimal import Decimal, InvalidOperation
from collections import Counter

REQUIRED = {"order_id","customer_id","order_date","quantity","unit_price","region","product"}

def validate_orders(raw_rows):
    """Return (accepted, rejected). Never mutate raw_rows in-place."""
    id_counts = Counter((r.get("order_id") or "").strip() for r in raw_rows)
    accepted, rejected = [], []
    for source_row, row in enumerate(raw_rows, start=2):
        reasons=[]
        missing_cols = REQUIRED - set(row)
        if missing_cols:
            reasons.append("missing_columns:" + ",".join(sorted(missing_cols)))
        oid=(row.get("order_id") or "").strip()
        cid=(row.get("customer_id") or "").strip()
        if not oid: reasons.append("missing_order_id")
        if not cid: reasons.append("missing_customer_id")
        if oid and id_counts[oid] > 1: reasons.append("duplicate_order_id")
        try:
            d=date.fromisoformat((row.get("order_date") or "").strip())
        except ValueError:
            d=None; reasons.append("invalid_order_date")
        try:
            qty=int((row.get("quantity") or "").strip())
            if qty <= 0: reasons.append("quantity_must_be_positive")
        except ValueError:
            qty=None; reasons.append("invalid_quantity")
        try:
            price=Decimal((row.get("unit_price") or "").strip())
            if price < 0: reasons.append("unit_price_must_be_nonnegative")
        except (InvalidOperation, ValueError):
            price=None; reasons.append("invalid_unit_price")
        if reasons:
            rejected.append({**row,"source_row":source_row,"rejection_reasons":"|".join(reasons)})
        else:
            accepted.append({
                **row,"source_row":source_row,"order_date":d.isoformat(),"quantity":qty,
                "unit_price":str(price),"amount":str(price*qty)
            })
    return accepted, rejected
