"""M05 integrated checkpoint. Work from a COPY in your module-work folder.
Do not open the reference/review until you have saved a genuine attempt.
"""
from pathlib import Path
import csv, json, hashlib

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/"data"/"M05_Module_Orders.csv"
OUT=Path("m05_checkpoint_output")

# TODO 1: preserve/identify the exact source bytes (checksum + source filename).
# TODO 2: parse CSV with a CSV parser; do not split lines on commas.
# TODO 3: validate schema, key, date, quantity and unit_price rules.
# TODO 4: write accepted and rejected outputs. Rejected rows need reason codes.
# TODO 5: prove raw = accepted + rejected and prove accepted order_id uniqueness.
# TODO 6: reconcile accepted amount independently.
# TODO 7: save run metadata and explain what a safe rerun should do.
# Known course control values are NOT printed here. Produce them from your code.
