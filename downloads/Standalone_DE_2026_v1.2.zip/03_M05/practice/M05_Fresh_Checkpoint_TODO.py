"""M05 fresh checkpoint. Different entity, identifiers and controls from the module practical."""
from pathlib import Path
import csv, json
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/"data"/"M05_Fresh_Inventory.csv"
OUT=Path("m05_fresh_output")
# Build from a blank/near-blank start after review is closed.
# Rules: sku required/unique; quantity must be positive integer; unit_cost nonnegative decimal; received_on valid ISO date.
# Save accepted/rejected with reasons, reconcile rows, prove unique accepted SKU, calculate accepted inventory value, and save run metadata.
