from __future__ import annotations
import os, time, random, requests

BASE=os.getenv("M05_API_BASE","http://127.0.0.1:8765")
TOKEN=os.getenv("M05_API_TOKEN")

def headers():
    if not TOKEN: raise RuntimeError("Set M05_API_TOKEN; do not hardcode real credentials.")
    return {"Authorization":f"Bearer {TOKEN}"}

def get_json(path, *, timeout=5, max_attempts=4):
    last=None
    for attempt in range(1,max_attempts+1):
        try:
            r=requests.get(BASE+path,headers=headers(),timeout=timeout)
            if r.status_code==429:
                if attempt==max_attempts: r.raise_for_status()
                delay=float(r.headers.get("Retry-After","1")); time.sleep(delay); continue
            if 500 <= r.status_code < 600:
                if attempt==max_attempts: r.raise_for_status()
                time.sleep(min(2.0,0.25*(2**(attempt-1)))+random.uniform(0,0.05)); continue
            r.raise_for_status()
            ctype=r.headers.get("Content-Type","").lower()
            if "application/json" not in ctype: raise ValueError(f"Expected JSON, got {ctype!r}")
            return r.json()
        except (requests.Timeout, requests.ConnectionError) as e:
            last=e
            if attempt==max_attempts: raise
            time.sleep(min(2.0,0.25*(2**(attempt-1)))+random.uniform(0,0.05))
    raise RuntimeError("unreachable") from last

def fetch_all_orders(page_size=3):
    rows=[]; page=1; seen=set()
    while page is not None:
        payload=get_json(f"/v1/orders?page={page}&page_size={page_size}")
        for row in payload["records"]:
            oid=row["order_id"]
            if oid in seen: raise ValueError(f"duplicate API order_id {oid}")
            seen.add(oid); rows.append(row)
        page=payload["next_page"]
    if len(rows)!=len(seen): raise AssertionError("row/key mismatch")
    return rows

if __name__=="__main__":
    rows=fetch_all_orders(); print(f"fetched={len(rows)} unique={len({r['order_id'] for r in rows})} amount={sum(r['amount'] for r in rows)}")
