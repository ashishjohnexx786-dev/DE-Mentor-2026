from __future__ import annotations
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import json, os

HOST="127.0.0.1"; PORT=int(os.getenv("M05_API_PORT","8765"))
TOKEN="training-token"   # deliberately fictional local training token
ORDERS=[
 {"order_id":"A101","amount":1000,"region":"East"},
 {"order_id":"A102","amount":1200,"region":"West"},
 {"order_id":"A103","amount":700,"region":"North"},
 {"order_id":"A104","amount":1600,"region":"South"},
 {"order_id":"A105","amount":1500,"region":"North"},
 {"order_id":"A106","amount":1000,"region":"East"},
 {"order_id":"A107","amount":900,"region":"West"},
]
STATE={"flaky":0,"rate":0}

class H(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Intentionally do not log Authorization headers.
        print("API", self.address_string(), fmt % args)
    def send_json(self,status,payload,headers=None):
        raw=json.dumps(payload).encode()
        self.send_response(status); self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(raw)))
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(raw)
    def auth_ok(self):
        return self.headers.get("Authorization")==f"Bearer {TOKEN}"
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path=="/health": return self.send_json(200,{"status":"ok"})
        if u.path=="/reset": STATE.update(flaky=0,rate=0); return self.send_json(200,{"reset":True})
        if u.path=="/bad-content":
            raw=b"not-json"; self.send_response(200); self.send_header("Content-Type","text/plain"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); return self.wfile.write(raw)
        if u.path.startswith("/v1/") and not self.auth_ok(): return self.send_json(401,{"error":"unauthorized"})
        if u.path=="/v1/orders":
            page=max(1,int(q.get("page",["1"])[0])); size=min(4,max(1,int(q.get("page_size",["3"])[0])))
            start=(page-1)*size; rows=ORDERS[start:start+size]
            next_page=page+1 if start+size < len(ORDERS) else None
            return self.send_json(200,{"records":rows,"page":page,"page_size":size,"total":len(ORDERS),"next_page":next_page})
        if u.path=="/v1/flaky":
            STATE["flaky"]+=1
            if STATE["flaky"]==1: return self.send_json(500,{"error":"temporary"})
            return self.send_json(200,{"ok":True,"attempt":STATE["flaky"]})
        if u.path=="/v1/rate-limit":
            STATE["rate"]+=1
            if STATE["rate"]==1: return self.send_json(429,{"error":"slow_down"},{"Retry-After":"1"})
            return self.send_json(200,{"ok":True,"attempt":STATE["rate"]})
        return self.send_json(404,{"error":"not_found"})

if __name__=="__main__":
    print(f"M05 local API on http://{HOST}:{PORT}; token is a fictional local training value. Press Ctrl+C to stop.")
    ThreadingHTTPServer((HOST,PORT),H).serve_forever()
