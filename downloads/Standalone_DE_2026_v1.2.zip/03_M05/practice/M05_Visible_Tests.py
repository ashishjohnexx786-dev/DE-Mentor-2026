from pathlib import Path
import sys, csv
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from M05_Validation import validate_orders

def test_one_valid_record():
    rows=[{"order_id":"T01","customer_id":"C1","order_date":"2026-09-01","quantity":"2","unit_price":"10.50","region":"East","product":"Pen"}]
    ok,bad=validate_orders(rows); assert len(ok)==1 and not bad and ok[0]["amount"]=="21.00"

def test_duplicate_ids_are_rejected():
    base={"customer_id":"C1","order_date":"2026-09-01","quantity":"1","unit_price":"10","region":"East","product":"Pen"}
    ok,bad=validate_orders([{**base,"order_id":"D1"},{**base,"order_id":"D1"}]); assert not ok and len(bad)==2

if __name__=="__main__":
    test_one_valid_record(); test_duplicate_ids_are_rejected(); print("visible tests passed")
