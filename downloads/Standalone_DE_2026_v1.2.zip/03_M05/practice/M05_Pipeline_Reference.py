from __future__ import annotations
from pathlib import Path
import csv, json, hashlib
from M05_Validation import validate_orders

HERE=Path(__file__).resolve().parent
DATA=HERE.parent/"data"
OUT=HERE/"output"

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(65536),b""): h.update(chunk)
    return h.hexdigest()

def read_csv(path):
    with open(path,newline="",encoding="utf-8") as f: return list(csv.DictReader(f))

def write_csv(path, rows, fields):
    path.parent.mkdir(parents=True,exist_ok=True)
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore"); w.writeheader(); w.writerows(rows)

def run(source=None):
    source=Path(source) if source else DATA/"M05_Module_Orders.csv"
    raw=read_csv(source)
    accepted,rejected=validate_orders(raw)
    amount=sum(float(r["amount"]) for r in accepted)
    run_meta={"source":source.name,"sha256":sha256(source),"raw_rows":len(raw),"accepted_rows":len(accepted),"rejected_rows":len(rejected),"accepted_amount":amount}
    OUT.mkdir(exist_ok=True)
    write_csv(OUT/"accepted.csv",accepted,["source_row","order_id","customer_id","order_date","quantity","unit_price","region","product","amount"])
    write_csv(OUT/"rejected.csv",rejected,["source_row","order_id","customer_id","order_date","quantity","unit_price","region","product","rejection_reasons"])
    (OUT/"run_metadata.json").write_text(json.dumps(run_meta,indent=2),encoding="utf-8")
    return run_meta

if __name__=="__main__": print(json.dumps(run(),indent=2))
