# M00-M12 Revision and Test System

Use this folder after studying the normal learner books. Every completed module has the same companion structure:

1. `MXX_Quick_Revision_Book.pdf` - concise lesson-by-lesson recall notes.
2. `MXX_Module_Revision_Test.pdf` - closed-book changed tasks covering every canonical lesson.
3. `PROTECTED_OPEN_AFTER_ATTEMPT/MXX_Module_Revision_Test_Answers.pdf` - expected answers/validation controls after a saved attempt.

These module revision tests do not replace formal Gates G01-G04. There is no formal Gate after M11 or M12. No forced timer: master untimed first.
