# M00-M19 Revision + Test Index

Use each module only after completing its learner book and practice. Module Tests are closed-book. Open Protected Answers only after saving a genuine attempt. Formal Gates stay separate.

| Module | Units | Quick Revision | Module Test | Protected Answers | Gate after |
|---|---:|---|---|---|---|
| M00 - Computer, Setup & Learning Foundations | 8 | `M00/M00_Quick_Revision_Book.pdf` | `M00/M00_Module_Revision_Test.pdf` | `M00/PROTECTED_OPEN_AFTER_ATTEMPT/M00_Module_Revision_Test_Answers.pdf` | none |
| M01 - Data Foundations + Essential Excel | 15 | `M01/M01_Quick_Revision_Book.pdf` | `M01/M01_Module_Revision_Test.pdf` | `M01/PROTECTED_OPEN_AFTER_ATTEMPT/M01_Module_Revision_Test_Answers.pdf` | G01 |
| M02 - SQL Foundations | 14 | `M02/M02_Quick_Revision_Book.pdf` | `M02/M02_Module_Revision_Test.pdf` | `M02/PROTECTED_OPEN_AFTER_ATTEMPT/M02_Module_Revision_Test_Answers.pdf` | none |
| M03 - Advanced SQL + PostgreSQL / Database Thinking | 16 | `M03/M03_Quick_Revision_Book.pdf` | `M03/M03_Module_Revision_Test.pdf` | `M03/PROTECTED_OPEN_AFTER_ATTEMPT/M03_Module_Revision_Test_Answers.pdf` | G02 |
| M04 - Python Foundations | 16 | `M04/M04_Quick_Revision_Book.pdf` | `M04/M04_Module_Revision_Test.pdf` | `M04/PROTECTED_OPEN_AFTER_ATTEMPT/M04_Module_Revision_Test_Answers.pdf` | none |
| M05 - Python for Data Engineering | 15 | `M05/M05_Quick_Revision_Book.pdf` | `M05/M05_Module_Revision_Test.pdf` | `M05/PROTECTED_OPEN_AFTER_ATTEMPT/M05_Module_Revision_Test_Answers.pdf` | none |
| M06 - Git + GitHub + Linux/WSL Engineering Foundations | 13 | `M06/M06_Quick_Revision_Book.pdf` | `M06/M06_Module_Revision_Test.pdf` | `M06/PROTECTED_OPEN_AFTER_ATTEMPT/M06_Module_Revision_Test_Answers.pdf` | G03 |
| M07 - PostgreSQL + Data Modeling | 13 | `M07/M07_Quick_Revision_Book.pdf` | `M07/M07_Module_Revision_Test.pdf` | `M07/PROTECTED_OPEN_AFTER_ATTEMPT/M07_Module_Revision_Test_Answers.pdf` | none |
| M08 - Files, APIs & Data Ingestion | 17 | `M08/M08_Quick_Revision_Book.pdf` | `M08/M08_Module_Revision_Test.pdf` | `M08/PROTECTED_OPEN_AFTER_ATTEMPT/M08_Module_Revision_Test_Answers.pdf` | none |
| M09 - ETL/ELT + Data Quality + Transformation Engineering | 13 | `M09/M09_Quick_Revision_Book.pdf` | `M09/M09_Module_Revision_Test.pdf` | `M09/PROTECTED_OPEN_AFTER_ATTEMPT/M09_Module_Revision_Test_Answers.pdf` | none |
| M10 - Docker + Airflow | 19 | `M10/M10_Quick_Revision_Book.pdf` | `M10/M10_Module_Revision_Test.pdf` | `M10/PROTECTED_OPEN_AFTER_ATTEMPT/M10_Module_Revision_Test_Answers.pdf` | G04 |
| M11 - Storage & File Formats Foundations | 10 | `M11/M11_Quick_Revision_Book.pdf` | `M11/M11_Module_Revision_Test.pdf` | `M11/PROTECTED_OPEN_AFTER_ATTEMPT/M11_Module_Revision_Test_Answers.pdf` | none |
| M12 - Distributed Processing with Spark / PySpark | 18 | `M12/M12_Quick_Revision_Book.pdf` | `M12/M12_Module_Revision_Test.pdf` | `M12/PROTECTED_OPEN_AFTER_ATTEMPT/M12_Module_Revision_Test_Answers.pdf` | none |
| M13 - Delta Lake + Lakehouse | 11 | `M13/M13_Quick_Revision_Book.pdf` | `M13/M13_Module_Revision_Test.pdf` | `M13/PROTECTED_OPEN_AFTER_ATTEMPT/M13_Module_Revision_Test_Answers.pdf` | none |
| M14 - Kafka + Streaming Foundations | 12 | `M14/M14_Quick_Revision_Book.pdf` | `M14/M14_Module_Revision_Test.pdf` | `M14/PROTECTED_OPEN_AFTER_ATTEMPT/M14_Module_Revision_Test_Answers.pdf` | G05 |
| M15 - Azure + Microsoft Fabric Data Engineering | 16 | `M15/M15_Quick_Revision_Book.pdf` | `M15/M15_Module_Revision_Test.pdf` | `M15/PROTECTED_OPEN_AFTER_ATTEMPT/M15_Module_Revision_Test_Answers.pdf` | none |
| M16 - DataOps, CI/CD, Security & Observability | 14 | `M16/M16_Quick_Revision_Book.pdf` | `M16/M16_Module_Revision_Test.pdf` | `M16/PROTECTED_OPEN_AFTER_ATTEMPT/M16_Module_Revision_Test_Answers.pdf` | none |
| M17 - Architecture + Promotion Foundations | 10 | `M17/M17_Quick_Revision_Book.pdf` | `M17/M17_Module_Revision_Test.pdf` | `M17/PROTECTED_OPEN_AFTER_ATTEMPT/M17_Module_Revision_Test_Answers.pdf` | G06 |
| M18 - Portfolio Projects + Production Capstone | 50 | `M18/M18_Quick_Revision_Book.pdf` | `M18/M18_Module_Revision_Test.pdf` | `M18/PROTECTED_OPEN_AFTER_ATTEMPT/M18_Module_Revision_Test_Answers.pdf` | none |
| M19 - Interview, Technical English & Job Launch | 14 | `M19/M19_Quick_Revision_Book.pdf` | `M19/M19_Module_Revision_Test.pdf` | `M19/PROTECTED_OPEN_AFTER_ATTEMPT/M19_Module_Revision_Test_Answers.pdf` | G07 |

M18 contains 50 controlled project/capstone phases rather than formal lessons. G07 follows M19 and is the final job-ready simulation.
