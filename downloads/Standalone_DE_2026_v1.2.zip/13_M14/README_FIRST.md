# M14 - Kafka + Streaming Foundations

Study route:
1. Open `books/M14_Learner_Book.pdf`.
2. Use `WATCH_GUIDE.md` for visual support.
3. Run `practice/README_FIRST.md` setup and matching scripts.
4. Complete cluster checks only after the related lessons.
5. Use Quick Revision later.
6. Take the Module Revision Test closed-book.
7. Open protected answers only after saving a genuine attempt.
8. G05 is a separate formal stage-boundary gate after M14.

Live Kafka, Python client and Spark runtime evidence remains learner-PC validation.
