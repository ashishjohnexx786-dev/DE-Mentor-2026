# M14 STYLE FREEZE

- Navy #173047: lesson/main identity.
- Blue #2563EB: all normal lesson section headings.
- Teal #087F8C: structural rules/callout borders/table accents only.
- No alternating blue/teal ordinary headings.
- No forced timer.
- Videos preserved under the video-first retention policy.
