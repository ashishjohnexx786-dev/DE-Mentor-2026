# M14 local practice - start here

## Starting working directory
Run the commands below from the extracted `13_M14` module directory (the folder that contains `practice/`). Confirm with `pwd`/`cd` before starting.

## Resource-conscious route
Run only Kafka for DE14-02 through DE14-10. Stop other heavy learner services. For DE14-11, you may stop the Python consumer and use Spark only when required.

```bash
docker compose -f practice/docker-compose.yml up -d
docker ps
docker exec m14-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
```

Create topics:
```bash
docker exec m14-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic m14-orders --partitions 3
docker exec m14-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic m14-quarantine --partitions 1
```

Python environment:
```bash
python -m venv .venv
# activate .venv
pip install -r practice/requirements.txt
python practice/kafka/00_env_probe.py
```

Important: the build environment only statically validates these client scripts. Your saved learner-PC evidence is the authority for live Docker/Kafka/Python/Spark execution.

## DE14-11 repaired Structured Streaming validation lab

The Spark example is no longer a connectivity-only script disguised as validation. It now classifies every consumed Kafka record into exactly one of two outcomes:

- **valid**: non-empty Kafka key, event/order IDs present, amount numeric and non-negative;
- **quarantine**: malformed JSON, missing Kafka key, missing IDs, missing amount, nonnumeric amount, or negative amount.

Both outputs retain the raw payload plus topic, partition and offset for diagnosis. Each `foreachBatch` write uses a `batch_id=<n>` evidence directory in overwrite mode so retrying the same micro-batch does not append a second copy of that same batch. The streaming checkpoint remains under `practice/output/spark_checkpoint`.

Before calling the lesson complete, produce at least these four cases in addition to a valid record:
1. malformed JSON;
2. a record with no Kafka key;
3. `amount="abc"`;
4. a negative amount.

For each micro-batch, the console line `total = valid + quarantine` must reconcile. Stop and restart the script **without deleting the checkpoint**, then prove already-committed Kafka offsets are not re-read as a fresh stream. Deleting the checkpoint is a deliberate reset, not normal recovery.

Live Spark/Kafka execution remains learner-PC evidence; Python compilation in the release build is not a substitute.
