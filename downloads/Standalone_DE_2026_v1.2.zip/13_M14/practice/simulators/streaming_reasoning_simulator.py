import json
from hashlib import sha256

def part(key,n=4): return int(sha256(key.encode()).hexdigest()[:8],16)%n

def run():
    events=[("O1","E1"),("O2","E2"),("O1","E3"),("O3","E4"),("O1","E5")]
    seq={}; offsets=[0]*4
    for key,eid in events:
        p=part(key); o=offsets[p]; offsets[p]+=1; seq.setdefault(key,[]).append((p,o,eid))
    assert len({x[0] for x in seq["O1"]})==1
    committed={0:3,1:2,2:5,3:1}; end={0:5,1:2,2:9,3:1}
    lag={p:end[p]-committed[p] for p in end}
    assert lag=={0:2,1:0,2:4,3:0}
    duplicate=[{"event_id":"E9"},{"event_id":"E9"}]
    dedup={e["event_id"]:e for e in duplicate}
    assert len(dedup)==1
    result={"partition_ordering":"PASS","lag_math":"PASS","idempotent_sink_reasoning":"PASS","lag":lag}
    print(json.dumps(result,indent=2)); return result
if __name__=="__main__": run()
