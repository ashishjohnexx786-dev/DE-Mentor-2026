positions={0:5,1:9,2:4}
log_end={0:8,1:11,2:10}
for p in sorted(positions): print("partition",p,"committed",positions[p],"log_end",log_end[p],"lag",log_end[p]-positions[p])
print("Replay changes reading position; it does not mutate retained events.")
