events=[{"t":0,"order":"O1"},{"t":2,"order":"O2"},{"t":9,"order":"O3"}]
print("BATCH: wait until boundary then process",len(events),"events")
for e in events: print("STREAM: react when event arrives",e)
