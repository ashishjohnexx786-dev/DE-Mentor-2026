events=[{"event_id":"E9","order_id":"O9","status":"PAID"},{"event_id":"E9","order_id":"O9","status":"PAID"}]
append_sink=[]; idempotent={}
for e in events:
 append_sink.append(e.copy()); idempotent[e["event_id"]]=e.copy()
print("append rows",len(append_sink),"idempotent business effects",len(idempotent))
assert len(append_sink)==2 and len(idempotent)==1
