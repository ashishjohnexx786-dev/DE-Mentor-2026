# Use the CLI commands in practice/README_FIRST.md. This file records the learner contract.
EVENT={"event_id":"E1","order_id":"O1","status":"CREATED"}
print("topic=m14-orders event=",EVENT)
print("Kafka topic consumption does not delete retained records for other consumer groups.")
