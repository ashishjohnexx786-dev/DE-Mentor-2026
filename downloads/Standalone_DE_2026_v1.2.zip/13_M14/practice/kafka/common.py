import json
import os
from pathlib import Path

class InvalidEventError(ValueError):
    """Source payload is malformed or violates the declared business event contract."""


def parse_json_bytes(value):
    try:
        if isinstance(value, bytes):
            value = value.decode("utf-8")
        obj = json.loads(value)
    except (UnicodeDecodeError, json.JSONDecodeError, TypeError) as exc:
        raise InvalidEventError(f"malformed_json:{exc}") from exc
    if not isinstance(obj, dict):
        raise InvalidEventError("event_must_be_json_object")
    return obj


def validate_event(obj):
    for key in ("event_id", "order_id", "status"):
        if not isinstance(obj.get(key), str) or not obj[key].strip():
            raise InvalidEventError(f"missing_{key}")
    if obj["status"] not in {"NEW", "PAID", "CANCELLED"}:
        raise InvalidEventError("unsupported_status")
    return obj


def _durable_append(path, record):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def append_unique_ledger(path, obj):
    path = Path(path)
    seen = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                stored = json.loads(line)
                seen[stored["event_id"]] = stored
    if obj["event_id"] in seen:
        if seen[obj["event_id"]] != obj:
            raise ValueError("event_id_content_conflict: preserve state and investigate")
        return False
    _durable_append(path, obj)
    return True


def append_quarantine(path, record):
    _durable_append(path, record)


def raw_for_quarantine(msg):
    value = msg.value()
    return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else str(value)


def commit_message_strict(consumer, msg):
    """Synchronously commit only after a durable handled outcome; surface per-partition errors."""
    result = consumer.commit(message=msg, asynchronous=False)
    for tp in result or []:
        err = getattr(tp, "err", None)
        if err:
            raise RuntimeError(f"offset_commit_failed:{tp}:{err}")
    return result


def handle_message(consumer, msg, ledger, quarantine):
    """Apply the course poison-record policy without hiding infrastructure failures.

    Invalid source/business records -> durable quarantine -> commit.
    Valid record -> durable idempotent ledger -> commit.
    Sink/filesystem/network failures -> raise, do NOT quarantine, do NOT commit.
    Commit failures -> raise, do NOT relabel as invalid data.
    """
    try:
        obj = validate_event(parse_json_bytes(msg.value()))
    except InvalidEventError as exc:
        append_quarantine(quarantine, {
            "topic": msg.topic(), "partition": msg.partition(), "offset": msg.offset(),
            "raw": raw_for_quarantine(msg), "error": str(exc), "class": "invalid_source_record"
        })
        commit_message_strict(consumer, msg)
        return {"outcome": "QUARANTINED", "error": str(exc)}

    # Anything failing from here is an infrastructure/side-effect problem, not poison source data.
    inserted = append_unique_ledger(ledger, obj)
    commit_message_strict(consumer, msg)
    return {"outcome": "PROCESSED", "event_id": obj["event_id"], "inserted": inserted}
