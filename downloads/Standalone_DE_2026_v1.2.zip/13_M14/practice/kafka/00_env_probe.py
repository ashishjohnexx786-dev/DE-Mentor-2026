import shutil, subprocess, sys
print("python",sys.version.split()[0])
print("docker", shutil.which("docker") or "NOT_FOUND")
try:
 import confluent_kafka
 print("confluent_kafka", getattr(confluent_kafka,"__version__","installed"))
except Exception as e:
 print("confluent_kafka NOT_READY", type(e).__name__)
try:
 import pyspark
 print("pyspark",pyspark.__version__)
except Exception as e:
 print("pyspark NOT_READY", type(e).__name__)
