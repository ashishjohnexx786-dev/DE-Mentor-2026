from pathlib import Path
from confluent_kafka import Consumer
from common import handle_message

consumer = Consumer({
    "bootstrap.servers": "localhost:9092",
    "group.id": "m14-safe-v2",
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,
})
consumer.subscribe(["m14-orders"])
ledger = Path("practice/output/processed.jsonl")
quarantine = Path("practice/output/quarantine.jsonl")

try:
    idle = 0
    while idle < 10:
        msg = consumer.poll(1.0)
        if msg is None:
            idle += 1
            continue
        if msg.error():
            print("KAFKA_POLL_ERROR", msg.error())
            continue
        idle = 0
        try:
            result = handle_message(consumer, msg, ledger, quarantine)
            print(result["outcome"], "p", msg.partition(), "o", msg.offset(), result)
        except Exception as exc:
            # Critical rule: valid records with failed sinks/commits stay recoverable.
            # Stop this learner process rather than silently advancing progress.
            print("INFRASTRUCTURE_FAILURE_UNCOMMITTED", msg.partition(), msg.offset(), repr(exc))
            raise
finally:
    consumer.close()
