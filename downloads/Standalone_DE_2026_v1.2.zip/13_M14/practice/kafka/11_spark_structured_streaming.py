from pathlib import Path
from pyspark.sql import SparkSession, functions as F, types as T

schema = T.StructType([
    T.StructField("event_id", T.StringType()),
    T.StructField("order_id", T.StringType()),
    # Read amount as text first so we can distinguish missing/non-numeric/negative values explicitly.
    T.StructField("amount", T.StringType()),
    T.StructField("status", T.StringType()),
])


def classify(df):
    event = F.from_json(F.col("raw_value"), schema)
    staged = (
        df.withColumn("event", event)
        .withColumn("amount_decimal", F.expr("try_cast(event.amount AS DECIMAL(12, 2))"))
    )
    reason = (
        F.when(F.col("event").isNull(), F.lit("malformed_json"))
        .when(F.col("kafka_key").isNull() | (F.length(F.trim(F.col("kafka_key"))) == 0), F.lit("missing_kafka_key"))
        .when(F.col("event.event_id").isNull() | (F.length(F.trim(F.col("event.event_id"))) == 0), F.lit("missing_event_id"))
        .when(F.col("event.order_id").isNull() | (F.length(F.trim(F.col("event.order_id"))) == 0), F.lit("missing_order_id"))
        .when(F.col("event.amount").isNull() | (F.length(F.trim(F.col("event.amount"))) == 0), F.lit("missing_amount"))
        .when(F.col("amount_decimal").isNull(), F.lit("amount_not_numeric"))
        .when(F.col("amount_decimal") < F.lit(0), F.lit("amount_negative"))
        .when(~F.col("event.amount").rlike(r"^\d+(\.\d{1,2})?$"), F.lit("amount_precision_or_format"))
        .when(F.col("event.status").isNull() | ~F.col("event.status").isin("NEW", "PAID", "CANCELLED"), F.lit("invalid_status"))
    )
    return staged.withColumn("invalid_reason", reason)


OUT = Path("practice/output")
VALID_ROOT = str(OUT / "spark_valid")
QUARANTINE_ROOT = str(OUT / "spark_quarantine")
CHECKPOINT = str(OUT / "spark_checkpoint")


def handle_batch(batch_df, batch_id: int):
    classified = classify(batch_df).persist()
    total = classified.count()
    valid = classified.filter(F.col("invalid_reason").isNull())
    bad = classified.filter(F.col("invalid_reason").isNotNull())
    valid_count = valid.count()
    bad_count = bad.count()
    assert total == valid_count + bad_count, (total, valid_count, bad_count)

    # Retry the same batch only with this checkpoint. These two writes are NOT
    # one transaction: downstream readers must wait for the completed query batch.
    # Never delete the checkpoint while reusing output directories: batch IDs restart.
    # Retrying the same micro-batch replaces its own incomplete output.
    valid_path = f"{VALID_ROOT}/batch_id={batch_id}"
    bad_path = f"{QUARANTINE_ROOT}/batch_id={batch_id}"

    (
        valid.select(
            "kafka_key", "topic", "partition", "offset", "timestamp", "raw_value",
            F.col("event.event_id").alias("event_id"),
            F.col("event.order_id").alias("order_id"),
            F.col("amount_decimal").alias("amount"),
            F.col("event.status").alias("status"),
        )
        .write.mode("overwrite").json(valid_path)
    )
    (
        bad.select(
            "kafka_key", "topic", "partition", "offset", "timestamp", "raw_value", "invalid_reason"
        )
        .write.mode("overwrite").json(bad_path)
    )
    print(f"M14_BATCH batch_id={batch_id} total={total} valid={valid_count} quarantine={bad_count}")
    classified.unpersist()


if __name__ == '__main__':
    spark = SparkSession.builder.appName("M14KafkaValidated").master("local[2]").getOrCreate()
    
    raw = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", "localhost:9092")
        .option("subscribe", "m14-orders")
        .option("startingOffsets", "earliest")
        .load()
        .selectExpr(
            "CAST(key AS STRING) AS kafka_key",
            "CAST(value AS STRING) AS raw_value",
            "topic", "partition", "offset", "timestamp"
        )
    )
    
    query = (
        raw.writeStream
        .foreachBatch(handle_batch)
        .option("checkpointLocation", CHECKPOINT)
        .queryName("m14_validated_kafka")
        .start()
    )
    query.awaitTermination()
