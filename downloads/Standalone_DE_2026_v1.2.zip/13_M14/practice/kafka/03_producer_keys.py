import json
from confluent_kafka import Producer

def delivered(err,msg):
    if err: print("FAILED",err)
    else: print("DELIVERED",msg.topic(),msg.partition(),msg.offset(),msg.key())

p=Producer({"bootstrap.servers":"localhost:9092","enable.idempotence":True})
for i,status in enumerate(["CREATED","PAID","PACKED"],1):
    event={"event_id":f"E{i}","order_id":"O17","status":status}
    p.produce("m14-orders",key="O17",value=json.dumps(event),on_delivery=delivered)
p.flush()
