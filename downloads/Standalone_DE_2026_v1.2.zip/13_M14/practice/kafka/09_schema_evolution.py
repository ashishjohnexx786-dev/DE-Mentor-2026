def compatible(reader_required,writer_fields): return set(reader_required).issubset(set(writer_fields))
v1={"order_id":"O1","amount":19.9}
v2={"order_id":"O1","amount":19.9,"currency":"INR"}
breaking={"id":"O1","amount":"19.9 INR"}
print("v1 reader on v2",compatible(["order_id","amount"],v2))
print("v1 reader on breaking",compatible(["order_id","amount"],breaking))
assert compatible(["order_id","amount"],v2) and not compatible(["order_id","amount"],breaking)
print("Teaching simulator only; real Avro/Protobuf/JSON Schema compatibility rules are format-specific.")
