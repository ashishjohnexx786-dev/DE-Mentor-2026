partitions={0:{"end":100,"committed":96},1:{"end":100,"committed":95},2:{"end":100,"committed":20},3:{"end":100,"committed":97}}
for p,x in partitions.items(): print(p,"lag",x["end"]-x["committed"])
print("Largest lag partition",max(partitions,key=lambda p:partitions[p]["end"]-partitions[p]["committed"]))
