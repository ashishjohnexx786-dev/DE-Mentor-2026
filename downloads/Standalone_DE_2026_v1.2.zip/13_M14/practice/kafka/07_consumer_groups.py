def assign(partitions,consumers):
 out={c:[] for c in range(consumers)}
 for p in range(partitions): out[p%consumers].append(p)
 return out
for n in [1,2,3,6,8]: print(n,"consumers ->",assign(6,n))
print("Different group IDs each get an independent logical subscription.")
