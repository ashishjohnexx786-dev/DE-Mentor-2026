from hashlib import sha256
PARTITIONS=4
def learning_partition(key): return int(sha256(key.encode()).hexdigest()[:8],16)%PARTITIONS
seq=[("S1","CREATED"),("S2","CREATED"),("S1","LOADED"),("S3","CREATED"),("S1","DEPARTED"),("S2","PAID")]
offsets=[0]*PARTITIONS
for key,status in seq:
 p=learning_partition(key); o=offsets[p]; offsets[p]+=1; print(key,status,"partition",p,"offset",o)
print("NOTE: this is a teaching partitioner, not a claim about Kafka's exact default hash implementation.")
