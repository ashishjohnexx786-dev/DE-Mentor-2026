# Instructor videos and complete books

Preserve useful instructor videos. Read each link’s scope: it can teach the main topic, support a prerequisite or refresh an earlier lesson. Repeated sources are not repeated compulsory assignments.

A printed time range is a start/stop instruction, usually requiring a manual stop. Published chapters and metadata are not full-playback verification. A useful recording without a verified bounded range remains labelled **Optional visual — no verified bounded range**. Two M07 topics use complete written explanations and diagrams because no suitable instructor demonstration was assigned. No generated videos are included.
