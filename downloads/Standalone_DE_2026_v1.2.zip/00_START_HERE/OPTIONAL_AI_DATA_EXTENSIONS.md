# Optional AI-ready data extensions

Retained from the supplied workbook. These extensions do not replace or add required units to the M00–M19 course. Finish each named core module first.

## After M08 — Unstructured ingestion + metadata
Ingest a small PDF/text corpus; preserve source URI/hash/timestamp/content type; extract text into a documented record contract.
Same source/landing/quarantine/idempotency principles as normal ingestion.
Priority: Medium later. Required before applications: no.
Official further reading: https://docs.databricks.com/aws/en/agents/tutorials/ai-cookbook/quality-data-pipeline-rag

## After M09 — AI dataset transformation + quality
Create clean chunk/document metadata tables; validate required fields, duplicates, empty content and source-to-output reconciliation.
AI-ready data still needs deterministic transformation and quality contracts.
Priority: Medium later. Required before applications: no.
Official further reading: https://docs.databricks.com/aws/en/agents/gen-ai-challenges

## After M14 — Streaming feed awareness for AI/agents
Translate Kafka event semantics into near-real-time feature/context/update feeds; keep exactly-once claims cautious.
AI consumers may need fresh events, but streaming fundamentals come first.
Priority: Optional target-driven. Required before applications: no.
Official further reading: https://kafka.apache.org/documentation/

## After M15 — Cloud retrieval/search translation
Map the course's Azure/Fabric primitives to a managed retrieval/vector/search service conceptually; do not learn three clouds deeply.
Cloud implementation belongs after one primary cloud is understood.
Priority: Optional target-driven. Required before applications: no.
Official further reading: https://learn.microsoft.com/en-us/fabric/data-engineering/data-engineering-overview

## After M16 — AI governance, lineage and access
Add PII classification, least privilege, lineage, retention and audit fields to an AI-facing dataset.
AI increases the cost of weak governance; these are DataOps/security responsibilities.
Priority: High after M16. Required before applications: no.
Official further reading: https://docs.databricks.com/aws/en/agents/gen-ai-challenges

## After M17 — RAG / agent data architecture
Draw source -> ingest -> clean/chunk -> index/retrieval -> model/agent -> observability boundaries; identify ownership and failure modes.
System design is useful only after core pipelines/storage/security are understood.
Priority: Medium after M17. Required before applications: no.
Official further reading: https://docs.databricks.com/aws/en/agents/tutorials/ai-cookbook/quality-data-pipeline-rag

## After M18 — Optional AI-ready portfolio extension
Add one bounded extension to an existing DE project: document ingestion + metadata + quality + retrieval-ready table/index handoff. Keep the DE pipeline as the main artifact.
Shows AI-era relevance without turning the portfolio into an ML course.
Priority: Optional differentiator. Required before applications: no.
Official further reading: https://docs.databricks.com/aws/en/agents/tutorials/ai-cookbook/quality-data-pipeline-rag
