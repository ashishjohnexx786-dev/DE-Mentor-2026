# Complete course index

Study edition 1.2 · 314 units. Page means the printed/PDF page of the module learner book. Module and lesson times are rough planning allowances, not deadlines.


## M00 — Computer and study foundations

4–6 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE00-01 | Files, folders, drives and paths | 4 |
| DE00-02 | File extensions and common data files | 7 |
| DE00-03 | Download, ZIP, extract, copy, move and rename | 10 |
| DE00-04 | Install only the software this stage needs | 13 |
| DE00-05 | VS Code from zero | 16 |
| DE00-06 | Terminal fundamentals | 19 |
| DE00-07 | Read errors and repair one cause at a time | 22 |
| DE00-08 | Study, evidence, attempts and review discipline | 25 |

## M01 — Data and essential Excel

8–10 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE01-01 | What data is: tables, records, fields and data types | 4 |
| DE01-02 | Grain: what one row represents | 11 |
| DE01-03 | Keys, duplicates and missing values | 14 |
| DE01-04 | Data quality and useful validation | 17 |
| DE01-05 | Meet Excel: workbook, worksheet, cells and formulas | 20 |
| DE01-06 | Enter, save and structure tabular data safely | 23 |
| DE01-07 | Sort and filter without damaging records | 26 |
| DE01-08 | Basic formulas and essential functions | 29 |
| DE01-09 | Relative and absolute references | 32 |
| DE01-10 | Excel Tables and structured working habits | 35 |
| DE01-11 | Practical cleaning and exact lookups | 38 |
| DE01-12 | PivotTables and Power Query awareness | 41 |
| DE01-13 | Chart choice and basic visual communication | 44 |
| DE01-14 | Reconciliation, sanity checks and source preservation | 47 |
| DE01-15 | A complete small workflow: inspect, calculate, validate, explain and save | 50 |

## M02 — SQL foundations

10–12 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE02-01 | Database, table, row, column and query mental model | 4 |
| DE02-02 | SELECT, aliases and LIMIT | 7 |
| DE02-03 | WHERE and comparison operators | 10 |
| DE02-04 | AND, OR, NOT and parentheses | 13 |
| DE02-05 | ORDER BY, DISTINCT and result inspection | 15 |
| DE02-06 | NULL, IS NULL and COALESCE | 18 |
| DE02-07 | Arithmetic expressions and safe calculations | 21 |
| DE02-08 | Aggregate functions | 24 |
| DE02-09 | GROUP BY and grouped grain | 27 |
| DE02-10 | HAVING after aggregation | 30 |
| DE02-11 | CASE for business categories | 32 |
| DE02-12 | String and date basics | 35 |
| DE02-13 | Simple subqueries and IN/EXISTS awareness | 38 |
| DE02-14 | Debugging and validation workflow | 41 |

## M03 — SQL for engineering

12–16 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE03-01 | INNER JOIN and LEFT JOIN | 4 |
| DE03-02 | Cardinality, row multiplication and join validation | 7 |
| DE03-03 | UNION and UNION ALL | 10 |
| DE03-04 | String functions for cleaning and standardization | 13 |
| DE03-05 | Dates, timestamps and time analysis | 16 |
| DE03-06 | Subqueries and nested logic | 19 |
| DE03-07 | CTEs and readable multi-step SQL | 22 |
| DE03-08 | Window functions and PARTITION BY | 25 |
| DE03-09 | ROW_NUMBER, ranking and LAG/LEAD | 28 |
| DE03-10 | Advanced aggregation and multi-grain reasoning | 31 |
| DE03-11 | PostgreSQL setup, schemas and dialect awareness | 34 |
| DE03-12 | Constraints and transactions | 37 |
| DE03-13 | Indexes and EXPLAIN basics | 40 |
| DE03-14 | Views and reusable database logic | 43 |
| DE03-15 | Integrated unseen SQL challenge | 46 |
| DE03-16 | Timed SQL interview set and explanation | 49 |

## M04 — Python foundations

14–18 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE04-01 | Python setup and first program | 4 |
| DE04-02 | Variables, data types and operators | 7 |
| DE04-03 | Strings and formatting | 10 |
| DE04-04 | Conditions and boolean logic | 13 |
| DE04-05 | Lists, tuples, sets and dictionaries | 16 |
| DE04-06 | Loops and iteration | 19 |
| DE04-07 | Functions and scope | 22 |
| DE04-08 | Modules, imports and project structure | 25 |
| DE04-09 | Exceptions and debugging basics | 28 |
| DE04-10 | Files, paths, CSV and JSON I/O | 31 |
| DE04-11 | pandas foundations: load, inspect, filter and aggregate | 34 |
| DE04-12 | Practical Big-O intuition | 37 |
| DE04-13 | Coding drills: lists and strings | 40 |
| DE04-14 | Coding drills: dictionaries and sets | 43 |
| DE04-15 | Stack, queue, search and sort basics | 46 |
| DE04-16 | Integrated Python checkpoint and reproducible script habits | 49 |

## M05 — Python for data engineering

10–14 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE05-01 | CSV properly: parse, inspect, preserve raw | 4 |
| DE05-02 | JSON and JSONL from zero | 6 |
| DE05-03 | Paths, folders and deterministic batch files | 8 |
| DE05-04 | pandas profiling before transformation | 10 |
| DE05-05 | Cleaning with pandas and rejected rows | 12 |
| DE05-06 | pandas merge, cardinality and aggregation | 14 |
| DE05-07 | Data validation: record, batch and relationship rules | 16 |
| DE05-08 | HTTP and REST APIs from zero | 18 |
| DE05-09 | Calling APIs safely with requests | 20 |
| DE05-10 | Pagination and authentication without leaking secrets | 22 |
| DE05-11 | Retries, rate limits and partial failure | 24 |
| DE05-12 | Python + PostgreSQL with SQLAlchemy | 26 |
| DE05-13 | Configuration, environment variables and secret hygiene | 28 |
| DE05-14 | Logging, testing and reusable pipeline code | 30 |
| DE05-15 | Integrated Python data-engineering pipeline | 32 |

## M06 — Linux, Git and reproducible projects

8–10 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE06-01 | Verify WSL2 and choose a safe Linux workspace | 4 |
| DE06-02 | Linux navigation and safe file operations | 7 |
| DE06-03 | Pipes, redirection, command history and inspection | 10 |
| DE06-04 | Permissions, packages, sudo and command safety | 12 |
| DE06-05 | Git state: init, status, add, commit, diff and log | 14 |
| DE06-06 | Branches, merges and real conflict resolution | 16 |
| DE06-07 | GitHub remotes: push, fetch, pull and tracking | 18 |
| DE06-08 | Pull requests and review workflow | 20 |
| DE06-09 | Python virtual environments inside a repository | 22 |
| DE06-10 | .gitignore, secrets and repository hygiene | 24 |
| DE06-11 | restore, revert, reflog and safe history repair | 26 |
| DE06-12 | Shell scripts, exit codes and environment-driven commands | 29 |
| DE06-13 | Repository handoff and clean-clone reproducibility | 31 |

## M07 — PostgreSQL and data modeling

8–11 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE07-01 | Verify PostgreSQL connection and database/schema context | 4 |
| DE07-02 | Tables, data types and explicit DDL | 8 |
| DE07-03 | Primary keys, foreign keys and constraints | 11 |
| DE07-04 | Transactions, DML and UPSERT | 14 |
| DE07-05 | Indexes and EXPLAIN evidence | 17 |
| DE07-06 | Operational vs analytical modeling and normalization | 20 |
| DE07-07 | Facts, dimensions and star-schema grain | 23 |
| DE07-08 | Surrogate keys and referential integrity | 27 |
| DE07-09 | Slowly Changing Dimension Type 2 history | 30 |
| DE07-10 | Build and validate a small analytical database | 34 |
| DE07-11 | Bulk loading with COPY / staging boundaries | 38 |
| DE07-12 | Schemas, roles and least-privilege boundaries | 43 |
| DE07-13 | Schema change, backup/restore and handoff validation | 46 |

## M08 — Files, APIs and ingestion

10–13 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE08-01 | Ingestion architecture: source -> landing -> staging | 5 |
| DE08-02 | Defensive CSV ingestion | 8 |
| DE08-03 | JSON and nested-record ingestion | 11 |
| DE08-04 | Parquet ingestion and metadata inspection | 14 |
| DE08-05 | REST API contracts, status codes and timeouts | 17 |
| DE08-06 | API authentication, pagination and rate limits | 20 |
| DE08-07 | Retries, backoff, jitter and transient failures | 23 |
| DE08-08 | Database extraction and safe query boundaries | 26 |
| DE08-09 | Historical batch landing and raw metadata | 29 |
| DE08-10 | Incremental loads and high-water marks | 32 |
| DE08-11 | CDC concepts and change-event semantics | 35 |
| DE08-12 | Schema drift, compatibility, time zones and quarantine | 38 |
| DE08-13 | Checkpoint/state management and replay safety | 41 |
| DE08-14 | Idempotent landing and content identity | 43 |
| DE08-15 | Late-arriving data, event time and processing time | 46 |
| DE08-16 | Ingestion observability: counts, latency and run metadata | 49 |
| DE08-17 | Ingestion integration, reconciliation and backfill proof | 52 |

## M09 — ETL/ELT, dbt transformations and data quality

9–12 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE09-01 | ETL vs ELT and transformation boundaries | 4 |
| DE09-02 | Raw, staging, clean/intermediate and serving contracts | 7 |
| DE09-03 | Deterministic transformations and production SQL style | 10 |
| DE09-04 | Deduplication and key integrity | 13 |
| DE09-05 | Schema checks and data contracts | 16 |
| DE09-06 | Source-to-target reconciliation | 19 |
| DE09-07 | Incremental processing and safe reruns | 22 |
| DE09-08 | Failure behavior, retries, quarantine and atomic state | 25 |
| DE09-09 | Lineage, run metadata and auditability | 28 |
| DE09-10 | Build and defend a reliable batch pipeline | 31 |
| DE09-11 | dbt-style project anatomy, sources and dependency graph | 34 |
| DE09-12 | Executable data tests, quality severity and CI boundaries | 38 |
| DE09-13 | Incremental models, materialization, documentation and handoff | 41 |

## M10 — Docker and Apache Airflow

12–16 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE10-01 | Why containers exist | 4 |
| DE10-02 | Images and containers | 7 |
| DE10-03 | Writing a Dockerfile | 10 |
| DE10-04 | Ports | 13 |
| DE10-05 | Volumes and persistence | 16 |
| DE10-06 | Networks and service communication | 19 |
| DE10-07 | Compose, configuration and secrets | 22 |
| DE10-08 | Why orchestration exists | 25 |
| DE10-09 | Airflow architecture and UI | 28 |
| DE10-10 | DAGs, tasks and dependencies | 31 |
| DE10-11 | TaskFlow, operators and task communication | 34 |
| DE10-12 | Scheduling and data intervals | 37 |
| DE10-13 | Retries, timeouts and failure behavior | 40 |
| DE10-14 | Parameters and task communication | 43 |
| DE10-15 | Connections, variables and secrets | 46 |
| DE10-16 | Sensors and waiting | 49 |
| DE10-17 | Logs and debugging | 52 |
| DE10-18 | Catchup, backfills and reprocessing | 55 |
| DE10-19 | Integration and production-style orchestration | 58 |

## M11 — Storage, Parquet and lakehouse foundations

6–8 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE11-01 | Row vs columnar storage; where Parquet fits | 4 |
| DE11-02 | Parquet schema, row groups and metadata | 7 |
| DE11-03 | Projection, predicates and analytical reads | 10 |
| DE11-04 | Compression, small files and compaction | 13 |
| DE11-05 | Partitioning strategy and over-partitioning | 16 |
| DE11-06 | Lake vs warehouse vs lakehouse | 19 |
| DE11-07 | Delta tables, transaction log and ACID concepts | 22 |
| DE11-08 | MERGE/upsert and current-state records | 25 |
| DE11-09 | Schema enforcement, controlled evolution and compatibility | 28 |
| DE11-10 | Time travel, retention, VACUUM safety and medallion checkpoint | 31 |

## M12 — Distributed processing with Spark

12–16 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE12-01 | Why Spark exists: driver, executors, partitions and tasks | 4 |
| DE12-02 | PySpark setup, SparkSession and laptop-safe local mode | 7 |
| DE12-03 | DataFrames and explicit schemas | 10 |
| DE12-04 | Spark SQL and expression equivalence | 13 |
| DE12-05 | Lazy transformations and actions | 16 |
| DE12-06 | Jobs, stages, tasks and physical plans | 19 |
| DE12-07 | repartition vs coalesce | 22 |
| DE12-08 | Aggregations and shuffle cost | 25 |
| DE12-09 | Joins and broadcast strategy | 28 |
| DE12-10 | Join correctness, fan-out and reconciliation | 31 |
| DE12-11 | Data skew | 34 |
| DE12-12 | Adaptive Query Execution (AQE) | 37 |
| DE12-13 | Caching and persistence | 40 |
| DE12-14 | Parquet I/O and partition pruning | 43 |
| DE12-15 | Built-in functions vs Python UDFs | 46 |
| DE12-16 | Driver safety: collect, toPandas and bounded inspection | 49 |
| DE12-17 | Testing and debugging Spark transformations | 52 |
| DE12-18 | Integrated PySpark pipeline and distributed-processing checkpoint | 55 |

## M13 — Delta Lake and reliable tables

8–11 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE13-01 | Data Lake vs Warehouse vs Lakehouse | 4 |
| DE13-02 | Why plain files are not tables | 8 |
| DE13-03 | Delta transaction log, ACID and table versions | 11 |
| DE13-04 | Create, read, update and delete | 15 |
| DE13-05 | Schema enforcement and schema evolution | 18 |
| DE13-06 | Time travel and version history | 21 |
| DE13-07 | MERGE, upserts and idempotent incremental loads | 24 |
| DE13-08 | Slowly Changing Dimension Type 2 with Delta | 28 |
| DE13-09 | Bronze, Silver and Gold lakehouse layers | 31 |
| DE13-10 | Compaction, OPTIMIZE, VACUUM and maintenance boundaries | 35 |
| DE13-11 | Integrated lakehouse pipeline and debugging checkpoint | 39 |

## M14 — Kafka and streaming pipelines

10–14 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE14-01 | Batch vs streaming | 4 |
| DE14-02 | Events, brokers and topics | 8 |
| DE14-03 | Producers and message keys | 12 |
| DE14-04 | Consumers and safe processing | 16 |
| DE14-05 | Partitions and ordering | 20 |
| DE14-06 | Offsets, group position and replay | 23 |
| DE14-07 | Consumer groups and scaling | 26 |
| DE14-08 | Delivery semantics and idempotency | 29 |
| DE14-09 | Serialization, schemas and evolution | 33 |
| DE14-10 | Python producer and consumer workflow | 37 |
| DE14-11 | Spark Structured Streaming + Kafka | 41 |
| DE14-12 | Lag, failures and streaming operations | 45 |

## M15 — Azure and Microsoft Fabric

10–14 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE15-01 | Cloud fundamentals for data engineers | 4 |
| DE15-02 | Identity, IAM and least privilege | 8 |
| DE15-03 | Azure Storage concepts and OneLake | 11 |
| DE15-04 | Fabric workspace and item model | 14 |
| DE15-05 | OneLake paths, files, tables and shortcuts | 17 |
| DE15-06 | Fabric Lakehouse and Delta tables | 20 |
| DE15-07 | Fabric notebooks | 23 |
| DE15-08 | Spark in Fabric | 26 |
| DE15-09 | Fabric Data Pipelines | 29 |
| DE15-10 | SQL analytics endpoint and warehouse choice | 32 |
| DE15-11 | Medallion architecture in Fabric | 36 |
| DE15-12 | Incremental loads and MERGE in cloud | 39 |
| DE15-13 | Permissions, connections and secrets | 43 |
| DE15-14 | Monitoring, reliability and cost awareness | 46 |
| DE15-15 | Git, deployment and environment separation | 49 |
| DE15-16 | End-to-end Fabric data engineering case | 52 |

## M16 — DataOps, quality, security and observability

10–13 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE16-01 | Production mindset | 4 |
| DE16-02 | Testing strategy for data engineering | 7 |
| DE16-03 | Automated quality gates | 10 |
| DE16-04 | Continuous Integration fundamentals | 13 |
| DE16-05 | GitHub Actions for data projects | 16 |
| DE16-06 | Dev, test and prod environments | 19 |
| DE16-07 | Deployment and rollback | 22 |
| DE16-08 | Secrets and credential safety | 25 |
| DE16-09 | RBAC and least privilege | 28 |
| DE16-10 | PII, encryption and masking | 31 |
| DE16-11 | Metadata, lineage and governance | 34 |
| DE16-12 | Observability for data pipelines | 37 |
| DE16-13 | Incidents, runbooks and root cause | 40 |
| DE16-14 | Terraform and IaC foundations | 43 |

## M17 — Architecture and engineering decisions

8–10 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE17-01 | From requirements to architecture | 4 |
| DE17-02 | Batch vs streaming decisions | 8 |
| DE17-03 | Warehouse vs lakehouse | 11 |
| DE17-04 | Managed service vs build yourself | 14 |
| DE17-05 | Scaling and bottleneck reasoning | 17 |
| DE17-06 | Reliability and failure domains | 20 |
| DE17-07 | Cost-aware architecture | 23 |
| DE17-08 | Security and governance by design | 26 |
| DE17-09 | Promotion foundations: CDC, Contracts, Vault, Mesh, Kubernetes | 30 |
| DE17-10 | Architecture review and defense | 34 |

## M18 — Portfolio projects and production capstone

35–50 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| P01-01 | Read the batch-pipeline brief and define business questions | 6 |
| P01-02 | Profile every source; state grain, keys and defects | 8 |
| P01-03 | Draw architecture and create the repository scaffold | 10 |
| P01-04 | Preserve raw landing evidence and source/run metadata | 13 |
| P01-05 | Build ingestion with validation and quarantine | 15 |
| P01-06 | Add incremental state and rerun-safe identity | 17 |
| P01-07 | Build trusted PostgreSQL/dbt-style transformations | 20 |
| P01-08 | Add tests and source-to-target reconciliation | 22 |
| P01-09 | Automate the repeatable run/orchestration path | 25 |
| P01-10 | Inject failure, diagnose, repair and prove recovery | 28 |
| P01-11 | Finish README, runbook, architecture and evidence index | 30 |
| P01-12 | Clean-clone rerun and project defense | 33 |
| P02-01 | Read the analytics-engineering brief and define outputs | 36 |
| P02-02 | Profile billing/customer sources and state grains | 38 |
| P02-03 | Design facts, dimensions, keys and serving grain | 40 |
| P02-04 | Create dbt project, sources and dependency graph | 42 |
| P02-05 | Build thin staging models with explicit contracts | 44 |
| P02-06 | Build dimensional marts without fan-out | 46 |
| P02-07 | Add data tests and critical quality gates | 48 |
| P02-08 | Implement incremental model/update behavior | 51 |
| P02-09 | Preserve history with snapshot/SCD reasoning | 54 |
| P02-10 | Add orchestration and reproducible run order | 56 |
| P02-11 | Inject duplicate/relationship/partial-run failures | 59 |
| P02-12 | Document lineage, runbook, limitations and evidence | 61 |
| P02-13 | Clean-clone build and analytics-platform defense | 63 |
| P03-01 | Read the scalable-lakehouse brief and define scale risks | 66 |
| P03-02 | Profile event schema, grain, keys and timestamps | 69 |
| P03-03 | Create Spark environment and explicit schemas | 71 |
| P03-04 | Build deterministic distributed transformations | 74 |
| P03-05 | Join reference data and validate cardinality | 77 |
| P03-06 | Reason about partitions, shuffle and skew | 79 |
| P03-07 | Write Parquet with justified partition strategy | 82 |
| P03-08 | Apply Delta-style incremental merge/idempotency | 85 |
| P03-09 | Define Bronze/Silver/Gold lakehouse contracts | 88 |
| P03-10 | Handle schema evolution and supplied failure cases | 91 |
| P03-11 | Inspect plans/performance and prove equivalent results | 93 |
| P03-12 | Map the design to Fabric/cloud deployment | 96 |
| P03-13 | Clean rerun, reconcile outputs and defend trade-offs | 98 |
| CAP-01 | Read capstone requirements and write source contracts | 101 |
| CAP-02 | Design architecture and record major ADRs | 103 |
| CAP-03 | Build multi-source ingestion and raw evidence | 105 |
| CAP-04 | Implement critical quality, quarantine and reconciliation | 107 |
| CAP-05 | Build trusted warehouse/dbt serving layer | 109 |
| CAP-06 | Orchestrate dependencies, retries and bounded backfills | 111 |
| CAP-07 | Use Spark/Delta where scale justifies it | 114 |
| CAP-08 | Design Fabric deployment, access and secret boundaries | 117 |
| CAP-09 | Add CI/CD, monitoring, alerts and runbook | 119 |
| CAP-10 | Open incident pack, diagnose and recover safely | 122 |
| CAP-11 | Reproduce from clean state and freeze evidence bundle | 124 |
| CAP-12 | Final technical defense and Gate 7 readiness | 126 |

## M19 — Interviews, technical English and job launch

12–16 study days including revision/test.

| Unit | Topic | Book page |
| --- | --- | ---: |
| DE19-01 | Truthful one-page Data Engineer resume | 4 |
| DE19-02 | GitHub and project portfolio final polish | 7 |
| DE19-03 | LinkedIn/professional profile without overclaiming | 9 |
| DE19-04 | Degree-aware job targeting: apply/skip rules | 11 |
| DE19-05 | SQL interview drills | 13 |
| DE19-06 | Python interview drills | 16 |
| DE19-07 | Data-engineering concepts and troubleshooting drills | 19 |
| DE19-08 | Project walkthrough interview | 22 |
| DE19-09 | Architecture/system-design defense for junior roles | 25 |
| DE19-10 | Behavioral answers and career-transition story | 27 |
| DE19-11 | Technical English: explain code, failures and decisions clearly | 29 |
| DE19-12 | Application tracker, feedback loop and weekly repair cycle | 31 |
| DE19-13 | Timed coding test: arrays, strings and hash-map problems | 33 |
| DE19-14 | Combined SQL + Python interview simulation | 35 |