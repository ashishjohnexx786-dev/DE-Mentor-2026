# Start here — Standalone Data Engineer 2026, edition 1.2

1. Extract the complete ZIP on your laptop. Keep the ZIP as your recovery copy.
2. Open HOW_TO_STUDY.pdf in this folder. It explains your daily routine, estimated module times, exact files, practical work and help when stuck.
3. Open ../00_STUDY_MODULES/M00/M00_Learner_Book.pdf. Start at DE00-01 using Contents or bookmarks.
4. Watch the assigned instructor video, reproduce the example and save an independent task before opening a protected review.
5. Finish each module with Quick Revision, Module Revision Test and its separate Protected Answers. Use the seven gates at the boundaries in HOW_TO_STUDY.pdf.

The complete route contains M00–M19, 264 formal lessons and 50 M18 project phases: 314 units. Each module has its own learner folder, revision, test and protected answers. M00–M03 share one supporting lab folder because they reuse source files; the study books remain separate.

STUDY_INDEX.xlsx is an optional offline tracker. You can instead track your study in the mentor. They do not synchronize automatically. COURSE_INDEX.md lists all units and their actual book pages. VIDEO_ASSIGNMENTS.csv records each lesson's visual sources and scope.

Read VERIFICATION.md for the actual checks and native-runtime limits. A source link and published chapter range are not proof of full video playback. No generated videos are included.
