# Package layout

00_STUDY_MODULES is the learner route. Original module folders contain supporting practice and compatible copies of books. 09_GATES contains the seven assessments. 12_REVISION_AND_TESTS is the compatible original assessment route; its books match the normalized learner copies. 99_ADMIN_AUDIT contains only this edition’s verification evidence.

Do not mix these files with an older extracted package. Open this edition in a new folder; your old ZIP can remain as a backup.
