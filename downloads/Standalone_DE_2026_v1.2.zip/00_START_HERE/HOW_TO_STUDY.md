# Your beginner study guide

Standalone Data Engineer 2026 · Study edition 1.2


## 1. Your route and a realistic time budget

You can start this course without a technical degree. The first job is to learn one small action, practise it, check the result and explain it. You do not need to understand the whole data-engineering system on day one.

Plan for approximately 230–310 focused study days at six hours a day: about 1,380–1,860 hours. At six study days per week, this is roughly 9–12 calendar months. These are author planning estimates for this complete package, not measured completion times. They include ordinary practice and repair; major interruptions or repeated setup problems can extend them. Completing the course does not promise an interview or a job by that date.

The module ranges below total 216–290 study days. Reserve another 14–21 days across the seven gates, including their reviews and changed retries. That gives an unrounded total of 230–311 days. A study day means six hours actually learning or practising; meals, scrolling, downloads running unattended and breaks do not count.

Do not divide the number of PDF pages by your reading speed. A short SQL page may need an hour of experiments. A familiar explanation may take ten minutes. Most lessons need roughly half a day to one day; a difficult lesson may take two days. One M18 phase can occupy several sessions. Judge completion by the result you can produce, not by the clock.

| Module / topic | Lessons or phases | Study days at 6 h/day |
| --- | --- | --- |
| M00 · Computer and study foundations | 8 | 4–6 |
| M01 · Data and essential Excel | 15 | 8–10 |
| M02 · SQL foundations | 14 | 10–12 |
| M03 · SQL for engineering | 16 | 12–16 |
| M04 · Python foundations | 16 | 14–18 |
| M05 · Python for data engineering | 15 | 10–14 |
| M06 · Linux, Git and reproducible projects | 13 | 8–10 |
| M07 · PostgreSQL and data modeling | 13 | 8–11 |
| M08 · Files, APIs and ingestion | 17 | 10–13 |
| M09 · ETL/ELT, dbt transformations and data quality | 13 | 9–12 |
| M10 · Docker and Apache Airflow | 19 | 12–16 |
| M11 · Storage, Parquet and lakehouse foundations | 10 | 6–8 |
| M12 · Distributed processing with Spark | 18 | 12–16 |
| M13 · Delta Lake and reliable tables | 11 | 8–11 |
| M14 · Kafka and streaming pipelines | 12 | 10–14 |
| M15 · Azure and Microsoft Fabric | 16 | 10–14 |
| M16 · DataOps, quality, security and observability | 14 | 10–13 |
| M17 · Architecture and engineering decisions | 10 | 8–10 |
| M18 · Portfolio projects and production capstone | 50 | 35–50 |
| M19 · Interviews, technical English and job launch | 14 | 12–16 |

The ranges include each module’s learner work, quick revision, module test and answer review. Gates are counted separately above. Excel gets a short foundation block because this course begins with understanding tables and checking results; advanced spreadsheet specialization is not a separate requirement here.

Use six study days and one recovery day each week. The recovery day can be a full rest day. If you prefer seven study days, protect sleep and take shorter recovery days when tired. More than six hours is optional; do not use extra hours to stack new videos while practical work remains unfinished.


## 2. What to open first

On the laptop, keep the downloaded complete ZIP unchanged as your recovery copy. In File Explorer, right-click it and choose Extract All. Work from the extracted ordinary folder. Do not edit documents while browsing inside the ZIP. The folder containing 00_START_HERE and 00_STUDY_MODULES is the course root.

First open 00_START_HERE/HOW_TO_STUDY.pdf — this guide. Then open 00_STUDY_MODULES/M00/M00_Learner_Book.pdf and use its Contents page to select DE00-01. Read only today’s lesson and the setup it asks for. You do not need to open every PDF now.

Phone: use it for the PDF and instructor video beside your laptop. Laptop: use it for files, spreadsheets, SQL, Python and later engineering tools. A phone-only reading session is useful revision, but it does not replace a lab that requires the laptop.

The mentor is an alternative front door to the same books and tasks. Choose the module, select the first unfinished lesson, open its video and book, then download its practice. The mentor’s evidence note stores text, not your SQL scripts or workbook files. Save those files on your computer.

Start with File Explorer, Notepad and a browser. Install later software only when the module’s setup guide asks for it. On an i3/8 GB laptop, close heavy applications and run one lab environment at a time. Use the provided small fixtures first. A local simulator teaches a pattern; it does not certify that you ran the corresponding cloud or distributed engine.

| File or label | When to open it | What you do |
| --- | --- | --- |
| Mxx_Learner_Book.pdf | Each study day | Read the lesson, watch its source and perform the worked example and independent task. |
| Practice / labs folder | During the lesson | Open or copy the named input file; create your own output beside your attempt. |
| Explained Reviews | After a saved lesson/cluster attempt | Compare the worked solution, locate the first wrong step, close the review and retry. |
| Mxx_Quick_Revision_Book.pdf | After the module; later recall sessions | First recall without looking, then check and repair gaps. |
| Mxx_Module_Revision_Test.pdf | After module revision | Attempt its questions under the conditions printed in the test. |
| PROTECTED_OPEN_AFTER_ATTEMPT / Answers | After saving the module test | Use the reasoning and marking guide to review your actual answers. |
| G01–G07 | At the boundaries in section 8 | Complete A, review A, attempt fresh B, then review B. |
| STUDY_INDEX.xlsx | Optional tracking | Record status and evidence. It does not automatically sync with the mentor. |


## 3. A six-hour day you can follow

Use the following as a routine, not an examination timetable. If the video is short, move the spare time into practice. If the setup fails, that session becomes a setup-repair session; do not pretend you completed the lesson. Breaks sit between blocks and are additional to the six focused hours.

| Block | Minutes | Concrete action |
| --- | --- | --- |
| Recall yesterday | 20 | Close the notes. Explain one idea and repeat one small action from memory. |
| Prepare today | 30 | Open one lesson. Read its purpose, prerequisite and new words. Find its named input files. |
| Watch actively | 60 | Watch the assigned range; pause, predict the next step and connect it to the book. Do not chase recommendations. |
| Follow the example | 90 | Type or click the book’s guided steps yourself. Save the working example and inspect its result. |
| Try it yourself | 90 | Start the independent task without the answer. Use the supplied changed input or question. |
| Check and repair | 50 | Compare counts, values and files. Read the protected review only after saving an attempt; fix the cause and retry. |
| Close the day | 20 | Save evidence, explain the result aloud and write tomorrow’s exact lesson/step. |

Total: 360 minutes. A practical clock could run 09:00–12:00 and 14:00–17:00 plus short breaks; shift the clock to your household schedule. Stop the optional stopwatch during meals or scrolling. There is no compulsory 25-minute timer and no timer-based mastery rule.

You do not have to finish a lesson every day. End a session at a saved checkpoint: for example, “DE04-05: guided loop works; tomorrow start the independent task.” Never restart the whole chapter because you stopped halfway through.


## 4. How one lesson becomes a skill

Step 1 — Locate the task. Headings such as “Follow with me once” or “Guided example” mean reproduce the demonstrated action. “Try it yourself”, “Independent practice”, “You do it alone” and “changed retry” mean you must produce your own attempt. “Check your work”, “Expected result” and “Validation” tell you how to judge it. Some earlier source headings use these alternate words; they describe the same sequence.

Step 2 — Read a small amount. Read the purpose and vocabulary, then explain the aim in a sentence: “I need to find orders whose quantity is at least two.” If you cannot state the aim, ask about that before typing commands.

Step 3 — Watch with a question. Before pressing Play, know what you are looking for: a row, a join, a folder, a failed request or a retry. Pause after a meaningful step. Predict what happens next. A tutorial can use a different dataset or older screen; the lesson’s supplied files and version notes define your practical task.

Step 4 — Reproduce the worked example. Open the named tool and file. Type short SQL and Python examples rather than only reading them. It is fine to copy a long setup command exactly, but first identify where it must run and which folder it uses. Run a small portion, inspect the result, then continue. Do not paste SQL into a Windows terminal or a shell command into a SQL editor.

Step 5 — Make an independent attempt. Save the worked example, start a separate attempt file and solve the printed task. Reading definitions and official documentation is allowed during ordinary practice unless the task says otherwise. Keep the protected solution closed. An error is part of the attempt; save it instead of silently replacing it with the answer.

Step 6 — Validate. Compare the actual output with the stated rule. A command that exits successfully is not enough: check the row count, total, required columns, duplicate keys and output location that matter for that task. The lesson specifies which checks are relevant; do not invent a large checklist for a small exercise.

Step 7 — Review and retry. After saving your attempt, open the matching protected review. Identify the first step at which your reasoning differs. Write one sentence about that cause, close the review and retry the changed task. Copying a corrected answer with the review open is useful demonstration, but it is not an independent retry.

Step 8 — Finish only when you have evidence. You can reproduce the main action, check the result and explain why it works. Use the mentor’s four checks as reminders. Its Complete button records your judgement; it does not automatically grade your work. If one condition is weak, leave the lesson open or reopen it.


## 5. A real example from your first module

For DE00-01, open M00_Learner_Book.pdf at DE00-01. Watch the listed File Explorer segments, then press Windows key + E and follow the book. Create the requested folders. Write folder-map.txt in the evidence folder, save it, close it and reopen it. This reopened file is evidence of the practical skill; a screenshot of a watched video is not.

For DE01-02, the question is what one row represents. Watch the reused introductory visual only if you need the reminder. Read the envelope/order-line example and the printed table. State a grain sentence before adding values. Follow the book’s own worked and independent tasks. At this early stage, paper or Notepad is enough unless the lesson asks for a workbook; you do not need SQL yet.

A small demonstration: order O1 has two lines with line amounts 100 and 50. Its order-level delivery fee is 20, repeated beside each line. Goods total 150. Delivery belongs to the order once, so goods plus delivery total 170. Adding the repeated fee twice gives 190. The problem is not addition; it is mixing a line-level amount with an order-level amount. Explain that distinction before attempting the book’s different input.

Save three short sentences: “One row represents …”; “I summed … because …”; “I counted the delivery fee … times because …”. Keep the calculations or workbook too. You do not need to rewrite every paragraph in the PDF.


## 6. Your first week, step by step

This is a suggested opening week, not a deadline. If a step takes longer, carry it into the next day and move the later entries forward.

| Study day | Open / do | Save before stopping |
| --- | --- | --- |
| 1 | Read this guide. Open M00 DE00-01 and DE00-02. Practise folders, paths, extensions and plain text. | Your reopened folder map and the extension exercise. |
| 2 | M00 DE00-03 and DE00-04. Extract, copy and preserve source files; install only the requested tools. | An unchanged original plus an edited copy; setup/version note. |
| 3 | M00 DE00-05. Practise VS Code. Begin DE00-06 only when you can reopen your saved file. | A saved file and the exact folder from which you opened it. |
| 4 | Finish DE00-06, then DE00-07. Read terminal output and repair the small printed failure. | The original error and the corrected command/result. |
| 5 | M00 DE00-08, Quick Revision and the Module Revision Test. Save the test, then use Protected Answers. | Test attempt, correction and changed retry. |
| 6 | Repair any remaining M00 gap. If ready, begin M01 DE01-01. | The lesson’s own table-reading attempt and explanation. |
| 7 | Rest or brief voluntary recall. | No compulsory new lesson. |


## 7. Files, attempts and notes without extra busywork

Use one stable folder such as Documents/DE_Study. Keep the original course ZIP separately. Inside your working area, keep one folder per module and one per lesson. For example, DE_Study/work/M02/DE02-03 can hold attempt-01.sql, result-01.csv, error-01.txt and retry-02.sql. These are naming examples, not extra files every task must create.

If a lesson already gives a filename, use it. If it gives a blank answer form, fill a copy. If it asks you to create a query, script, diagram or explanation, create that file. “Artifact” means the thing you made; “evidence” means the saved result that supports your claim. Neither word means you need a fancy report.

Keep the book as your notes. Maintain only a small mistake log: lesson ID, what failed, why it failed and what fixed it. Copying the textbook into another notebook uses time without proving that you can perform the task. For vocabulary, write a short explanation only when a word still confuses you.

When following a command, first identify its working folder. In File Explorer, open the folder named by the lesson. Use the terminal navigation taught in M00. Confirm the files you expect are there before running it. If the printed command names a subfolder, keep the supplied folder structure. Do not drag individual scripts away from their data and supporting modules.

At the end of the week, copy your work to a second location you control. In the mentor, export a progress backup before clearing browser data or moving to another device. Phone and PC progress do not synchronize automatically. You can use the PDF books without using the tracker at all.


## 8. Revision, module tests and gates

After the last lesson of a module: open its Quick Revision book, first answer from memory, then fill gaps. Next open its Module Revision Test. Follow that test’s printed rules and save the attempt. Then open the separate protected test answers and assess your reasoning. Use the module’s published pass/control requirements; this guide does not invent a different universal pass mark.

On ordinary study days, recall a small part of yesterday’s work. Revisit one old weak task later in the week and again after one or two weeks. You do not need to reread every completed PDF. A quick repeat from memory exposes a gap more clearly than familiar-looking paragraphs.

A gate combines skills from several modules. Gate A comes first. Save the full attempt before opening Protected Review A. Repair the weak skill using the module books. Then open the different fresh Gate B, attempt it without its review, save it and finally open Review B. “Protected” and “sealed” are study instructions; the files are not encrypted.

Do not move ahead after merely copying a gate answer. Follow the gate’s own success criteria. If you fall short, keep the attempt, return to the named weak lessons and make a fresh attempt. There is no penalty for taking longer to understand a prerequisite.

| Gate | When | Skill boundary |
| --- | --- | --- |
| G01 | After M01 | Data and essential Excel |
| G02 | After M03 | SQL |
| G03 | After M06 | Python, Linux and Git |
| G04 | After M10 | Ingestion, transformation and orchestration |
| G05 | After M14 | Storage, Spark, Delta and streaming |
| G06 | After M17 | Cloud, DataOps and architecture |
| G07 | After M19 | Portfolio and interview readiness |

Exact G01 example: open 09_GATES/G01/G01_GATE_A.pdf, then PROTECTED_OPEN_AFTER_ATTEMPT/G01_REVIEW_A.pdf. After repair, open SEALED_FRESH_RETEST/G01_GATE_B.pdf, then that same folder’s G01_REVIEW_B.pdf. The other gate folders follow the same sequence.


## 9. What to do when you are stuck

First separate “I do not understand the idea” from “the tool reports an error”. For an idea, ask for a tiny example and the meaning of one unfamiliar word. For an error, preserve the exact message, the command and your current folder. A screenshot of the last line alone often hides the cause.

Try a short diagnosis: reread the immediately preceding step; check the filename, folder and tool; compare your input with the worked example; change one suspected cause and run again. For an ordinary small error, about 15–20 minutes of focused investigation is enough before asking for help. That is a guide, not a compulsory waiting period. Ask sooner if you do not understand what the command could change.

You can ask me in this chat. ChatGPT or another assistant can help interpret an error, but the mentor itself is a study organizer, not a live human tutor. Include the relevant lesson excerpt because an assistant in another chat may not have your package. Ask for one hint first, not a finished answer. Run and inspect any suggested correction.

If the issue is with a tool version, include the version and the course’s printed version note. For an unavailable video, send the lesson ID, visible title and link. Continue with the book’s worked explanation if it is sufficient; do not replace a clearly missing prerequisite with guesses.

Remove passwords, tokens, account keys and personal information before sharing an error. Keep the useful technical context: the error text, short code, column names and a few harmless sample rows. Do not post a whole personal dataset to solve a two-line mistake.

```text
Lesson: DE02-03
My aim: return rows where unit_price is at least 30.
Tool and version: [fill in]
Current folder / database: [fill in]
Exact command or short code: [paste]
Expected result: [what the book says]
Actual result or full error: [paste]
What I already tried: [one or two changes]
Please explain the first cause in simple language. Give one hint, let me try, then check my result. Do not reveal the protected answer yet.
```


## 10. What the video labels really mean

A link beside a lesson is a visual aid assigned to that lesson. It is not a claim that the recording covers every sentence in the book. Some recordings teach the main topic; some explain a prerequisite, demonstrate the tool or refresh an earlier skill. Read the scope printed beside the link.

A bounded range such as 06:26–10:40 means watch that part, then stop manually. The link may open at the start but usually does not stop automatically. A range in this package can come from the source’s published chapters or runtime; that is different from someone verifying every second of playback.

“Optional visual — no verified bounded range” means a legitimate source is retained, but an exact start/stop segment has not been established. Do not automatically watch the entire multi-hour recording again for every lesson. Use its published chapters to find the topic, or learn this step from the complete written example.

“Reused visual” means you have already been assigned that source. Rewatch only the part you need. Videos use their own datasets and may have a different title from the course chapter. The book supplies the missing definitions, project-specific rules, tasks and expected results.

No generated videos are included. Where no suitable instructor video is assigned, the lesson says so and provides the written explanation, worked example and diagrams where helpful. Link availability can change after publication; an unavailable source is not a reason to invent a substitute link.

| Your screenshot | What its video covers | What the book adds |
| --- | --- | --- |
| DE01-02 · Grain | The data introduction already used in DE01-01; an optional reminder about records and summary data. | The precise “one row represents …” sentence and order-versus-line calculations. |
| DE01-03 · Keys and missing values | Validation context: valid, invalid, missing and unusual values. | Candidate/composite keys, duplicate handling and why missing is not zero. |
| DE01-04 · Data quality | The same validation source. No second mandatory viewing. | Designing checks for the business question and understanding what a passing check does not prove. |


## 11. Projects and the transition to applications

M18 has four builds split into 50 phases. Read the matching project brief, then perform its phases in order. Each phase names an output and completion control. Save the working files, tests and explanation; do not mark a whole project complete because a dashboard looks attractive.

Use the supplied fixtures to establish an expected result first. Then test replay, bad input and recovery as the project asks. A clean rerun means you can run from the documented starting state and obtain the same controlled business result. It does not mean deleting evidence of a failed run.

A protected reference solution is available after your attempt. It explains business controls and provides executable examples. A standard-library reference or local simulation does not replace the native engine evidence required by your chosen portfolio implementation. Name honestly which engines you ran and which you only simulated.

Keep interview preparation small and continuous: explain one SQL result aloud, summarize one bug you fixed and practise describing a project decision. M19 supplies the structured job-launch work. Apply when you can demonstrate the role’s required skills and defend your work; the course calendar alone is not evidence of readiness.

Your daily finish line is simple: I made something, checked it and can explain it. If you only watched or read today, record it as study in progress and make the practical attempt your next step.
