# M11 - Storage & File Formats Foundations

Study in canonical order DE11-01 -> DE11-10. This module is foundations: it teaches Parquet physical reasoning and the table-management mental model needed before Spark/M13 deeper lakehouse implementation.

For each lesson: open the mapped visual/reference, close it, follow the guided example, do the independent task, save evidence, open review only after an attempt, then solve the changed retry.

Runtime boundary: `parquet_lab.py` is syntax/static-checked, but native PyArrow metadata/projection execution remains a learner-PC proof. The supplied transaction-log lab is explicitly a Delta-like simulator, not the Delta Lake engine. M13 will deepen real Delta/lakehouse implementation.

After M11, continue to M12 Spark/PySpark. There is no formal Gate after M11.
