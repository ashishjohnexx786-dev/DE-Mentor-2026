from pathlib import Path
import argparse, csv, sys
BASE=Path(__file__).resolve().parents[1]
DATA=BASE/'data'; OUT=Path(__file__).resolve().parent/'out'; OUT.mkdir(exist_ok=True)
try:
    import pyarrow as pa
    import pyarrow.csv as pacsv
    import pyarrow.parquet as pq
except ModuleNotFoundError:
    raise SystemExit('PyArrow is not installed. Install the pinned requirement on the learner PC, then rerun. This package does not claim native Parquet execution; rerun the lab on the learner PC after installing the pinned requirement.')
P=OUT/'orders.parquet'
def build():
    table=pacsv.read_csv(DATA/'orders.csv')
    pq.write_table(table,P,row_group_size=4,compression='snappy')
    print('rows',table.num_rows,'columns',table.num_columns,'path',P)
def metadata():
    if not P.exists(): build()
    pf=pq.ParquetFile(P); print('rows',pf.metadata.num_rows,'row_groups',pf.metadata.num_row_groups); print(pf.schema)
    for i in range(pf.metadata.num_row_groups):
        rg=pf.metadata.row_group(i); print('row_group',i,'rows',rg.num_rows)
        for j in range(rg.num_columns):
            col=rg.column(j)
            if col.path_in_schema in {'order_date','amount'}:
                print(col.path_in_schema,'stats',col.statistics)
def projection():
    if not P.exists(): build()
    t=pq.read_table(P,columns=['order_id','amount']); print(t.schema); print('rows',t.num_rows,'cols',t.num_columns)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--section',required=True,choices=['build','metadata','projection']); a=ap.parse_args(); globals()[a.section]()
if __name__=='__main__': main()
