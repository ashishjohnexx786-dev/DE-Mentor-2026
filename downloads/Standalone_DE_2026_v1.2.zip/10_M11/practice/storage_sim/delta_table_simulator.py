from pathlib import Path
import csv, json, sys, shutil
from datetime import datetime, timezone
BASE=Path(__file__).resolve().parents[1]; DATA=BASE/'data'; OUT=Path(__file__).resolve().parent/'delta_sim_output'; LOG=OUT/'_delta_log_sim'; SNAP=OUT/'snapshots'
REQ=['order_id','order_date','region','customer_id','quantity','amount']

def read_csv(name):
    with open(DATA/name,newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
def numeric(row):
    try: float(row['amount']); int(row['quantity']); return True
    except: return False
def total(rows): return round(sum(float(r['amount']) for r in rows),2)
def write_version(v,op,rows,removed=None,extra=None):
    SNAP.mkdir(parents=True,exist_ok=True); LOG.mkdir(parents=True,exist_ok=True)
    sp=SNAP/f'part-v{v}.json'; sp.write_text(json.dumps(rows,indent=2),encoding='utf-8')
    rec={'version':v,'timestamp':datetime.now(timezone.utc).isoformat(),'operation':op,'active_snapshot':sp.name,'rows':len(rows),'unique_keys':len({r['order_id'] for r in rows}),'amount_total':total(rows),'removed_snapshot':removed}
    if extra: rec.update(extra)
    (LOG/f'{v:06}.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
def versions():
    if not LOG.exists(): return []
    return sorted(int(p.stem) for p in LOG.glob('*.json'))
def load(v=None):
    vs=versions()
    if not vs: raise SystemExit('No table. Run init first.')
    if v is None: v=vs[-1]
    rec=json.loads((LOG/f'{v:06}.json').read_text()); rows=json.loads((SNAP/rec['active_snapshot']).read_text()); return rec,rows
def init():
    if OUT.exists(): shutil.rmtree(OUT)
    rows=read_csv('orders.csv'); assert all(numeric(r) for r in rows); assert len({r['order_id'] for r in rows})==len(rows); write_version(0,'INIT',rows); print('version=0 rows=8 unique=8 total=1100.0')
def reset(): init()
def merge_file(name='merge_changes.csv'):
    rec,rows=load(); src=read_csv(name); ids=[r['order_id'] for r in src]
    if len(ids)!=len(set(ids)):
        print('MERGE_BLOCKED duplicate source keys',file=sys.stderr); return 2
    if not all(numeric(r) for r in src): print('MERGE_BLOCKED incompatible numeric type',file=sys.stderr); return 3
    d={r['order_id']:r for r in rows}; updates=sum(1 for r in src if r['order_id'] in d); inserts=sum(1 for r in src if r['order_id'] not in d)
    for r in src: d[r['order_id']]=r
    out=sorted(d.values(),key=lambda r:r['order_id']); v=rec['version']+1; write_version(v,'MERGE',out,rec['active_snapshot'],{'updates':updates,'inserts':inserts}); print(f'version={v} updates={updates} inserts={inserts} rows={len(out)} unique={len(d)} total={total(out)}'); return 0
def merge(): return merge_file()
def merge_duplicate_source(): return merge_file('merge_changes_duplicate_key.csv')
def evolve_add_column():
    rec,rows=load();
    if rec['version']<1: raise SystemExit('Run merge first.')
    out=[]
    for r in rows:
        x=dict(r); x['source_system']='training_fixture'; out.append(x)
    v=rec['version']+1; write_version(v,'SCHEMA_EVOLUTION_ADD_COLUMN',out,rec['active_snapshot'],{'added_column':'source_system'}); print(f'version={v} added=source_system rows={len(out)} total={total(out)}')
def incompatible_write():
    rec,rows=load(); src=read_csv('incompatible_amount.csv')
    ok=all(numeric(r) for r in src)
    if not ok:
        print(f'WRITE_REJECTED version_stays={rec["version"]} reason=amount_not_numeric'); return 0
    raise SystemExit('Fixture unexpectedly compatible')
def history():
    for v in versions(): print((LOG/f'{v:06}.json').read_text())
def time_travel(v):
    rec,rows=load(int(v)); print(f'version={v} rows={len(rows)} unique={len({r["order_id"] for r in rows})} total={total(rows)}')
def current():
    rec,rows=load(); print(f'version={rec["version"]} rows={len(rows)} unique={len({r["order_id"] for r in rows})} total={total(rows)}')
def vacuum_dry_run():
    vs=versions(); cur=vs[-1]; current_rec,_=load(cur); active=current_rec['active_snapshot']; candidates=[p.name for p in SNAP.glob('part-v*.json') if p.name!=active]; print(json.dumps({'current_version':cur,'active_snapshot':active,'candidate_old_snapshots':candidates,'deleted':False,'notice':'SIMULATOR DRY RUN ONLY - NOT DELTA VACUUM'},indent=2))
cmd=sys.argv[1] if len(sys.argv)>1 else ''
if cmd=='init': init()
elif cmd=='reset': reset()
elif cmd=='merge': raise SystemExit(merge())
elif cmd=='merge-duplicate-source': raise SystemExit(merge_duplicate_source())
elif cmd=='evolve-add-column': evolve_add_column()
elif cmd=='incompatible-write': incompatible_write()
elif cmd=='history': history()
elif cmd=='time-travel': time_travel(sys.argv[2])
elif cmd=='current': current()
elif cmd=='vacuum-dry-run': vacuum_dry_run()
else: raise SystemExit('commands: init reset merge merge-duplicate-source evolve-add-column incompatible-write history time-travel <v> current vacuum-dry-run')
