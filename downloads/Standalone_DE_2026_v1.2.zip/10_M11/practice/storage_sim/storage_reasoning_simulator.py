from pathlib import Path
import argparse, csv, json
BASE=Path(__file__).resolve().parents[1]
DATA=BASE/'data'

def read_orders():
    with open(DATA/'orders.csv',newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))

def layout(rows):
    cols=list(rows[0])
    print(json.dumps({'rows':len(rows),'columns':len(cols),'logical_cells':len(rows)*len(cols),'projection_columns':['region','amount'],'projected_logical_values':len(rows)*2},indent=2))

def metadata():
    m=json.loads((DATA/'parquet_metadata_fixture.json').read_text())
    print(json.dumps(m,indent=2))

def reads():
    m=json.loads((DATA/'parquet_metadata_fixture.json').read_text())
    candidate=[]; skipped=[]
    for rg in m['row_groups']:
        if rg['order_date']['max'] < '2026-09-03': skipped.append(rg['id'])
        else: candidate.append(rg['id'])
    print(json.dumps({'query':'order_date >= 2026-09-03','output_projection':['order_id','amount'],'filter_column':'order_date','candidate_row_groups':candidate,'skipped_row_groups':skipped},indent=2))

def compaction():
    m=json.loads((DATA/'small_files_manifest.json').read_text())
    total=sum(f['size_mb'] for f in m['files'])
    print(json.dumps({'source_files':len(m['files']),'source_total_mb':total,'classroom_target_mb':128,'proposed_compacted_groups':1,'logical_rows_before':m['logical_rows'],'logical_rows_after':m['logical_rows'],'amount_total_before':m['logical_amount_total'],'amount_total_after':m['logical_amount_total']},indent=2))

def partitioning(rows):
    keys=['order_date','region','order_id']
    out={}
    for k in keys:
        vals={r[k] for r in rows}
        out[k]={'partitions':len(vals),'rows_per_partition_avg':round(len(rows)/len(vals),2)}
    print(json.dumps(out,indent=2))

def architecture(rows=None):
    out={
      'lake':{'raw':'object/files','table_semantics':'conventions/catalog depend on implementation','serving':'one or more engines'},
      'warehouse':{'raw':'usually staged/loaded into managed database','table_semantics':'managed transactional/SQL table system','serving':'warehouse SQL/BI'},
      'lakehouse':{'raw':'object/file storage retained','table_semantics':'table layer adds transactions/schema/history/governance','serving':'multiple compatible analytical engines where supported'}
    }
    print(json.dumps(out,indent=2))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--section',required=True,choices=['layout','metadata','reads','compaction','partitioning','architecture']); a=ap.parse_args(); rows=read_orders()
    globals()[a.section](rows) if a.section in {'layout','partitioning','architecture'} else globals()[a.section]()
if __name__=='__main__': main()
