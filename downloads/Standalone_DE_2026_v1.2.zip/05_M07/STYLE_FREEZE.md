# Standalone DE 2026 - learner-facing visual style freeze

- Body font: DejaVu Sans, 10.5 pt / 15 pt leading
- Main ink: #173047
- Teal accent: #087F8C
- Blue heading/link accent: #2563EB
- Pale teaching/code fill: #EDF7FA
- A4, 43 pt side margins
- Thin teal running-header rule
- Teal + blue footer bars
- Cover grammar aligned to M00-M06

- Normal lesson-section headings: blue #2563EB.
- Teal #087F8C is structural only: rules, borders, callout accents, header/footer bars and cover kickers.
