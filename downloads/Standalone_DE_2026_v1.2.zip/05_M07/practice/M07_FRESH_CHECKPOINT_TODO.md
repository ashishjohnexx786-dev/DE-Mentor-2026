# M07 Fresh Changed Checkpoint - Receipt/Supplier Database

After repair, build a different receipt/supplier model. Change business keys, fact grain, SCD2 attribute, dirty-file defects and control totals. Include the same competency families as the module practical. A renamed shipment solution does not pass.
