# COPY / staging practice

Use a learner-owned copy of `practice/data/customer_stage_bad.csv`.

Server-side SQL `COPY ... FROM '/server/path/file.csv'` makes the PostgreSQL server process read the file. The path and OS permissions therefore belong to the server host, and elevated file roles may be required.

Inside **psql**, `\copy ... FROM 'client/path/file.csv'` is a psql meta-command. The client reads the local file and sends rows to the server. Do not paste `\copy` into a generic SQL engine and call it SQL.

Recommended learning boundary:
1. load text into a staging table first;
2. retain source row identity/raw values;
3. profile missing/duplicate/invalid fields;
4. insert valid typed rows into the governed target;
5. quarantine rejects with reasons;
6. reconcile source = accepted + rejected.
