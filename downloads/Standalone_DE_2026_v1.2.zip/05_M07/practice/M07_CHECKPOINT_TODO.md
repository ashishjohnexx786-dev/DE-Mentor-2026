# M07 Module Practical - Shipment Database

Build a learner-owned PostgreSQL model from a fresh schema. Save evidence for: context before DDL; normalized source; named constraints and deliberate failures; rollback; current-state UPSERT exact rerun; query-driven EXPLAIN/index comparison; one-line fact grain; SCD2 hub region; source/fact row and amount controls; dirty staging accepted/rejected reconciliation; least-privilege matrix/tests when safe; staged schema change; pg_dump/restore to a separate target when native tools exist; 3-5 minute architecture defense.

Do not copy the supplied order schema. Preserve first failures. Mark native-only tasks pending if your environment cannot execute them.
