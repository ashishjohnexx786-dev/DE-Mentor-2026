-- M07 analytical model. Read after DE07-07; type/rebuild rather than blindly executing as independent proof.
BEGIN;
CREATE SCHEMA IF NOT EXISTS m07_dw;
DROP TABLE IF EXISTS m07_dw.fact_order_line, m07_dw.dim_product, m07_dw.dim_customer CASCADE;
CREATE TABLE m07_dw.dim_customer (
  customer_sk bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  customer_id text NOT NULL,
  customer_name text NOT NULL,
  region text NOT NULL,
  valid_from date NOT NULL,
  valid_to date NOT NULL,
  is_current boolean NOT NULL,
  CONSTRAINT uq_dim_customer_version UNIQUE(customer_id, valid_from),
  CONSTRAINT ck_customer_window CHECK (valid_from < valid_to)
);
CREATE UNIQUE INDEX uq_dim_customer_one_current
  ON m07_dw.dim_customer(customer_id) WHERE is_current;
CREATE TABLE m07_dw.dim_product (
  product_sk bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  product_id text NOT NULL UNIQUE,
  product_name text NOT NULL,
  category text NOT NULL
);
CREATE TABLE m07_dw.fact_order_line (
  order_id text NOT NULL,
  line_no integer NOT NULL,
  order_date date NOT NULL,
  customer_sk bigint NOT NULL REFERENCES m07_dw.dim_customer(customer_sk),
  product_sk bigint NOT NULL REFERENCES m07_dw.dim_product(product_sk),
  quantity integer NOT NULL CHECK (quantity > 0),
  line_amount numeric(14,2) NOT NULL CHECK (line_amount >= 0),
  PRIMARY KEY(order_id,line_no)
);
INSERT INTO m07_dw.dim_customer(customer_id,customer_name,region,valid_from,valid_to,is_current) VALUES
('C001','Asha','East','2025-01-10','2026-02-01',false),
('C001','Asha','South','2026-02-01','9999-12-31',true),
('C002','Ravi','West','2025-03-12','9999-12-31',true),
('C003','Mina','North','2025-05-20','9999-12-31',true),
('C004','Dev','East','2025-07-01','9999-12-31',true);
INSERT INTO m07_dw.dim_product(product_id,product_name,category)
SELECT product_id,product_name,category FROM m07_source.products;
INSERT INTO m07_dw.fact_order_line(order_id,line_no,order_date,customer_sk,product_sk,quantity,line_amount)
SELECT o.order_id, i.line_no, o.order_date, dc.customer_sk, dp.product_sk,
       i.quantity, i.quantity*i.unit_price
FROM m07_source.orders o
JOIN m07_source.order_items i USING(order_id)
JOIN m07_dw.dim_customer dc
  ON dc.customer_id=o.customer_id
 AND o.order_date >= dc.valid_from
 AND o.order_date < dc.valid_to
JOIN m07_dw.dim_product dp ON dp.product_id=i.product_id
WHERE o.status='Completed';
COMMIT;
