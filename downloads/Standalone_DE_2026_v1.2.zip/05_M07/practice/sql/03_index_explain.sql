-- Guided DE07-05. Disposable large fixture.
DROP TABLE IF EXISTS m07_lab.order_search;
CREATE TABLE m07_lab.order_search AS
SELECT g AS row_id,
       'C' || lpad(((g % 1000)+1)::text,4,'0') AS customer_id,
       DATE '2026-01-01' + (g % 180) AS order_date,
       (g % 5000)::numeric(12,2) AS amount
FROM generate_series(1,50000) AS g;
ANALYZE m07_lab.order_search;
EXPLAIN SELECT * FROM m07_lab.order_search
WHERE customer_id='C0007' AND order_date >= DATE '2026-04-01';
CREATE INDEX idx_m07_order_search_customer_date
ON m07_lab.order_search(customer_id,order_date);
ANALYZE m07_lab.order_search;
EXPLAIN SELECT * FROM m07_lab.order_search
WHERE customer_id='C0007' AND order_date >= DATE '2026-04-01';
