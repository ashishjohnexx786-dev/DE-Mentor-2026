-- Guided DE07-04.
CREATE SCHEMA IF NOT EXISTS m07_lab;
CREATE TABLE IF NOT EXISTS m07_lab.product_feed(
  product_id text PRIMARY KEY,
  product_name text NOT NULL,
  unit_price numeric(12,2) NOT NULL CHECK(unit_price>=0)
);
BEGIN;
INSERT INTO m07_lab.product_feed VALUES ('P01','Notebook',120)
ON CONFLICT(product_id) DO UPDATE
SET product_name=EXCLUDED.product_name, unit_price=EXCLUDED.unit_price;
SELECT * FROM m07_lab.product_feed WHERE product_id='P01';
ROLLBACK;
