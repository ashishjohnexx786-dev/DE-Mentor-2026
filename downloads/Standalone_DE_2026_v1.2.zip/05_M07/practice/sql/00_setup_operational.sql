-- M07 supplied source setup. Run in your own standalone_de database, not a shared/work database.
BEGIN;
CREATE SCHEMA IF NOT EXISTS m07_source;
DROP TABLE IF EXISTS m07_source.order_items, m07_source.orders, m07_source.products, m07_source.customers CASCADE;
CREATE TABLE m07_source.customers (
  customer_id text PRIMARY KEY,
  customer_name text NOT NULL CHECK (btrim(customer_name) <> ''),
  region text NOT NULL CHECK (region IN ('East','West','North','South')),
  signup_date date NOT NULL
);
CREATE TABLE m07_source.products (
  product_id text PRIMARY KEY,
  product_name text NOT NULL,
  category text NOT NULL,
  unit_price numeric(12,2) NOT NULL CHECK (unit_price >= 0)
);
CREATE TABLE m07_source.orders (
  order_id text PRIMARY KEY,
  customer_id text NOT NULL REFERENCES m07_source.customers(customer_id),
  order_date date NOT NULL,
  status text NOT NULL CHECK (status IN ('Completed','Cancelled','Pending'))
);
CREATE TABLE m07_source.order_items (
  order_id text NOT NULL REFERENCES m07_source.orders(order_id),
  line_no integer NOT NULL CHECK (line_no > 0),
  product_id text NOT NULL REFERENCES m07_source.products(product_id),
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price numeric(12,2) NOT NULL CHECK (unit_price >= 0),
  PRIMARY KEY (order_id,line_no)
);
INSERT INTO m07_source.customers VALUES
('C001','Asha','East','2025-01-10'),('C002','Ravi','West','2025-03-12'),('C003','Mina','North','2025-05-20'),('C004','Dev','East','2025-07-01');
INSERT INTO m07_source.products VALUES
('P01','Notebook','Paper',120),('P02','Pen','Writing',20),('P03','Bag','Accessories',500),('P04','Marker','Writing',50);
INSERT INTO m07_source.orders VALUES
('O101','C001','2026-01-05','Completed'),('O102','C001','2026-02-10','Completed'),('O103','C002','2026-02-15','Completed'),('O104','C003','2026-03-01','Cancelled'),('O105','C004','2026-03-05','Completed'),('O106','C002','2026-03-09','Completed');
INSERT INTO m07_source.order_items VALUES
('O101',1,'P01',2,120),('O101',2,'P02',3,20),('O102',1,'P03',1,500),('O102',2,'P02',5,20),('O103',1,'P01',1,120),('O103',2,'P04',4,50),('O104',1,'P03',1,500),('O105',1,'P01',3,120),('O106',1,'P02',10,20);
COMMIT;
