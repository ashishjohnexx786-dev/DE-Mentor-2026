-- Guided DE07-06. Read source grains before dimensional build.
SELECT COUNT(*) AS customer_rows FROM m07_source.customers;
SELECT COUNT(*) AS order_rows FROM m07_source.orders;
SELECT COUNT(*) AS line_rows FROM m07_source.order_items;
-- Explain why customer_name/region are not repeated as authoritative current-state fields on every line.
