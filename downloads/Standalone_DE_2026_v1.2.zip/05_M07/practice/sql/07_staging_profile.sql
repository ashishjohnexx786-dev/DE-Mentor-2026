-- Guided DE07-11. Create raw staging before client COPY/\copy.
CREATE SCHEMA IF NOT EXISTS m07_stage;
DROP TABLE IF EXISTS m07_stage.customer_raw;
CREATE TABLE m07_stage.customer_raw(
  source_row bigint GENERATED ALWAYS AS IDENTITY,
  customer_id text,
  customer_name text,
  region text,
  signup_date_text text
);
-- Load practice/data/customer_stage_bad.csv through a client/server method appropriate to your machine.
-- Then profile without destroying raw values:
SELECT count(*) AS source_rows,
       count(*) FILTER (WHERE nullif(btrim(region),'') IS NULL) AS blank_region_rows
FROM m07_stage.customer_raw;
SELECT customer_id,count(*) FROM m07_stage.customer_raw
GROUP BY customer_id HAVING count(*)>1;
