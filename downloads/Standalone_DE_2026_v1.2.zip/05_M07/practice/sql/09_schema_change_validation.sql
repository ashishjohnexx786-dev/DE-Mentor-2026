-- Guided DE07-13 SQL part. Example staged additive change.
ALTER TABLE m07_source.products ADD COLUMN IF NOT EXISTS source_system text;
UPDATE m07_source.products SET source_system='COURSE' WHERE source_system IS NULL;
SELECT count(*) AS missing_source_system
FROM m07_source.products WHERE source_system IS NULL;
ALTER TABLE m07_source.products ALTER COLUMN source_system SET NOT NULL;
-- Backup/restore commands are shell commands and belong in your run log, not this SQL file.
