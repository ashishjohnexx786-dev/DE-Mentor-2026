-- Guided DE07-10/13 reusable controls.
SELECT COUNT(*) AS source_lines,
       SUM(quantity*unit_price) AS source_amount
FROM m07_source.order_items;
SELECT COUNT(*) AS completed_lines,
       COUNT(DISTINCT o.order_id) AS completed_orders,
       SUM(i.quantity*i.unit_price) AS completed_amount
FROM m07_source.orders o JOIN m07_source.order_items i USING(order_id)
WHERE o.status='Completed';
SELECT COUNT(*) AS fact_lines, SUM(line_amount) AS fact_amount
FROM m07_dw.fact_order_line;
