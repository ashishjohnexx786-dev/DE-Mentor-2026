-- Guided DE07-01..03. Run only in a learner-owned database.
SELECT current_database(), current_user, current_schema(), current_schemas(true);
SHOW search_path;
CREATE SCHEMA IF NOT EXISTS m07_student;
CREATE TABLE IF NOT EXISTS m07_student.warehouses (
  warehouse_sk bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  warehouse_code text NOT NULL UNIQUE,
  warehouse_name text NOT NULL CHECK (btrim(warehouse_name) <> ''),
  active boolean NOT NULL DEFAULT true
);
-- Deliberate failure: duplicate warehouse_code. Wrap learner test in BEGIN/ROLLBACK.
