-- M07 reconciliation controls
SELECT COUNT(*) AS source_completed_lines,
       SUM(i.quantity*i.unit_price) AS source_completed_amount
FROM m07_source.orders o JOIN m07_source.order_items i USING(order_id)
WHERE o.status='Completed';

SELECT COUNT(*) AS fact_lines, SUM(line_amount) AS fact_amount
FROM m07_dw.fact_order_line;

SELECT dc.region, COUNT(DISTINCT f.order_id) AS orders, SUM(f.line_amount) AS amount
FROM m07_dw.fact_order_line f JOIN m07_dw.dim_customer dc USING(customer_sk)
GROUP BY dc.region ORDER BY dc.region;

-- Asha's January order must retain East history; February order must use South.
SELECT f.order_id, dc.region, SUM(f.line_amount) AS amount
FROM m07_dw.fact_order_line f JOIN m07_dw.dim_customer dc USING(customer_sk)
WHERE dc.customer_id='C001'
GROUP BY f.order_id,dc.region ORDER BY f.order_id;

-- one current row per business customer
SELECT customer_id, count(*) FILTER (WHERE is_current) AS current_versions
FROM m07_dw.dim_customer GROUP BY customer_id ORDER BY customer_id;
-- overlap diagnostic (should return zero rows)
SELECT a.customer_id, a.customer_sk AS a_sk, b.customer_sk AS b_sk
FROM m07_dw.dim_customer a
JOIN m07_dw.dim_customer b
  ON a.customer_id=b.customer_id AND a.customer_sk < b.customer_sk
 AND a.valid_from < b.valid_to AND b.valid_from < a.valid_to;
