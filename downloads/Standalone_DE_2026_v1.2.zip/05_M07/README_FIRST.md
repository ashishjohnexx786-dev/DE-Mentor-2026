# M07 PostgreSQL + Data Modeling - Review Edition

Open `books/M07_Learner_Book.pdf` and study DE07-01 -> DE07-13 in order. This module uses the same learner-facing visual family and beginner-first teaching standard as the completed earlier modules.

Run database-changing work only in a learner-owned local PostgreSQL database/schema. Keep `M07_Explained_Reviews.pdf` closed until a genuine attempt is saved. Cluster checks and the module practical are closed book on first attempt.

Native PostgreSQL/pgAdmin/psql, real role permissions, filesystem COPY behavior, pg_dump/pg_restore and Android smoke remain learner-device checks. This package does not fabricate those results.
