#!/usr/bin/env bash
set -euo pipefail
LAB_ROOT="${1:-/tmp/m06_local_git_lab}"
rm -rf "$LAB_ROOT"
mkdir -p "$LAB_ROOT"
cd "$LAB_ROOT"

git init --bare -b main remote.git >/dev/null
git clone remote.git learner >/dev/null 2>&1
cd learner
git config user.name "M06 Learner"
git config user.email "m06@example.invalid"
printf 'stage=raw\n' > pipeline.txt
git add pipeline.txt
git commit -m 'Add initial pipeline stage' >/dev/null
git branch -M main
git push -u origin main >/dev/null 2>&1
git --git-dir="$LAB_ROOT/remote.git" symbolic-ref HEAD refs/heads/main

git switch -c feature/quality >/dev/null
printf 'stage=quality\n' > pipeline.txt
git commit -am 'Change stage on feature branch' >/dev/null

git switch main >/dev/null
printf 'stage=validated\n' > pipeline.txt
git commit -am 'Change stage on main' >/dev/null
set +e
git merge feature/quality >/tmp/m06_merge_output.txt 2>&1
merge_rc=$?
set -e
if [ "$merge_rc" -eq 0 ]; then
  echo 'Expected a merge conflict but merge succeeded unexpectedly' >&2
  exit 30
fi
grep -q '<<<<<<<' pipeline.txt
printf 'stage=validated_quality\n' > pipeline.txt
git add pipeline.txt
git commit -m 'Resolve stage conflict deliberately' >/dev/null
git push origin main >/dev/null 2>&1
cd "$LAB_ROOT"
git clone remote.git clean >/dev/null 2>&1
cd clean
[ "$(cat pipeline.txt)" = 'stage=validated_quality' ]
echo 'LOCAL_GIT_LAB_PASS'
