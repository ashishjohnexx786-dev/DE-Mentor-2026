#!/usr/bin/env bash
set -u
input="${1:-}"
if [ -z "$input" ]; then
  echo 'missing input argument' >&2
  exit 2
fi
if [ ! -f "$input" ]; then
  echo "input not found: $input" >&2
  exit 3
fi
lines=$(wc -l < "$input")
echo "ok lines=$lines file=$input"
exit 0
