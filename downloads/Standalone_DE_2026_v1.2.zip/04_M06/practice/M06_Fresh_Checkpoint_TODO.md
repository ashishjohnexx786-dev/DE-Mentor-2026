# M06 Fresh Changed Checkpoint - TODO

Start in a NEW folder/repository. Build a tiny shipment-check project instead of the order project.

Changed requirements:
- source file name must be `shipments.csv`;
- shell wrapper receives the file path as argument rather than INPUT_FILE environment variable;
- branch name `feature/hub-summary`;
- create and resolve a conflict in README's run-command line;
- ignore `.venv/`, `.env`, `dist/`, and `*.tmp`;
- create one faulty commit and undo it with `git revert`;
- perform a clean clone and prove the documented run command works;
- explain what `git fetch` changes locally and what it does NOT merge;
- no finished course answer is supplied.
