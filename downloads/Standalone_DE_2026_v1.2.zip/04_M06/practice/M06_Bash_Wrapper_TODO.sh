#!/usr/bin/env bash
# TODO after DE06-12. Do not look for a finished answer before your attempt.
# Requirements:
# - fail if INPUT_FILE is unset or missing
# - accept an optional output path argument
# - run the sample Python project
# - return non-zero on failure
# - print a short safe success message without secrets
