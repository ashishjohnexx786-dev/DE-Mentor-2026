# M06 Module Practical - TODO

Build a learner-owned repository in your Linux/WSL home filesystem. Do not work directly in the course source folder.

Required proof:
1. Safe Linux workspace and terminal transcript (`pwd`, `ls -la`, file operations).
2. A small Python project with `.venv`, README, `.gitignore`, `.env.example`, and no real secret.
3. Git evidence: init, status, selective add, staged diff, meaningful commits, branch, merge and one real conflict resolution.
4. Remote evidence: use your own GitHub repository if available; otherwise also prove the mechanics with the supplied local-bare-remote lab. State clearly which mode you used.
5. Pull-request evidence when GitHub is available: branch, PR description, diff inspection, one self-review note or reviewer comment, merge/close decision. Do not fabricate GitHub evidence offline.
6. Safe history repair: one `restore`, one `revert`, and one `reflog` explanation/recovery exercise. Do not use `reset --hard` as your default repair.
7. Bash wrapper with meaningful exit codes.
8. Clean-clone reproducibility: clone into a new folder, follow README only, run the project, and verify controls.
9. Save first failures and explain what they taught you.
