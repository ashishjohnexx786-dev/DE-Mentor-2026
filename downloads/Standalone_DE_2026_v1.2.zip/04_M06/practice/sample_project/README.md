# M06 sample project

## Run from a fresh clone
1. `python3 -m venv .venv`
2. `. .venv/bin/activate`
3. `python app.py`

Expected control: `source_rows=6`, `completed_rows=4`, `completed_amount=3900`.
The `output/` folder is generated and intentionally ignored by Git.
