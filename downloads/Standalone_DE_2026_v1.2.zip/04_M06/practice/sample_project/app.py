from pathlib import Path
import csv, json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "data" / "orders.csv"
OUT = ROOT / "output" / "summary.json"

def summarize(path=SOURCE):
    with path.open(newline="", encoding="utf-8") as f:
        rows=list(csv.DictReader(f))
    completed=[r for r in rows if r["status"]=="Completed"]
    total=sum(int(r["amount"]) for r in completed)
    return {"source_rows":len(rows),"completed_rows":len(completed),"completed_amount":total}

if __name__ == "__main__":
    result=summarize()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(result)
