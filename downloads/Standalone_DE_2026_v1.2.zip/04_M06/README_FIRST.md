# M06 Git + GitHub + Linux/WSL Engineering Foundations - Review Edition

Start with `books/M06_Learner_Book.pdf` and study DE06-01 through DE06-13 in order. Work from a learner-owned Linux/WSL-home folder, not inside the course master folder. Save a genuine attempt before opening `books/M06_Explained_Reviews.pdf`; use `books/M06_Cluster_Checks.pdf` closed-book.

After genuine M04 + M05 + M06 mastery, take `gates/G03/G03_GATE_A.pdf`. Keep Review A and the sealed fresh Gate B family closed until the assessment route calls for them. Local bare-remote work is valid Git-mechanics practice but must never be mislabelled as real GitHub evidence.

 No generated course videos are included. This is a review edition: static Git/Bash/G03 QA is complete, while native Windows/WSL, real GitHub and Android learner-device validation remains pending.
