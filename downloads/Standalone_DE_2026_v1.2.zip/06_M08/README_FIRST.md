# M08 - Files, APIs & Data Ingestion

Start with `books/M08_Learner_Book.pdf`. Work inside `practice/`. Save first attempts before `books/M08_Explained_Reviews.pdf`. Run the four cluster checks closed-book. Complete `practice/assessments/M08_MODULE_CHECKPOINT.md`, then use the fresh changed checkpoint only after targeted repair.

The project preserves immutable landing evidence, staging, quarantine and explicit state. No generated teaching videos are included.
