from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json, os

HOST="127.0.0.1"; PORT=8008
TOKEN="stage08-demo-token"
ROWS=[
  {
    "order_id": "A4001",
    "updated_at": "2026-08-05T08:00:00Z",
    "customer_id": "C201",
    "product_id": "P001",
    "qty": 1,
    "unit_price": 850.0,
    "currency": "INR"
  },
  {
    "order_id": "A4002",
    "updated_at": "2026-08-05T08:10:00Z",
    "customer_id": "C202",
    "product_id": "P002",
    "qty": 2,
    "unit_price": 450.0,
    "currency": "INR"
  },
  {
    "order_id": "A4003",
    "updated_at": "2026-08-05T08:20:00Z",
    "customer_id": "C203",
    "product_id": "P003",
    "qty": 4,
    "unit_price": 220.0,
    "currency": "INR"
  },
  {
    "order_id": "A4004",
    "updated_at": "2026-08-05T08:30:00Z",
    "customer_id": "C204",
    "product_id": "P004",
    "qty": 1,
    "unit_price": 1200.0,
    "currency": "INR"
  },
  {
    "order_id": "A4005",
    "updated_at": "2026-08-05T08:40:00Z",
    "customer_id": "C205",
    "product_id": "P001",
    "qty": 3,
    "unit_price": 850.0,
    "currency": "INR"
  },
  {
    "order_id": "A4006",
    "updated_at": "2026-08-05T08:50:00Z",
    "customer_id": "C206",
    "product_id": "P002",
    "qty": 1,
    "unit_price": 450.0,
    "currency": "INR"
  },
  {
    "order_id": "A4007",
    "updated_at": "2026-08-05T09:00:00Z",
    "customer_id": "C207",
    "product_id": "P003",
    "qty": 5,
    "unit_price": 220.0,
    "currency": "INR"
  },
  {
    "order_id": "A4008",
    "updated_at": "2026-08-05T09:00:00Z",
    "customer_id": "C208",
    "product_id": "P004",
    "qty": 2,
    "unit_price": 1200.0,
    "currency": "INR"
  },
  {
    "order_id": "A4009",
    "updated_at": "2026-08-05T09:10:00Z",
    "customer_id": "C209",
    "product_id": "P001",
    "qty": 1,
    "unit_price": 850.0,
    "currency": "INR"
  },
  {
    "order_id": "A4010",
    "updated_at": "2026-08-05T09:20:00Z",
    "customer_id": "C210",
    "product_id": "P002",
    "qty": 6,
    "unit_price": 450.0,
    "currency": "INR"
  }
]

failure_memory={}
rate_memory={}

def pair(row):
    return (row["updated_at"], row["order_id"])

class Handler(BaseHTTPRequestHandler):
    def send_json(self,status,payload,headers=None):
        body=json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        for k,v in (headers or {}).items():
            self.send_header(k,v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed=urlparse(self.path); qs=parse_qs(parsed.query)

        if parsed.path=="/health":
            return self.send_json(200,{"status":"ok"})

        if parsed.path not in ("/v1/orders","/v2/orders"):
            return self.send_json(404,{"error":"not found"})

        auth=self.headers.get("Authorization","")
        if auth!=f"Bearer {TOKEN}":
            return self.send_json(401,{"error":"missing or invalid bearer token"})

        # Simulated one-time transient 500 for a unique request key.
        if qs.get("fail_once")==["1"]:
            key=parsed.path + ":fail_once"
            if failure_memory.get(key,0)==0:
                failure_memory[key]=1
                return self.send_json(500,{"error":"simulated transient server error"})

        page=max(int(qs.get("page",["1"])[0]),1)
        page_size=min(max(int(qs.get("page_size",["3"])[0]),1),5)

        # Page 2 can rate-limit once when rate_limit_once=1.
        if qs.get("rate_limit_once")==["1"] and page==2:
            key=f"{parsed.path}:page2"
            if rate_memory.get(key,0)==0:
                rate_memory[key]=1
                return self.send_json(429,{"error":"simulated rate limit"},{"Retry-After":"1"})

        after_ts=qs.get("after_updated_at",[None])[0]
        after_id=qs.get("after_order_id",[None])[0]
        filtered=ROWS
        if after_ts is not None:
            marker=(after_ts, after_id or "")
            filtered=[r for r in ROWS if pair(r)>marker]

        start=(page-1)*page_size
        items=filtered[start:start+page_size]
        next_page=page+1 if start+page_size<len(filtered) else None

        if parsed.path=="/v2/orders":
            # Intentional contract drift: unit_price -> price and customer_id -> nested customer object.
            items=[
                {
                    "order_id":r["order_id"],
                    "updated_at":r["updated_at"],
                    "customer":{"id":r["customer_id"]},
                    "product_id":r["product_id"],
                    "qty":r["qty"],
                    "price":r["unit_price"],
                    "currency":r["currency"],
                    "source_schema_version":2
                } for r in items
            ]

        return self.send_json(200,{
            "schema_version": 1 if parsed.path=="/v1/orders" else 2,
            "page":page,
            "page_size":page_size,
            "items":items,
            "next_page":next_page,
            "total_filtered":len(filtered)
        })

    def log_message(self,format,*args):
        return

if __name__=="__main__":
    print(f"Stage 08 API at http://{HOST}:{PORT}")
    print("Token: stage08-demo-token")
    print("Endpoints: /health, /v1/orders, /v2/orders")
    HTTPServer((HOST,PORT),Handler).serve_forever()
