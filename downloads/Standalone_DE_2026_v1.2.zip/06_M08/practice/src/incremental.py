from pathlib import Path
import json
from api_client import request_json
from ingestion_core import atomic_write_json

def pair(r):
    return (r["updated_at"], r["order_id"])

def read_checkpoint(state_path: Path, ignore_checkpoint: bool = False):
    if ignore_checkpoint or not state_path.exists():
        return None
    return json.loads(state_path.read_text(encoding="utf-8"))

def fetch_incremental(base, token, state_path: Path, ignore_checkpoint: bool = False):
    """Fetch eligible rows without mutating the live checkpoint.

    Returns (rows, candidate_checkpoint). The caller must durably persist/validate
    the returned rows before calling commit_checkpoint().
    """
    state = read_checkpoint(state_path, ignore_checkpoint)
    params = {"page": 1, "page_size": 3}
    if state:
        params["after_updated_at"] = state["updated_at"]
        params["after_order_id"] = state["order_id"]
    rows = []
    page = 1
    while page is not None:
        params["page"] = page
        payload, _ = request_json(
            base + "/v1/orders",
            headers={"Authorization": f"Bearer {token}"},
            params=params,
        )
        rows.extend(payload["items"])
        page = payload["next_page"]
    rows = sorted(rows, key=pair)
    candidate = None
    if rows:
        last = rows[-1]
        candidate = {"updated_at": last["updated_at"], "order_id": last["order_id"]}
    return rows, candidate

def commit_checkpoint(state_path: Path, candidate_checkpoint):
    """Atomically advance state only after the caller has durably saved output."""
    if candidate_checkpoint is None:
        return None
    atomic_write_json(state_path, candidate_checkpoint)
    return candidate_checkpoint
