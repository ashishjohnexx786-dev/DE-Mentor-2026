from pathlib import Path
import json
from datetime import datetime,timezone
ROOT=Path(__file__).parents[1]
def parse(s):
    if s.endswith('Z'): s=s[:-1]+'+00:00'
    dt=datetime.fromisoformat(s)
    if dt.tzinfo is None: raise ValueError('offset-less timestamp')
    return dt.astimezone(timezone.utc)
def classify(tolerance_minutes=60):
    out=[]
    for line in (ROOT/'source/events/late_events.jsonl').read_text().splitlines():
        e=json.loads(line); lag=(parse(e['arrived_at'])-parse(e['event_time'])).total_seconds()/60
        out.append({**e,'lag_minutes':lag,'late':lag>tolerance_minutes})
    return out
if __name__=='__main__': print(json.dumps(classify(),indent=2))
