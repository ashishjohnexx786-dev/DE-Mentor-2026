from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
ROOT=Path(__file__).parents[1]
df=pd.read_csv(ROOT/'source/files/orders_2026-08-01.csv',dtype={'order_id':'string','customer_id':'string'})
table=pa.Table.from_pandas(df,preserve_index=False)
out=ROOT/'output/orders.parquet'; out.parent.mkdir(exist_ok=True)
pq.write_table(table,out,row_group_size=2)
pf=pq.ParquetFile(out)
print('rows',pf.metadata.num_rows,'row_groups',pf.metadata.num_row_groups)
print(pf.schema)
projected=pq.read_table(out,columns=['order_id','updated_at','qty'])
assert projected.num_rows==len(df)
print(projected.to_pandas())
