from pathlib import Path
import sqlite3, json
ROOT=Path(__file__).parents[1]
DB=ROOT/'output/source_orders.sqlite'

def build_db():
    DB.parent.mkdir(exist_ok=True)
    if DB.exists(): DB.unlink()
    con=sqlite3.connect(DB)
    con.execute('create table source_orders(order_id text primary key, updated_at text not null, customer_id text, amount real)')
    rows=[('D5001','2026-08-05T08:00:00Z','C1',100),('D5002','2026-08-05T08:15:00Z','C2',200),('D5003','2026-08-05T08:15:00Z','C3',300),('D5004','2026-08-05T08:30:00Z','C4',400)]
    con.executemany('insert into source_orders values(?,?,?,?)',rows); con.commit(); con.close()

def extract(ts,id_,limit=10):
    uri=f'file:{DB}?mode=ro'; con=sqlite3.connect(uri,uri=True)
    sql="""SELECT order_id, updated_at, customer_id, amount FROM source_orders\n           WHERE updated_at > ? OR (updated_at = ? AND order_id > ?)\n           ORDER BY updated_at, order_id LIMIT ?"""
    rows=con.execute(sql,(ts,ts,id_,limit)).fetchall(); con.close(); return rows
if __name__=='__main__':
    build_db(); rows=extract('2026-08-05T08:15:00Z','D5002'); print(rows); assert [r[0] for r in rows]==['D5003','D5004']
