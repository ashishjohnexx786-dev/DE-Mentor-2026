from pathlib import Path
import json,time,hashlib
from ingestion_core import atomic_write_json

def write_run(path:Path,**fields):
    rec={'recorded_at':time.time(),**fields}
    if 'source_records' in rec and 'accepted' in rec and 'quarantined' in rec:
        rec['reconciles']=rec['source_records']==rec['accepted']+rec['quarantined']
    atomic_write_json(path,rec); return rec
