from pathlib import Path
import hashlib
import json
import os
import re
import tempfile
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

FIELDS = ['order_id','updated_at','customer_id','product_id','qty','unit_price','currency']
_SAFE_NAME = re.compile(r'^[A-Za-z0-9._-]+$')


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def utc_stamp() -> str:
    """Collision-resistant UTC run identity for learner landing zones."""
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ') + '-' + uuid.uuid4().hex[:8]


def _parse_decimal(value, field_name: str):
    if isinstance(value, bool):
        raise ValueError(f'{field_name}_not_numeric')
    try:
        d = Decimal(str(value).strip())
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f'{field_name}_not_numeric')
    if not d.is_finite():
        raise ValueError(f'{field_name}_not_finite')
    return d


def validate_order(row):
    """Validate the common CSV/JSON order contract.

    Contract used by this module:
    - qty must be a positive whole number; integer-looking CSV strings and JSON numbers are accepted.
    - unit_price must be finite, non-negative, and have at most 2 decimal places. We reject rather than silently round.
    - updated_at must be an ISO-8601 timestamp explicitly expressed as UTC with trailing Z.
    """
    reasons = []
    for f in FIELDS:
        if f not in row or row[f] in (None, ''):
            reasons.append(f'missing_{f}')
    if reasons:
        return reasons

    try:
        q = _parse_decimal(row['qty'], 'qty')
        if q != q.to_integral_value():
            reasons.append('qty_not_integer')
        elif q <= 0:
            reasons.append('qty_not_positive')
    except ValueError as exc:
        reasons.append(str(exc))

    try:
        p = _parse_decimal(row['unit_price'], 'unit_price')
        if p < 0:
            reasons.append('unit_price_negative')
        elif -p.as_tuple().exponent > 2:
            reasons.append('unit_price_too_many_decimal_places')
    except ValueError as exc:
        reasons.append(str(exc))

    ts = row['updated_at']
    if not isinstance(ts, str) or not ts.endswith('Z'):
        reasons.append('updated_at_not_explicit_utc_z')
    else:
        try:
            parsed = datetime.fromisoformat(ts[:-1] + '+00:00')
            if parsed.tzinfo is None or parsed.utcoffset() != timezone.utc.utcoffset(parsed):
                reasons.append('updated_at_not_utc')
        except Exception:
            reasons.append('updated_at_invalid_iso8601')
    return reasons


def atomic_write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(obj, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise


def _safe_source_name(source_name: str) -> str:
    name = Path(source_name).name
    if name != source_name or not _SAFE_NAME.fullmatch(name):
        raise ValueError('source_name_must_be_a_plain_safe_filename')
    return name


def land_bytes(raw: bytes, source_name: str, landing_root: Path, run_id=None):
    """Land immutable raw bytes and a consistent manifest record.

    Collision policy:
    - Default run IDs are collision-resistant.
    - If caller intentionally reuses run_id + source_name with identical bytes, return the existing object as a safe replay
      without appending a contradictory duplicate manifest entry.
    - If the same immutable identity exists with different bytes, fail without modifying the existing file or manifest.
    """
    if not isinstance(raw, (bytes, bytearray)):
        raise TypeError('raw_must_be_bytes')
    raw = bytes(raw)
    source_name = _safe_source_name(source_name)
    if source_name == '_manifest.json':
        raise ValueError('reserved_manifest_filename')
    run_id = run_id or utc_stamp()
    if not isinstance(run_id, str) or not _SAFE_NAME.fullmatch(run_id):
        raise ValueError('run_id_must_be_a_safe_identifier')
    run = landing_root / f'run_id={run_id}'
    run.mkdir(parents=True, exist_ok=True)
    target = run / source_name
    digest = sha256_bytes(raw)
    rec = {'run_id': run_id, 'source_name': source_name, 'bytes': len(raw), 'sha256': digest}
    mf = run / '_manifest.json'
    existing = {'run_id': run_id, 'objects': []}
    if mf.exists():
        existing = json.loads(mf.read_text(encoding='utf-8'))
        if existing.get('run_id') != run_id:
            raise ValueError('manifest_run_id_mismatch')

    if target.exists():
        old = target.read_bytes()
        old_digest = sha256_bytes(old)
        if old_digest != digest:
            raise FileExistsError(
                f'immutable_landing_collision:{target}:existing_sha256={old_digest}:new_sha256={digest}'
            )
        # Identical replay: verify or repair exactly one matching manifest record, but do not duplicate it.
        matching = [
            o for o in existing.get('objects', [])
            if o.get('source_name') == source_name and o.get('sha256') == digest and o.get('bytes') == len(raw)
        ]
        contradictory = [
            o for o in existing.get('objects', [])
            if o.get('source_name') == source_name and (
                o.get('sha256') != digest or o.get('bytes') != len(raw)
            )
        ]
        if contradictory:
            raise ValueError('manifest_contradicts_existing_raw_object')
        if not matching:
            existing.setdefault('objects', []).append(rec)
            atomic_write_json(mf, existing)
        return run, {**rec, 'replay': True}

    # Exclusive create ensures an accidental concurrent writer cannot overwrite earlier raw evidence.
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        try:
            target.unlink()
        except FileNotFoundError:
            pass
        raise

    try:
        existing.setdefault('objects', []).append(rec)
        atomic_write_json(mf, existing)
    except Exception:
        # Do not leave an unmanifested learner raw object if manifest persistence fails.
        try:
            target.unlink()
        except FileNotFoundError:
            pass
        raise
    return run, rec
