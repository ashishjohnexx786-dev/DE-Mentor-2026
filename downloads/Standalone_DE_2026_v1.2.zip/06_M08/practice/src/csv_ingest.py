from pathlib import Path
import csv, json
from ingestion_core import validate_order, land_bytes

def ingest(path:Path,out:Path,run_id='csv_demo'):
    raw=path.read_bytes(); run,manifest=land_bytes(raw,path.name,out/'landing',run_id)
    rows=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    accepted=[]; rejected=[]; seen=set()
    for i,row in enumerate(rows,start=2):
        reasons=validate_order(row)
        if row.get('order_id') in seen: reasons.append('duplicate_order_id_in_batch')
        if row.get('order_id'): seen.add(row['order_id'])
        rec=dict(row); rec['source_row']=i
        if reasons:
            rec['reasons']=reasons; rejected.append(rec)
        else:
            rec['qty']=int(rec['qty']); rec['unit_price']=float(rec['unit_price']); accepted.append(rec)
    assert len(rows)==len(accepted)+len(rejected)
    out.mkdir(parents=True,exist_ok=True)
    (out/'staging').mkdir(exist_ok=True); (out/'quarantine').mkdir(exist_ok=True)
    (out/'staging'/f'{run_id}.json').write_text(json.dumps(accepted,indent=2),encoding='utf-8')
    (out/'quarantine'/f'{run_id}.json').write_text(json.dumps(rejected,indent=2),encoding='utf-8')
    result={'source_rows':len(rows),'accepted':len(accepted),'quarantined':len(rejected),'sha256':manifest['sha256']}
    print(json.dumps(result)); return result

if __name__=='__main__':
    import sys
    ingest(Path(sys.argv[1]),Path(sys.argv[2]) if len(sys.argv)>2 else Path('output/csv'))
