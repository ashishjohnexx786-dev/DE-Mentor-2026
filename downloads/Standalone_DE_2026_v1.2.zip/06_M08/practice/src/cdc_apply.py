from pathlib import Path
import json
ROOT=Path(__file__).parents[1]
def apply(path):
    state={}; seen=set(); events=[]
    for line in path.read_text().splitlines():
        e=json.loads(line)
        if e['event_id'] in seen: continue
        seen.add(e['event_id']); events.append(e)
        if e['op'] in ('c','u'): state[e['key']]=e['after']
        elif e['op']=='d': state.pop(e['key'],None)
        else: raise ValueError('unknown op')
    return state,events
if __name__=='__main__':
    s,e=apply(ROOT/'source/events/cdc_changes.jsonl'); print(s); assert s['A5001']['status']=='paid' and 'A5002' not in s
