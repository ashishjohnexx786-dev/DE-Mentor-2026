import os,time,random,requests

def request_json(url,headers=None,params=None,max_attempts=4,timeout=3,sleep=True):
    retry_status={429,500,502,503,504}
    attempts=[]
    for attempt in range(1,max_attempts+1):
        try:
            r=requests.get(url,headers=headers,params=params,timeout=timeout)
            attempts.append({'attempt':attempt,'status':r.status_code})
            if r.status_code in retry_status and attempt<max_attempts:
                if r.status_code==429 and r.headers.get('Retry-After'):
                    wait=min(float(r.headers['Retry-After']),2.0)
                else:
                    wait=min(0.05*(2**(attempt-1))+random.uniform(0,0.02),0.25)
                if sleep: time.sleep(wait)
                continue
            r.raise_for_status()
            return r.json(),attempts
        except (requests.Timeout,requests.ConnectionError) as e:
            attempts.append({'attempt':attempt,'exception':type(e).__name__})
            if attempt>=max_attempts: raise
            if sleep: time.sleep(min(0.05*(2**(attempt-1)),0.25))
    raise RuntimeError('unreachable')

def fetch_all(base,token,page_size=3,rate_limit_once=False,fail_once=False):
    headers={'Authorization':f'Bearer {token}'}
    page=1; rows=[]; trace=[]
    while page is not None:
        params={'page':page,'page_size':page_size}
        if rate_limit_once: params['rate_limit_once']='1'
        if fail_once and page==1: params['fail_once']='1'
        payload,attempts=request_json(base+'/v1/orders',headers=headers,params=params)
        trace.extend([dict(x,page=page) for x in attempts])
        rows.extend(payload['items']); page=payload['next_page']
    ids=[r['order_id'] for r in rows]
    if len(ids)!=len(set(ids)): raise ValueError('duplicate order ids across pages')
    return rows,trace
if __name__=='__main__':
    token=os.environ.get('STAGE08_API_TOKEN','stage08-demo-token')
    rows,trace=fetch_all('http://127.0.0.1:8008',token,3,True,False)
    print(len(rows),trace)
