from pathlib import Path
import json

def flatten(path:Path):
    orders=json.loads(path.read_text(encoding='utf-8'))
    rows=[]
    for order in orders:
        for line_no,item in enumerate(order.get('items',[]),start=1):
            rows.append({
                'order_id':order['order_id'],'line_no':line_no,
                'updated_at':order['updated_at'],'customer_id':order['customer']['id'],
                'product_id':item['product_id'],'qty':item['qty'],'unit_price':item['unit_price']
            })
    return rows
if __name__=='__main__':
    p=Path(__file__).parents[1]/'source/files/orders_nested.json'
    rows=flatten(p); print(json.dumps(rows,indent=2));
    assert sum(r['order_id']=='J3001' for r in rows)==2
