# M08 module checkpoint - closed book

Build a fresh ingestion run using the supplied checkpoint fixtures. Score 100. Pass >=85 and no critical state/data-loss failure.

- 15: preserve raw landing + manifest/checksum
- 15: classify CSV/nested data correctly
- 20: API auth/pagination/timeout/retry without token leakage or infinite retry
- 15: deterministic composite incremental state committed after success
- 10: CDC/schema-drift semantics
- 10: replay/idempotency proof
- 10: event/processing-time and run observability
- 5: technical explanation/handoff

Critical fail: silently drop rows; stage incompatible schema; advance checkpoint before failed run completes; hard-code real secret; replay multiplies logical rows without an explicit event-history model.
