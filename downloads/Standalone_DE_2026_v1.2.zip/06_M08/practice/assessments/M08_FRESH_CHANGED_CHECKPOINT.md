# M08 fresh changed checkpoint - sealed until repair

Use different IDs/times. Do not copy first checkpoint code blindly.

A mock source contains Q9001..Q9008. Q9004 and Q9005 share `2026-09-02T11:00:00Z`. One page rate-limits once; one record arrives 95 minutes late; schema v3 renames `qty` to `quantity` but preserves other fields. Design landing, validation/quarantine, pagination/retry, `(updated_at, order_id)` state, replay policy and run metadata.

Write expected row/state controls before implementation. Preserve first attempt. Review only the failed competency, close review, then solve this changed case independently.
