# M08 Practice Project

1. Copy this folder to your own module-work area. Keep `source/` fixtures unchanged.
2. Use `workspace/` for first attempts.
3. Keep `src/` reference implementations closed until a genuine attempt is saved and the learner book/review tells you to compare.
4. Start the API with `python mock_ingestion_api.py`. Use the classroom token through `STAGE08_API_TOKEN`; do not edit it into your TODO code.
5. `output/` is disposable. Raw master fixtures are not.
6. Parquet requires PyArrow on your learner PC.
7. Module/fresh assessments are in `assessments/`.
