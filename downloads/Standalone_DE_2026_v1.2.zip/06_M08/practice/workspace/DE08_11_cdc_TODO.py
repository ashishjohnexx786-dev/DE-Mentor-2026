# TODO: apply c/u/d events in source position to a current-state projection while preserving the event log.
# Add duplicate-event identity protection.
