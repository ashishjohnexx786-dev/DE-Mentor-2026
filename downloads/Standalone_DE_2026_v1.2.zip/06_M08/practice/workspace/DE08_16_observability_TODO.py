# TODO: write structured run metadata with source/accepted/quarantine/retry/checkpoint controls.
# Mark run unhealthy when source_records != accepted + quarantined.
