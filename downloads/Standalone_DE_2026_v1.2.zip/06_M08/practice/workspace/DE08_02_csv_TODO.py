from pathlib import Path
# TODO: land raw bytes, parse with csv module, validate declared fields/types, quarantine with reasons, reconcile counts.
SOURCE=Path('../source/files/orders_bad.csv')
# Write your implementation below. Save first attempt before opening reference scripts.
