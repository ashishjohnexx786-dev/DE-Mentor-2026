# TODO: replay from raw evidence under no-commit-state policy.
# Preserve new run evidence, keep live checkpoint unchanged, and prove logical staging does not multiply.
