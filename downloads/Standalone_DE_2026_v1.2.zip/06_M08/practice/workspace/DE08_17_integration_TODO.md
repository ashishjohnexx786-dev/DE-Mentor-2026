# DE08-17 independent integration workspace

Write expected controls BEFORE running. Build source inventory -> landing -> validation -> staging/quarantine -> state -> replay -> run metadata. Inject one failure. Save first attempt. Do not open reference code/review until evidence is saved.
