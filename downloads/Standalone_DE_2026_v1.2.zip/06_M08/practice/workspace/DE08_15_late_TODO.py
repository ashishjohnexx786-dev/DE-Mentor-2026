# TODO: compare event time and arrival time in UTC; classify lateness under 60-minute tolerance without rewriting event_time.
