from pathlib import Path
# TODO: load orders_nested.json and flatten to one row/order-item.
# Before coding, write the output grain and key. Prove J3001 creates 2 rows.
