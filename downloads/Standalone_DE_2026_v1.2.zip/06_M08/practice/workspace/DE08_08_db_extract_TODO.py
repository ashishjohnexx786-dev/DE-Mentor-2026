# TODO: create/read the local SQLite source using a read-only connection for extraction.
# Use explicit columns, parameters, deterministic (updated_at, order_id) ordering, and a development LIMIT.
