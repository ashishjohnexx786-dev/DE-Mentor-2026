# TODO: call local API with explicit timeout and bearer token from environment.
# Record status before trusting JSON. Add complete pagination, 429/selected-5xx bounded retry, and NO retry loop for 401.
# Do not print the token.
