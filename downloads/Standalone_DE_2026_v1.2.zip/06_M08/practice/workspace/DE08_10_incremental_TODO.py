# TODO: implement composite high-water mark (updated_at, order_id).
# State commits only after complete successful output. Prove A4007/A4008 tie handling and zero-new-row rerun.
