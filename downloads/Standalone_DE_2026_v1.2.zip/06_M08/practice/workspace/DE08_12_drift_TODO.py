# TODO: land v2 response but quarantine it from the v1 staging contract.
# Prove live v1 checkpoint does not advance. Classify Z/+05:30/offset-less timestamps.
