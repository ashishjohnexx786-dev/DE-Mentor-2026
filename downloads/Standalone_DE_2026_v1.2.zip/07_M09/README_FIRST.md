# M09 - ETL/ELT + Data Quality + Transformation Engineering

Start with `books/M09_Learner_Book.pdf`. Work inside `practice/`. Save first attempts before opening `books/M09_Explained_Reviews.pdf`. Run the four closed-book cluster checks, then complete `practice/assessments/M09_MODULE_CHECKPOINT.md`. Use the fresh changed checkpoint only after a saved first attempt and targeted repair.

For later revision use `../00_STUDY_MODULES/M09/M09_Quick_Revision_Book.pdf`, then take `../00_STUDY_MODULES/M09/M09_Module_Revision_Test.pdf` closed-book. Open `../00_STUDY_MODULES/M09/PROTECTED_OPEN_AFTER_ATTEMPT/M09_Module_Revision_Test_Answers.pdf` only after saving your attempt.

The module includes a runnable local Python + SQLite reliability pipeline and a real local dbt project scaffold. The Python/SQLite route passed local execution QA. Live dbt/DuckDB runtime is **not claimed** by this package; run the documented dbt checks on the learner PC.

No generated teaching videos are included.  G04 comes after M10, not after M09.
