# M09 practice route

1. Copy `practice/` into your own `01_module_work/M09/` folder.
2. Keep `source/` fixtures unchanged. Save first attempts in `workspace/` or your own files.
3. `python -m src.pipeline_reference source/batch_001.csv --workdir output/runtime --reset` is a guided/reference run; keep it closed during independent attempts.
4. Use `workspace/pipeline_TODO.py` for your own implementation.
5. Inspect `output/runtime/raw`, `staging`, `quarantine`, `runs`, `state.json` and `serving.sqlite` - do not mark success from one log line.
6. The dbt project is genuine project structure. Actual dbt/DuckDB execution is a learner-PC validation; the supplied project is statically checked but no live dbt run is claimed here.
7. Save a genuine attempt before opening Explained Reviews or protected test answers.
