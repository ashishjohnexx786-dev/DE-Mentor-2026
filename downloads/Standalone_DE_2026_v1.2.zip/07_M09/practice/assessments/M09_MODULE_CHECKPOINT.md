# M09 Module Practical - closed book

Use a clean runtime folder. With learner book/review/answers closed:
1. Run batch_001 and batch_002 and prove 9 unique serving orders with total net_sales 84870.00.
2. Prove O6002 is the newer four-unit version with net_sales 1800.00.
3. Run the bad batch and schema-drift batch and prove neither advances processed state nor mutates serving output.
4. Trigger one transient database-lock retry and one injected post-staging failure; explain why only the transient case may end in SUCCESS.
5. Trace one serving row to source_run_id, run metadata, raw filename and SHA-256.
6. Draw the dbt dependency graph source -> stg_orders -> int_orders_deduped -> fct_orders; identify tests and materializations.
7. Explain which checks belong in CI and which require runtime/source access.

Pass only with saved commands, actual outputs, row/value reconciliation and a 3-5 minute architecture defense.
