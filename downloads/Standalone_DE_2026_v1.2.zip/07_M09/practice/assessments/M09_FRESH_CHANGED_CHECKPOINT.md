# M09 Fresh Changed Checkpoint - keep sealed until needed

Use batch_fresh_retest.csv in a clean runtime. Do not copy commands from the first checkpoint.
- Predict normalized region/product and all three net_sales values before execution.
- Run the pipeline and reconcile source rows to serving outcomes.
- Add one deliberately duplicated fresh key with a later timestamp, then explain the expected latest-wins result.
- Change one source column name and prove contract failure cannot silently enter serving.
- In the dbt project, design one additional business test for this fresh scenario and state whether it should be error or warning severity.
- Explain how you would rebuild from scratch if the incremental model's historical logic changes.
