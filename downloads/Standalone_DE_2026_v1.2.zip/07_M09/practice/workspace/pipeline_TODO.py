"""M09 learner workspace. Fill TODOs after following the learner book.
Do not copy pipeline_reference.py before a genuine attempt.
"""
from pathlib import Path

def transform_row(raw):
    # TODO DE09-03/05: normalize text, parse types, validate contract, derive net_sales deterministically.
    raise NotImplementedError

def deduplicate(records):
    # TODO DE09-04: stable latest-wins; ambiguous same-timestamp conflicts must not be guessed.
    raise NotImplementedError

def reconcile(source_rows, staged_rows, quarantined_rows, dedup_discarded):
    # TODO DE09-06: prove every source row has an explicit outcome.
    raise NotImplementedError

def run_pipeline(batch_path: Path):
    # TODO DE09-07..10: raw evidence -> stage/quarantine -> quality gate -> transactional serving -> atomic state -> run metadata.
    raise NotImplementedError
