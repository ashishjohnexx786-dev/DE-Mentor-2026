"""Create the local raw.raw_orders source table for the M09 dbt practice project.
Run from the dbt_project directory after installing requirements.
"""
from pathlib import Path
import csv
import duckdb

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'source'
DB = HERE / 'm09_dbt.duckdb'
FILES = [SOURCE / 'batch_001.csv', SOURCE / 'batch_002_incremental.csv']

con = duckdb.connect(str(DB))
con.execute('create schema if not exists raw')
con.execute('drop table if exists raw.raw_orders')
con.execute('''create table raw.raw_orders(
    order_id varchar,
    updated_at timestamp,
    customer_id varchar,
    region varchar,
    product varchar,
    qty integer,
    unit_price decimal(18,2),
    discount_pct decimal(9,4),
    status varchar
)''')
for path in FILES:
    con.execute("""insert into raw.raw_orders
        select order_id, cast(replace(updated_at,'Z','') as timestamp), customer_id,
               region, product, cast(qty as integer), cast(unit_price as decimal(18,2)),
               cast(discount_pct as decimal(9,4)), status
        from read_csv_auto(?, header=true)
    """, [str(path)])
rows = con.execute('select count(*) from raw.raw_orders').fetchone()[0]
print(f'raw.raw_orders rows={rows}; database={DB}')
con.close()
