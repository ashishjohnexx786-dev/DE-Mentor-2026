-- A dbt singular data test passes when this query returns zero rows.
select *
from {{ ref('fct_orders') }}
where net_sales < 0
