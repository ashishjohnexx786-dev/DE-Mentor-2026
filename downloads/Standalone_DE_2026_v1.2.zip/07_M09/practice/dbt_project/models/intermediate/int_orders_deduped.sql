with latest_ts as (
    select order_id, max(updated_at) as max_updated_at
    from {{ ref('stg_orders') }}
    group by order_id
),
latest_candidates as (
    select s.*
    from {{ ref('stg_orders') }} s
    inner join latest_ts l
      on s.order_id = l.order_id
     and s.updated_at = l.max_updated_at
),
unambiguous_latest as (
    select order_id, updated_at
    from latest_candidates
    group by order_id, updated_at
    having count(*) = 1
)
select
    c.order_id,
    c.updated_at,
    c.customer_id,
    c.region,
    c.product,
    c.qty,
    c.unit_price,
    c.discount_pct,
    c.status
from latest_candidates c
inner join unambiguous_latest u
  on c.order_id = u.order_id
 and c.updated_at = u.updated_at
