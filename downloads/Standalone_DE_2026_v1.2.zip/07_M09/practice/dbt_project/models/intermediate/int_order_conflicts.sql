with latest_ts as (
    select order_id, max(updated_at) as max_updated_at
    from {{ ref('stg_orders') }}
    group by order_id
),
latest_candidates as (
    select s.*
    from {{ ref('stg_orders') }} s
    inner join latest_ts l
      on s.order_id = l.order_id
     and s.updated_at = l.max_updated_at
)
select
    order_id,
    updated_at,
    count(*) as candidate_count
from latest_candidates
group by order_id, updated_at
having count(*) > 1
