{{ config(materialized='incremental', unique_key='order_id') }}

select
  order_id,
  updated_at,
  customer_id,
  region,
  product,
  qty,
  unit_price,
  discount_pct,
  status,
  round(qty * unit_price * (1 - discount_pct), 2) as net_sales
from {{ ref('int_orders_deduped') }}
{% if is_incremental() %}
-- >= intentionally re-reads the current maximum timestamp so a new row tied at
-- that timestamp is not skipped. unique_key makes those re-reads safe.
-- A real source with arbitrarily late historical updates needs a wider lookback,
-- CDC, or another source-owned change contract; this one predicate is not magic.
where updated_at >= (select coalesce(max(updated_at), '1900-01-01') from {{ this }})
{% endif %}
