select
  order_id, updated_at, customer_id, region, product, qty, unit_price, discount_pct, status,
  round(qty * unit_price * (1 - discount_pct), 2) as net_sales
from {{ ref('int_orders_deduped') }}
