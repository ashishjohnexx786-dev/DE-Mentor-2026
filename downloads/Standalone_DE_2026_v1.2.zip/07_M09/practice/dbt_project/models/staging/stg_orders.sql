select
  trim(order_id) as order_id,
  updated_at,
  trim(customer_id) as customer_id,
  case lower(trim(region))
    when 'east' then 'East' when 'west' then 'West'
    when 'north' then 'North' when 'south' then 'South'
    else null end as region,
  trim(product) as product,
  cast(qty as integer) as qty,
  cast(unit_price as decimal(18,2)) as unit_price,
  cast(discount_pct as decimal(9,4)) as discount_pct,
  trim(status) as status
from {{ source('raw','raw_orders') }}
