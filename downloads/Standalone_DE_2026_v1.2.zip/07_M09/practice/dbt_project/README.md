# M09 dbt practice project

This is a real local dbt project for DE09-11 through DE09-13. It uses DuckDB, so no paid cloud account is required.

## Runtime truth

The project structure, SQL/Jinja, YAML, tests and setup script are statically checked. `dbt debug`, `dbt parse`, `dbt build`, `dbt test` and `dbt docs generate` remain learner-PC runtime checks. Do not treat "files exist" as proof that dbt ran.

As checked on 14 September 2026: dbt-core 1.12.4 is the current stable Core release, dbt-duckdb 1.11.0 is current, and DuckDB 1.5.5 is the stable DuckDB line. The supplied requirements allow compatible stable 1.x patch updates rather than freezing one patch forever.

## Local route

1. Create and activate a virtual environment.
2. From `practice/`, run `python -m pip install -r requirements.txt`.
3. Enter `practice/dbt_project/`.
4. Run `python setup_raw_duckdb.py`. Expected: `raw.raw_orders rows=10`.
5. Copy `profiles.yml.example` to `profiles.yml` **inside this dbt_project folder**. It contains no real secret and is git-ignored.
6. Run `dbt debug --profiles-dir .` and save the result.
7. Run `dbt parse --profiles-dir .`, then `dbt build --profiles-dir .`.
8. Inspect the graph and relations. Deliberately break one fixture or rule so a test fails for the reason you predict.
9. Repair the weak rule and rerun `dbt build --profiles-dir .` / `dbt test --profiles-dir .`.
10. Run `dbt docs generate --profiles-dir .`; if your route supports a local docs server, inspect model descriptions and lineage.

## What should exist

`source('raw','raw_orders')` resolves to schema `raw`, table `raw_orders`, which is exactly what `setup_raw_duckdb.py` creates. The staging model normalizes fields. The intermediate model deduplicates the supplied unambiguous order versions. The fact model calculates net sales. The incremental model uses `order_id` as its unique key.

The Python reliability lab also contains an intentionally ambiguous same-timestamp duplicate case. That case is quarantined there instead of being forced through an arbitrary `row_number()` winner. The dbt fixture is deliberately narrower: it contains only order versions whose latest record is unambiguous.

## Incremental caution

The incremental model re-reads the current maximum timestamp (`>=`) so a newly arrived row tied at the current max timestamp is not skipped. `unique_key='order_id'` makes those re-reads update/merge safely in this exercise. This does **not** solve every late-arriving-data problem. A source that can send arbitrarily old updates needs a source-owned CDC/change contract, a deliberate lookback window, or another reconciliation strategy.

Never put real passwords, tokens or cloud secrets in this project.

## Ambiguous latest-version test
The project deliberately refuses to invent a winner when two rows for the same `order_id` share the same **latest** `updated_at`. `int_order_conflicts` exposes such keys, `int_orders_deduped` excludes them, and `tests/assert_no_ambiguous_latest_orders.sql` makes `dbt test` fail until the source contract supplies a trustworthy tie-break or the conflict is repaired upstream.

Changed proof on the learner PC: insert two different payloads with the same `order_id` and same maximum timestamp into `raw.raw_orders`; run `dbt build --profiles-dir .`. Expect the conflict model to contain that key and the singular test to fail. Do **not** repair this by adding file order or an arbitrary `row_number()` tie-break.
