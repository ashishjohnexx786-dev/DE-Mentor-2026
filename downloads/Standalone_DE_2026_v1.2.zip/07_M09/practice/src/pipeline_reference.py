from __future__ import annotations
import argparse, csv, hashlib, json, shutil, sqlite3, time, uuid
from collections import defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path

EXPECTED=['order_id','updated_at','customer_id','region','product','qty','unit_price','discount_pct','status']
REGIONS={'East','West','North','South'}
STATUSES={'Completed','Pending','Cancelled'}

def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def parse_utc(s):
    if not s.endswith('Z'): raise ValueError('updated_at_must_be_UTC_Z')
    return datetime.fromisoformat(s[:-1]+'+00:00')

def money(x):
    return Decimal(str(x)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def normalize_region(x):
    s=(x or '').strip().title()
    return s

def transform_row(raw, source_row):
    reasons=[]
    def req(k):
        v=(raw.get(k) or '').strip()
        if not v: reasons.append(f'{k}_required')
        return v
    order_id=req('order_id'); customer_id=req('customer_id'); product=req('product')
    region=normalize_region(raw.get('region'))
    if region not in REGIONS: reasons.append('region_invalid')
    status=(raw.get('status') or '').strip().title()
    if status not in STATUSES: reasons.append('status_invalid')
    updated=(raw.get('updated_at') or '').strip()
    try: parse_utc(updated)
    except Exception: reasons.append('updated_at_invalid')
    try:
        qty=int((raw.get('qty') or '').strip())
        if qty<=0: reasons.append('qty_not_positive')
    except Exception:
        qty=None; reasons.append('qty_not_integer')
    try:
        unit=money((raw.get('unit_price') or '').strip())
        if unit<0: reasons.append('unit_price_negative')
    except Exception:
        unit=None; reasons.append('unit_price_invalid')
    try:
        disc=Decimal((raw.get('discount_pct') or '').strip())
        if not (Decimal('0')<=disc<=Decimal('1')): reasons.append('discount_out_of_range')
    except Exception:
        disc=None; reasons.append('discount_invalid')
    if reasons:
        return None, {'source_row':source_row,'order_id':order_id or raw.get('order_id'),'reasons':sorted(set(reasons)),'raw':raw}
    net=money(Decimal(qty)*unit*(Decimal('1')-disc))
    rec={'order_id':order_id,'updated_at':updated,'customer_id':customer_id,'region':region,'product':product.strip(),
         'qty':qty,'unit_price':str(unit),'discount_pct':str(disc.normalize() if disc!=0 else Decimal('0')),
         'status':status,'net_sales':str(net)}
    return rec,None

def canonical_payload(r):
    return json.dumps({k:r[k] for k in sorted(r) if k!='source_row'},sort_keys=True,separators=(',',':'))

def deduplicate(valid):
    by=defaultdict(list)
    for r in valid: by[r['order_id']].append(r)
    accepted=[]; quarantined=[]; discarded=[]
    for key,rows in sorted(by.items()):
        if len(rows)==1:
            accepted.append(rows[0]); continue
        mx=max(r['updated_at'] for r in rows)
        maxima=[r for r in rows if r['updated_at']==mx]
        if len(maxima)>1 and len({canonical_payload(r) for r in maxima})>1:
            for r in maxima:
                quarantined.append({'source_row':r['source_row'],'order_id':key,'reasons':['ambiguous_latest_duplicate'],'raw':r})
            for r in rows:
                if r not in maxima: discarded.append(r)
        else:
            chosen=maxima[0]; accepted.append(chosen)
            for r in rows:
                if r is not chosen: discarded.append(r)
    return accepted,quarantined,discarded

def ensure_db(db):
    con=sqlite3.connect(db)
    con.execute('''CREATE TABLE IF NOT EXISTS orders_serving(
      order_id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, customer_id TEXT NOT NULL,
      region TEXT NOT NULL, product TEXT NOT NULL, qty INTEGER NOT NULL,
      unit_price REAL NOT NULL, discount_pct REAL NOT NULL, status TEXT NOT NULL,
      net_sales REAL NOT NULL, source_run_id TEXT NOT NULL)''')
    con.commit(); return con

def read_state(p):
    if not p.exists(): return {'processed_hashes':[]}
    return json.loads(p.read_text())

def atomic_write_json(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,sort_keys=True),encoding='utf-8')
    tmp.replace(p)

def serving_controls(db):
    con=sqlite3.connect(db)
    try:
        row=con.execute('SELECT COUNT(*), COALESCE(ROUND(SUM(net_sales),2),0) FROM orders_serving').fetchone()
        return {'serving_rows':row[0],'serving_net_sales':float(row[1])}
    finally: con.close()

def run(batch,workdir,threshold=.25,replay=False,fail_after_staging=False,simulate_lock_once=False):
    batch=Path(batch); workdir=Path(workdir); workdir.mkdir(parents=True,exist_ok=True)
    state_p=workdir/'state.json'; db=workdir/'serving.sqlite'; runs=workdir/'runs'; raw_root=workdir/'raw'; staging_root=workdir/'staging'; q_root=workdir/'quarantine'
    for p in [runs,raw_root,staging_root,q_root]: p.mkdir(parents=True,exist_ok=True)
    digest=sha256_file(batch); state=read_state(state_p)
    if digest in state.get('processed_hashes',[]) and not replay:
        return {'status':'SKIPPED_ALREADY_PROCESSED','source_sha256':digest,**serving_controls(db)} if db.exists() else {'status':'SKIPPED_ALREADY_PROCESSED','source_sha256':digest,'serving_rows':0,'serving_net_sales':0.0}
    run_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'Z_'+uuid.uuid4().hex[:6]
    raw_dir=raw_root/run_id; raw_dir.mkdir(); raw_copy=raw_dir/batch.name; shutil.copy2(batch,raw_copy)
    manifest={'run_id':run_id,'source_file':batch.name,'source_sha256':digest,'status':'STARTED','replay':replay,'started_at':datetime.now(timezone.utc).isoformat()}
    atomic_write_json(raw_dir/'_manifest.json',manifest)
    # Read header and preserve raw before contract check.
    with batch.open(newline='',encoding='utf-8-sig') as f:
        rd=csv.DictReader(f); header=rd.fieldnames or []; raw_rows=list(rd)
    if header!=EXPECTED:
        manifest.update(status='FAILED_CONTRACT',expected_columns=EXPECTED,observed_columns=header,source_rows=len(raw_rows))
        atomic_write_json(raw_dir/'_manifest.json',manifest); atomic_write_json(runs/f'{run_id}.json',manifest)
        return manifest
    valid=[]; quarantined=[]
    for i,raw in enumerate(raw_rows,start=2):
        rec,bad=transform_row(raw,i)
        if bad: quarantined.append(bad)
        else: rec['source_row']=i; valid.append(rec)
    staged,dq,discarded=deduplicate(valid); quarantined.extend(dq)
    # remove source-row metadata from stage business rows
    stage_clean=[{k:v for k,v in r.items() if k!='source_row'} for r in staged]
    staging_p=staging_root/f'{run_id}.jsonl'; q_p=q_root/f'{run_id}.jsonl'
    staging_p.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in stage_clean),encoding='utf-8')
    q_p.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in quarantined),encoding='utf-8')
    source_n=len(raw_rows); q_n=len(quarantined); d_n=len(discarded); s_n=len(stage_clean)
    if source_n != s_n+q_n+d_n:
        manifest.update(status='FAILED_RECONCILIATION',source_rows=source_n,staged_rows=s_n,quarantine_rows=q_n,dedup_discarded=d_n)
        atomic_write_json(raw_dir/'_manifest.json',manifest); atomic_write_json(runs/f'{run_id}.json',manifest); return manifest
    q_ratio=(q_n/source_n) if source_n else 0
    manifest.update(source_rows=source_n,staged_rows=s_n,quarantine_rows=q_n,dedup_discarded=d_n,quarantine_ratio=q_ratio)
    if q_ratio>threshold:
        manifest['status']='FAILED_QUALITY_GATE'; atomic_write_json(raw_dir/'_manifest.json',manifest); atomic_write_json(runs/f'{run_id}.json',manifest); return manifest
    if fail_after_staging:
        manifest['status']='FAILED_INJECTED_AFTER_STAGING'; atomic_write_json(raw_dir/'_manifest.json',manifest); atomic_write_json(runs/f'{run_id}.json',manifest); return manifest
    attempts=0
    while True:
        attempts+=1
        try:
            if simulate_lock_once and attempts==1:
                raise sqlite3.OperationalError('simulated database is locked')
            con=ensure_db(db)
            try:
                con.execute('BEGIN IMMEDIATE')
                applied=ignored=0
                for r in stage_clean:
                    old=con.execute('SELECT updated_at,customer_id,region,product,qty,unit_price,discount_pct,status,net_sales FROM orders_serving WHERE order_id=?',(r['order_id'],)).fetchone()
                    if old:
                        if r['updated_at']<old[0]: ignored+=1; continue
                        if r['updated_at']==old[0]:
                            old_payload=(old[1],old[2],old[3],old[4],round(old[5],2),old[6],old[7],round(old[8],2))
                            new_payload=(r['customer_id'],r['region'],r['product'],r['qty'],float(r['unit_price']),float(r['discount_pct']),r['status'],float(r['net_sales']))
                            if old_payload!=new_payload: raise ValueError(f'conflicting_same_timestamp:{r["order_id"]}')
                            ignored+=1; continue
                    con.execute('''INSERT INTO orders_serving(order_id,updated_at,customer_id,region,product,qty,unit_price,discount_pct,status,net_sales,source_run_id)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?)
                      ON CONFLICT(order_id) DO UPDATE SET updated_at=excluded.updated_at,customer_id=excluded.customer_id,region=excluded.region,product=excluded.product,qty=excluded.qty,unit_price=excluded.unit_price,discount_pct=excluded.discount_pct,status=excluded.status,net_sales=excluded.net_sales,source_run_id=excluded.source_run_id''',
                      (r['order_id'],r['updated_at'],r['customer_id'],r['region'],r['product'],r['qty'],float(r['unit_price']),float(r['discount_pct']),r['status'],float(r['net_sales']),run_id))
                    applied+=1
                con.commit()
            except Exception:
                con.rollback(); raise
            finally: con.close()
            break
        except sqlite3.OperationalError as e:
            if 'locked' in str(e).lower() and attempts<3:
                time.sleep(.05); continue
            raise
    ctrl=serving_controls(db)
    manifest.update(status='SUCCESS',db_attempts=attempts,applied_rows=applied,ignored_stale_or_same=ignored,**ctrl,finished_at=datetime.now(timezone.utc).isoformat())
    atomic_write_json(raw_dir/'_manifest.json',manifest); atomic_write_json(runs/f'{run_id}.json',manifest)
    if digest not in state.get('processed_hashes',[]):
        state.setdefault('processed_hashes',[]).append(digest)
    state['last_successful_run_id']=run_id
    atomic_write_json(state_p,state)
    return manifest

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('batch'); ap.add_argument('--workdir',default='output/runtime'); ap.add_argument('--threshold',type=float,default=.25); ap.add_argument('--replay',action='store_true'); ap.add_argument('--reset',action='store_true'); ap.add_argument('--fail-after-staging',action='store_true'); ap.add_argument('--simulate-lock-once',action='store_true')
    a=ap.parse_args(); w=Path(a.workdir)
    if a.reset and w.exists(): shutil.rmtree(w)
    out=run(a.batch,w,a.threshold,a.replay,a.fail_after_staging,a.simulate_lock_once); print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
