import sqlite3, sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else 'output/runtime/serving.sqlite')
con=sqlite3.connect(p)
rows=con.execute('SELECT order_id,updated_at,region,product,qty,net_sales,source_run_id FROM orders_serving ORDER BY order_id').fetchall()
for r in rows: print(r)
print('COUNT',len(rows))
print('NET',con.execute('SELECT ROUND(SUM(net_sales),2) FROM orders_serving').fetchone()[0])
