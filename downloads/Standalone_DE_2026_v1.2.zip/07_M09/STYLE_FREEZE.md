# House style freeze
M09 follows the M00-M08 learner-facing visual family: DejaVu Sans, ink #173047, teal #087F8C, blue #2563EB, pale teaching/code #EDF7FA, A4, 43pt side margins, thin teal running-header line, teal+blue footer bar. Learner-facing files contain no internal benchmark/model names.

- Normal lesson-section headings: blue #2563EB.
- Teal #087F8C is structural only: rules, borders, footer bars, callout accents and cover kickers.
