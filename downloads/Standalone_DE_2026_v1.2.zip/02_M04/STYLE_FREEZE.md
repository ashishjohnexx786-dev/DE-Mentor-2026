# Standalone DE 2026 - learner-facing visual style freeze

This module uses the same visual family as the M00-M03 house books.

- Body font: DejaVu Sans, 10.5 pt / 15 pt leading
- Main ink: #173047
- Teal accent: #087F8C
- Blue heading/link accent: #2563EB
- Pale teaching/code fill: #EDF7FA
- A4, 43 pt side margins
- Thin teal running-header rule
- Teal + blue footer bars
- Cover grammar: kicker -> module title -> Read/Watch/Do/Explain (or matching review/check subtitle)
- Learner content was not intentionally shortened during this style normalization.

- Normal lesson-section headings: blue #2563EB.
- Teal #087F8C is structural only: rules, borders, callout accents, header/footer bars and cover kickers.
