# M04 Python Foundations - Review Edition

Start with `books/M04_Learner_Book.pdf` and study DE04-01 through DE04-16 in order. Use `WATCH_GUIDE.md` for the assigned real instructor/source support. Save your independent attempt before opening `books/M04_Explained_Reviews.pdf`. Use `books/M04_Cluster_Checks.pdf` only after the matching lesson cluster.

M04 stays deliberately local: Git/WSL arrives in M06, Docker/Airflow later. pandas begins at DE04-11 and the lightweight coding/interview lane begins at DE04-12/13. DE04-16 is the integrated module checkpoint.

 No generated course videos are included. This is a review edition: static/fixture QA is complete, while native Windows/VS Code and Android learner-device validation remains pending.
