"""DE04-16 Major Checkpoint - FIRST ATTEMPT.
Build this without review/answer material open.

Required outcome:
1) accept a CSV path relative to this project/module, not a personal absolute path;
2) fail clearly if the file is absent or required columns are missing;
3) preserve raw input;
4) parse qty/unit_price as numeric with invalid values surfaced, not silently coerced to zero;
5) calculate sales = qty * unit_price;
6) keep Completed rows;
7) produce regional totals, top 3 Completed orders, missing-sales_rep count;
8) write deterministic JSON (stable key ordering / predictable structure);
9) read the JSON back and validate critical controls;
10) document the exact run command and one deliberate bad-input failure.
"""
from pathlib import Path

REQUIRED = {"order_id","region","status","qty","unit_price","sales_rep"}


def main():
    raise NotImplementedError("Build the checkpoint independently.")

if __name__ == "__main__":
    main()
