"""Standalone DE 2026 - M04 learner practice.

Work in a COPY under your own module-work folder. Do not turn this file into an answer key.
Save a genuine attempt before opening M04_Explained_Reviews.pdf.
"""

# DE04-01 - Python setup and first program
# Create a separate p01_first_program.py. Print your name, "Standalone DE 2026",
# and the result of 7 * 8. Then deliberately create, observe, save and repair one syntax error.

# DE04-02 - Variables, data types and operators
# Create order_id="O3107", qty=4, unit_price=850.0, status="Completed".
# Calculate gross_sales and a boolean gross_sales >= 3000. Print each value and type.

# DE04-03 - Strings and formatting
# Start with raw_label="  north HUB  " and shipment_id="s009".
# Create a cleaned display label without destroying the raw value. Build a readable message
# with an f-string. Prove that string cleaning is not the same as identity matching.

# DE04-04 - Conditions and boolean logic
# Classify an order as "priority" only when status == "Completed" and amount >= 2500.
# Predict and test at least: Completed/2499, Completed/2500, Completed/2501, Pending/3000.

# DE04-05 - Lists, tuples, sets and dictionaries
# Represent: processing steps in order, one fixed year/month pair, unique failed batch IDs,
# and a region -> manager mapping. Explain why each collection fits its job.

# DE04-06 - Loops and iteration
# Given amounts=[1200, 500, 0, 800, 1500], calculate a total and count positive amounts
# without mutating the input while iterating. Then write a loop that records invalid zeros separately.

# DE04-07 - Functions and scope
# Write summarize_order(order_id, qty, unit_price) returning a dict with order_id and gross_sales.
# Test at least two normal inputs and one zero-quantity input. Do not rely on a hidden global.

# DE04-08 - Modules, imports and project structure
# Use stage04_helpers.py from a separate entry script. Import one function without duplicating it.
# Add a __main__ guard to the entry script and explain what executes on import vs direct run.

# DE04-09 - Exceptions and debugging basics
# Use M04_Debug_Me.py. Preserve the first traceback/error, identify the exception type and failing
# expression, repair one cause at a time, and add a narrow exception handler only where recovery is valid.

# DE04-10 - Files, paths, CSV and JSON I/O
# Read ../data/M04_Retail_Orders.csv with csv.DictReader using pathlib.
# Write a JSON manifest with source filename, expected row count and status; read it back and assert values.

# DE04-11 - pandas foundations
# Load ../data/M04_Retail_Orders.csv. Inspect shape, columns, dtypes and missingness BEFORE transformation.
# Calculate sales=qty*unit_price, filter Completed, aggregate by region, find top 3 Completed orders,
# and count missing sales_rep. State the grain of every output.

# DE04-12 - Practical Big-O intuition
# Explain in comments why repeated membership checks against a list are O(n) per lookup,
# why set membership is average O(1), and why a nested full scan can be O(n^2).
# Do not use a one-off stopwatch as proof of Big-O.
