"""Starter helper module for DE04-08. Keep this file small and explicit."""

def gross_sales(qty, unit_price):
    """Return gross sales for one record."""
    return qty * unit_price


def normalized_label(text):
    """Return a display-normalized label while leaving source data untouched."""
    return text.strip().lower()
