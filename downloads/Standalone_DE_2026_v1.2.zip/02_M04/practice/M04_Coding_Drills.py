"""DE04-13 to DE04-15 starter drills. Implement TODOs without opening review first."""
from collections import deque

# DE04-13

def reverse_words(text):
    """Return words in reverse order, preserving the characters inside each word."""
    raise NotImplementedError("TODO DE04-13")


def count_vowels(text):
    """Return the number of a/e/i/o/u characters, case-insensitive."""
    raise NotImplementedError("TODO DE04-13")

# DE04-14

def frequency_map(items):
    """Return {item: occurrence_count}."""
    raise NotImplementedError("TODO DE04-14")


def unique_in_order(items):
    """Return first occurrences in original order. Use a set for membership, list for output order."""
    raise NotImplementedError("TODO DE04-14")

# DE04-15

def linear_search(values, target):
    """Return first index of target, or -1 when absent."""
    raise NotImplementedError("TODO DE04-15")


def binary_search(sorted_values, target):
    """Return an index of target in sorted_values, or -1. PRECONDITION: input sorted ascending."""
    raise NotImplementedError("TODO DE04-15")


def stack_demo():
    stack=[]
    # TODO: push ingest, transform, publish; pop one and return (popped, remaining)
    raise NotImplementedError("TODO DE04-15")


def queue_demo():
    queue=deque()
    # TODO: enqueue ingest, transform, publish; remove one FIFO and return (removed, remaining_list)
    raise NotImplementedError("TODO DE04-15")
