"""DE04-09 debugging starter. This file is intentionally broken.
Do not repair every issue at once. Save the observed traceback first.
"""
orders = [
    {"order_id": "O1", "qty": 2, "unit_price": 850.0},
    {"order_id": "O2", "qty": "3", "unit_price": 500.0},
    {"order_id": "O3", "qty": 1, "unit_price": 0.0},
]

def calculate_sales(order):
    return order["qty"] * order["unit_price"]

for order in orders:
    sales = calculate_sales(order)
    average_unit = sales / order["qty"]
    print(order["order_id"], sales, average_unit)
