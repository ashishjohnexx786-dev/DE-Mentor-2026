"""DE04-16 CHANGED RETEST - open only if review assigns it.
Use M04_Retest_Shipments.csv. This is not the same problem with renamed variables.

Required outcome:
- validate shipment_id, hub, status, cartons, unit_cost, coordinator;
- calculate shipment_value;
- preserve Delivered only for the main report;
- aggregate value by hub;
- list top 3 Delivered shipments with deterministic tie handling;
- count missing coordinator values over the declared population;
- write/read deterministic JSON;
- demonstrate one schema or file-path failure visibly;
- explain input grain, report grain and rerun behavior.
"""

def main():
    raise NotImplementedError("Fresh retest: implement after assigned repair.")

if __name__ == "__main__":
    main()
