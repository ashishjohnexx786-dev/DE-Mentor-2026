"""Visible learner tests for DE04-13..15. These reveal contracts, not implementations."""
from M04_Coding_Drills import (
    reverse_words, count_vowels, frequency_map, unique_in_order,
    linear_search, binary_search, stack_demo, queue_demo,
)

def run():
    assert reverse_words("data engineering is fun") == "fun is engineering data"
    assert reverse_words("") == ""
    assert count_vowels("Data") == 2
    assert count_vowels("") == 0
    assert frequency_map(["A","B","A","C","A"]) == {"A":3,"B":1,"C":1}
    assert unique_in_order(["B","A","B","C","A"]) == ["B","A","C"]
    assert linear_search([4,12,7,3], 12) == 1
    assert linear_search([4,12,7,3], 99) == -1
    assert binary_search([1,3,4,7,12], 7) in {3}
    assert binary_search([1,3,4,7,12], 6) == -1
    popped, remaining = stack_demo()
    assert popped == "publish" and remaining == ["ingest","transform"]
    removed, remaining_q = queue_demo()
    assert removed == "ingest" and remaining_q == ["transform","publish"]
    print("VISIBLE TESTS PASS")

if __name__ == "__main__":
    run()
