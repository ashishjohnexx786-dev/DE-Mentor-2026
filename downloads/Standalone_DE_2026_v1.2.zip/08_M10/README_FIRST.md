# M10 - Docker + Airflow

Study `books/M10_Learner_Book.pdf` in DE10-01 -> DE10-19 order. Run the pure-Python simulator locally. Use the Docker and Airflow folders for real learner-PC execution when those runtimes are available. Save first attempts before `M10_Explained_Reviews.pdf`.

After M10 mastery, take protected **G04 Gate A**. Review A may repair; it never counts as a pass. Fresh Gate B is a different scenario.

Later recall: `../00_STUDY_MODULES/M10/M10_Quick_Revision_Book.pdf` -> closed-book Module Revision Test -> protected answer guide.
