#!/usr/bin/env bash
set -euo pipefail

AIRFLOW_VERSION="3.3.1"
VENV_DIR="${M10_VENV_DIR:-$HOME/venvs/m10-airflow}"

python3 -m venv "$VENV_DIR"
# shellcheck disable=SC1090
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip
PYTHON_VERSION="$(python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
CONSTRAINT_URL="https://raw.githubusercontent.com/apache/airflow/constraints-${AIRFLOW_VERSION}/constraints-${PYTHON_VERSION}.txt"
python -m pip install "apache-airflow==${AIRFLOW_VERSION}" --constraint "$CONSTRAINT_URL"
airflow version
printf '\nInstalled Airflow %s in %s\n' "$AIRFLOW_VERSION" "$VENV_DIR"
printf 'Next: source practice/airflow/activate_m10_airflow.sh\n'
