# M10 Airflow 3.3.1 scaffold

Start with `AIRFLOW_SETUP_WSL.md` and source `activate_m10_airflow.sh` in **every** WSL terminal.

This package uses the Airflow 3 DAG-authoring namespace (`airflow.sdk`). The build environment does not run a live Airflow scheduler, so Python compile/static checks are release evidence only. Learner-PC proof remains required for DAG discovery, scheduler execution, task logs, a missing-input failure/recovery, and the FileSensor lesson.

The daily DAG reads learner-owned paths from `M10_DATA_ROOT` and writes to `M10_OUTPUT_ROOT`; it no longer assumes Docker-only `/opt/airflow/...` paths.
