# M10 Airflow 3.3.1 setup - Windows learner route via WSL2

Use this once before DE10-08. If WSL2 already works from M06, do not reinstall it.

This repair removes a hidden two-terminal state problem: **every WSL terminal must source the supplied `activate_m10_airflow.sh` file**. Activating a Python venv alone does not restore `AIRFLOW_HOME` or the course data/output paths.

## 0. Know the extracted course path

In Windows Explorer, locate the extracted course folder. In WSL it may look like `/mnt/c/Users/YOU/Downloads/STANDALONE_DE_2026/...`.
For the commands below, set one variable to the real extracted M10 directory:

```bash
export M10_COURSE_DIR="/mnt/c/replace/with/your/extracted/course/08_M10"
```

Verify:

```bash
test -f "$M10_COURSE_DIR/practice/airflow/activate_m10_airflow.sh" && echo COURSE_PATH_OK
```

Expected: `COURSE_PATH_OK`.

## 1. Create the isolated venv

```bash
mkdir -p ~/standalone-de/m10-airflow
cd ~/standalone-de/m10-airflow
python3 -m venv .venv
source .venv/bin/activate
python --version
python -m pip install --upgrade pip
```

## 2. Install Airflow 3.3.1 with official constraints

```bash
export AIRFLOW_HOME="$HOME/airflow-m10"
AIRFLOW_VERSION=3.3.1
PYTHON_VERSION="$(python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
CONSTRAINT_URL="https://raw.githubusercontent.com/apache/airflow/constraints-${AIRFLOW_VERSION}/constraints-${PYTHON_VERSION}.txt"
python -m pip install "apache-airflow==${AIRFLOW_VERSION}" --constraint "${CONSTRAINT_URL}"
airflow version
```

Expected course baseline: `3.3.1`. Save the exact Python version and error if installation fails. Do not drop the constraints file simply to force an install.

## 3. Source the reusable course environment in **every** terminal

```bash
source "$M10_COURSE_DIR/practice/airflow/activate_m10_airflow.sh"
```

Expected printed paths include:
- `AIRFLOW_HOME=$HOME/airflow-m10`
- `DAGS=$AIRFLOW_HOME/dags`
- learner-owned `DATA` and `OUTPUT` folders under `~/standalone-de/m10-airflow/`.

Sanity check:

```bash
printf '%s\n' "$AIRFLOW_HOME" "$AIRFLOW__CORE__DAGS_FOLDER" "$M10_DATA_ROOT" "$M10_OUTPUT_ROOT"
```

## 4. Copy the supplied data and DAGs to the exact paths the DAG uses

```bash
cp "$M10_COURSE_DIR"/practice/simulator/input/orders_2026-09-0{1,2,3}.csv "$M10_DATA_ROOT/"
cp "$M10_COURSE_DIR/practice/airflow/dags/m10_daily_orders.py" "$AIRFLOW__CORE__DAGS_FOLDER/"
cp "$M10_COURSE_DIR/practice/airflow/dags/m10_wait_for_file.py" "$AIRFLOW__CORE__DAGS_FOLDER/"
ls -l "$M10_DATA_ROOT"
ls -l "$AIRFLOW__CORE__DAGS_FOLDER"
```

Expected data files: `orders_2026-09-01.csv`, `orders_2026-09-02.csv`, `orders_2026-09-03.csv`.

The daily DAG has a **finite teaching history**: it represents only those three partitions. This prevents catchup from generating months of intentional missing-file failures.

## 5. Start the local learning instance

Terminal A:

```bash
source "$M10_COURSE_DIR/practice/airflow/activate_m10_airflow.sh"
airflow standalone
```

Keep Terminal A open. Standalone initializes the local metadata database and starts the local components. SQLite is acceptable for this single-machine learning route; it is not the production-backend recommendation.

Open `http://localhost:8080` in the Windows browser. Airflow 3.x may write generated Simple Auth credentials under the selected Airflow home. If needed:

```bash
cat "$AIRFLOW_HOME/simple_auth_manager_passwords.json.generated"
```

Do not commit that password or the generated Airflow home directory.

## 6. Prove DAG discovery from a fresh second terminal

Terminal B:

```bash
export M10_COURSE_DIR="/mnt/c/replace/with/your/extracted/course/08_M10"
source "$M10_COURSE_DIR/practice/airflow/activate_m10_airflow.sh"
airflow version
airflow dags list
airflow dags list-import-errors
```

`m10_daily_orders` must appear and `airflow dags list-import-errors` must not show an import error for it.

Airflow 3.3.1 uses an absolute DAG folder configured from `AIRFLOW_HOME` by default; this lab also exports `AIRFLOW__CORE__DAGS_FOLDER` explicitly so a new terminal cannot silently inspect another home.

## 7. Run the three supplied historical partitions with the scheduler

DAGs may be paused at creation. In the UI, unpause `m10_daily_orders`. Because the DAG has `start_date=2026-09-01`, `end_date=2026-09-03`, daily schedule and `catchup=True`, the end date bounds the interval start inclusively, so the scheduler has exactly three teaching data intervals whose `data_interval_start` dates are September 1, 2 and 3.

Watch the Graph/Grid and open task logs. The expected learner outputs are:

```bash
ls -l "$M10_OUTPUT_ROOT"
cat "$M10_OUTPUT_ROOT/published_2026-09-01.txt"
cat "$M10_OUTPUT_ROOT/published_2026-09-02.txt"
cat "$M10_OUTPUT_ROOT/published_2026-09-03.txt"
```

Each published file should contain a positive `rows=<n>` value. Save UI/log evidence that the partition date comes from Airflow data-interval context rather than `date.today()`.

## 8. Deliberate missing-input failure and recovery

Do this only after you have proved one successful run. Pause the DAG, remove one output, temporarily move the September 3 input aside, clear/rerun only the corresponding failed interval/task in the UI, and observe `FileNotFoundError` with the exact missing learner path.

```bash
mv "$M10_DATA_ROOT/orders_2026-09-03.csv" "$M10_DATA_ROOT/orders_2026-09-03.csv.hold"
```

After saving the failure evidence, restore the file:

```bash
mv "$M10_DATA_ROOT/orders_2026-09-03.csv.hold" "$M10_DATA_ROOT/orders_2026-09-03.csv"
```

Clear the failed task/run and rerun it. Recovery is complete only when the September 3 published output is recreated and the log shows the same business partition.

## 9. FileSensor lesson/provider setup (only when DE10 reaches sensors)

Install the standard provider under the same Airflow constraints:

```bash
source "$M10_COURSE_DIR/practice/airflow/activate_m10_airflow.sh"
AIRFLOW_VERSION=3.3.1
PYTHON_VERSION="$(python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
CONSTRAINT_URL="https://raw.githubusercontent.com/apache/airflow/constraints-${AIRFLOW_VERSION}/constraints-${PYTHON_VERSION}.txt"
python -m pip install apache-airflow-providers-standard --constraint "${CONSTRAINT_URL}"
```

The supplied `m10_wait_for_file.py` uses connection id `m10_fs`. Create a File (path) connection named `m10_fs` whose extra/path points to your learner data directory. In the Airflow UI use Connections, or use an equivalent supported connection method for your install. The important invariant is: the FileSensor's base path resolves to the same directory printed as `$M10_DATA_ROOT`.

Then re-run:

```bash
airflow dags list-import-errors
```

and trigger `m10_wait_for_file`. It should succeed while `orders_2026-09-03.csv` exists and fail/timeout if you deliberately move that file away.

Official FileSensor behavior: `filepath` is relative to the base path defined by its filesystem connection.

## 10. Evidence before you move on

Save:
- `airflow version`;
- the four environment paths printed by `activate_m10_airflow.sh`;
- no import error for `m10_daily_orders`;
- Graph/Grid showing the three finite historical runs;
- one successful task log with partition identity;
- one missing-input failure and recovered rerun;
- output files under `$M10_OUTPUT_ROOT`;
- when the sensor lesson is reached, provider/connection evidence and one sensor success/failure case.

## 11. Stop/recover

Stop `airflow standalone` with Ctrl+C when the lab is over. On an 8 GB learning laptop, do not keep Docker Desktop, Airflow, Spark and Kafka all running together unless a deliberate integration lesson requires it.

If the environment becomes unclear, preserve your DAG/evidence, then rebuild the disposable venv/AIRFLOW_HOME only after confirming what you need to keep. Always re-source `activate_m10_airflow.sh` in a new terminal.

Official references:
- Airflow 3.3.1 configuration reference: https://airflow.apache.org/docs/apache-airflow/3.3.1/configurations-ref.html
- Airflow configuration environment variables: https://airflow.apache.org/docs/apache-airflow/3.3.1/howto/set-config.html
- FileSensor reference: https://airflow.apache.org/docs/apache-airflow-providers-standard/stable/sensors/file.html
