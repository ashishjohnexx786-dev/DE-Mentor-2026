from __future__ import annotations
from datetime import timedelta
from pathlib import Path
import csv
import logging
import os
import pendulum
from airflow.sdk import Param, dag, get_current_context, task

DATA_ROOT = Path(os.environ.get("M10_DATA_ROOT", str(Path.home() / "standalone-de/m10-airflow/data")))
OUTPUT_ROOT = Path(os.environ.get("M10_OUTPUT_ROOT", str(Path.home() / "standalone-de/m10-airflow/output")))

@dag(
    dag_id="m10_daily_orders",
    schedule="@daily",
    start_date=pendulum.datetime(2026, 9, 1, tz="UTC"),
    # end_date bounds interval START inclusively. Finite learner history: data_interval_start dates 2026-09-01, 02 and 03 only.
    end_date=pendulum.datetime(2026, 9, 3, tz="UTC"),
    catchup=True,
    max_active_runs=1,
    params={"min_rows": Param(1, type="integer", minimum=1)},
    tags=["standalone-de", "m10"],
)
def m10_daily_orders():
    @task(retries=2, retry_delay=timedelta(seconds=30), execution_timeout=timedelta(minutes=5))
    def extract_partition() -> dict:
        ctx = get_current_context()
        start = ctx["data_interval_start"]
        partition = start.date().isoformat()
        path = DATA_ROOT / f"orders_{partition}.csv"
        if not path.exists():
            raise FileNotFoundError(
                f"missing learner partition {path}; DATA_ROOT={DATA_ROOT}. "
                "Copy the supplied simulator/input files using AIRFLOW_SETUP_WSL.md."
            )
        return {"partition": partition, "path": str(path)}

    @task
    def validate_partition(meta: dict) -> dict:
        ctx = get_current_context()
        min_rows = int(ctx["params"]["min_rows"])
        path = Path(meta["path"])
        rows = list(csv.DictReader(path.open(encoding="utf-8")))
        ids = [r["order_id"] for r in rows]
        if len(rows) < min_rows:
            raise ValueError(f"row count {len(rows)} below min_rows {min_rows}")
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate order_id")
        logging.info("partition=%s rows=%s", meta["partition"], len(rows))
        return {"partition": meta["partition"], "rows": len(rows), "path": meta["path"]}

    @task
    def publish_partition(check: dict) -> dict:
        OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
        target = OUTPUT_ROOT / f"published_{check['partition']}.txt"
        target.write_text(f"rows={check['rows']}\n", encoding="utf-8")
        return {"partition": check["partition"], "output": str(target), "rows": check["rows"]}

    publish_partition(validate_partition(extract_partition()))

m10_daily_orders()
