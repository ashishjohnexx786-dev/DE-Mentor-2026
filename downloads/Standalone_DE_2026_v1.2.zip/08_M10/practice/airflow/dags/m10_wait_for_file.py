from __future__ import annotations
import os
from pathlib import Path
import pendulum
from airflow.sdk import dag
from airflow.providers.standard.sensors.filesystem import FileSensor

DATA_ROOT = Path(os.environ.get("M10_DATA_ROOT", str(Path.home() / "standalone-de/m10-airflow/data")))

@dag(dag_id="m10_wait_for_file", schedule=None, start_date=pendulum.datetime(2026,9,1,tz="UTC"), catchup=False)
def m10_wait_for_file():
    # FileSensor requires a File(path) connection. Setup guide creates m10_fs rooted at M10_DATA_ROOT.
    FileSensor(
        task_id="wait_for_partition",
        fs_conn_id="m10_fs",
        filepath="orders_2026-09-03.csv",
        poke_interval=10,
        timeout=180,
        deferrable=False,
    )

m10_wait_for_file()
