#!/usr/bin/env bash
# Source this file in every new WSL terminal used for M10 Airflow labs:
#   source /path/to/extracted/course/08_M10/practice/airflow/activate_m10_airflow.sh
set -a
export M10_VENV_DIR="${M10_VENV_DIR:-$HOME/standalone-de/m10-airflow/.venv}"
export AIRFLOW_HOME="${AIRFLOW_HOME:-$HOME/airflow-m10}"
export AIRFLOW__CORE__DAGS_FOLDER="${AIRFLOW__CORE__DAGS_FOLDER:-$AIRFLOW_HOME/dags}"
export M10_DATA_ROOT="${M10_DATA_ROOT:-$HOME/standalone-de/m10-airflow/data}"
export M10_OUTPUT_ROOT="${M10_OUTPUT_ROOT:-$HOME/standalone-de/m10-airflow/output}"
set +a
if [ -f "$M10_VENV_DIR/bin/activate" ]; then
  # shellcheck disable=SC1090
  source "$M10_VENV_DIR/bin/activate"
else
  echo "M10 venv not found at $M10_VENV_DIR. Create it first using AIRFLOW_SETUP_WSL.md." >&2
fi
mkdir -p "$AIRFLOW_HOME" "$AIRFLOW__CORE__DAGS_FOLDER" "$M10_DATA_ROOT" "$M10_OUTPUT_ROOT"
printf 'M10 Airflow env\n  AIRFLOW_HOME=%s\n  DAGS=%s\n  DATA=%s\n  OUTPUT=%s\n' \
  "$AIRFLOW_HOME" "$AIRFLOW__CORE__DAGS_FOLDER" "$M10_DATA_ROOT" "$M10_OUTPUT_ROOT"
