from __future__ import annotations
import csv, io, json, os, urllib.request
from decimal import Decimal
from pathlib import Path

url = os.environ.get("SOURCE_URL", "http://source:8000/orders.csv")
out = Path(os.environ.get("OUTPUT_PATH", "/output/report.json"))
with urllib.request.urlopen(url, timeout=10) as response:
    raw = response.read().decode("utf-8")
rows = list(csv.DictReader(io.StringIO(raw)))
total = sum((Decimal(r["amount"]) for r in rows), Decimal("0"))
report = {"source_url": url, "rows": len(rows), "amount_total": f"{total:.2f}"}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, sort_keys=True))
