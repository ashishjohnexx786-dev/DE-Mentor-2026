# M10 Docker lab

Learner-PC commands (Docker is not available in the artifact build environment):

```bash
cp .env.example .env
docker compose config
docker compose up --build
docker compose logs worker
docker compose down
```

Expected worker report: 4 rows and amount_total 500.00. `docker compose down` keeps the named volume; `docker compose down -v` deliberately deletes it.
