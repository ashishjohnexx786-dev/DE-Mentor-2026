from __future__ import annotations
import argparse, csv, json
from decimal import Decimal
from pathlib import Path

def process(day, input_dir, output_dir, fail_once_day=None, memory=None):
    memory = memory if memory is not None else {}
    attempts = memory.get(day, 0) + 1
    memory[day] = attempts
    if fail_once_day == day and attempts == 1:
        raise RuntimeError(f"simulated transient failure for {day}")
    src = input_dir / f"orders_{day}.csv"
    rows = list(csv.DictReader(src.open(encoding="utf-8")))
    ids = [r['order_id'] for r in rows]
    if len(ids) != len(set(ids)):
        raise ValueError(f"duplicate order_id in {day}")
    total = sum((Decimal(r['amount']) for r in rows), Decimal('0'))
    report = {"partition": day, "rows": len(rows), "amount_total": f"{total:.2f}", "attempt": attempts, "status": "SUCCESS"}
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / f"report_{day}.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input-dir', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--dates', nargs='+', required=True)
    p.add_argument('--fail-once')
    a=p.parse_args()
    memory={}; results=[]
    for day in a.dates:
        try:
            results.append(process(day,a.input_dir,a.output_dir,a.fail_once,memory))
        except RuntimeError as e:
            # bounded one retry for this controlled transient lab
            results.append(process(day,a.input_dir,a.output_dir,a.fail_once,memory))
    summary={"results":results,"partitions":len(results),"rows":sum(x['rows'] for x in results),"amount_total":f"{sum((Decimal(x['amount_total']) for x in results), Decimal('0')):.2f}"}
    (a.output_dir/'M10_SIMULATOR_RESULT.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,sort_keys=True))
if __name__=='__main__': main()
