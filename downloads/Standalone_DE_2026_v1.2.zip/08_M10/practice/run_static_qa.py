from pathlib import Path
import py_compile

ROOT = Path(__file__).resolve().parent
files = [
    ROOT/'docker/app/worker.py',
    ROOT/'airflow/dags/m10_daily_orders.py',
    ROOT/'airflow/dags/m10_wait_for_file.py',
    ROOT/'simulator/scripts/orchestration_simulator.py',
]
for p in files:
    py_compile.compile(str(p), doraise=True)
for date in ('2026-09-01','2026-09-02','2026-09-03'):
    p = ROOT/f'simulator/input/orders_{date}.csv'
    assert p.exists(), p
print(f'M10 static QA PASS: {len(files)} Python files compile; 3 historical fixtures present')
