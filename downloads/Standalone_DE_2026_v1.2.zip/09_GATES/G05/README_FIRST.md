# G05

Route: Gate A -> save genuine attempt -> Protected Review A only if needed -> close review -> Fresh Gate B -> save attempt -> Review B only after attempt.

No forced timer. G05 covers the M11-M14 SCALE stage: storage/file formats, Spark, Delta/lakehouse and Kafka/streaming.
