import csv
import json
from collections import defaultdict
from datetime import date
from decimal import Decimal
from pathlib import Path


def controls(source, variant):
    id_col, value_col = (
        ("meter_id", "liters") if variant == "A" else ("dispatch_id", "minutes")
    )
    seen, groups = set(), defaultdict(lambda: {"rows": 0, "total": Decimal(0)})
    with Path(source).open(newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        day = date.fromisoformat(row["event_date"]).isoformat()
        key = (row[id_col], day) if variant == "A" else row[id_col]
        value = Decimal(row[value_col])
        if not row[id_col] or key in seen or not value.is_finite() or value <= 0:
            raise ValueError(f"Invalid or duplicate source record: {row}")
        seen.add(key)
        groups[day]["rows"] += 1
        groups[day]["total"] += value
    total = sum((x["total"] for x in groups.values()), Decimal(0))
    return {
        "rows": len(rows),
        "total": str(total),
        "days": {
            day: {"rows": x["rows"], "total": str(x["total"])}
            for day, x in sorted(groups.items())
        },
    }
