BEGIN;
CREATE SCHEMA IF NOT EXISTS course;
DROP TABLE IF EXISTS course.g02b_items;
DROP TABLE IF EXISTS course.g02b_orders;
DROP TABLE IF EXISTS course.g02b_customers;

CREATE TABLE course.g02b_customers (
  customer_id text PRIMARY KEY,
  customer_name text NOT NULL,
  region text NOT NULL
);
CREATE TABLE course.g02b_orders (
  order_id text PRIMARY KEY,
  customer_id text NULL,
  ordered_on date NOT NULL,
  shipping_fee numeric(10,2) NOT NULL CHECK (shipping_fee >= 0),
  is_paid boolean NULL
);
CREATE TABLE course.g02b_items (
  order_id text NOT NULL,
  line_no integer NOT NULL,
  item text NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price numeric(10,2) NOT NULL CHECK (unit_price >= 0),
  PRIMARY KEY (order_id, line_no)
);

INSERT INTO course.g02b_customers VALUES
('R01','Asha','East'),('R02','Biren','West'),('R03','Chitra','North'),('R04','Dev','South');
INSERT INTO course.g02b_orders VALUES
('Q701','R01','2026-12-10',10.00,TRUE),
('Q702','R02','2026-12-10',10.00,FALSE),
('Q703','R01','2026-12-11',5.00,NULL),
('Q704','R03','2026-12-12',8.00,TRUE),
('Q705',NULL,'2026-12-12',0.00,FALSE);
INSERT INTO course.g02b_items VALUES
('Q701',1,'Cable',2,30.00),('Q701',2,'Adapter',1,40.00),
('Q702',1,'Notebook',3,20.00),('Q703',1,'Folder',1,50.00),
('Q704',1,'Marker',2,25.00),('Q704',2,'Pen',4,10.00);
COMMIT;

SELECT 'customers' AS source, COUNT(*) AS rows FROM course.g02b_customers
UNION ALL SELECT 'orders', COUNT(*) FROM course.g02b_orders
UNION ALL SELECT 'items', COUNT(*) FROM course.g02b_items
ORDER BY source;
