#!/usr/bin/env bash
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
input="${INPUT_FILE:?Set INPUT_FILE to the shipment CSV}"
outdir="${1:-output}"
[[ -f "$input" ]] || { echo "Missing input: $input" >&2; exit 2; }
"$here/.venv/bin/python" "$here/validate.py" "$input" "$outdir/report.json"
