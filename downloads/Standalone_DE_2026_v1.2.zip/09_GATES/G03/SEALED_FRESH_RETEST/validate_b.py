"""Worked G03 A/B reference. Open only after the matching attempt.

Source order is authoritative for duplicates: first ID reserves the key,
including an invalid first occurrence. A later occurrence is rejected.
This is a stated assessment policy, not a universal business deduplication rule.
"""

import argparse
import csv
import json
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path


def number(text, positive=False, integer=False):
    try:
        value = Decimal(text)
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("invalid_number") from None
    if not value.is_finite() or value < 0 or (positive and value == 0):
        raise ValueError("invalid_number")
    if integer and value != value.to_integral_value():
        raise ValueError("not_whole_cartons")
    return value


def validate(rows, variant="B"):
    key, area = ("shipment_id", "hub")
    allowed = {"Dispatched", "Delivered", "Held"}
    include = "Delivered"
    seen, accepted, rejected = set(), [], []
    totals, statuses = defaultdict(Decimal), Counter()
    for line, row in enumerate(rows, 2):
        identifier = (row.get(key) or "").strip()
        reason = None
        if not identifier:
            reason = "missing_id"
        elif identifier in seen:
            reason = "duplicate_id"
        else:
            seen.add(identifier)
        if reason is None and row.get("status") not in allowed:
            reason = "invalid_status"
        value = None
        if reason is None:
            try:
                value = number(
                    row["cartons"], positive=True, integer=True
                ) * number(row["unit_cost"])
            except (ValueError, KeyError) as exc:
                reason = str(exc)
        if reason:
            rejected.append({"source_line": line, "row": row, "reason": reason})
            continue
        accepted.append({**row, key: identifier, "validated_value": str(value)})
        statuses[row["status"]] += 1
        if row["status"] == include:
            totals[row[area]] += value
    assert len(rows) == len(accepted) + len(rejected)
    assert len({r[key] for r in accepted}) == len(accepted)
    return {
        "variant": variant,
        "raw_rows": len(rows),
        "accepted_rows": len(accepted),
        "rejected_rows": len(rejected),
        "accepted_status_counts": dict(sorted(statuses.items())),
        "totals": {k: format(v, ".2f") for k, v in sorted(totals.items())},
        "accepted": accepted,
        "rejected": rejected,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    with args.source.open(newline="", encoding="utf-8-sig") as f:
        result = validate(list(csv.DictReader(f)), "B")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # A disposable report can be replaced. The input file is only read.
    if args.output.resolve() == args.source.resolve():
        raise ValueError("output must not overwrite the source")
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
