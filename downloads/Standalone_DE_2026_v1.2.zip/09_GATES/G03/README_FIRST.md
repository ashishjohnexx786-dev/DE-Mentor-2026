# G03 protected gate family

G03 tests the integrated M04-M06 boundary: Python + Linux/WSL + Git/GitHub reasoning.

Study rule:
- open Gate A only after M04, M05 and M06 are complete;
- save the Gate A attempt before opening Review A;
- use Review A for diagnosis and targeted repair;
- open the sealed fresh Gate B only when a full reassessment is assigned;
- save Gate B before opening Review B.

Do not fabricate GitHub evidence. Offline/local bare-remote evidence is valid only when explicitly labeled OFFLINE as the gate brief requires.
