#!/usr/bin/env bash
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
input="${1:?Usage: bash run_a.sh INPUT_CSV [OUTPUT_JSON]}"
output="${2:-output/report.json}"
[[ -f "$input" ]] || { echo "Missing input: $input" >&2; exit 2; }
"$here/.venv/bin/python" "$here/validate.py" "$input" "$output"
