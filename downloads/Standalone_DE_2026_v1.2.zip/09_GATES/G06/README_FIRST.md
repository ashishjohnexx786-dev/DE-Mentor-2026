# G06 - Cloud + Production + Architecture

Use after M17. Gate A -> save attempt -> protected Review A -> targeted repair -> sealed different Gate B -> protected Review B. Untimed mastery first.
