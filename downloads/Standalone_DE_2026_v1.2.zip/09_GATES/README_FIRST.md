# Seven assessment boundaries

- G01 after M01: Data and Excel.
- G02 after M03: SQL.
- G03 after M06: Python, Linux and Git.
- G04 after M10: Pipeline engineering.
- G05 after M14: Storage and streaming.
- G06 after M17: Cloud, DataOps and architecture.
- G07 after M19: Portfolio and interviews.

For every gate: save Gate A, open Protected Review A, repair, attempt the different fresh Gate B, then open Review B. Read the gate’s own help and success rules. Protected and sealed are study instructions, not encryption.

G01 asks you to create a workbook from the table printed in its question. G02 uses ../01_M00_M03/labs/SQL/01_load_assessments.sql; its Gate B setup is in G02/SEALED_FRESH_RETEST. Other gate fixtures sit in their gate folders, or are named explicitly in the questions.
