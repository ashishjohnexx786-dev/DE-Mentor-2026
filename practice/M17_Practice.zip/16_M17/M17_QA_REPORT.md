# Edition 1.2 verification

This historical filename is retained for compatible folder references. Use ../00_START_HERE/VERIFICATION.md and ../99_ADMIN_AUDIT/REPAIR_LEDGER.md for the current checks, corrections and native-runtime limitations. Earlier PASS labels are superseded.
