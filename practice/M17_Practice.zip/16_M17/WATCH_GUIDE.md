# M17 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE17-01 — From requirements to architecture

- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost
- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 five categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## DE17-02 — Batch vs streaming decisions

- [Confluent Developer - Stream Processing | Apache Kafka 101 (2025 Edition)](https://www.youtube.com/watch?v=vF5y17Pypds) — 00:00-04:10 stream processing and batch/stream comparison
- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost

## DE17-03 — Warehouse vs lakehouse

- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost

## DE17-04 — Managed service vs build yourself

- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost
- [Microsoft Mechanics - Azure Well-Architected Framework](https://www.youtube.com/watch?v=xDhaHSK7mgM) — 00:34-01:57 five categories; 01:57-04:32 recommendations; 04:32-07:22 workload recommendations

## DE17-05 — Scaling and bottleneck reasoning

- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost

## DE17-06 — Reliability and failure domains

- [Microsoft Learn - Start improving the reliability of your Azure workloads](https://learn.microsoft.com/en-us/shows/azure-essentials-show/start-improving-the-reliability-of-your-azure-workloads--reliability-ep-1--well-architected-series) — 00:58-03:58 reliability/platform vs application; 03:58-09:27 building blocks; 11:08 architecture walkthrough
- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost

## DE17-07 — Cost-aware architecture

- [Microsoft Developer - Start optimizing your Azure costs](https://www.youtube.com/watch?v=5lELFRLGeQg) — 01:05-02:10 common cost issues; 02:10-04:00 design/provision/monitor/optimize; 04:00 onward monitoring/optimization
- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost

## DE17-08 — Security and governance by design

- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost
- [HashiCorp - Introduction to Vault](https://www.youtube.com/watch?v=eA_9WwYwXp0) — 01:04-05:41 Vault goal, discovery/import/centralized access; 11:06-15:46 architecture; 18:45-20:10 auditing/policy

## DE17-09 — Promotion foundations: CDC, Contracts, Vault, Mesh, Kubernetes

- [HashiCorp - Introduction to Vault](https://www.youtube.com/watch?v=eA_9WwYwXp0) — 01:04-05:41 Vault goal, discovery/import/centralized access; 11:06-15:46 architecture; 18:45-20:10 auditing/policy
- [Google Cloud Tech - Kubernetes architecture: Nodes and control plane](https://www.youtube.com/watch?v=VQUZF6k6g88) — 00:17-03:02 node/control-plane mental model and automation
- [Thoughtworks - Core principles of Data Mesh](https://www.thoughtworks.com/en-us/about-us/events/webinars/core-principles-of-data-mesh) — Optional visual - no verified bounded range; recordings cover domain ownership, data as product, self-service platform and federated governance

## DE17-10 — Architecture review and defense

- [Microsoft Learn - Apply Well-Architected Framework to your solution design](https://learn.microsoft.com/en-us/shows/learn-live/fasttrack-for-azure-season-2-ep07-apply-well-architected-framework-to-your-solution-design) — 02:35-07:53 requirements; 09:16-11:41 trade-offs; 11:41-33:10 reliability; 33:10-43:16 performance; 43:16-52:01 security; 57:40-1:02:44 cost
- [Microsoft Learn - Start improving the reliability of your Azure workloads](https://learn.microsoft.com/en-us/shows/azure-essentials-show/start-improving-the-reliability-of-your-azure-workloads--reliability-ep-1--well-architected-series) — 00:58-03:58 reliability/platform vs application; 03:58-09:27 building blocks; 11:08 architecture walkthrough
- [Microsoft Developer - Start optimizing your Azure costs](https://www.youtube.com/watch?v=5lELFRLGeQg) — 01:05-02:10 common cost issues; 02:10-04:00 design/provision/monitor/optimize; 04:00 onward monitoring/optimization