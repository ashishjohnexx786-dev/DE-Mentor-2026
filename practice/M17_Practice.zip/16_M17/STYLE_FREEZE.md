# M17 STYLE FREEZE
- Navy #173047 titles.
- Blue #2563EB normal section headings.
- Teal #087F8C structural accents only.
- No forced timer.
- Video-first retention policy active.
