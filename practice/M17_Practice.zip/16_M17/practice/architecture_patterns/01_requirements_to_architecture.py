scenario={"latency_min":60,"rpo_min":0,"rto_min":30,"pii":True,"team":2,"daily_gb":20}
responses={"batch_window":"15m/hourly","raw_immutable":True,"mask_before_bi":True,"managed_bias":True}
assert responses["raw_immutable"] and responses["mask_before_bi"]
print("PASS requirements->architecture",scenario,responses)
