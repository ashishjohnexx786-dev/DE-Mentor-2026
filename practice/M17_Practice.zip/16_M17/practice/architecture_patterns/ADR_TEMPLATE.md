# Architecture Decision Record

## Context
## Requirements / constraints
## Options considered
## Decision
## Consequences / trade-offs
## Failure and recovery impact
## Evidence to validate
## Revisit trigger
