workloads=[("payroll",43200,False),("fraud",10,True),("daily_revenue",3600,False)]
for name,lat,event_action in workloads:
    choice="stream" if lat<=30 and event_action else ("micro-batch" if lat<7200 else "batch")
    print(name,choice)
