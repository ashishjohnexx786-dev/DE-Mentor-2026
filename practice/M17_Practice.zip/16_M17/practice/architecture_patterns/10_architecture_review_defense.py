review={"requirements":True,"failure_replay":True,"security":True,"cost":True,"alternatives":True,"evidence":True}
missing=[k for k,v in review.items() if not v]
assert not missing
print("PASS architecture defense checklist")
