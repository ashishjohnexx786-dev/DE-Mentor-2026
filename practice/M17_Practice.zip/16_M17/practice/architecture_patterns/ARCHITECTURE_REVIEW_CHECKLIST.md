# Architecture Review Checklist
1. Requirements and unknowns
2. Data grain and flow
3. Batch/stream/storage choices
4. State, replay and idempotency
5. Scaling bottleneck
6. Failure domains/RTO/RPO
7. Security/governance
8. Cost model
9. Observability/runbook
10. Alternatives, rollout and evidence
