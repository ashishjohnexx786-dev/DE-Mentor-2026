risks=[{"failure":"worker","rto":10,"rpo":0},{"failure":"zone","rto":60,"rpo":0},{"failure":"catalog","rto":120,"rpo":0}]
requirements={"rto":120,"rpo":0}
assert all(r["rto"]<=requirements["rto"] and r["rpo"]<=requirements["rpo"] for r in risks)
print("PASS failure budget",risks)
