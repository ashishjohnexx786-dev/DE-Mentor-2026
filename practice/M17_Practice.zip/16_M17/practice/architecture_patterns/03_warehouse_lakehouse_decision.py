needs={"bi_concurrency":5,"semi_structured":5,"spark_ml":4,"open_engine":4,"simple_ops":2}
warehouse=needs["bi_concurrency"]+needs["simple_ops"]
lakehouse=needs["semi_structured"]+needs["spark_ml"]+needs["open_engine"]
print({"warehouse_score":warehouse,"lakehouse_score":lakehouse,"decision":"hybrid" if abs(lakehouse-warehouse)<8 else ("lakehouse" if lakehouse>warehouse else "warehouse")})
