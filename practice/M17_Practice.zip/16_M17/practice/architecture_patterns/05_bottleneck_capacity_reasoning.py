stages={"ingest":50000,"spark":30000,"sink":12000}; target=20000
bottleneck=min(stages,key=stages.get)
assert bottleneck=="sink" and stages[bottleneck]<target
print("bottleneck",bottleneck,"capacity",stages[bottleneck],"target",target)
