roles={"ingest":{"raw:write"},"transform":{"raw:read","curated:write"},"analyst":{"curated_masked:read"}}
assert "raw:read" not in roles["analyst"] and "owner" not in set().union(*roles.values())
print("PASS security matrix",roles)
