weights={"ops_burden":5,"custom_control":2,"time_to_value":4,"portability":2}
managed={"ops_burden":5,"custom_control":2,"time_to_value":5,"portability":3}
selfhost={"ops_burden":1,"custom_control":5,"time_to_value":2,"portability":4}
def score(x): return sum(weights[k]*x[k] for k in weights)
print("managed",score(managed),"selfhost",score(selfhost))
