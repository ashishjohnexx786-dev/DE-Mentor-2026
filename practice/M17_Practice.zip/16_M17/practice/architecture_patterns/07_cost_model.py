days=30
serverless_tb_day=8; serverless_per_tb=5; cluster_day=120
serverless=serverless_tb_day*serverless_per_tb*days
cluster=cluster_day*days
print({"serverless_month":serverless,"cluster_month":cluster,"serverless_2x_volume":serverless*2})
