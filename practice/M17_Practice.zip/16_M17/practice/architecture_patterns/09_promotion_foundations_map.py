map_={"CDC":"change propagation","contract":"interface promise","Vault":"secret lifecycle","mesh":"ownership/product model","Kubernetes":"container orchestration"}
assert len(set(map_.values()))==5
for k,v in map_.items(): print(k,"->",v)
