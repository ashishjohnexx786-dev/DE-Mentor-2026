# M18 STYLE FREEZE
- Navy #173047 project/phase identity.
- Blue #2563EB normal section headings.
- Teal #087F8C structural accents only.
- No forced timer.
- Video-first retention active; no tutorial-copy acceptance.
