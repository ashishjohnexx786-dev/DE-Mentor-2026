# ClickStream Scalable Lakehouse

A commerce site produces clickstream events with campaign/product reference data. Build a Spark/lakehouse design with explicit schemas, join controls, partition reasoning, Delta-style idempotency, medallion contracts and schema-evolution recovery.

Use the M18 Portfolio Build Manual phase-by-phase. Preserve raw data. Save evidence under `evidence/`. Do not open protected project reviews before saving a genuine attempt.
