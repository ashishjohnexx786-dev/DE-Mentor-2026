import json,pathlib
R=pathlib.Path(__file__).parents[1]
ctrl=json.load(open(R/'expected_controls.json'))
ev=[json.loads(x) for x in open(R/'data/raw/events.jsonl') if x.strip()]
assert len(ev)==ctrl['events'] and len({x['event_id'] for x in ev})==ctrl['unique_event_ids']
print('PASS P03 supplied-source controls',ctrl)
