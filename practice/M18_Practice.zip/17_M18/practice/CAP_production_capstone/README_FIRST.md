# OmniRetail Production Data Platform Capstone

Combine orders, payments, customer data and inventory changes into one production-grade design. Integrate ingestion, quality, dbt/warehouse serving, orchestration, scale-aware Spark/Delta choices, Fabric deployment planning, CI/CD, observability and incident recovery.

Use the M18 Portfolio Build Manual phase-by-phase. Preserve raw data. Save evidence under `evidence/`. Do not open protected project reviews before saving a genuine attempt.
