import csv,json,pathlib
R=pathlib.Path(__file__).parents[1]
ctrl=json.load(open(R/'expected_controls.json'))
orders=list(csv.DictReader(open(R/'data/raw/orders.csv')))
pays=[json.loads(x) for x in open(R/'data/raw/payments.jsonl') if x.strip()]
assert len(orders)==ctrl['orders'] and len(pays)==ctrl['payments']
assert round(sum(float(x['amount']) for x in pays if x['status']=='CAPTURED'),2)==ctrl['captured_payment_amount']
print('PASS CAP supplied-source controls',ctrl)
