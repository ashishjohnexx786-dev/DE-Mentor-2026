# Architecture Decision Record

## Context
## Requirements / constraints
## Options considered
## Decision
## Consequences / trade-offs
## Evidence / validation
## Revisit trigger
