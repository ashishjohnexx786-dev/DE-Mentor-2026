# Runbook

## Start state / prerequisites
## Normal run
## Validation / reconciliation
## Known failures
## Recovery
## Backfill / replay
## Ownership / escalation
