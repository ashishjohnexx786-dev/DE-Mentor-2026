# Evidence index

For each phase record: command/run, expected result, actual result, saved artifact, failure/recovery, changed retry, unresolved limitation.
