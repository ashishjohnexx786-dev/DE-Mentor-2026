import csv,json,pathlib
R=pathlib.Path(__file__).parents[1]
ctrl=json.load(open(R/'expected_controls.json'))
rows=list(csv.DictReader(open(R/'data/raw/orders_2026-09-01.csv')))
assert len(rows)==ctrl['day1_source_rows']
assert len({r['order_id'] for r in rows})==ctrl['day1_unique_order_ids']
print('PASS P01 supplied-source controls',ctrl)
