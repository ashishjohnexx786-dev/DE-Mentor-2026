# ParcelFlow Reliable Batch Pipeline

A regional parcel company receives daily order CSVs plus customer/product reference data. Build a replayable batch pipeline that preserves raw evidence, quarantines invalid rows, supports incremental reruns, produces trusted serving outputs and survives a deliberate failure.

Use the M18 Portfolio Build Manual phase-by-phase. Preserve raw data. Save evidence under `evidence/`. Do not open protected project reviews before saving a genuine attempt.
