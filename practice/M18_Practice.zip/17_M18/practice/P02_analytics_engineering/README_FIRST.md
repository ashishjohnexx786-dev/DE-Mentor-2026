# SaaS Billing Analytics Engineering

A subscription SaaS company needs governed billing marts. Build dbt-style sources/staging/dimensions/facts, tests, incremental logic, history and reproducible orchestration without fan-out or hidden grain changes.

Use the M18 Portfolio Build Manual phase-by-phase. Preserve raw data. Save evidence under `evidence/`. Do not open protected project reviews before saving a genuine attempt.
