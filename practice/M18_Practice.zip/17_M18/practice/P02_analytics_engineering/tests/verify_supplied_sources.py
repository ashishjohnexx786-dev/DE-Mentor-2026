import csv,json,pathlib
R=pathlib.Path(__file__).parents[1]
ctrl=json.load(open(R/'expected_controls.json'))
inv=list(csv.DictReader(open(R/'data/raw/invoices.csv')))
paid=sum(float(r['amount']) for r in inv if r['status']=='PAID')
assert len(inv)==ctrl['invoices'] and round(paid,2)==ctrl['paid_invoice_amount']
print('PASS P02 supplied-source controls',ctrl)
