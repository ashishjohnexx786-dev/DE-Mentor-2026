# M18 - Portfolio Projects + Production Capstone

Primary route: Portfolio Build Manual -> project practice/evidence -> Project Checkpoints -> Quick Revision -> closed-book Module Test -> protected Answers. Phase reviews are protected under `17_M18/PROTECTED_OPEN_AFTER_ATTEMPT/`. No formal Gate follows M18; G07 remains after M19.
