# M16 - DataOps, CI/CD, Security & Observability

Study order: Learner Book -> practice -> Cluster Checks -> Quick Revision -> closed-book Module Revision Test -> protected answers after saved attempt.

No formal Gate follows M16. G06 follows M17. 

Live cloud/GitHub/Terraform product execution is learner-PC evidence; local simulators teach the contracts without pretending to execute external systems.
