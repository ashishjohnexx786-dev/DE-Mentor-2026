graph={"orders_api":["raw_orders"],"raw_orders":["silver_orders"],"silver_orders":["gold_daily_sales"],"gold_daily_sales":["dashboard"]}
def downstream(node):
    seen=[]; stack=list(graph.get(node,[]))
    while stack:
        x=stack.pop(0)
        if x in seen: continue
        seen.append(x); stack+=graph.get(x,[])
    return seen
assert downstream("silver_orders")==["gold_daily_sales","dashboard"]
print(downstream("silver_orders"))
