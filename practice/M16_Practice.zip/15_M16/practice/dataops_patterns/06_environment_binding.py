bindings={"dev":"dev_storage","test":"test_storage","prod":"prod_storage"}
def safe(env,target): return target==bindings[env]
assert safe("test","test_storage")
assert not safe("test","prod_storage")
print("PASS environment binding")
