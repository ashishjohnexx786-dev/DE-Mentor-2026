import re
samples=["DB_USER=reader","AZURE_CLIENT_SECRET=super-secret-value","MODE=test"]
pattern=re.compile(r"(secret|token|password|api[_-]?key)\s*=",re.I)
flagged=[x for x in samples if pattern.search(x)]
print("flagged",flagged)
assert len(flagged)==1
