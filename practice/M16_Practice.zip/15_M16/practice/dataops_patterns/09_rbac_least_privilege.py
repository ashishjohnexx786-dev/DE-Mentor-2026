roles={"ingest":{"raw:write"},"transform":{"raw:read","curated:write"},"analyst":{"curated:read"}}
assert "subscription:owner" not in set().union(*roles.values())
assert "raw:read" not in roles["analyst"]
print("PASS least privilege",roles)
