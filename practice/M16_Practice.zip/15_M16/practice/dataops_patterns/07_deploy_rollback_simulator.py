state={"active_version":"v1","v2_rows":[101,102]}
state["active_version"]="v2"
reconcile_ok=False
if not reconcile_ok: state["active_version"]="v1"
assert state["active_version"]=="v1" and state["v2_rows"]==[101,102]
print("PASS code rollback preserved data-repair evidence",state)
