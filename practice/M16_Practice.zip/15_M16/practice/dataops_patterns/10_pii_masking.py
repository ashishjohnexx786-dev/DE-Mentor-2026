def mask_email(v):
    name,domain=v.split("@",1); return name[0]+"***@"+domain
assert mask_email("asha@example.com")=="a***@example.com"
print(mask_email("asha@example.com"))
