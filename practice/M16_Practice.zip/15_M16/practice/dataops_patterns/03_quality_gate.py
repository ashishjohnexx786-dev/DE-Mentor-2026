import json
rows=[{"id":1,"country":"IN"},{"id":2,"country":"IN"},{"id":2,"country":"IN"}]
rules={"nonempty":len(rows)>0,"unique_id":len({r["id"] for r in rows})==len(rows),"country":all(r["country"] in {"IN","US"} for r in rows)}
decision="PASS" if all(rules.values()) else "QUARANTINE"
print(json.dumps({"rules":rules,"decision":decision},indent=2))
assert decision=="QUARANTINE"
