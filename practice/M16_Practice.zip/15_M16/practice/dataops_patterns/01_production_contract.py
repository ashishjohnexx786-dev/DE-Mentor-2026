import json
contract={"correctness":"one accepted order per business key","freshness_minutes":360,"secret_in_logs":False,"rollback":"previous artifact + replayable raw"}
assert contract["secret_in_logs"] is False
print(json.dumps(contract,indent=2))
