from pathlib import Path
text=(Path(__file__).parent/"14_terraform"/"main.tf").read_text()
issues=[]
if 'required_version = ">= 1.16, < 1.17"' not in text: issues.append("version constraint missing")
if "*" in text and "actions" in text: issues.append("possible wildcard authority")
assert not issues, issues
print("PASS local Terraform teaching-policy check")
