incident={"facts":["raw complete","silver validation failed","gold publication held"],"hypotheses":["schema drift"],"containment":"hold publish","recovery":"repair schema contract + replay","prevention":"add contract test"}
assert "hold publish" in incident["containment"]
print(incident)
