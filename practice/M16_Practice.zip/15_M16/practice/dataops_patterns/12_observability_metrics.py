health={"runtime_s":120,"errors":0,"output_rows":2000,"expected_rows":10000,"freshness_min":15,"reconcile_delta":0}
health["volume_ratio"]=health["output_rows"]/health["expected_rows"]
health["status"]="ALERT" if health["volume_ratio"]<0.8 or health["freshness_min"]>60 or health["reconcile_delta"]!=0 else "OK"
assert health["status"]=="ALERT"
print(health)
