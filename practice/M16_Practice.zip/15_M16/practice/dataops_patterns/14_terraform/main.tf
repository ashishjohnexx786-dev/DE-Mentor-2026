terraform {
  required_version = ">= 1.16, < 1.17"
}

variable "environment" {
  type    = string
  default = "dev"
}

locals {
  labels = { environment = var.environment, course = "m16" }
}
