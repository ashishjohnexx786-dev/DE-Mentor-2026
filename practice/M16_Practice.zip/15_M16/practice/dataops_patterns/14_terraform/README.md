# M16 Terraform local reading exercise
Run fmt/validate/plan only after installing a current stable Terraform 1.16.x build. This sample intentionally creates no cloud resource.
