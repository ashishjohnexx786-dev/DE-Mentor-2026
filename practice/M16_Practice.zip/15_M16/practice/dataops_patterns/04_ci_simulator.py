stages=[("compile",True),("unit_tests",False),("quality_fixture",True),("deploy",True)]
executed=[]
for name,ok in stages:
    if executed and executed[-1][1] is False: break
    executed.append((name,ok))
print(executed)
assert executed[-1][0]=="unit_tests" and executed[-1][1] is False
