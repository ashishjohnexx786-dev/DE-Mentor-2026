tests=[("unit","transform_order"),("contract","required_columns"),("quality","unique_order_id"),("integration","sqlite_write"),("reconcile","revenue_sum")]
assert len({x[0] for x in tests})>=4
print("PASS layered tests",tests)
