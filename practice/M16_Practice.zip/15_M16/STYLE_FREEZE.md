# M16 STYLE FREEZE
- Navy #173047: titles/module identity.
- Blue #2563EB: all ordinary lesson-section headings.
- Teal #087F8C: structural rules/callout borders/table accents only.
- No forced timer.
- Video-first retention policy remains active.
