# G07 Final Job-Ready Simulation
1. Take Gate A cold and save evidence.
2. Open Protected Review A only after the attempt.
3. Repair weak domains and close the review.
4. Take SEALED_FRESH_RETEST/G07_GATE_B.pdf — different fixture and prompts.
5. Open Review B only after that attempt.
No forced timer. Optional interview timing may be added after correct untimed mastery.
