House family: DejaVu Sans | ink #173047 | teal #087F8C | blue #2563EB | pale #EDF7FA | A4 | teal header rule | teal+blue footer bars.

- Normal lesson-section headings: blue #2563EB.
- Teal #087F8C is structural only: rules, borders, callout accents, header/footer bars and cover kickers.
