# M12 - Distributed Processing with Spark / PySpark

Study in canonical order DE12-01 -> DE12-18. M12 teaches Spark 4.2.0 structured processing from the driver/executor/partition model through plans, shuffle, joins, skew/AQE, caching, Parquet, testing and an integrated checkpoint.

Laptop-safe learning profile: `local[2]`, 1g driver memory, four shuffle partitions, AQE enabled. These are teaching values, not universal production tuning values. Use one heavy local stack at a time.

Runtime honesty: all Spark scripts compile and static/reference controls pass, but live Spark runtime evidence is separate. Run the SparkSession, UI, physical plans, shuffle/broadcast behavior, Parquet writes and cache checks on the learner PC and save the observed evidence.

After M12, continue to M13 Delta Lake + Lakehouse. There is no formal Gate after M12.
