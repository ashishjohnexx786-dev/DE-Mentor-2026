from pathlib import Path
import argparse,csv,json
ROOT=Path(__file__).resolve().parents[1]
def orders(): return list(csv.DictReader(open(ROOT/'data/orders.csv',encoding='utf-8')))
def main(sec):
    rs=orders(); comp=[r for r in rs if r['status']=='Completed']
    if sec=='architecture':
        print(json.dumps({'driver':'plans/co-ordinates application','executors':'execute tasks on partitions','local_2':'two local task threads, not two production executors','source_rows':len(rs)},indent=2))
    elif sec=='partitions':
        print(json.dumps({'input_partitions':4,'repartition_to':2,'coalesce_to':2,'warning':'same number does not mean same dependency/shuffle behavior'},indent=2))
    elif sec=='shuffle':
        by={}
        for r in comp: by[r['region']]=by.get(r['region'],0)+int(r['qty'])*float(r['unit_price'])
        print(json.dumps({'groupBy_region_requires_key_redistribution':True,'region_totals':by,'reconciles':sum(by.values())==25230},indent=2))
    elif sec=='join':
        contacts=list(csv.DictReader(open(ROOT/'data/customer_contacts_bad.csv',encoding='utf-8')))
        mult={k:v for k,v in __import__('collections').Counter(r['customer_id'] for r in contacts).items() if v>1}
        bad=sum(mult.get(r['customer_id'],1) for r in comp)
        print(json.dumps({'left_rows':len(comp),'bad_join_rows':bad,'duplicate_dimension_keys':mult,'fanout':bad>len(comp)},indent=2))
    elif sec=='skew':
        sk=list(csv.DictReader(open(ROOT/'data/skew_keys.csv',encoding='utf-8'))); c=__import__('collections').Counter(r['key'] for r in sk)
        print(json.dumps({'rows':len(sk),'hot_key_rows':c['HOT'],'hot_share':c['HOT']/len(sk),'largest_key':'HOT'},indent=2))
    elif sec=='aqe':
        print(json.dumps({'aqe_enabled_in_course_profile':True,'can_use_runtime_statistics':True,'does_not_guarantee_every_skew_problem_disappears':True},indent=2))
    elif sec=='cache':
        print(json.dumps({'reuse_same_expensive_dataframe_many_actions':'candidate','single_use_dataframe':'usually_not_candidate','must_unpersist_when_done':True},indent=2))
    elif sec=='driver':
        print(json.dumps({'safe':'limit/show, aggregates, distributed writes','risky':'unbounded collect/toPandas on unknown-large data','principle':'bound before materializing on driver'},indent=2))
    elif sec=='integrated':
        gross=sum(int(r['qty'])*float(r['unit_price']) for r in comp)
        print(json.dumps({'source':len(rs),'completed':len(comp),'gross':gross,'valid':gross==25230 and len(comp)==16},indent=2))
    else: raise SystemExit('unknown section')
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--section',required=True); a=p.parse_args(); main(a.section)
