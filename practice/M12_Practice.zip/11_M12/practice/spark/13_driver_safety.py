from common import spark_session,read_orders
from pyspark.sql import functions as F
spark=spark_session('m12-driver-safety'); df=read_orders(spark).withColumn('gross_sales',F.col('qty')*F.col('unit_price'))
# Safe: distributed aggregate, then one tiny result row on driver.
total=df.filter(F.col('status')=='Completed').agg(F.sum('gross_sales').alias('gross_sales')).first()['gross_sales']; print(total)
# Bounded inspection only. Never use df.collect() or df.toPandas() on unknown-large input.
small=df.orderBy('order_id').limit(5).collect(); print(small)
spark.stop()
