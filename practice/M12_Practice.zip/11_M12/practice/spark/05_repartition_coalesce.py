from common import spark_session,read_orders
spark=spark_session('m12-partitions'); df=read_orders(spark)
print('start',df.rdd.getNumPartitions()); a=df.repartition(4,'region'); print('repartition',a.rdd.getNumPartitions()); b=a.coalesce(2); print('coalesce',b.rdd.getNumPartitions())
a.explain('formatted'); b.explain('formatted'); spark.stop()
