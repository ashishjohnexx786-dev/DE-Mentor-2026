from common import spark_session,read_orders,ROOT
from pyspark.sql import functions as F
spark=spark_session('m12-parquet'); out=ROOT/'output_parquet'; df=read_orders(spark).withColumn('gross_sales',F.col('qty')*F.col('unit_price'))
df.write.mode('overwrite').partitionBy('order_date').parquet(str(out)); q=spark.read.parquet(str(out)).select('order_id','order_date','region','gross_sales').filter(F.col('order_date')==F.lit('2026-09-03'))
q.explain('formatted'); q.show(); spark.stop()
