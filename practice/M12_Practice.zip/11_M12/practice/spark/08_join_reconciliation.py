from common import spark_session,read_orders,ROOT
from pyspark.sql import functions as F,types as T
spark=spark_session('m12-join-reconcile'); fact=read_orders(spark).filter(F.col('status')=='Completed').withColumn('gross_sales',F.col('qty')*F.col('unit_price'))
schema=T.StructType([T.StructField('customer_id',T.StringType(),False),T.StructField('contact_type',T.StringType(),False)])
contacts=spark.read.option('header',True).schema(schema).csv(str(ROOT/'data/customer_contacts_bad.csv'))
bad=fact.join(contacts,'customer_id','left'); print('fact rows',fact.count(),'joined rows',bad.count()); print('fact gross',fact.agg(F.sum('gross_sales')).first()[0],'joined gross',bad.agg(F.sum('gross_sales')).first()[0]); bad.groupBy('customer_id').count().orderBy(F.desc('count')).show(); spark.stop()
