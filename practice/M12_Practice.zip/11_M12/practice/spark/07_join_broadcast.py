from common import spark_session,read_orders,ROOT
from pyspark.sql import functions as F, types as T
spark=spark_session('m12-broadcast'); fact=read_orders(spark).filter(F.col('status')=='Completed')
schema=T.StructType([T.StructField('customer_id',T.StringType(),False),T.StructField('customer_name',T.StringType(),False),T.StructField('home_region',T.StringType(),False)])
dim=spark.read.option('header',True).schema(schema).csv(str(ROOT/'data/customers.csv'))
joined=fact.join(F.broadcast(dim),'customer_id','left'); joined.explain('formatted'); print('rows',joined.count()); spark.stop()
