from common import spark_session,ROOT
from pyspark.sql import functions as F,types as T
spark=spark_session('m12-skew-aqe'); schema=T.StructType([T.StructField('event_id',T.StringType(),False),T.StructField('key',T.StringType(),False),T.StructField('value',T.IntegerType(),False)])
df=spark.read.option('header',True).schema(schema).csv(str(ROOT/'data/skew_keys.csv'))
print('AQE',spark.conf.get('spark.sql.adaptive.enabled')); out=df.groupBy('key').agg(F.sum('value').alias('value')); out.explain('formatted'); out.orderBy(F.desc('value')).show(12); spark.stop()
