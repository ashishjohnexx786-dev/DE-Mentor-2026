from common import spark_session,read_orders
from pyspark.sql import functions as F
spark=spark_session('m12-dataframe'); df=read_orders(spark)
df.printSchema(); out=df.withColumn('gross_sales',F.col('qty')*F.col('unit_price')).select('order_id','region','status','gross_sales')
out.orderBy('order_id').show(20,truncate=False); spark.stop()
