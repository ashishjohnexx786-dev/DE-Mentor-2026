from common import spark_session,read_orders
from pyspark.sql import functions as F, types as T
spark=spark_session('m12-builtins'); df=read_orders(spark)
builtin=df.withColumn('region_upper',F.upper('region'))
@F.udf(returnType=T.StringType())
def upper_python(x): return None if x is None else x.upper()
udf_df=df.withColumn('region_upper',upper_python('region'))
print('BUILT-IN PLAN'); builtin.explain('formatted'); print('PYTHON UDF PLAN'); udf_df.explain('formatted'); spark.stop()
