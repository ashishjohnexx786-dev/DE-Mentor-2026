# M12 Spark runtime lane

Recommended learner profile for this course lab: PySpark 4.2.0, Python 3.10+, Java 17+, `local[2]`, 1g driver memory, four shuffle partitions, AQE enabled. These are laptop-safe teaching settings, not production tuning rules.

Run `python 00_env_probe.py` first from this folder. Then run numbered labs. Keep only one heavy local stack active at a time. Live Spark execution is not claimed by this package, so learner-PC runtime evidence remains required.
