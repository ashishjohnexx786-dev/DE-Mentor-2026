from pathlib import Path
from pyspark.sql import SparkSession, functions as F, types as T
ROOT=Path(__file__).resolve().parents[1]
def spark_session(app):
    return (SparkSession.builder.appName(app).master("local[2]")
            .config("spark.driver.memory","1g")
            .config("spark.sql.shuffle.partitions","4")
            .config("spark.sql.adaptive.enabled","true").getOrCreate())
ORDER_SCHEMA=T.StructType([
    T.StructField("order_id",T.StringType(),False),T.StructField("order_date",T.DateType(),False),
    T.StructField("customer_id",T.StringType(),False),T.StructField("product_id",T.StringType(),False),
    T.StructField("region",T.StringType(),False),T.StructField("category",T.StringType(),False),
    T.StructField("status",T.StringType(),False),T.StructField("qty",T.IntegerType(),False),
    T.StructField("unit_price",T.DoubleType(),False)])
def read_orders(spark):
    return spark.read.option("header",True).schema(ORDER_SCHEMA).csv(str(ROOT/'data/orders.csv'))
