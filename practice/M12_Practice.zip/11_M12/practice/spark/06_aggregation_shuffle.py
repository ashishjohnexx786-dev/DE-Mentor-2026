from common import spark_session,read_orders
from pyspark.sql import functions as F
spark=spark_session('m12-shuffle'); df=read_orders(spark).filter(F.col('status')=='Completed').withColumn('gross_sales',F.col('qty')*F.col('unit_price'))
out=df.groupBy('region').agg(F.sum('gross_sales').alias('gross_sales')); out.explain('formatted'); out.orderBy('region').show(); spark.stop()
