import sys
try:
    import pyspark
    print('python',sys.version.split()[0]); print('pyspark',pyspark.__version__)
except Exception as e:
    print('PySpark unavailable:',repr(e)); raise
