from common import spark_session,read_orders,ROOT
from pyspark.sql import functions as F,types as T
from pyspark.testing.utils import assertDataFrameEqual
spark=spark_session('m12-integrated'); raw=read_orders(spark)
clean=(raw.filter(F.col('status')=='Completed').withColumn('gross_sales',F.col('qty')*F.col('unit_price')))
region=clean.groupBy('region').agg(F.sum('gross_sales').alias('gross_sales')).orderBy('region')
category=clean.groupBy('category').agg(F.sum('gross_sales').alias('gross_sales')).orderBy('category')
print('SOURCE',raw.count(),'COMPLETED',clean.count(),'GROSS',clean.agg(F.sum('gross_sales')).first()[0])
region.explain('formatted'); region.show(); category.show()
expected=spark.createDataFrame([('East',5950.0),('North',6380.0),('South',6000.0),('West',6900.0)],['region','gross_sales']).orderBy('region')
assertDataFrameEqual(region,expected,checkRowOrder=True)
# Persist reusable clean data only if more than one downstream action justifies it.
clean.cache(); clean.count(); clean.groupBy('category').count().show(); clean.unpersist()
# Bounded inspection, never unbounded collect/toPandas.
print(clean.select('order_id','gross_sales').orderBy('order_id').limit(5).collect())
clean.write.mode('overwrite').partitionBy('order_date').parquet(str(ROOT/'output_integrated/completed_orders'))
spark.stop()
