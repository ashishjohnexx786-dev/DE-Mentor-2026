from common import spark_session,read_orders
from pyspark.sql import functions as F
from pyspark.testing.utils import assertDataFrameEqual, assertSchemaEqual
spark=spark_session('m12-tests'); df=read_orders(spark)
actual=(df.filter(F.col('status')=='Completed').withColumn('gross_sales',F.col('qty')*F.col('unit_price')).groupBy('region').agg(F.sum('gross_sales').alias('gross_sales')).orderBy('region'))
expected=spark.createDataFrame([('East',5950.0),('North',6380.0),('South',6000.0),('West',6900.0)],['region','gross_sales']).orderBy('region')
assertSchemaEqual(actual.schema,expected.schema); assertDataFrameEqual(actual,expected,checkRowOrder=True); print('PASS'); spark.stop()
