from common import spark_session,read_orders
from pyspark.sql import functions as F
spark=spark_session('m12-sql'); df=read_orders(spark).withColumn('gross_sales',F.col('qty')*F.col('unit_price'))
df.createOrReplaceTempView('orders')
a=(df.filter(F.col('status')=='Completed').groupBy('region').agg(F.sum('gross_sales').alias('gross_sales')).orderBy('region'))
b=spark.sql("SELECT region, SUM(gross_sales) gross_sales FROM orders WHERE status='Completed' GROUP BY region ORDER BY region")
a.show(); b.show(); spark.stop()
