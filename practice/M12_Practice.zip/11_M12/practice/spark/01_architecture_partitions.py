from common import spark_session,read_orders
spark=spark_session('m12-architecture'); df=read_orders(spark)
print('defaultParallelism',spark.sparkContext.defaultParallelism); print('input partitions',df.rdd.getNumPartitions())
print('rows',df.count()); spark.stop()
