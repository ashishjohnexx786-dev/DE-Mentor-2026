from common import spark_session,read_orders
from pyspark.sql import functions as F
spark=spark_session('m12-lazy-plan'); df=read_orders(spark)
planned=df.filter(F.col('status')=='Completed').withColumn('gross_sales',F.col('qty')*F.col('unit_price')).groupBy('region').agg(F.sum('gross_sales').alias('gross_sales'))
print('No action has been called yet. Inspect the plan first:'); planned.explain('formatted')
print('Action result:'); planned.orderBy('region').show(); spark.stop()
