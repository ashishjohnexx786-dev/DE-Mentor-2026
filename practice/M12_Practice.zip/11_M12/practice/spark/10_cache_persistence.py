from common import spark_session,read_orders
from pyspark.sql import functions as F
spark=spark_session('m12-cache'); base=read_orders(spark).filter(F.col('status')=='Completed').withColumn('gross_sales',F.col('qty')*F.col('unit_price'))
base.cache(); print('materialize',base.count()); base.groupBy('region').agg(F.sum('gross_sales')).show(); base.groupBy('category').agg(F.sum('gross_sales')).show(); base.unpersist(); spark.stop()
