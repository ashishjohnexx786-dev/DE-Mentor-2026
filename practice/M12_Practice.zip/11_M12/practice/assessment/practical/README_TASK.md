# M12 Module Practical - ParcelSpark
Build a small Spark job over `parcel_orders.csv`. Filter Completed, summarize gross_sales by region, use an explicit schema, explain the grouped plan, use bounded inspection, and prove Completed rows=7 and gross=6000. Save actual plan/runtime evidence.
