# M12 Fresh Retest - ClinicSpark
Fresh domain. Build from blank file over `clinic_jobs.csv`. Filter Completed, summarize by ward, prove Completed rows=6 and amount=3500. Use an explicit schema, one explain output, one safe partition decision, and no unbounded driver collection.
