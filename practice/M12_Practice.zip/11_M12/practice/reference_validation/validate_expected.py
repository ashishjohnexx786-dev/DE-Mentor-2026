from pathlib import Path
import csv, json
ROOT=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader(open(ROOT/'data/orders.csv',encoding='utf-8')))
completed=[r for r in rows if r['status']=='Completed']
def amount(r): return int(r['qty'])*float(r['unit_price'])
region={}
category={}
for r in completed:
    region[r['region']]=region.get(r['region'],0)+amount(r)
    category[r['category']]=category.get(r['category'],0)+amount(r)
out={
 'source_rows':len(rows),'completed_rows':len(completed),'gross_sales':sum(map(amount,completed)),
 'region':region,'category':category,'unique_completed_order_ids':len({r['order_id'] for r in completed})
}
expected={'source_rows':18,'completed_rows':16,'gross_sales':25230.0,
          'region':{'East':5950.0,'North':6380.0,'South':6000.0,'West':6900.0},
          'category':{'Accessories':16830.0,'Office':8400.0},'unique_completed_order_ids':16}
assert out==expected,(out,expected)
print(json.dumps(out,indent=2,sort_keys=True))
