# M12 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE12-01 — Why Spark exists: driver, executors, partitions and tasks

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Driver, executors, partitions, distributed work mental model

## DE12-02 — PySpark setup, SparkSession and laptop-safe local mode

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Local PySpark setup and first SparkSession context

## DE12-03 — DataFrames and explicit schemas

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — DataFrame reading and schema-oriented workflow

## DE12-04 — Spark SQL and expression equivalence

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — DataFrame/Spark SQL transformation examples

## DE12-05 — Lazy transformations and actions

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Transformation chain and action context

## DE12-06 — Jobs, stages, tasks and physical plans

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Execution-plan and distributed-stage context

## DE12-07 — repartition vs coalesce

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Partition-count changes in practical Spark work

## DE12-08 — Aggregations and shuffle cost

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — groupBy/shuffle context

## DE12-09 — Joins and broadcast strategy

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Join strategy context

## DE12-10 — Join correctness, fan-out and reconciliation

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Join mechanics; book adds grain/fan-out reconciliation

## DE12-11 — Data skew

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Uneven partitions and skew context

## DE12-12 — Adaptive Query Execution (AQE)

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Adaptive execution context

## DE12-13 — Caching and persistence

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Repeated-action/caching context

## DE12-14 — Parquet I/O and partition pruning

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Parquet read/write and partitioned data context

## DE12-15 — Built-in functions vs Python UDFs

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Built-in expression style and transformation examples

## DE12-16 — Driver safety: collect, toPandas and bounded inspection

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Driver vs distributed work context

## DE12-17 — Testing and debugging Spark transformations

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=ti3aC1m3rE8) — Transformation refresher; testing task remains independent

## DE12-18 — Integrated PySpark pipeline and distributed-processing checkpoint

- [Optional visual: DataTalksClub - Apache Spark / PySpark (no verified bounded range)](https://www.youtube.com/watch?v=r_Sf6fCB40c) — Review the flow, then close video and build independently