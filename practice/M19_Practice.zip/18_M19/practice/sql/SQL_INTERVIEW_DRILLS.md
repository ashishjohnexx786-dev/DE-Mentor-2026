# SQL interview drills — save first attempt
1. Paid revenue by region; include only regions with paid orders.
2. Customers with no PAID order.
3. Latest PAID order per customer. For tied updated_at, surface or deterministically resolve the tie and state your rule.
4. Running paid revenue by updated_at.
5. Top customer by paid revenue; state tie policy.
6. Prove a join does not fan out: return one row per customer with paid order count and paid amount.
For every task: state output grain, expected row count or aggregate control, and one wrong-query failure mode.
