# Professional profile claims
## Headline
Draft:
Evidence-backed keywords:
Words removed because they overclaim:

## About
1. Current direction
2. Evidence/projects
3. Engineering principles you can demonstrate
4. Target role

## Skills
For each skill, link one project/lab where you used it.
