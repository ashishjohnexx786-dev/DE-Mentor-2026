# Combined SQL + Python simulation
1. Load orders.csv into SQLite (you may use Python sqlite3 import).
2. SQL: one row per customer with paid_orders, paid_amount and latest_paid_at. Reconcile total paid amount = 500.00.
3. Export result to customer_paid.csv.
4. Python: add `risk_flag=HIGH_VALUE` when paid_amount >= 250 else NORMAL. Preserve row count and total paid amount.
5. Add changed retry: a new paid order tied at an existing max timestamp. State a deterministic tie policy if selecting latest order ID.
6. Save first attempt before opening protected solution.
