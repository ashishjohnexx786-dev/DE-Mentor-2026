# Project walkthrough
## 90-second version
Business need:
One source row/event represents:
Architecture in one sentence:
Hardest decision + alternative:
Failure/recovery proof:
Validation/reconciliation proof:
Limitation / next step:

## 5-minute deep version
Sources/grain/keys:
State/checkpoint boundary:
Transforms/storage/orchestration:
Quality and observability:
Security/cost:
Changed-input retry:
My personal contribution:
