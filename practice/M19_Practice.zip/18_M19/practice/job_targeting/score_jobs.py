import csv,pathlib,re
p=pathlib.Path(__file__).with_name('sample_job_descriptions.csv')
for r in csv.DictReader(open(p,encoding='utf-8')):
    hard=bool(re.search(r'mandatory|campus batch only',r['degree_rule'],re.I)) and not re.search(r'equivalent',r['degree_rule'],re.I)
    print(r['job_id'],r['role'],'SKIP_HARD_GATE' if hard else 'REVIEW/APPLY', '| rule:',r['degree_rule'])
