import python_interview_drills as m
assert m.first_duplicate(['A','B','A','C'])=='A'
assert m.first_duplicate([]) is None
assert m.counts_by_status([{'status':'PAID'},{'status':'PAID'},{'status':'OPEN'}])=={'PAID':2,'OPEN':1}
assert m.first_non_repeating('swiss')=='w'
assert m.reconcile_ids({'A','B'},{'B','C'})=={'missing':{'A'},'unexpected':{'C'}}
rows=[{'id':'A','version':1,'value':10},{'id':'A','version':2,'value':12},{'id':'B','version':1,'value':5}]
out=m.dedupe_keep_latest(rows); assert out['A']['value']==12 and out['B']['value']==5
try:
 m.dedupe_keep_latest([{'id':'A','version':2,'value':10},{'id':'A','version':2,'value':11}]); raise AssertionError('conflict not raised')
except ValueError: pass
print('PASS Python interview drills')
