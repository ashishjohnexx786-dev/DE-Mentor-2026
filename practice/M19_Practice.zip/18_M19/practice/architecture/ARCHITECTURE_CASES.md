# Junior DE architecture cases
## Case A — Orders analytics
1.2M orders/day; dashboards can be 15 minutes late; source DB plus partner API; late updates up to 3 days; 2-year history; cost matters. Design ingestion, raw, processing, serving, state, data quality, backfill and monitoring.
## Case B — Product events
25k events/sec peak; product team needs <60-second metrics; event schema changes monthly; duplicates possible; PII must not enter general analytics. Design flow, partition/key strategy, schemas, quarantine, checkpoint/replay, serving and governance.

Score yourself 0-2 each: requirements, grain, scale, flow, state/replay, quality/reconciliation, failure/recovery, security/governance, cost, trade-offs.
