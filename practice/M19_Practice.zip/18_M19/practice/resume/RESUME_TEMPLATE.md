# NAME
Target: Entry-Level / Junior Data Engineering
City | phone/email | GitHub | professional profile

## Technical evidence
Python | SQL | PostgreSQL | Airflow | Spark | Delta/Lakehouse | Kafka | Fabric/Azure (only keep what you can defend)

## Selected projects
### Project name — repository link
- Problem + action + correctness/reliability evidence.
- Failure/recovery or validation evidence.

## Education
Exact earned degree, institution, year.

## Additional
Only truthful certifications/skills/languages.
