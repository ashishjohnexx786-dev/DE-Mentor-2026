from pathlib import Path
import re,sys
p=Path(sys.argv[1] if len(sys.argv)>1 else 'RESUME_DRAFT.md')
text=p.read_text(encoding='utf-8') if p.exists() else ''
risky=[r'\bexpert\b',r'\bsenior\b',r'\benterprise[- ]scale\b',r'\bproduction experience\b',r'\b\d+\+? years?\b']
for pat in risky:
    for m in re.finditer(pat,text,re.I): print('REVIEW CLAIM:',m.group(0))
print('Linter is only a reminder; truth must be checked against your evidence matrix.')
