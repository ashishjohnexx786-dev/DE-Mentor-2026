import csv,pathlib,collections
p=pathlib.Path(__file__).with_name('APPLICATION_TRACKER.csv')
rows=list(csv.DictReader(open(p,encoding='utf-8'))); c=collections.Counter(r['stage'] for r in rows)
print('applications/tracked',len(rows)); print('stages',dict(c))
active=[r for r in rows if r['stage'] not in {'SKIPPED'}]
print('hard-gate-pass active',len(active))
print('REPAIR RULE: low screens -> targeting/resume/profile; screens but low technical -> SQL/Python/project defense; technical but low final -> architecture/behavioral/communication evidence.')
