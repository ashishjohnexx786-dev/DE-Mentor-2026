import coding_drills as m
assert m.first_duplicate([1,2,3,2])==2
assert m.first_non_repeating('aabbcddee')=='c'
assert m.two_sum([2,7,11,15],9)==(0,1)
assert m.group_by_customer([('C2','O1'),('C1','O2'),('C2','O3')])=={'C2':['O1','O3'],'C1':['O2']}
assert m.top_k_statuses(['PAID','OPEN','PAID','FAIL','OPEN','PAID'],2)==[('PAID',3),('OPEN',2)]
assert m.reconcile_ids(['A','B'],['B','C'])==({'A'},{'C'})
print('PASS coding drills')
