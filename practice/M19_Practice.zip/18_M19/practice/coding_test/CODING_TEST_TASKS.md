# Coding test — master untimed first
1. First duplicate in arrival order.
2. First non-repeating character.
3. Two-sum: return indices or None.
4. Group order IDs by customer preserving first-seen customer order.
5. Top-k statuses by frequency with deterministic tie rule.
6. Reconcile two ID lists: missing and unexpected.
For every task: tiny example, complexity, edge cases, code, tests. Optional timing only after an untimed correct attempt.
