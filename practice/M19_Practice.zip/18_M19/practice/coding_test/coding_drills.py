def first_duplicate(xs): raise NotImplementedError
def first_non_repeating(s): raise NotImplementedError
def two_sum(nums,target): raise NotImplementedError
def group_by_customer(rows): raise NotImplementedError
def top_k_statuses(statuses,k): raise NotImplementedError
def reconcile_ids(a,b): raise NotImplementedError
