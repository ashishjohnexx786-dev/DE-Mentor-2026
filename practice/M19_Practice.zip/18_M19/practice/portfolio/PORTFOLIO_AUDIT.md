# Portfolio audit
For each candidate pinned repo:
- Problem understandable in 30 seconds?
- Architecture/data flow visible?
- Grain/keys/state boundary documented?
- Setup + run commands tested from clean clone?
- Expected controls and tests present?
- Failure/recovery evidence present?
- Changed-input retry present?
- Secrets/generated junk absent?
- Limitations honest?
- Can I defend every named technology?
