# Hi — I build data-engineering projects
## What I can show
- Reliable batch pipeline: problem | architecture | proof | limitation
- Analytics engineering: problem | grain | tests | proof | limitation
- Lakehouse: scale decision | replay/merge | proof | limitation
## Skills I can defend
## How to run my projects
## Current target
