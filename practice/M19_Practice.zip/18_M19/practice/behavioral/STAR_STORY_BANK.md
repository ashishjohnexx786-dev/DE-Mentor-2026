# Truthful STAR story bank
For each story: Situation (2 sentences max) | Task (your responsibility) | Action (specific steps) | Result (facts/evidence) | Reflection.
1. A failure you found and repaired.
2. Ambiguous requirements you clarified.
3. Fast learning of a new tool/concept.
4. Feedback/disagreement you handled constructively.
5. Ownership when nobody gave step-by-step instructions.
6. Prioritization under limited time/resources.

# 60-second transition story
Past foundation -> deliberate technical training -> strongest project evidence -> target role. No apology, no invented employment.
