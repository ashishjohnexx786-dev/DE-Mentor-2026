# Protected combined simulation reference
Expected base controls: paid orders=4; total paid amount=500.00; customers with paid orders=2. Customer C1=200.00, C2=300.00. Both customer rows survive Python; C2 HIGH_VALUE, C1 NORMAL. A timestamp tie must not change aggregate totals; if latest order identity is required, add a deterministic secondary key or surface ambiguity.
