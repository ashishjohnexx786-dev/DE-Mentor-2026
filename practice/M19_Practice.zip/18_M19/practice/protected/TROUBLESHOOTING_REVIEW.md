# Protected troubleshooting review
1. Freeze checkpoint; diff source/sink IDs; inspect rejects and write/commit ordering. Recover only missing unsafe range; reconcile 5,000 = accepted + quarantined.
2. Check AIRFLOW_HOME/fixture path, logical date vs filename, FileSensor/provider, then run a supplied historical partition.
3. Inspect lag per partition/key distribution, processing time, downstream sink; address hot-key partition strategy before adding random consumers.
4. Re-state grain and uniqueness of dimension key; prove join cardinality; deduplicate/surface ambiguous dimension versions rather than DISTINCT-ing the symptom.
5. Inspect partition sizes/shuffle plan; isolate hot key and use justified skew handling while proving results unchanged.
6. Compare source identity/version rules and merge predicate; verify equal-version conflicts/idempotency and state advancement after durable validation.
