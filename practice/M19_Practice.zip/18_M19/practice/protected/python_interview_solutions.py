from collections import Counter


def first_duplicate(ids):
    s = set()
    for x in ids:
        if x in s:
            return x
        s.add(x)
    return None


def counts_by_status(rows):
    return dict(Counter(r["status"] for r in rows))


def first_non_repeating(text):
    c = Counter(text)
    return next((ch for ch in text if c[ch] == 1), None)


def dedupe_keep_latest(rows):
    """Keep highest version per id; reject conflicting content at that maximum.
    Older conflicting versions are irrelevant to this particular interview contract.
    """
    rows = list(rows)
    maximum = {}
    for row in rows:
        key = row["id"]
        maximum[key] = max(maximum.get(key, row["version"]), row["version"])
    result = {}
    for row in rows:
        key = row["id"]
        if row["version"] != maximum[key]:
            continue
        if key in result and result[key] != row:
            raise ValueError("conflicting latest version")
        result[key] = dict(row)
    return result


def reconcile_ids(source_ids, target_ids):
    return {
        "missing": set(source_ids) - set(target_ids),
        "unexpected": set(target_ids) - set(source_ids),
    }
