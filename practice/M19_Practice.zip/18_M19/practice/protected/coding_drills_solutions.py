from collections import Counter
def first_duplicate(xs):
 s=set()
 for x in xs:
  if x in s:return x
  s.add(x)
 return None
def first_non_repeating(s):
 c=Counter(s); return next((x for x in s if c[x]==1),None)
def two_sum(nums,target):
 seen={}
 for i,x in enumerate(nums):
  if target-x in seen:return (seen[target-x],i)
  seen[x]=i
 return None
def group_by_customer(rows):
 out={}
 for c,o in rows: out.setdefault(c,[]).append(o)
 return out
def top_k_statuses(statuses,k): return sorted(Counter(statuses).items(),key=lambda x:(-x[1],x[0]))[:k]
def reconcile_ids(a,b): return (set(a)-set(b),set(b)-set(a))
