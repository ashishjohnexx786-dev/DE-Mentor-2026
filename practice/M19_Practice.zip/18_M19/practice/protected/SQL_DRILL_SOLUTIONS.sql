-- Open after genuine attempt. One defensible solution set.
-- 1 grain: one row per region
SELECT c.region, ROUND(SUM(o.amount),2) paid_revenue FROM orders o JOIN customers c USING(customer_id) WHERE o.status='PAID' GROUP BY c.region ORDER BY c.region;
-- 2 grain: one row per customer
SELECT c.customer_id FROM customers c WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id=c.customer_id AND o.status='PAID') ORDER BY c.customer_id;
-- 3: ties are surfaced using RANK; interviewer can ask for a deterministic ROW_NUMBER variant.
WITH p AS (SELECT *, RANK() OVER(PARTITION BY customer_id ORDER BY updated_at DESC) r FROM orders WHERE status='PAID') SELECT * FROM p WHERE r=1 ORDER BY customer_id,order_id;
-- 4
SELECT order_id,updated_at,amount,SUM(amount) OVER(ORDER BY updated_at,order_id) running_paid FROM orders WHERE status='PAID' ORDER BY updated_at,order_id;
-- 5
WITH x AS (SELECT customer_id,SUM(amount) amt FROM orders WHERE status='PAID' GROUP BY customer_id), r AS (SELECT *,RANK() OVER(ORDER BY amt DESC) pos FROM x) SELECT * FROM r WHERE pos=1;
-- 6
SELECT c.customer_id,COUNT(o.order_id) paid_orders,COALESCE(SUM(o.amount),0) paid_amount FROM customers c LEFT JOIN orders o ON o.customer_id=c.customer_id AND o.status='PAID' GROUP BY c.customer_id ORDER BY c.customer_id;
