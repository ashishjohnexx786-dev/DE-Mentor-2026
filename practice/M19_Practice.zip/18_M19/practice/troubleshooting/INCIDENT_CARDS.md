# Six data-engineering incident cards
For each: safe durable state, first three checks, leading boundary, recovery, reconciliation, prevention.
1. API returned 5,000 rows; sink has 4,970; checkpoint advanced.
2. Airflow DAG imports but a historical task waits forever for a file.
3. Kafka consumer lag rises while CPU is low; one partition is much hotter than others.
4. dbt fact total doubles after adding a customer dimension join.
5. Spark job became 8x slower after one customer generated 60% of events.
6. Delta MERGE rerun changes totals even though source input is byte-identical.
