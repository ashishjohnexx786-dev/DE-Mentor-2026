# M19 Interview, Technical English & Job Launch
Start with books/M19_Learner_Book.pdf. Produce the artifacts in practice/ rather than only reading. Quick Revision and the closed-book Module Test come after all 14 lessons. G07 is the protected final stage gate. Master untimed first; optional interview timing comes later.
