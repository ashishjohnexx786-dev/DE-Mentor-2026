# Style freeze
Navy #173047 titles. Blue #2563EB ordinary section headings. Teal #087F8C structural accents only.
