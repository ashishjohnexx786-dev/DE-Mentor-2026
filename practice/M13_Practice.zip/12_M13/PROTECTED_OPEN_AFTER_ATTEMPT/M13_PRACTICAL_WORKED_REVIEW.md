# M13 practical worked solutions
## P1 - executable merge pattern
Run this inside the configured M13 Spark/Delta environment. target_path must name an existing disposable Delta table with order_id, amount and updated_at. source must have the same business columns and typed timestamps. The precheck deliberately rejects all repeated source keys in this practical; it does not choose an arbitrary winner. Validate fields and types before calling the function.
```python
from delta.tables import DeltaTable
from pyspark.sql import functions as F

def apply_order_batch(spark, target_path, source):
    if source.filter(
        F.col("order_id").isNull()
        | F.col("updated_at").isNull()
        | F.col("amount").isNull()
    ).limit(1).count():
        raise ValueError("missing required source value")
    if source.groupBy("order_id").count().filter(
        "count > 1"
    ).limit(1).count():
        raise ValueError("ambiguous source key")
    target = spark.read.format("delta").load(target_path)
    if target.groupBy("order_id").count().filter(
        "count > 1"
    ).limit(1).count():
        raise ValueError("target grain already broken")
    same_version = source.alias("s").join(
        target.alias("t"),
        (F.col("s.order_id") == F.col("t.order_id"))
        & (F.col("s.updated_at") == F.col("t.updated_at"))
    )
    if same_version.filter(
        ~F.col("s.amount").eqNullSafe(F.col("t.amount"))
    ).limit(1).count():
        raise ValueError("equal-version amount conflict")
    table = DeltaTable.forPath(spark, target_path)
    (
        table.alias("t")
        .merge(source.alias("s"), "t.order_id = s.order_id")
        .whenMatchedUpdate(
            condition="s.updated_at > t.updated_at",
            set={"amount": "s.amount",
                 "updated_at": "s.updated_at"}
        )
        .whenNotMatchedInsertAll()
        .execute()
    )
```
The matched predicate blocks stale updates. Equal-version identical rows leave the target unchanged, and an equal-version amount disagreement fails before the merge. In the supplied 06_merge_idempotency.py example, O1=50 and O2=80 start at total 130. O2 becomes 85 and O3=30 is inserted, so the final result has 3 rows/3 keys/165. Applying that batch again leaves the same controls; a stale O2=1 must not replace 85. The function assumes one writer during its precheck and merge. Production concurrency requires a transaction-aware design and conflict handling, not a promise that separate prechecks lock the table.
## P2 - reconcile a changed/new/unchanged SCD2 load
Suppose the target begins with four customers and one current row per customer. The incoming batch changes two of them, leaves one unchanged and introduces one new customer. Expire two existing current rows, append two new versions for changed customers, and append one new customer. History grows from 4 to 7 rows, while current rows grow from 4 to 5. The unchanged customer gets no new version; the existing customer absent from the batch remains current unless the source contract says absence is deletion.
Use half-open validity intervals [valid_from, valid_to). For each changed key, the old valid_to equals the new valid_from, so the change instant matches exactly one row. Test exactly one current row per active key, no overlapping history intervals, deterministic handling of duplicate/equal versions and an as-of join that preserves the fact row count. On exact replay, there are still 7 history rows and 5 current customers. These numbers demonstrate the logic; calculate the corresponding actual controls for your own fixture.
## P3 - prove more than row accounting
120 = 115 + 5 explains all delivered rows only if the accepted and rejected sets are disjoint and cover the same batch. Also verify 115 valid keys at the intended Silver grain or explicitly account for a deduplication category. Preserve the five raw rejected rows and reasons. Sum the accepted Silver revenue using the same currency, status and date scope as Gold; it must independently equal 91250. Check relationships and explain any intentional exclusions. The number 91250 appearing in a dashboard is not a control unless it reconciles to the contributing rows.
## P4 - recover before physical cleanup
First preserve history and identify the version immediately before the bad delete. Read that snapshot and compare the deleted key set and business amount with current state. A historical read is diagnostic and does not change current data. Once the intended recovery is established, a supported RESTORE or a carefully validated forward correction can create a new correct current version. Reconcile it before serving. OPTIMIZE may improve physical layout later; it cannot undelete business records. VACUUM waits because removing old files could destroy the recovery path you need.
## P5 - commit progress last and explain partial failure
Capture source identity and raw bytes, validate and separate rejects, publish trusted current records, build Gold, reconcile across layers, save output versions and only then advance the external checkpoint. A table commit is not a transaction across all those steps. If Silver commits and Gold fails, consumers must keep using the last fully validated publication or see a clear unavailable state. Replay the source safely to rebuild Gold and commit progress. A single success badge cannot establish that every layer belongs to the same logical run.
