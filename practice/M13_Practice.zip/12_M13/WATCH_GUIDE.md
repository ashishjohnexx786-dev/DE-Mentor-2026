# M13 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE13-01 — Data Lake vs Warehouse vs Lakehouse

- [Optional visual - no verified bounded range: Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Conceptual transaction-log/lakehouse walkthrough; version-specific commands may be old

## DE13-02 — Why plain files are not tables

- [Optional visual - no verified bounded range: Databricks - Unpacking the Transaction Log](https://www.youtube.com/watch?v=lXlBJdehsdw) — Deep conceptual visual of the log; use for mental model, not version-specific setup

## DE13-03 — Delta transaction log, ACID and table versions

- [Optional visual - no verified bounded range: Databricks - Unpacking the Transaction Log](https://www.youtube.com/watch?v=lXlBJdehsdw) — Conceptual transaction-log walkthrough

## DE13-04 — Create, read, update and delete

- [Optional visual - no verified bounded range: Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Conceptual Delta/lakehouse visual; learner book + official docs remain current syntax/runtime authority.

## DE13-05 — Schema enforcement and schema evolution

- [Optional visual - no verified bounded range: Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Conceptual Delta/lakehouse visual; learner book + official docs remain current syntax/runtime authority.

## DE13-06 — Time travel and version history

- [Optional visual - no verified bounded range: Databricks - Unpacking the Transaction Log](https://www.youtube.com/watch?v=lXlBJdehsdw) — Conceptual Delta transaction-log/version-state visual; learner book + official docs remain authority.

## DE13-07 — MERGE, upserts and idempotent incremental loads

- [Optional visual - no verified bounded range: Databricks - Unpacking the Transaction Log](https://www.youtube.com/watch?v=lXlBJdehsdw) — Conceptual Delta transaction-log/version-state visual; learner book + official docs remain authority.

## DE13-08 — Slowly Changing Dimension Type 2 with Delta

- [Optional visual - no verified bounded range: Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Conceptual Delta/lakehouse visual; learner book + official docs remain current syntax/runtime authority.

## DE13-09 — Bronze, Silver and Gold lakehouse layers

- [Optional visual with publisher chapter markers: Medallion Architecture in Databricks - Bronze, Silver, Gold](https://www.youtube.com/watch?v=cyDLRr24mBs) — 00:00-01:36 medallion concept; implementation chapters later in the video. UI/vendor details are supplementary.

## DE13-10 — Compaction, OPTIMIZE, VACUUM and maintenance boundaries

- [Optional visual - no verified bounded range: Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Conceptual Delta/lakehouse visual; learner book + official docs remain current syntax/runtime authority.

## DE13-11 — Integrated lakehouse pipeline and debugging checkpoint

- [Optional visual - no verified bounded range: Databricks - How Delta Lake Supercharges Data Lakes](https://www.youtube.com/watch?v=u1VfOiHVeMI) — Conceptual Delta/lakehouse visual; learner book + official docs remain current syntax/runtime authority.