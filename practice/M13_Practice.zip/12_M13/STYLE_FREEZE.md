# M13 visual freeze
- Lesson/main identity: dark navy #173047
- Every normal lesson section heading: blue #2563EB
- Teal #087F8C only for structural rules/callout borders/table accents
- No alternating blue/teal body heading pattern
- No forced timer
