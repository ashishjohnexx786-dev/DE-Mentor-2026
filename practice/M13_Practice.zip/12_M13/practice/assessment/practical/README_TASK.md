# M13 practical checkpoint
Build a disposable Delta lakehouse for order updates. Preserve source/Bronze evidence, validate Silver, MERGE curated state idempotently, build Gold, save versions and reconcile counts/keys/totals. Inject one duplicate-key source failure and prove it stops before target progress.
