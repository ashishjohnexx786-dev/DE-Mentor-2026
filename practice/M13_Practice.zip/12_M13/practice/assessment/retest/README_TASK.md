# M13 fresh retest - fixed parcel-shipment fixtures

This is a **fresh changed retest**, not a copy of the orders solution.

Files in this folder are the authoritative fresh fixtures:
- `parcel_shipments_base.csv`
- `parcel_shipments_changes.csv`
- `customer_scd2_base.csv`
- `customer_scd2_changes.csv`
- `EXPECTED_CONTROLS.json`

## Required implementation
1. Create/load a fresh Delta parcel table from `parcel_shipments_base.csv`.
2. Apply `parcel_shipments_changes.csv` with deterministic version precedence on `parcel_id` + `updated_at`.
3. Quarantine the invalid `P2006` timestamp; do not let it advance trusted state.
4. Prove the stale `P2003` change is ignored and its current status remains `CREATED`.
5. Prove the genuinely newer `P2002` change wins (`DELIVERED`, `HUB-C`).
6. Insert `P2005`.
7. Build SCD2 history for `customer_scd2_base.csv` + `customer_scd2_changes.csv`: expire C902 BRONZE and insert C902 GOLD while keeping one active version.
8. Save a run-evidence JSON with current parcel count, quarantined count, P2002/P2003 controls, C902 history count/current tier and relevant Delta version/history evidence.
9. Rerun the same changes and prove the logical result does not multiply.

## Independent controls
Use `EXPECTED_CONTROLS.json` only **after** your first saved attempt. The protected review may explain the reasoning, but your code/output must prove the result.
