import shutil
from common import spark_session, BASE, controls
from delta.tables import DeltaTable

spark=spark_session("m13-maintenance"); path=BASE/"09_maintenance"; shutil.rmtree(path,ignore_errors=True)
for i in range(6):
    spark.createDataFrame([(f"O{i}",float(i+1))],["order_id","amount"]).write.format("delta").mode("append" if i else "overwrite").save(str(path))
df=spark.read.format("delta").load(str(path)); before=controls(df,"order_id","amount"); print("before",before)
d=DeltaTable.forPath(spark,str(path)); d.detail().select("numFiles","sizeInBytes").show(); metrics=d.optimize().executeCompaction(); metrics.show(truncate=False)
after=controls(spark.read.format("delta").load(str(path)),"order_id","amount"); print("after",after); assert before==after
print("VACUUM not executed. Review safe retention in official docs before any destructive cleanup."); spark.stop()
