import json, shutil
from datetime import datetime
from pathlib import Path
from common import spark_session, BASE, controls
from delta.tables import DeltaTable
from pyspark.sql import functions as F

spark=spark_session("m13-integrated"); root=BASE/"10_integrated"; root.mkdir(parents=True,exist_ok=True)
bronze=root/"bronze"; silver=root/"silver"; quarantine=root/"quarantine"; curated=root/"curated"; gold=root/"gold"
source=spark.createDataFrame([("O1",10.0,"2026-09-14T10:00:00"),("O2",20.0,"2026-09-14T10:01:00"),("BAD",-5.0,"2026-09-14T10:02:00")],["order_id","amount","updated_at_s"]).withColumn("updated_at",F.to_timestamp("updated_at_s")).drop("updated_at_s")
# Bronze is append evidence for the exercise; use a batch id for real multi-run control.
if not DeltaTable.isDeltaTable(spark,str(bronze)): source.write.format("delta").save(str(bronze))
valid=source.filter("order_id <> 'BAD' AND amount >= 0"); bad=source.filter("order_id='BAD' OR amount < 0")
valid.write.format("delta").mode("overwrite").save(str(silver)); bad.write.format("delta").mode("overwrite").save(str(quarantine))
if not DeltaTable.isDeltaTable(spark,str(curated)): valid.write.format("delta").save(str(curated))
else:
    d=DeltaTable.forPath(spark,str(curated)); assert valid.groupBy("order_id").count().filter("count <> 1").count()==0
    (d.alias("t").merge(valid.alias("s"),"t.order_id=s.order_id").whenMatchedUpdate(condition="s.updated_at > t.updated_at",set={"amount":"s.amount","updated_at":"s.updated_at"}).whenNotMatchedInsertAll().execute())
cur=spark.read.format("delta").load(str(curated)); gold_df=cur.agg(F.round(F.sum("amount"),2).alias("total_sales")); gold_df.write.format("delta").mode("overwrite").save(str(gold))
assert source.count()==valid.count()+bad.count(); total=float(cur.agg(F.sum("amount")).first()[0]); assert round(total,2)==round(float(gold_df.first()[0]),2)
latest=int(DeltaTable.forPath(spark,str(curated)).history(1).select("version").first()[0])
evidence={"source_rows":source.count(),"silver_rows":valid.count(),"quarantine_rows":bad.count(),"curated":controls(cur,"order_id","amount"),"gold_sales":total,"curated_version":latest}
out=Path(__file__).resolve().parents[1]/"output"/"M13_INTEGRATED_EVIDENCE.json"; out.parent.mkdir(exist_ok=True); out.write_text(json.dumps(evidence,indent=2)); print(json.dumps(evidence,indent=2)); spark.stop()
