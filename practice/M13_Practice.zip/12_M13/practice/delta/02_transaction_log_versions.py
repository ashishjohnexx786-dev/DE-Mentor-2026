import shutil
from common import spark_session, BASE, controls
from delta.tables import DeltaTable

spark=spark_session("m13-versions"); path=BASE/"02_versions"; shutil.rmtree(path,ignore_errors=True)
spark.createDataFrame([("O1",10.0,"open"),("O2",20.0,"open")],["order_id","amount","status"]).write.format("delta").save(str(path))
spark.createDataFrame([("O3",30.0,"open")],["order_id","amount","status"]).write.format("delta").mode("append").save(str(path))
d=DeltaTable.forPath(spark,str(path)); d.update("order_id = 'O2'", {"status":"'closed'"})
print(controls(spark.read.format("delta").load(str(path)),"order_id","amount"))
d.history().select("version","timestamp","operation").show(truncate=False)
spark.stop()
