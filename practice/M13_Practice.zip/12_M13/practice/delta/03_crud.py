import shutil
from common import spark_session, BASE, controls
from delta.tables import DeltaTable

spark=spark_session("m13-crud"); path=BASE/"03_crud"; shutil.rmtree(path,ignore_errors=True)
rows=[("O1",40.0,"open"),("O2",80.0,"open"),("O3",25.0,"open"),("O4",5.0,"cancelled")]
spark.createDataFrame(rows,["order_id","amount","status"]).write.format("delta").save(str(path))
d=DeltaTable.forPath(spark,str(path)); before=spark.read.format("delta").load(str(path)); print("before",controls(before,"order_id","amount"))
print("update candidates"); before.filter("order_id='O2'").show()
d.update("order_id='O2'", {"status":"'closed'"})
print("delete candidates"); spark.read.format("delta").load(str(path)).filter("order_id='O4' AND status='cancelled'").show()
d.delete("order_id='O4' AND status='cancelled'")
after=spark.read.format("delta").load(str(path)); print("after",controls(after,"order_id","amount")); after.orderBy("order_id").show(); d.history().select("version","operation").show()
spark.stop()
