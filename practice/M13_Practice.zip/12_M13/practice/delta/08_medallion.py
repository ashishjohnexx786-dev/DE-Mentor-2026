import shutil
from datetime import datetime
from common import spark_session, BASE
from pyspark.sql import functions as F

spark=spark_session("m13-medallion"); root=BASE/"08_medallion"; shutil.rmtree(root,ignore_errors=True)
bronze=root/"bronze"; silver=root/"silver"; quarantine=root/"quarantine"; gold=root/"gold"
rows=[("O1","2026-09-14",2,10.0),("O2","2026-09-14",1,15.0),("O3","2026-09-14",-1,9.0),("O4","2026-09-15",3,5.0)]
b=spark.createDataFrame(rows,["order_id","order_date","qty","unit_price"]).withColumn("ingested_at",F.current_timestamp())
b.write.format("delta").save(str(bronze))
valid=b.filter("order_id is not null AND qty > 0 AND unit_price >= 0").withColumn("gross_sales",F.col("qty")*F.col("unit_price")); bad=b.filter("NOT (order_id is not null AND qty > 0 AND unit_price >= 0)")
valid.write.format("delta").save(str(silver)); bad.write.format("delta").save(str(quarantine))
g=valid.groupBy("order_date").agg(F.round(F.sum("gross_sales"),2).alias("daily_sales")); g.write.format("delta").save(str(gold))
assert b.count()==valid.count()+bad.count(); ssum=valid.agg(F.sum("gross_sales")).first()[0]; gsum=g.agg(F.sum("daily_sales")).first()[0]; assert round(ssum,2)==round(gsum,2)
print({"bronze":b.count(),"silver":valid.count(),"quarantine":bad.count(),"gold_sales":float(gsum)}); spark.stop()
