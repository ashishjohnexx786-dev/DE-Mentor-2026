from pathlib import Path
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

BASE = Path(__file__).resolve().parents[1] / "workspace"
BASE.mkdir(parents=True, exist_ok=True)

def spark_session(app_name):
    builder = (SparkSession.builder
        .appName(app_name)
        .master("local[2]")
        .config("spark.driver.memory", "1g")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog"))
    return configure_spark_with_delta_pip(builder).getOrCreate()

def controls(df, key, amount=None):
    from pyspark.sql import functions as F
    row = df.agg(F.count("*").alias("rows"), F.countDistinct(key).alias("keys"),
                 (F.sum(amount) if amount else F.lit(None)).alias("amount_sum")).first()
    return {"rows": row["rows"], "keys": row["keys"], "amount_sum": None if amount is None else float(row["amount_sum"] or 0)}
