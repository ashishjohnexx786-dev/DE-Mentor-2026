from pathlib import Path
import shutil
from common import spark_session, BASE

spark=spark_session("m13-files-vs-tables")
root=BASE/"01_files_vs_tables"; shutil.rmtree(root,ignore_errors=True); root.mkdir(parents=True)
df=spark.createDataFrame([("O1",10.0),("O2",20.0)], ["order_id","amount"])
parquet_path=root/"parquet_orders"; delta_path=root/"delta_orders"
df.write.mode("overwrite").parquet(str(parquet_path))
df.write.format("delta").mode("overwrite").save(str(delta_path))
spark.createDataFrame([("O3",30.0)],["order_id","amount"]).write.format("delta").mode("append").save(str(delta_path))
print("PARQUET DIRECTORY:", sorted(p.name for p in parquet_path.iterdir()))
print("DELTA DIRECTORY:", sorted(p.name for p in delta_path.iterdir()))
from delta.tables import DeltaTable
DeltaTable.forPath(spark,str(delta_path)).history().select("version","operation").show(truncate=False)
spark.read.format("delta").load(str(delta_path)).orderBy("order_id").show()
spark.stop()
