import sys, importlib.metadata as md
print("python", sys.version.split()[0])
for p in ["pyspark","delta-spark"]:
    try: print(p, md.version(p))
    except md.PackageNotFoundError: print(p, "NOT INSTALLED")
print("Required course pair: pyspark 4.2.0 + delta-spark 4.4.0")
