import shutil
from common import spark_session, BASE, controls
from delta.tables import DeltaTable

spark=spark_session("m13-time-travel"); path=BASE/"05_time_travel"; shutil.rmtree(path,ignore_errors=True)
spark.createDataFrame([("I1",5), ("I2",7)],["item_id","qty"]).write.format("delta").save(str(path))
spark.createDataFrame([("I3",9)],["item_id","qty"]).write.format("delta").mode("append").save(str(path))
v0=spark.read.format("delta").option("versionAsOf",0).load(str(path)); latest=spark.read.format("delta").load(str(path))
print("v0",controls(v0,"item_id","qty")); print("latest",controls(latest,"item_id","qty")); DeltaTable.forPath(spark,str(path)).history().select("version","operation").show()
spark.stop()
