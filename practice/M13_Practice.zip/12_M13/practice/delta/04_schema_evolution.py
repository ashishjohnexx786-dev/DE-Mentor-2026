import shutil
from common import spark_session, BASE

spark=spark_session("m13-schema"); path=BASE/"04_schema"; shutil.rmtree(path,ignore_errors=True)
base=spark.createDataFrame([("C1","Asha"),("C2","Ravi")],["customer_id","name"]); base.write.format("delta").save(str(path))
incoming=spark.createDataFrame([("C3","Mina","gold")],["customer_id","name","loyalty_tier"])
try:
    incoming.write.format("delta").mode("append").save(str(path))
    raise AssertionError("Expected schema mismatch did not fail")
except Exception as exc:
    print("EXPECTED SCHEMA FAILURE:", type(exc).__name__)
incoming.write.format("delta").option("mergeSchema","true").mode("append").save(str(path))
df=spark.read.format("delta").load(str(path)); df.printSchema(); df.orderBy("customer_id").show(); assert df.select("customer_id").distinct().count()==3
spark.stop()
