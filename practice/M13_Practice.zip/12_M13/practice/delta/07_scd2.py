import shutil
from datetime import datetime
from common import spark_session, BASE
from delta.tables import DeltaTable
from pyspark.sql import functions as F

spark=spark_session("m13-scd2"); path=BASE/"07_scd2"; shutil.rmtree(path,ignore_errors=True)
OPEN=datetime(9999,12,31,0,0); T0=datetime(2026,9,1,0,0); T1=datetime(2026,9,14,0,0)
base=[("C1","Asha","Patna",T0,OPEN,True),("C2","Ravi","Patna",T0,OPEN,True)]
schema="customer_id string, name string, city string, effective_from timestamp, effective_to timestamp, is_current boolean"
spark.createDataFrame(base,schema).write.format("delta").save(str(path))
updates=spark.createDataFrame([("C1","Asha","Patna",T1),("C2","Ravi","Pune",T1),("C3","Mina","Delhi",T1)],"customer_id string, name string, city string, effective_from timestamp")
assert updates.groupBy("customer_id").count().filter("count <> 1").count()==0
def apply_batch():
    current=spark.read.format("delta").load(str(path)).filter("is_current=true").select("customer_id","name","city")
    j=(updates.alias("u").join(current.alias("c"),"customer_id","left")
       .withColumn("is_new",F.col("c.name").isNull())
       .withColumn("is_changed",(~F.col("c.name").isNull()) & ((F.col("u.name")!=F.col("c.name")) | (F.col("u.city")!=F.col("c.city")))))
    new=j.filter("is_new").select("u.*")
    changed=j.filter("is_changed").select("u.*")
    new_stage=new.withColumn("merge_key",F.col("customer_id"))
    expire_stage=changed.withColumn("merge_key",F.col("customer_id"))
    insert_stage=changed.withColumn("merge_key",F.lit(None).cast("string"))
    staged=new_stage.unionByName(expire_stage).unionByName(insert_stage)
    d=DeltaTable.forPath(spark,str(path))
    (d.alias("t").merge(staged.alias("s"),"t.customer_id=s.merge_key AND t.is_current=true")
      .whenMatchedUpdate(set={"effective_to":"s.effective_from","is_current":"false"})
      .whenNotMatchedInsert(values={"customer_id":"s.customer_id","name":"s.name","city":"s.city","effective_from":"s.effective_from","effective_to":"TIMESTAMP '9999-12-31 00:00:00'","is_current":"true"})
      .execute())
apply_batch(); apply_batch()
df=spark.read.format("delta").load(str(path)); df.orderBy("customer_id","effective_from").show(truncate=False)
assert df.filter("is_current=true").groupBy("customer_id").count().filter("count <> 1").count()==0
assert df.filter("customer_id='C2'").count()==2; assert df.filter("customer_id='C1'").count()==1; assert df.filter("customer_id='C3'").count()==1
spark.stop()
