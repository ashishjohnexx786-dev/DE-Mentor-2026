import shutil
from datetime import datetime
from common import spark_session, BASE, controls
from delta.tables import DeltaTable
from pyspark.sql import functions as F

spark=spark_session("m13-merge"); path=BASE/"06_merge"; shutil.rmtree(path,ignore_errors=True)
target_rows=[("O1",50.0,datetime(2026,9,14,9,0)),("O2",80.0,datetime(2026,9,14,10,0))]
spark.createDataFrame(target_rows,"order_id string, amount double, updated_at timestamp").write.format("delta").save(str(path))
source=spark.createDataFrame([("O2",85.0,datetime(2026,9,14,10,5)),("O3",30.0,datetime(2026,9,14,10,6))],"order_id string, amount double, updated_at timestamp")
assert source.groupBy("order_id").count().filter("count <> 1").count()==0
def run_merge():
    d=DeltaTable.forPath(spark,str(path))
    (d.alias("t").merge(source.alias("s"),"t.order_id=s.order_id")
      .whenMatchedUpdate(condition="s.updated_at > t.updated_at",set={"amount":"s.amount","updated_at":"s.updated_at"})
      .whenNotMatchedInsertAll().execute())
run_merge(); first=controls(spark.read.format("delta").load(str(path)),"order_id","amount"); print("first",first)
run_merge(); second=controls(spark.read.format("delta").load(str(path)),"order_id","amount"); print("retry",second); assert first==second
# stale update must not regress
stale=spark.createDataFrame([("O2",1.0,datetime(2026,9,14,9,55))],"order_id string, amount double, updated_at timestamp")
d=DeltaTable.forPath(spark,str(path)); (d.alias("t").merge(stale.alias("s"),"t.order_id=s.order_id").whenMatchedUpdate(condition="s.updated_at > t.updated_at",set={"amount":"s.amount","updated_at":"s.updated_at"}).whenNotMatchedInsertAll().execute())
row=spark.read.format("delta").load(str(path)).filter("order_id='O2'").first(); assert float(row.amount)==85.0
print("stale update blocked; final", controls(spark.read.format("delta").load(str(path)),"order_id","amount")); spark.stop()
