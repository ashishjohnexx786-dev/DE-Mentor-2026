import json
from copy import deepcopy

def merge(target, source):
    by={r["order_id"]:deepcopy(r) for r in target}
    seen=set()
    for s in source:
        k=s["order_id"]
        if k in seen: raise ValueError(f"ambiguous source key: {k}")
        seen.add(k)
        if k not in by or s["updated_at"] > by[k]["updated_at"]:
            by[k]=deepcopy(s)
    return [by[k] for k in sorted(by)]

t=[{"order_id":"O1","amount":50.0,"updated_at":"2026-09-14T09:00:00Z"},{"order_id":"O2","amount":80.0,"updated_at":"2026-09-14T10:00:00Z"}]
s=[{"order_id":"O2","amount":85.0,"updated_at":"2026-09-14T10:05:00Z"},{"order_id":"O3","amount":30.0,"updated_at":"2026-09-14T10:06:00Z"}]
r1=merge(t,s); r2=merge(r1,s); assert r1==r2
stale=[{"order_id":"O2","amount":1.0,"updated_at":"2026-09-14T09:55:00Z"}]; assert merge(r2,stale)==r2
try:
    merge(r2,[{"order_id":"O9","amount":1,"updated_at":"2026-09-14T11:00:00Z"},{"order_id":"O9","amount":2,"updated_at":"2026-09-14T11:00:00Z"}])
    raise AssertionError("ambiguity not raised")
except ValueError: pass
result={"status":"PASS","first":r1,"retry_same":r2,"stale_blocked":True,"ambiguity_blocked":True,"row_count":len(r2),"amount_sum":sum(r["amount"] for r in r2)}
print(json.dumps(result,indent=2))
