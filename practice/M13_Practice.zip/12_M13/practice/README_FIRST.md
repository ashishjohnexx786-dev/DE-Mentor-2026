# M13 practice - Delta Lake + Lakehouse

1. Create/activate a fresh venv.
2. `pip install -r requirements.txt`
3. Run `delta/00_env_probe.py`. Required course pair: PySpark 4.2.0 + delta-spark 4.4.0.
4. Run scripts 01-10 in order inside a disposable learner workspace.
5. Save actual outputs/errors. Static/simulator QA does not equal live Delta runtime mastery.
6. The simulator is safe to run without Spark and proves only state/idempotency reasoning.

Never shorten VACUUM retention or disable safety checks merely to complete a lesson.
