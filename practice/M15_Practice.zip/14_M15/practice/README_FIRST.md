# M15 practice route

This module teaches Fabric, but this package cannot impersonate a live Microsoft tenant. Use two evidence layers:

1. **Local controls**: run the pure-Python simulators and inspect the SQL/config patterns. They prove state, IAM/path reasoning, idempotency, secret-source hygiene, monitoring math and deployment binding logic.
2. **Learner-PC / Fabric evidence**: in your own Fabric tenant/trial, create the matching items and save workspace/item/runtime/run evidence. Never manufacture screenshots if access is unavailable; mark the live proof pending.

Recommended order: run scripts 01-16 as each lesson routes you. Scripts use only Python standard library unless the file itself says otherwise.
