# M15: copy each CELL into its own Fabric notebook cell, in order.
# Attach orders_lh as the default lakehouse. Use one writer at a time.
# CELL 1 - PARAMETERS: mark THIS cell as the Fabric parameter cell.
p_batch = "initial"
p_expected_rows = 3
p_expected_paid_revenue = "200.50"
p_fail_after_silver = False

# CELL 2 - READ AND VALIDATE; no table changes here.
from decimal import Decimal
from pyspark.sql import functions as F, types as T, Window
spark.conf.set("spark.sql.session.timeZone", "UTC")
if p_batch not in {"initial", "changes", "conflict", "newer", "interrupt"}:
    raise ValueError("unsupported batch; use one supplied course file")
fields = ["order_id", "updated_at", "customer_id", "amount", "status"]
schema = T.StructType([T.StructField(x, T.StringType()) for x in fields])
raw = (spark.read.option("header", True).option("enforceSchema", False)
       .schema(schema).csv(f"Files/m15/orders/orders_{p_batch}.csv"))
if raw.limit(1).count() == 0:
    raise ValueError("empty batch: inspect the file before advancing progress")
staged = (raw.withColumn("event_ts", F.try_to_timestamp("updated_at"))
          .withColumn("amount_dec", F.expr("try_cast(amount AS DECIMAL(12,2))")))
invalid = F.lit(False)
for name in fields:
    invalid = invalid | F.col(name).isNull() | (F.length(F.trim(F.col(name))) == 0)
invalid = (invalid | F.col("event_ts").isNull()
           | ~F.col("updated_at").rlike(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$")
           | F.col("amount_dec").isNull()
           | ~F.col("amount").rlike(r"^\d{1,10}(\.\d{1,2})?$")
           | ~F.col("status").isin("NEW", "PAID", "CANCELLED"))
bad = staged.filter(invalid)
if bad.limit(1).count():
    bad.show(truncate=False)
    raise ValueError("invalid input: no business table or checkpoint was changed")
incoming_all = staged.select("order_id", "customer_id",
                            F.col("amount_dec").alias("amount"), "status", "event_ts").dropDuplicates()
# Same key/version with different content is ambiguous, even if order differs.
conflicts = incoming_all.groupBy("order_id", "event_ts").count().filter("count > 1")
if conflicts.limit(1).count():
    conflicts.show(truncate=False)
    raise ValueError("equal-version conflict inside the input")
w = Window.partitionBy("order_id").orderBy(F.col("event_ts").desc())
incoming = incoming_all.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")

# CELL 3 - COMPARE WITH EXISTING STATE; initial is NOT an overwrite command.
exists = spark.catalog.tableExists("silver_orders")
if not exists and p_batch != "initial":
    raise ValueError("bootstrap once with initial before applying changes")
current = spark.table("silver_orders") if exists else incoming.limit(0)
if current.groupBy("order_id").count().filter("count > 1").limit(1).count():
    raise ValueError("target key conflict: inspect Silver before writing")
s, t = incoming.alias("s"), current.alias("t")
paired = s.join(t, F.col("s.order_id") == F.col("t.order_id"), "inner")
changed = F.lit(False)
for name in ("customer_id", "amount", "status"):
    changed = changed | ~F.col("s." + name).eqNullSafe(F.col("t." + name))
if paired.filter((F.col("s.event_ts") == F.col("t.event_ts")) & changed).limit(1).count():
    raise ValueError("equal-version conflict against Silver; no write allowed")
updates = (s.join(t, F.col("s.order_id") == F.col("t.order_id"), "left")
           .filter(F.col("t.order_id").isNull() | (F.col("s.event_ts") > F.col("t.event_ts")))
           .select("s.*"))
projected = current.join(updates.select("order_id"), "order_id", "left_anti").unionByName(updates)

# CELL 4 - CHECK THE PROPOSED RESULT BEFORE WRITING.
row_count = projected.count()
paid = projected.filter("status = 'PAID'").agg(F.sum("amount")).first()[0]
paid = Decimal(str(paid or 0)).quantize(Decimal("0.01"))
expected = Decimal(str(p_expected_paid_revenue))
if not expected.is_finite() or row_count != int(p_expected_rows) or paid != expected:
    raise ValueError(f"reconciliation failed BEFORE write: rows={row_count}, paid={paid}")
# A checkpoint is a high-water mark over processed versions, not a wall-clock time.
row_max = incoming.agg(F.max("event_ts")).first()[0]
control_exists = spark.catalog.tableExists("m15_pipeline_control")
if control_exists:
    ctl = spark.table("m15_pipeline_control")
    if set(ctl.columns) != {"pipeline", "committed_ts"}:
        raise ValueError("old control schema: use a fresh disposable M15 lakehouse")
    previous = ctl.filter("pipeline = 'orders'").agg(F.max("committed_ts")).first()[0]
else:
    previous = None
candidate = max(x for x in (previous, row_max) if x is not None)
print({"before": str(previous), "candidate": str(candidate), "rows": row_count, "paid": str(paid)})

# CELL 5 - DURABLE SILVER, GOLD, THEN PROGRESS. Single-writer lab.
incoming.createOrReplaceTempView("m15_incoming")
if not exists:
    # errorifexists prevents a concurrent/bootstrap rerun from replacing a table.
    incoming.write.format("delta").mode("errorifexists").saveAsTable("silver_orders")
else:
    spark.sql("""
      MERGE INTO silver_orders t USING m15_incoming s
      ON t.order_id = s.order_id
      WHEN MATCHED AND s.event_ts > t.event_ts THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
    """)
if str(p_fail_after_silver).lower() == "true":
    raise RuntimeError("DELIBERATE_FAILURE_AFTER_SILVER: Gold and progress remain unchanged")
# Reconcile actual durable Silver; another writer is not permitted in this lab.
silver = spark.table("silver_orders")
actual_paid = silver.filter("status = 'PAID'").agg(F.sum("amount")).first()[0] or Decimal("0")
if silver.count() != row_count or actual_paid != paid:
    raise ValueError("durable Silver differs: stop before Gold/progress")
gold = spark.createDataFrame([(row_count, paid)], "unique_orders long, paid_revenue decimal(18,2)")
gold.write.format("delta").mode("overwrite").saveAsTable("gold_order_summary")
new_control = spark.createDataFrame([("orders", candidate)], "pipeline string, committed_ts timestamp")
if not control_exists:
    new_control.write.format("delta").mode("errorifexists").saveAsTable("m15_pipeline_control")
else:
    new_control.createOrReplaceTempView("m15_next_control")
    spark.sql("""
      MERGE INTO m15_pipeline_control t USING m15_next_control s
      ON t.pipeline = s.pipeline
      WHEN MATCHED AND s.committed_ts > t.committed_ts THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
    """)
print({"rows": row_count, "paid_revenue": str(paid), "committed": str(candidate)})
