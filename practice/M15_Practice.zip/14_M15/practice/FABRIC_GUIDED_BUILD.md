# M15 real Fabric guided build - supplied orders data

This guided walkthrough is for for DE15-04, DE15-09 and DE15-16. It connects the course's own files to a real Fabric lakehouse, notebook, pipeline and SQL result.

**Target proof:** after initial + changes runs, `silver_orders` has **5 unique orders** and the paid revenue is **460.00**. Do not mark LIVE FABRIC PASS unless you actually obtain the portal/run/table evidence in your own tenant.

## 0. Access and cost guardrail

Preferred learning route: use an eligible Microsoft Fabric trial or an existing Fabric-enabled workspace. Microsoft currently documents a 60-day trial, but eligibility depends on tenant/region/settings and can change.

If you cannot start a trial, **do not buy capacity just to satisfy this course**. Complete the local `fabric_patterns/16_end_to_end_local_case.py` control, study this walkthrough, and record `LIVE FABRIC = PENDING - ACCESS UNAVAILABLE`. Return to the real build when you have legitimate trial/workspace access.

Official references:
- Trial: https://learn.microsoft.com/en-us/fabric/get-started/fabric-trial
- Lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-get-started/
- OneLake/lakehouse upload: https://learn.microsoft.com/en-us/fabric/onelake/create-lakehouse-onelake
- Notebook activity: https://learn.microsoft.com/en-ca/fabric/data-factory/notebook-activity
- Pipeline parameters: https://learn.microsoft.com/en-us/fabric/data-factory/parameters

## 1. Create the DEV workspace and lakehouse

1. Sign in to Fabric and switch to the Fabric experience.
2. Create a workspace named `de2026-m15-dev` (add your initials if the name must be unique).
3. Assign the workspace to your eligible trial/paid Fabric capacity.
4. In the workspace select **New item -> Lakehouse**.
5. Name it `orders_lh`.
6. Open the lakehouse. Confirm you can see both **Files** and **Tables**.

Evidence: save the workspace name and lakehouse name. Do not screenshot secrets or tenant IDs unnecessarily.

## 2. Upload the supplied course files into OneLake

From the extracted course package use:
- `14_M15/practice/data/orders_initial.csv`
- `14_M15/practice/data/orders_changes.csv`

In the lakehouse Files area create `m15/orders/` and upload both files so the notebook paths are:

```text
Files/m15/orders/orders_initial.csv
Files/m15/orders/orders_changes.csv
```

Do not rename them. Open/preview each file and confirm the headers include:
`order_id, updated_at, customer_id, amount, status`.

## 3. Create notebook `nb_m15_orders`

Create a notebook in the same workspace, attach `orders_lh` as the default lakehouse, and add the following cells in order.

Use the complete companion file `FABRIC_GUIDED_BUILD_NOTEBOOK.py`. It is divided into five cells. Copy each cell below in order. Mark only Cell 1 as the parameter cell.

### Cell 1 - PARAMETERS: mark THIS cell as the Fabric parameter cell.

```python
p_batch = "initial"
p_expected_rows = 3
p_expected_paid_revenue = "200.50"
p_fail_after_silver = False
```

### Cell 2 - READ AND VALIDATE; no table changes here.

```python
from decimal import Decimal
from pyspark.sql import functions as F, types as T, Window
spark.conf.set("spark.sql.session.timeZone", "UTC")
if p_batch not in {"initial", "changes", "conflict", "newer", "interrupt"}:
    raise ValueError("unsupported batch; use one supplied course file")
fields = ["order_id", "updated_at", "customer_id", "amount", "status"]
schema = T.StructType([T.StructField(x, T.StringType()) for x in fields])
raw = (spark.read.option("header", True).option("enforceSchema", False)
       .schema(schema).csv(f"Files/m15/orders/orders_{p_batch}.csv"))
if raw.limit(1).count() == 0:
    raise ValueError("empty batch: inspect the file before advancing progress")
staged = (raw.withColumn("event_ts", F.try_to_timestamp("updated_at"))
          .withColumn("amount_dec", F.expr("try_cast(amount AS DECIMAL(12,2))")))
invalid = F.lit(False)
for name in fields:
    invalid = invalid | F.col(name).isNull() | (F.length(F.trim(F.col(name))) == 0)
invalid = (invalid | F.col("event_ts").isNull()
           | ~F.col("updated_at").rlike(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$")
           | F.col("amount_dec").isNull()
           | ~F.col("amount").rlike(r"^\d{1,10}(\.\d{1,2})?$")
           | ~F.col("status").isin("NEW", "PAID", "CANCELLED"))
bad = staged.filter(invalid)
if bad.limit(1).count():
    bad.show(truncate=False)
    raise ValueError("invalid input: no business table or checkpoint was changed")
incoming_all = staged.select("order_id", "customer_id",
                            F.col("amount_dec").alias("amount"), "status", "event_ts").dropDuplicates()
# Same key/version with different content is ambiguous, even if order differs.
conflicts = incoming_all.groupBy("order_id", "event_ts").count().filter("count > 1")
if conflicts.limit(1).count():
    conflicts.show(truncate=False)
    raise ValueError("equal-version conflict inside the input")
w = Window.partitionBy("order_id").orderBy(F.col("event_ts").desc())
incoming = incoming_all.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")
```

### Cell 3 - COMPARE WITH EXISTING STATE; initial is NOT an overwrite command.

```python
exists = spark.catalog.tableExists("silver_orders")
if not exists and p_batch != "initial":
    raise ValueError("bootstrap once with initial before applying changes")
current = spark.table("silver_orders") if exists else incoming.limit(0)
if current.groupBy("order_id").count().filter("count > 1").limit(1).count():
    raise ValueError("target key conflict: inspect Silver before writing")
s, t = incoming.alias("s"), current.alias("t")
paired = s.join(t, F.col("s.order_id") == F.col("t.order_id"), "inner")
changed = F.lit(False)
for name in ("customer_id", "amount", "status"):
    changed = changed | ~F.col("s." + name).eqNullSafe(F.col("t." + name))
if paired.filter((F.col("s.event_ts") == F.col("t.event_ts")) & changed).limit(1).count():
    raise ValueError("equal-version conflict against Silver; no write allowed")
updates = (s.join(t, F.col("s.order_id") == F.col("t.order_id"), "left")
           .filter(F.col("t.order_id").isNull() | (F.col("s.event_ts") > F.col("t.event_ts")))
           .select("s.*"))
projected = current.join(updates.select("order_id"), "order_id", "left_anti").unionByName(updates)
```

### Cell 4 - CHECK THE PROPOSED RESULT BEFORE WRITING.

```python
row_count = projected.count()
paid = projected.filter("status = 'PAID'").agg(F.sum("amount")).first()[0]
paid = Decimal(str(paid or 0)).quantize(Decimal("0.01"))
expected = Decimal(str(p_expected_paid_revenue))
if not expected.is_finite() or row_count != int(p_expected_rows) or paid != expected:
    raise ValueError(f"reconciliation failed BEFORE write: rows={row_count}, paid={paid}")
# A checkpoint is a high-water mark over processed versions, not a wall-clock time.
row_max = incoming.agg(F.max("event_ts")).first()[0]
control_exists = spark.catalog.tableExists("m15_pipeline_control")
if control_exists:
    ctl = spark.table("m15_pipeline_control")
    if set(ctl.columns) != {"pipeline", "committed_ts"}:
        raise ValueError("old control schema: use a fresh disposable M15 lakehouse")
    previous = ctl.filter("pipeline = 'orders'").agg(F.max("committed_ts")).first()[0]
else:
    previous = None
candidate = max(x for x in (previous, row_max) if x is not None)
print({"before": str(previous), "candidate": str(candidate), "rows": row_count, "paid": str(paid)})
```

### Cell 5 - DURABLE SILVER, GOLD, THEN PROGRESS. Single-writer lab.

```python
incoming.createOrReplaceTempView("m15_incoming")
if not exists:
    # errorifexists prevents a concurrent/bootstrap rerun from replacing a table.
    incoming.write.format("delta").mode("errorifexists").saveAsTable("silver_orders")
else:
    spark.sql("""
      MERGE INTO silver_orders t USING m15_incoming s
      ON t.order_id = s.order_id
      WHEN MATCHED AND s.event_ts > t.event_ts THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
    """)
if str(p_fail_after_silver).lower() == "true":
    raise RuntimeError("DELIBERATE_FAILURE_AFTER_SILVER: Gold and progress remain unchanged")
# Reconcile actual durable Silver; another writer is not permitted in this lab.
silver = spark.table("silver_orders")
actual_paid = silver.filter("status = 'PAID'").agg(F.sum("amount")).first()[0] or Decimal("0")
if silver.count() != row_count or actual_paid != paid:
    raise ValueError("durable Silver differs: stop before Gold/progress")
gold = spark.createDataFrame([(row_count, paid)], "unique_orders long, paid_revenue decimal(18,2)")
gold.write.format("delta").mode("overwrite").saveAsTable("gold_order_summary")
new_control = spark.createDataFrame([("orders", candidate)], "pipeline string, committed_ts timestamp")
if not control_exists:
    new_control.write.format("delta").mode("errorifexists").saveAsTable("m15_pipeline_control")
else:
    new_control.createOrReplaceTempView("m15_next_control")
    spark.sql("""
      MERGE INTO m15_pipeline_control t USING m15_next_control s
      ON t.pipeline = s.pipeline
      WHEN MATCHED AND s.committed_ts > t.committed_ts THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
    """)
print({"rows": row_count, "paid_revenue": str(paid), "committed": str(candidate)})
```

The proposed output is checked before the first write. Equal-version disagreements fail explicitly. An older initial file cannot overwrite newer orders. Silver, Gold and the checkpoint are separate Delta transactions: keep this teaching pipeline single-writer, and let consumers use it only after the whole run succeeds. A failed run can leave newer Silver with older Gold; replay repairs that boundary.

## 4. Run interactively once

Run the notebook with defaults (`initial`). Confirm:
- `silver_orders` = 3 keys;
- Gold = 3 unique orders, 200.50 paid revenue;
- control table has the initial maximum `committed_ts`.

Then manually change the parameter values to `changes`, `5`, `460.00` and run again. Confirm the target result **5 / 460.00**.

This interactive run proves the notebook before orchestration.

## 5. Build pipeline `pl_m15_orders`

1. Bootstrap interactively once, as in section 4. Confirm the initial run is 3 / 200.50 and the changes run is 5 / 460.00.
2. In the same workspace choose **New item -> Data pipeline** and name it `pl_m15_orders`.
3. Add one **Notebook** activity named `Apply changes`, choosing `nb_m15_orders`.
4. Set Base parameters: `p_batch` = `changes`, `p_expected_rows` = `5`, `p_expected_paid_revenue` = `460.00`, and `p_fail_after_silver` = `False`.
5. Save and run the pipeline. It replays the changes safely over the existing table.
6. Open the activity output and compare its counts/revenue/checkpoint with the interactive result.

Do not schedule an initial-load overwrite before every incremental run. Initial is a bootstrap input, not a reset operation. If you later replay the initial file over the final state, use expected controls 5 / 460.00: those are the controls of the resulting target, not the three-row input file. For a genuinely fresh demonstration, create a separate disposable lakehouse rather than deleting trusted output.

## 6. Query the result from the SQL analytics endpoint

Open the SQL analytics endpoint created with `orders_lh` and run:

```sql
SELECT COUNT(*) AS silver_rows
FROM dbo.silver_orders;

SELECT unique_orders, paid_revenue
FROM dbo.gold_order_summary;
```

Expected final result:

```text
silver_rows = 5
unique_orders = 5
paid_revenue = 460.00
```

If the table is not immediately visible, refresh the explorer/endpoint metadata and confirm the notebook wrote managed Delta tables to the attached lakehouse.

## 7. Deliberate failure + recovery

You need a real failure, not only a green screenshot.

1. In `Apply changes`, temporarily set `p_expected_paid_revenue` to `999.00`.
2. Run the pipeline. The changes activity should fail at reconciliation.
3. Inspect the activity output/notebook run and save the failing expected-vs-observed evidence.
4. Confirm the control table **did not get a new `committed_ts` from the failed validation**.
5. Restore the expected revenue to `460.00`.
6. Rerun. The MERGE is safe to replay and final Gold must be 5 / 460.00.

The deliberately wrong 999.00 control now fails before any write. To test a different boundary, set `p_fail_after_silver` to `True`: the activity fails after Silver, while Gold and committed progress remain unchanged. Restore `False` and rerun the same batch; it must converge. For a visibly newer checkpoint, upload `orders_newer.csv` and use expected controls 5 / 525.00 before this crash/recovery test. Do not run two copies concurrently.

## 8. Changed task - do it without copying the walkthrough

Create a second pipeline or notebook parameterization for a fictional returns feed:
- `return_id` is the business key;
- statuses are `REQUESTED`, `APPROVED`, `REFUNDED`;
- a later timestamp may update a return;
- Gold reports total refunded amount.

Write your own five-row fixture, include one stale update and one equal-version conflict, and document the conflict policy before running it.

## 9. Evidence / mastery checklist

Save:
- workspace + lakehouse + notebook + pipeline item names;
- Files path showing both supplied CSVs;
- notebook parameter cell;
- pipeline activity graph and Base parameters;
- successful pipeline run ID;
- Silver count = 5;
- Gold paid revenue = 460.00;
- control `committed_ts` before/after;
- deliberate 999.00 failure and corrected recovery;
- SQL endpoint result;
- one paragraph on why checkpoint commit is last;
- changed returns task attempt.

A simulator PASS is useful preparation but is **not** Fabric runtime proof. If access is unavailable, label the live items pending.

## 10. Cleanup / cost hygiene

When finished:
1. Stop any schedule you created.
2. Delete disposable test items/workspaces you no longer need, or end the trial if you explicitly want to stop using it.
3. Never leave copied credentials in notebook cells or Git.
4. Keep your evidence/screenshots and code, not unnecessary running resources.


## Controlled equal-version conflict
After successfully applying orders_newer.csv (5 orders / 525.00 paid), upload orders_conflict.csv and select p_batch = conflict with the same expected controls. It has the same O1005 version but a different status, so the run must fail before any write. If you run the conflict file before orders_newer.csv, it is instead a newer cancellation; that is a different experiment. Keep the sequence explicit.
