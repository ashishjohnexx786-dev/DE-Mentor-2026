-- Spark/notebook owns Delta writes. SQL analytics endpoint is read-oriented for lakehouse tables.
SELECT COUNT(*) AS order_count FROM dbo.silver_orders;
SELECT order_date, SUM(amount) AS revenue FROM dbo.gold_daily_sales GROUP BY order_date;
-- Do not teach UPDATE dbo.silver_orders through the lakehouse SQL analytics endpoint as the write route.
