import re
BAD=[re.compile(r'(?i)(password|api[_-]?key|token)\s*=\s*["\'][^"\']+["\']')]
def contains_hardcoded_secret(text): return any(p.search(text) for p in BAD)
if __name__=='__main__':
    assert contains_hardcoded_secret('API_KEY="do-not-commit"')
    assert not contains_hardcoded_secret('SECRET_NAME="crm-api-token"')
    print('secret-source lint PASS')
