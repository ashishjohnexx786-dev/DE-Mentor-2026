-- READ via lakehouse SQL analytics endpoint
SELECT TOP 100 * FROM dbo.gold_daily_sales ORDER BY order_date DESC;
-- Views/functions/procedures can represent SQL-layer logic subject to current endpoint support.
-- Table mutation of lakehouse Delta data belongs to Spark/Delta write paths, not the read-only endpoint.
