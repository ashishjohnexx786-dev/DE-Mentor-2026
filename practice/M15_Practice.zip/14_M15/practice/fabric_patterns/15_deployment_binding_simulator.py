bindings={'DEV':{'lakehouse':'lh-dev-001'},'PROD':{'lakehouse':'lh-prod-901'}}
def validate(stage, notebook_lakehouse_id):
    expected=bindings[stage]['lakehouse']
    if notebook_lakehouse_id!=expected: raise ValueError(f'wrong binding: expected {expected}')
    return True
if __name__=='__main__':
    assert validate('PROD','lh-prod-901')
    try: validate('PROD','lh-dev-001')
    except ValueError as e: print('caught expected binding failure:',e)
