from incremental_contract import validate_candidate

state={'committed':'2026-09-13T00:00:00Z'}

def run(candidate, validation_ok=True, durable_rows=True):
    before=state['committed']
    if not validation_ok or not durable_rows:
        return {'before':before,'after':state['committed'],'status':'NOT_COMMITTED'}
    candidate = validate_candidate(before, candidate, [])
    state['committed']=candidate
    return {'before':before,'after':state['committed'],'status':'COMMITTED'}

if __name__=='__main__':
    print(run('2026-09-14T00:00:00Z', True, True))
    safe=state['committed']
    print(run('2026-09-15T00:00:00Z', False, True)); assert state['committed']==safe
    print(run('2026-09-15T00:00:00Z', True, False)); assert state['committed']==safe
    try:
        run('2026-09-12T00:00:00Z', True, True)
        raise AssertionError('regression should fail')
    except ValueError as exc: assert 'checkpoint_regression' in str(exc)
    print('checkpoint ownership + monotonicity PASS')
