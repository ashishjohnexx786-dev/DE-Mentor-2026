components = [
 ('source_db','external source','orders','source identity'),
 ('workspace','Fabric control boundary','item metadata','Entra/Fabric role'),
 ('onelake','durable storage','files/tables','Entra/Fabric data access'),
 ('notebook','compute','transient session','run identity'),
 ('pipeline','orchestration','run/progress metadata','run identity'),
]
for row in components: print(' | '.join(row))
