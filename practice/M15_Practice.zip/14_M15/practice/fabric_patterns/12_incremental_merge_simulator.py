from incremental_contract import apply_versioned_changes, validate_candidate

base = {
    'O1001': {'order_id':'O1001','updated_at':'2026-09-13T08:00:00Z','customer_id':'C001','amount':'120.50','status':'PAID'},
    'O1003': {'order_id':'O1003','updated_at':'2026-09-13T10:30:00Z','customer_id':'C001','amount':'49.50','status':'NEW'},
}
changes = [
    {'order_id':'O1003','updated_at':'2026-09-14T07:00:00Z','customer_id':'C001','amount':'49.50','status':'PAID'},
    {'order_id':'O1004','updated_at':'2026-09-14T08:10:00Z','customer_id':'C003','amount':'210.00','status':'PAID'},
]

if __name__ == '__main__':
    target, outcomes = apply_versioned_changes(base, changes)
    replay, replay_outcomes = apply_versioned_changes(target, changes)
    assert replay == target
    assert all(o[1] == 'IDENTICAL_REPLAY' for o in replay_outcomes)

    # Genuine newer update wins.
    newer = [dict(target['O1004'], updated_at='2026-09-15T09:00:00Z', status='CANCELLED')]
    target2, out2 = apply_versioned_changes(target, newer)
    assert target2['O1004']['status'] == 'CANCELLED' and out2[0][1] == 'UPDATED_NEWER'

    # Stale update is ignored.
    stale = [dict(target2['O1004'], updated_at='2026-09-14T00:00:00Z', status='PAID')]
    target3, out3 = apply_versioned_changes(target2, stale)
    assert target3 == target2 and out3[0][1] == 'IGNORED_STALE'

    # Equal-version conflict is surfaced, never arbitrarily ranked.
    conflict = [dict(target2['O1004'], status='PAID')]
    try:
        apply_versioned_changes(target2, conflict)
        raise AssertionError('equal-version conflict must fail')
    except ValueError as exc:
        assert 'conflicting_equal_version' in str(exc)

    assert validate_candidate('2026-09-14T08:10:00Z','2026-09-15T09:00:00Z',newer) == '2026-09-15T09:00:00Z'
    try:
        validate_candidate('2026-09-15T09:00:00Z','2026-09-14T08:10:00Z',stale)
        raise AssertionError('watermark regression must fail')
    except ValueError as exc:
        assert 'checkpoint_regression' in str(exc)

    print('M15 timestamp/version/replay simulator PASS')
