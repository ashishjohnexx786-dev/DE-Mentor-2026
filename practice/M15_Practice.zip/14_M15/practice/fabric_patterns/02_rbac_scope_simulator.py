ROLE = {'Viewer': {'read'}, 'Contributor': {'read','edit','run'}, 'Admin': {'read','edit','run','manage_access'}}
assignments = {('Analyst','DEV'):'Viewer', ('Engineer','DEV'):'Contributor', ('DeploymentSP','TEST'):'Contributor'}
def allowed(principal, scope, action):
    role=assignments.get((principal,scope))
    return bool(role and action in ROLE[role])
if __name__=='__main__':
    tests=[('Analyst','DEV','edit',False),('Engineer','DEV','edit',True),('DeploymentSP','TEST','run',True)]
    for p,s,a,e in tests:
        got=allowed(p,s,a); print(p,s,a,got); assert got==e
    print('RBAC simulator PASS')
