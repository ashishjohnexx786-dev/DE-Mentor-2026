from __future__ import annotations
import csv
import json
import os
import tempfile
from decimal import Decimal
from pathlib import Path
from incremental_contract import apply_versioned_changes, validate_candidate

BASE=Path(__file__).resolve().parents[1]
DATA=BASE/'data'
OUT=BASE/'output'; OUT.mkdir(exist_ok=True)
STATE=OUT/'watermark.json'
SILVER=OUT/'silver.json'
GOLD=OUT/'gold_summary.json'


def read_csv(name):
    with open(DATA/name,newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))


def load_state():
    return json.loads(STATE.read_text()) if STATE.exists() else {'committed':'2026-09-13T00:00:00Z'}


def atomic_json(path: Path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as h:
            json.dump(obj,h,indent=2,sort_keys=True,allow_nan=False); h.flush(); os.fsync(h.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except FileNotFoundError: pass
        raise


def load_target():
    if SILVER.exists(): return json.loads(SILVER.read_text())
    return {r['order_id']:r for r in read_csv('orders_initial.csv')}


def gold_summary(target):
    paid = sum(Decimal(str(r['amount'])) for r in target.values() if r['status']=='PAID')
    return {'paid_revenue':float(paid.quantize(Decimal('0.01'))),'unique_orders':len(target)}


def run(changes_file, candidate=None, fail_validation=False, fail_after_silver=False):
    st=load_state(); before=st['committed']; changes=read_csv(changes_file)
    candidate = validate_candidate(before, candidate, changes)
    if fail_validation:
        return {'before':before,'after':st['committed'],'status':'FAILED_VALIDATION'}

    current=load_target()
    merged,outcomes=apply_versioned_changes(current,changes)
    summary=gold_summary(merged)

    # Durable business output first, checkpoint last. A crash after SILVER is safe to replay.
    atomic_json(SILVER,merged)
    if fail_after_silver:
        raise RuntimeError('SIMULATED_CRASH_AFTER_SILVER_BEFORE_GOLD_AND_CHECKPOINT')
    atomic_json(GOLD,summary)
    atomic_json(STATE,{'committed':candidate})
    return {
        'before':before,'after':candidate,'status':'PASS',
        'unique_orders':summary['unique_orders'],'paid_revenue':summary['paid_revenue'],
        'outcomes':outcomes,
    }


if __name__=='__main__':
    # Each demonstration owns a new directory; earlier learner evidence is retained.
    import uuid
    OUT = BASE / 'output' / ('demo-' + uuid.uuid4().hex[:12])
    OUT.mkdir(parents=True, exist_ok=False)
    STATE, SILVER, GOLD = (OUT / n for n in ('watermark.json', 'silver.json', 'gold_summary.json'))
    print('Evidence directory:', OUT)

    # 1. First incremental load -> five orders, paid revenue 460.00.
    a=run('orders_changes.csv','2026-09-14T08:10:00Z'); print('first',a)
    assert a['unique_orders']==5 and a['paid_revenue']==460.0

    # 2. Identical replay -> no business change and no progress regression.
    b=run('orders_changes.csv','2026-09-14T08:10:00Z'); print('identical replay',b)
    assert b['unique_orders']==5 and b['paid_revenue']==460.0 and b['after']=='2026-09-14T08:10:00Z'

    # 3. Replaying older initial rows is stale and must NOT reduce revenue or move progress backward.
    c=run('orders_initial.csv','2026-09-14T08:10:00Z'); print('stale replay',c)
    assert c['paid_revenue']==460.0 and c['after']=='2026-09-14T08:10:00Z'
    assert any(o[1]=='IGNORED_STALE' for o in c['outcomes'])

    # 4. Newer update wins and advances progress.
    d=run('orders_newer.csv','2026-09-15T09:00:00Z'); print('newer',d)
    assert d['paid_revenue']==525.0 and d['after']=='2026-09-15T09:00:00Z'

    # 5. Equal-version conflicting business content is rejected and progress remains safe.
    safe=load_state()['committed']; before_silver=SILVER.read_text(); before_gold=GOLD.read_text()
    try:
        run('orders_conflict.csv','2026-09-15T09:00:00Z')
        raise AssertionError('conflict should fail')
    except ValueError as exc:
        assert 'conflicting_equal_version' in str(exc)
    assert load_state()['committed']==safe and SILVER.read_text()==before_silver and GOLD.read_text()==before_gold

    # 6. Validation failure does not write business state/checkpoint.
    safe=load_state()['committed']; e=run('orders_newer.csv','2026-09-16T00:00:00Z',fail_validation=True); print('validation',e)
    assert load_state()['committed']==safe

    # 7. Interrupted write after SILVER: checkpoint stays old; rerun repairs GOLD and then advances safely.
    # Use a genuinely newer change for the interrupted case.
    try:
        run('orders_interrupt.csv','2026-09-16T10:00:00Z',fail_after_silver=True)
        raise AssertionError('simulated crash expected')
    except RuntimeError as exc:
        assert 'SIMULATED_CRASH' in str(exc)
    assert load_state()['committed']==safe
    repaired=run('orders_interrupt.csv','2026-09-16T10:00:00Z'); print('recovered',repaired)
    assert repaired['after']=='2026-09-16T10:00:00Z'

    # Explicit regression request is rejected rather than silently moving watermark backward.
    try:
        run('orders_initial.csv','2026-09-14T00:00:00Z')
        raise AssertionError('regression should fail')
    except ValueError as exc: assert 'checkpoint_regression' in str(exc)

    print('M15 end-to-end version/replay/checkpoint control PASS')
