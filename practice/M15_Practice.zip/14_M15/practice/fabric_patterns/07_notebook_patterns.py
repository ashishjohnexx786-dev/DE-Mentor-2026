from dataclasses import dataclass
@dataclass
class RunConfig:
    run_date: str
    target_layer: str

def validate_config(c):
    if c.target_layer not in {'bronze','silver','gold'}: raise ValueError('invalid target layer')
    return c

def transform(rows):
    return [dict(r, amount=float(r['amount'])) for r in rows]
if __name__=='__main__':
    print(validate_config(RunConfig('2026-09-14','silver')))
