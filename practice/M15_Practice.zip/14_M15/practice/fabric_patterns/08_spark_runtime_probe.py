def fabric_probe_instructions():
    return ['record Fabric Runtime shown in workspace/environment','print(spark.version)','print Python version','record attached environment','run one tiny DataFrame action']
if __name__=='__main__':
    for x in fabric_probe_instructions(): print('-',x)
