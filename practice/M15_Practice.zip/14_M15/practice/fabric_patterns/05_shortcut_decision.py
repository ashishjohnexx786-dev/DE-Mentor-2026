def decide(copy_required=False, independent_retention=False, source_sla_acceptable=True, source_format_delta=True):
    if copy_required or independent_retention or not source_sla_acceptable:
        return 'COPY', 'independent durability/retention/SLA requires a materialized copy'
    return 'SHORTCUT', 'reuse source without duplication; document source ownership and permissions'
if __name__=='__main__':
    print(decide()); print(decide(independent_retention=True))
