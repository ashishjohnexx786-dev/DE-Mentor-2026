deps={'bronze_orders':['source_orders'],'silver_orders':['bronze_orders'],'gold_daily_sales':['silver_orders']}
def assert_layers():
    assert 'source_orders' not in deps['gold_daily_sales']
    assert deps['silver_orders']==['bronze_orders']
    print('medallion dependency PASS')
if __name__=='__main__': assert_layers()
