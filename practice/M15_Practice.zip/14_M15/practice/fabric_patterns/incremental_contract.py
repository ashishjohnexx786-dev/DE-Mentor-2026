from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

KEY = 'order_id'
VERSION = 'updated_at'


def parse_utc_z(value: str) -> datetime:
    if not isinstance(value, str) or not value.endswith('Z'):
        raise ValueError(f'invalid_utc_timestamp:{value!r}')
    try:
        dt = datetime.fromisoformat(value[:-1] + '+00:00')
    except Exception as exc:
        raise ValueError(f'invalid_utc_timestamp:{value!r}') from exc
    if dt.tzinfo is None or dt.utcoffset() != timezone.utc.utcoffset(dt):
        raise ValueError(f'invalid_utc_timestamp:{value!r}')
    return dt


def validate_record(record: dict) -> dict:
    for field in ('order_id','updated_at','customer_id','amount','status'):
        if record.get(field) in (None, ''):
            raise ValueError(f'missing_{field}')
    parse_utc_z(record['updated_at'])
    try:
        amount = Decimal(str(record['amount']))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError('amount_not_numeric') from exc
    if not amount.is_finite() or amount < 0:
        raise ValueError('amount_invalid')
    if record['status'] not in {'NEW','PAID','CANCELLED'}:
        raise ValueError(f"unsupported_status:{record['status']}")
    return dict(record)


def _content_without_version(record: dict):
    return {k: v for k, v in record.items() if k != VERSION}


def apply_versioned_changes(target: dict[str, dict], changes: list[dict]):
    """Apply deterministic event-time precedence.

    newer timestamp -> update/insert
    older timestamp -> ignore as stale
    equal timestamp + identical business content -> safe replay/no-op
    equal timestamp + conflicting content -> raise; caller must not advance progress
    """
    working = {k: dict(v) for k, v in target.items()}
    outcomes = []
    for incoming0 in changes:
        incoming = validate_record(incoming0)
        key = incoming[KEY]
        old = working.get(key)
        if old is None:
            working[key] = incoming
            outcomes.append((key, 'INSERTED'))
            continue
        old_ts = parse_utc_z(old[VERSION])
        new_ts = parse_utc_z(incoming[VERSION])
        if new_ts > old_ts:
            working[key] = incoming
            outcomes.append((key, 'UPDATED_NEWER'))
        elif new_ts < old_ts:
            outcomes.append((key, 'IGNORED_STALE'))
        elif _content_without_version(incoming) == _content_without_version(old):
            outcomes.append((key, 'IDENTICAL_REPLAY'))
        else:
            raise ValueError(f'conflicting_equal_version:{key}:{incoming[VERSION]}')
    return working, outcomes


def max_version(records: list[dict]):
    if not records:
        return None
    return max(records, key=lambda r: parse_utc_z(r[VERSION]))[VERSION]


def validate_candidate(before: str, candidate: str | None, changes: list[dict]) -> str:
    """Checkpoint candidate cannot regress and cannot trail the rows just processed."""
    before_dt = parse_utc_z(before)
    row_max = max_version(changes)
    if candidate is None:
        candidate = row_max or before
    cand_dt = parse_utc_z(candidate)
    if cand_dt < before_dt:
        raise ValueError(f'checkpoint_regression:{candidate}<{before}')
    if row_max is not None and cand_dt < parse_utc_z(row_max):
        raise ValueError(f'checkpoint_before_processed_rows:{candidate}<{row_max}')
    return candidate
