def metrics(rows,duration,retries):
    throughput=rows/duration if duration else 0
    alert='WARN' if retries>1 or throughput<100 else 'OK'
    return {'rows':rows,'duration_seconds':duration,'throughput_rows_s':round(throughput,2),'retries':retries,'alert':alert}
if __name__=='__main__': print(metrics(180000,900,0)); print(metrics(180000,3600,2))
