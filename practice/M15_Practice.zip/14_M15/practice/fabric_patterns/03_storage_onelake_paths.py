def onelake_abfss(workspace,item,path):
    assert path.startswith(('Files/','Tables/'))
    return f'abfss://{workspace}@onelake.dfs.fabric.microsoft.com/{item}.lakehouse/{path}'
if __name__=='__main__':
    x=onelake_abfss('de_dev','ops_lh','Files/bronze/orders/')
    print(x); assert '/ops_lh.lakehouse/Files/' in x
