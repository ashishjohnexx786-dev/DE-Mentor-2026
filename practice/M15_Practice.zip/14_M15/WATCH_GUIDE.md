# M15 · Video assignments

Read scope before watching. Reuse is optional unless a lesson specifically asks for a changed observation. No generated videos.


## DE15-01 — Cloud fundamentals for data engineers

- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 02:19:27-02:39:20 - architectural decision-making
- [Vijay Perepa - Microsoft Fabric Data Engineering Explained: Lakehouse, Spark and OneLake Architecture](https://www.youtube.com/watch?v=vWdUjrxOYC4) — Optional visual - no verified bounded range

## DE15-02 — Identity, IAM and least privilege

- [CodeLucky - Azure RBAC Explained: Role-Based Access Control Tutorial for Beginners](https://www.youtube.com/watch?v=c5u_AzSCsco) — 00:26-04:18 - RBAC core components through best practices
- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 01:22:30-01:50:53 - security and governance

## DE15-03 — Azure Storage concepts and OneLake

- [Vijay Perepa - Microsoft Fabric Data Engineering Explained: Lakehouse, Spark and OneLake Architecture](https://www.youtube.com/watch?v=vWdUjrxOYC4) — Optional visual - no verified bounded range
- [endjin - Microsoft Fabric: Lakehouse & Medallion Architecture - Part 1](https://www.youtube.com/watch?v=x_CvCwSbRZI) — 02:10-04:43 - Fabric lakehouse and OneLake table/file structure

## DE15-04 — Fabric workspace and item model

- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 00:18:18-00:48:26 - admin settings and workspace governance
- [Vijay Perepa - Microsoft Fabric Data Engineering Explained: Lakehouse, Spark and OneLake Architecture](https://www.youtube.com/watch?v=vWdUjrxOYC4) — Optional visual - no verified bounded range

## DE15-05 — OneLake paths, files, tables and shortcuts

- [Centida Consulting - Microsoft Fabric: OneLake Shortcuts](https://www.youtube.com/watch?v=yvf-7gcVfr8) — 02:29-03:17 - shortcut concept and hands-on creation
- [endjin - Microsoft Fabric: Lakehouse & Medallion Architecture - Part 1](https://www.youtube.com/watch?v=x_CvCwSbRZI) — 04:43-05:19 - table/file structure context before medallion

## DE15-06 — Fabric Lakehouse and Delta tables

- [endjin - Microsoft Fabric: Lakehouse & Medallion Architecture - Part 1](https://www.youtube.com/watch?v=x_CvCwSbRZI) — 00:22-04:43 - lakehouse concept, Fabric lakehouse, files/tables
- [Vijay Perepa - Microsoft Fabric Data Engineering Explained: Lakehouse, Spark and OneLake Architecture](https://www.youtube.com/watch?v=vWdUjrxOYC4) — Optional visual - no verified bounded range

## DE15-07 — Fabric notebooks

- [Aleksi Partanen - Learn Microsoft Fabric Notebooks in 2026 - Full Course!](https://www.youtube.com/watch?v=qoVhkiU_XGc) — 04:31-25:03 - notebook overview; 25:03-41:38 - NotebookUtils
- [endjin - Microsoft Fabric: Good Notebook Development Practices](https://www.youtube.com/watch?v=UyS6ZUgh-Wc) — 00:12-13:05 - notebook structure, modularization and schemas as code

## DE15-08 — Spark in Fabric

- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 03:12:43-03:30:05 - hands-on PySpark
- [Aleksi Partanen - Learn Microsoft Fabric Notebooks in 2026 - Full Course!](https://www.youtube.com/watch?v=qoVhkiU_XGc) — 54:23-01:00:37 - Spark SQL in Fabric notebooks

## DE15-09 — Fabric Data Pipelines

- [Aleksi Partanen - Learn Microsoft Fabric Data Pipelines in 2026 - Full Course!](https://www.youtube.com/watch?v=1PGE9bWqY2g) — 04:49-27:35 - pipeline overview and Copy Data activity
- [Amit Chandak - Microsoft Fabric: Load data in Lakehouse using Data Pipeline | End to End](https://www.youtube.com/watch?v=jn_D2-b5YpY) — 02:00-12:30 - loading lakehouse data with a pipeline and schema/type handling

## DE15-10 — SQL analytics endpoint and warehouse choice

- [TechBrothersIT - Understanding SQL Analytics Endpoint in Microsoft Fabric](https://www.youtube.com/watch?v=Z1WVZ-COoFQ) — Optional visual - no verified bounded range
- [Amit Chandak - Microsoft Fabric: Load data in Lakehouse using Data Pipeline | End to End](https://www.youtube.com/watch?v=jn_D2-b5YpY) — 12:30-18:30 - analyze lakehouse data and downstream reporting context

## DE15-11 — Medallion architecture in Fabric

- [Microsoft Power BI - Learn Together: Organize a Fabric lakehouse using medallion architecture design](https://www.youtube.com/watch?v=gqTWFBzgAlg) — 09:55-42:55 - medallion principles, formats, movement and Fabric implementation
- [endjin - Microsoft Fabric: Lakehouse & Medallion Architecture - Part 1](https://www.youtube.com/watch?v=x_CvCwSbRZI) — 05:19-09:50 - medallion rationale through replayability/idempotency

## DE15-12 — Incremental loads and MERGE in cloud

- [Aleksi Partanen - Learn Microsoft Fabric Data Pipelines in 2026 - Full Course!](https://www.youtube.com/watch?v=1PGE9bWqY2g) — 01:22:35-01:32:40 - Lookup activity; 02:33:15-02:43:55 - stored procedures in pipelines
- [Aleksi Partanen - Learn Microsoft Fabric Notebooks in 2026 - Full Course!](https://www.youtube.com/watch?v=qoVhkiU_XGc) — 02:31:55-02:45:14 - metadata-driven notebooks before schema-drift lesson

## DE15-13 — Permissions, connections and secrets

- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 01:22:30-01:50:53 - security and governance
- [Aleksi Partanen - Learn Microsoft Fabric Notebooks in 2026 - Full Course!](https://www.youtube.com/watch?v=qoVhkiU_XGc) — 25:03-41:38 - NotebookUtils and platform utilities

## DE15-14 — Monitoring, reliability and cost awareness

- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 04:46:53-05:43:50 - monitoring/optimization of processing tools and data stores
- [Aleksi Partanen - Learn Microsoft Fabric Data Pipelines in 2026 - Full Course!](https://www.youtube.com/watch?v=1PGE9bWqY2g) — 01:40:09-01:48:17 - scheduling and monitoring pipelines

## DE15-15 — Git, deployment and environment separation

- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — 00:48:26-01:22:30 - CI/CD and lifecycle management
- [TECHIES STUDY - Fabric Git integration Process and Deployment pipelines](https://www.youtube.com/watch?v=jKqdymKf1vM) — Optional visual - no verified bounded range

## DE15-16 — End-to-end Fabric data engineering case

- [Amit Chandak - Microsoft Fabric: Load data in Lakehouse using Data Pipeline | End to End](https://www.youtube.com/watch?v=jn_D2-b5YpY) — 00:00-18:30 - end-to-end lakehouse + pipeline + analysis walkthrough
- [Vijay Perepa - Microsoft Fabric Data Engineering Explained: Lakehouse, Spark and OneLake Architecture](https://www.youtube.com/watch?v=vWdUjrxOYC4) — Optional visual - no verified bounded range
- [Learn Microsoft Fabric with Will - DP-700 Exam Full Course](https://www.youtube.com/watch?v=KiB4eAeFRsw) — Optional visual - no verified bounded range for the full course; use selected chapters from prior lessons