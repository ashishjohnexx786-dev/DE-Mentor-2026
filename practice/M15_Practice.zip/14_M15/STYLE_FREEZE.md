# Visual style freeze
- Navy #173047: title/main identity
- Blue #2563EB: all normal lesson-section headings
- Teal #087F8C: structural accents, rules, callout borders and table accents only
- Video links stay visible in learner-facing lessons. No useful video is removed only because a bounded timestamp is unavailable.
