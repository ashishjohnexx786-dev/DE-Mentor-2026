# M15 - Azure + Microsoft Fabric Data Engineering

Study the Learner Book lesson-by-lesson. Video links are intentionally visible inside each lesson. Complete the matching practice and save evidence before opening Explained Reviews. Use Quick Revision later, then take the closed-book Module Revision Test and only afterward open the protected answers.

Live Fabric execution is learner-PC proof. The package never claims a cloud run that was not actually executed.
