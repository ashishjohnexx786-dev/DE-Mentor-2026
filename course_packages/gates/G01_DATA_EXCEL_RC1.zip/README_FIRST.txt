ZERO TO JOB-READY DATA ENGINEER 2026
G01 - Data + Excel
Protected Gate RC1

Gate A is the first unseen attempt. Save evidence before opening its review. Gate B is a different fresh domain and is opened only after remediation routing.
