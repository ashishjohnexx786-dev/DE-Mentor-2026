CREATE TABLE assets(site_id TEXT PRIMARY KEY, site_name TEXT, capacity_mw REAL);
INSERT INTO assets VALUES ('SITE1','Sunrise',20),('SITE2','Horizon',18),('SITE3','Valley',15);
