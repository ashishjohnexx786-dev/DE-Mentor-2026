# TODO PySpark/Delta or Parquet path only where scale justifies it.
