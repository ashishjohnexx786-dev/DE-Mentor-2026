# TODO pure-Python local quality/reconciliation control; write result_summary.json.
raise SystemExit('TODO')
