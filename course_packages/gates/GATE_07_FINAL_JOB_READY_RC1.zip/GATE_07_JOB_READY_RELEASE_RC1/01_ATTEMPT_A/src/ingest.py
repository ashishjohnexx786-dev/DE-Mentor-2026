# TODO CSV + paginated API + database ingestion; preserve raw, batch metadata and idempotency.
