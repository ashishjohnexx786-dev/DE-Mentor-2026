CREATE TABLE depots(depot_id TEXT PRIMARY KEY, depot_name TEXT, region TEXT);
INSERT INTO depots VALUES ('D1','East Depot','EAST'),('D2','West Depot','WEST'),('D3','North Depot','NORTH');
