Gate 7 - Final Job-Ready Practical | Conditional RC1

Attempt A first. Preserve the first checker output. Open Review A only after the attempt is saved, repair weak competencies, then take fresh-domain B. Open Review B only after B is saved.
Internal known-good solutions are not included.
Gate 7 becomes technically FINAL only after the offline evidence and the required live PostgreSQL/dbt/Docker/Airflow/Spark/Delta/Kafka/Fabric runtime checks are both satisfied.
