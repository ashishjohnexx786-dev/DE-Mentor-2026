import json,sys
p=sys.argv[1]
d=json.load(open(p,encoding='utf-8'))
need=[
('requirements_summary',d.get('requirements_summary')),
('architecture.ingestion',d.get('architecture',{}).get('ingestion')),
('architecture.storage_serving',d.get('architecture',{}).get('storage_serving')),
('architecture.identity_security',d.get('architecture',{}).get('identity_security')),
('data_quality.blocking_checks>=2',len(d.get('data_quality',{}).get('blocking_checks',[]))>=2),
('data_quality.reconciliation',d.get('data_quality',{}).get('reconciliation')),
('ci_cd.tests>=2',len(d.get('ci_cd',{}).get('tests',[]))>=2),
('ci_cd.environment_promotion',d.get('ci_cd',{}).get('environment_promotion')),
('ci_cd.rollback',d.get('ci_cd',{}).get('rollback')),
('security.pii_handling',d.get('security',{}).get('pii_handling')),
('security.secret_handling',d.get('security',{}).get('secret_handling')),
('security.rbac',d.get('security',{}).get('rbac')),
('observability.freshness_sla',d.get('observability',{}).get('freshness_sla')),
('observability.signals>=2',len(d.get('observability',{}).get('signals',[]))>=2),
('incident_response.recover',d.get('incident_response',{}).get('recover')),
('incident_response.validate',d.get('incident_response',{}).get('validate')),
('iac.state_or_change_safety',d.get('iac',{}).get('state_or_change_safety')),
('architecture_defense.decisions>=3',len(d.get('architecture_defense',{}).get('decisions',[]))>=3),
('architecture_defense.rejected_alternatives>=2',len(d.get('architecture_defense',{}).get('rejected_alternatives',[]))>=2),
('architecture_defense.tradeoffs>=2',len(d.get('architecture_defense',{}).get('tradeoffs',[]))>=2),
('evidence.runtime_truth',d.get('evidence',{}).get('runtime_truth'))]
missing=[k for k,v in need if not v]
print(json.dumps({'status':'EVIDENCE_COMPLETE_FOR_HUMAN_GATE_REVIEW' if not missing else 'INCOMPLETE','missing':missing,'note':'Structure only; this does not decide technical correctness or Gate pass.'},indent=2))
sys.exit(0 if not missing else 2)
