-- G02 Gate protected PostgreSQL source - Logistics Shipments + Incidents
-- Creates only schema g02a. The learner performs transaction/index/view tasks after setup.
DROP SCHEMA IF EXISTS g02a CASCADE;
CREATE SCHEMA g02a;

CREATE TABLE g02a.carriers (
  carrier_id text PRIMARY KEY, entity_name text NOT NULL
);

CREATE TABLE g02a.settlements (
  settlement_id text PRIMARY KEY, carrier_id text NOT NULL REFERENCES g02a.carriers(carrier_id),
  state text NOT NULL CHECK (state IN ('Posted','Pending','Voided')),
  amount numeric(12,2) NOT NULL CHECK (amount >= 0)
);

INSERT INTO g02a.carriers VALUES
('CR1','Carrier North'),
('CR2','Carrier South'),
('CR3','Carrier Central');

INSERT INTO g02a.settlements VALUES
('ST1','CR1','Posted',1200),
('ST2','CR2','Posted',900),
('ST3','CR1','Pending',700),
('ST4','CR3','Posted',1500),
('ST5','CR2','Posted',1100),
('ST6','CR3','Voided',500),
('ST7','CR1','Posted',1300),
('ST8','CR2','Posted',800);

SELECT COUNT(*) AS entity_rows FROM g02a.carriers;
SELECT COUNT(*) AS transaction_rows FROM g02a.settlements;
-- Gate instructions define the ROLLBACK, EXPLAIN/index and normal-view proofs.
