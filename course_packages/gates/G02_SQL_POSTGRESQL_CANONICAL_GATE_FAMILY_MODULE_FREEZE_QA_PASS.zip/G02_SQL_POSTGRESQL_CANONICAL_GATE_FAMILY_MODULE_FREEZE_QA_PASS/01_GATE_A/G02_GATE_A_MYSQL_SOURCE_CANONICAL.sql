-- G02 Gate protected MySQL source - Logistics Shipments + Incidents
-- Assessment fixture only. Do not inspect a protected Review before saving the matching attempt.
DROP DATABASE IF EXISTS g02a_logistics;
CREATE DATABASE g02a_logistics;
USE g02a_logistics;

CREATE TABLE customers (
  customer_id varchar(12) PRIMARY KEY, entity_name varchar(60) NOT NULL, region varchar(20) NOT NULL, entity_type varchar(30) NOT NULL
);

CREATE TABLE shipments (
  shipment_id varchar(12) PRIMARY KEY, customer_id varchar(12) NOT NULL, ship_date date NOT NULL,
  service_raw varchar(40) NOT NULL, status varchar(20) NOT NULL, qty int NOT NULL,
  unit_price decimal(12,2) NOT NULL, discount_rate decimal(6,4) NOT NULL DEFAULT 0, dispatcher varchar(40) NULL,
  CONSTRAINT fk_shipments_entity FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE shipment_events (
  event_id varchar(12) PRIMARY KEY, shipment_id varchar(12) NOT NULL, event_ts datetime NOT NULL, event_type varchar(40) NOT NULL,
  CONSTRAINT fk_shipment_events_fact FOREIGN KEY (shipment_id) REFERENCES shipments(shipment_id)
);

CREATE TABLE shipment_returns (
  return_id varchar(12) PRIMARY KEY, shipment_id varchar(12) NOT NULL, reason varchar(60) NOT NULL,
  CONSTRAINT fk_shipment_returns_fact FOREIGN KEY (shipment_id) REFERENCES shipments(shipment_id)
);

INSERT INTO customers VALUES
('LC01','Arka Retail','East','Gold'),
('LC02','Bharat Mart','West','Silver'),
('LC03','Cedar Store','North','Bronze'),
('LC04','Delta Foods','South','Gold'),
('LC05','Ember Shop','East','Silver'),
('LC06','Falcon Care','North','Gold');

INSERT INTO shipments VALUES
('S101','LC01','2026-08-01',' Express ','Delivered',2,600,0.05,'Maya'),
('S102','LC02','2026-08-01','Standard','Delivered',3,350,0,NULL),
('S103','LC03','2026-08-02','express','InTransit',1,1200,0,'Raj'),
('S104','LC04','2026-08-02','Cold Chain','Delivered',4,300,0.1,'Neha'),
('S105','LC05','2026-08-03','EXPRESS','Delivered',5,420,0.05,'Maya'),
('S106','LC02','2026-08-03','Standard ','Returned',2,500,0,NULL),
('S107','LC06','2026-08-04','cold chain','Delivered',3,550,0.1,'Raj'),
('S108','LC04','2026-08-04','Express','Delivered',2,800,0,'Neha'),
('S109','LC01','2026-08-05','Standard','Returned',1,700,0,'Maya'),
('S110','LC02','2026-08-05','Cold Chain','Delivered',6,400,0.05,NULL),
('S111','LC03','2026-08-06','Express ','Delivered',2,450,0,'Raj'),
('S112','LC04','2026-08-06','Standard','Delivered',4,250,0.1,'Neha'),
('S113','LC05','2026-08-07','express','Delivered',1,2100,0.05,'Maya'),
('S114','LC06','2026-08-07','Cold Chain','Cancelled',2,600,0,'Raj');

INSERT INTO shipment_events VALUES
('E01','S101','2026-08-01 09:00','Picked'),
('E02','S101','2026-08-01 16:00','Delivered'),
('E03','S102','2026-08-01 17:00','Delivered'),
('E04','S103','2026-08-02 10:00','Picked'),
('E05','S104','2026-08-02 18:00','Delivered'),
('E06','S105','2026-08-03 08:00','Picked'),
('E07','S105','2026-08-03 15:00','Delivered'),
('E08','S106','2026-08-03 13:00','Returned'),
('E09','S107','2026-08-04 16:00','Delivered'),
('E10','S108','2026-08-04 10:00','Picked'),
('E11','S108','2026-08-04 18:00','Delivered'),
('E12','S109','2026-08-05 12:00','Returned'),
('E13','S110','2026-08-05 09:00','Picked'),
('E14','S110','2026-08-05 13:00','OutForDelivery'),
('E15','S110','2026-08-05 19:00','Delivered'),
('E16','S111','2026-08-06 17:00','Delivered'),
('E17','S113','2026-08-07 09:00','Picked'),
('E18','S113','2026-08-07 20:00','Delivered');

INSERT INTO shipment_returns VALUES
('R01','S106','Damaged'),
('R02','S109','Customer return');

SELECT COUNT(*) AS entity_rows FROM customers;
SELECT COUNT(*) AS fact_rows FROM shipments;
SELECT COUNT(*) AS event_rows FROM shipment_events;
SELECT COUNT(*) AS exception_rows FROM shipment_returns;
