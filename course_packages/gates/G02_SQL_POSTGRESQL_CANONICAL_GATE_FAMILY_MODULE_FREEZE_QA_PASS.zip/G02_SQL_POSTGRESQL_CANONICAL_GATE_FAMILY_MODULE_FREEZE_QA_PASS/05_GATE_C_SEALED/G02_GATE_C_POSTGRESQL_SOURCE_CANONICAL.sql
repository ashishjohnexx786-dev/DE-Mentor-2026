-- G02 Gate protected PostgreSQL source - Subscription Billing + Support Activity
-- Creates only schema g02c. The learner performs transaction/index/view tasks after setup.
DROP SCHEMA IF EXISTS g02c CASCADE;
CREATE SCHEMA g02c;

CREATE TABLE g02c.billing_accounts (
  billing_account_id text PRIMARY KEY, entity_name text NOT NULL
);

CREATE TABLE g02c.charges (
  charge_id text PRIMARY KEY, billing_account_id text NOT NULL REFERENCES g02c.billing_accounts(billing_account_id),
  state text NOT NULL CHECK (state IN ('Settled','Pending','Voided')),
  amount numeric(12,2) NOT NULL CHECK (amount >= 0)
);

INSERT INTO g02c.billing_accounts VALUES
('BA1','Billing A'),
('BA2','Billing B'),
('BA3','Billing C');

INSERT INTO g02c.charges VALUES
('CH1','BA1','Settled',1600),
('CH2','BA2','Settled',2300),
('CH3','BA3','Pending',1200),
('CH4','BA1','Settled',1900),
('CH5','BA2','Settled',1400),
('CH6','BA3','Voided',700),
('CH7','BA1','Settled',1800),
('CH8','BA2','Settled',1250);

SELECT COUNT(*) AS entity_rows FROM g02c.billing_accounts;
SELECT COUNT(*) AS transaction_rows FROM g02c.charges;
-- Gate instructions define the ROLLBACK, EXPLAIN/index and normal-view proofs.
