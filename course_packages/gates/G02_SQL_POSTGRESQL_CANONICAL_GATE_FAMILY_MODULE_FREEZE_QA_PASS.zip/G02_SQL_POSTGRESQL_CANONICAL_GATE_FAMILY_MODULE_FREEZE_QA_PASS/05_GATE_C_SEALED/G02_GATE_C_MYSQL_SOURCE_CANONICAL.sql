-- G02 Gate protected MySQL source - Subscription Billing + Support Activity
-- Assessment fixture only. Do not inspect a protected Review before saving the matching attempt.
DROP DATABASE IF EXISTS g02c_subscription;
CREATE DATABASE g02c_subscription;
USE g02c_subscription;

CREATE TABLE accounts (
  account_id varchar(12) PRIMARY KEY, entity_name varchar(60) NOT NULL, market varchar(20) NOT NULL, entity_type varchar(30) NOT NULL
);

CREATE TABLE invoices (
  invoice_id varchar(12) PRIMARY KEY, account_id varchar(12) NOT NULL, invoice_date date NOT NULL,
  plan_raw varchar(40) NOT NULL, state varchar(20) NOT NULL, seats int NOT NULL,
  unit_fee decimal(12,2) NOT NULL, discount_rate decimal(6,4) NOT NULL DEFAULT 0, account_manager varchar(40) NULL,
  CONSTRAINT fk_invoices_entity FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

CREATE TABLE support_events (
  ticket_event_id varchar(12) PRIMARY KEY, invoice_id varchar(12) NOT NULL, event_ts datetime NOT NULL, event_type varchar(40) NOT NULL,
  CONSTRAINT fk_support_events_fact FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id)
);

CREATE TABLE refunds (
  refund_id varchar(12) PRIMARY KEY, invoice_id varchar(12) NOT NULL, reason varchar(60) NOT NULL,
  CONSTRAINT fk_refunds_fact FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id)
);

INSERT INTO accounts VALUES
('AC01','Aqua Labs','East','Growth'),
('AC02','Bright Ops','West','Core'),
('AC03','Cloud Nine','North','Core'),
('AC04','Digi Works','South','Growth'),
('AC05','Evergreen','East','Scale'),
('AC06','Flux Tech','North','Scale');

INSERT INTO invoices VALUES
('I301','AC01','2026-08-20',' Core ','Paid',10,150,0.05,'Aarav'),
('I302','AC02','2026-08-20','Plus','Paid',8,220,0,NULL),
('I303','AC03','2026-08-21','core','Review',12,140,0,'Diya'),
('I304','AC04','2026-08-21','Pro','Paid',6,320,0.1,'Kunal'),
('I305','AC05','2026-08-22','PLUS','Paid',9,210,0.05,'Aarav'),
('I306','AC02','2026-08-22','Core ','Refunded',5,160,0,NULL),
('I307','AC06','2026-08-23','pro','Paid',7,300,0.1,'Diya'),
('I308','AC04','2026-08-23','Core','Paid',11,150,0,'Kunal'),
('I309','AC01','2026-08-24','Plus','Refunded',4,230,0,'Aarav'),
('I310','AC02','2026-08-24','Pro','Paid',5,340,0.05,NULL),
('I311','AC03','2026-08-25','Core ','Paid',10,155,0,'Diya'),
('I312','AC04','2026-08-25','Plus','Paid',8,225,0,'Kunal'),
('I313','AC05','2026-08-26','plus','Paid',10,180,0,'Aarav'),
('I314','AC06','2026-08-26','Pro','Void',3,350,0,'Diya');

INSERT INTO support_events VALUES
('T01','I301','2026-08-20 09:00','InvoiceSent'),
('T02','I301','2026-08-20 16:00','TicketClosed'),
('T03','I302','2026-08-20 17:00','InvoiceSent'),
('T04','I303','2026-08-21 10:00','TicketOpen'),
('T05','I304','2026-08-21 18:00','InvoiceSent'),
('T06','I305','2026-08-22 08:00','InvoiceSent'),
('T07','I305','2026-08-22 15:00','TicketOpen'),
('T08','I306','2026-08-22 13:00','Refunded'),
('T09','I307','2026-08-23 16:00','InvoiceSent'),
('T10','I308','2026-08-23 10:00','InvoiceSent'),
('T11','I308','2026-08-23 18:00','TicketClosed'),
('T12','I309','2026-08-24 12:00','Refunded'),
('T13','I310','2026-08-24 09:00','InvoiceSent'),
('T14','I310','2026-08-24 13:00','TicketOpen'),
('T15','I310','2026-08-24 19:00','TicketClosed'),
('T16','I311','2026-08-25 17:00','InvoiceSent'),
('T17','I313','2026-08-26 09:00','InvoiceSent'),
('T18','I313','2026-08-26 20:00','TicketClosed');

INSERT INTO refunds VALUES
('RF01','I306','Service credit'),
('RF02','I309','Customer refund');

SELECT COUNT(*) AS entity_rows FROM accounts;
SELECT COUNT(*) AS fact_rows FROM invoices;
SELECT COUNT(*) AS event_rows FROM support_events;
SELECT COUNT(*) AS exception_rows FROM refunds;
