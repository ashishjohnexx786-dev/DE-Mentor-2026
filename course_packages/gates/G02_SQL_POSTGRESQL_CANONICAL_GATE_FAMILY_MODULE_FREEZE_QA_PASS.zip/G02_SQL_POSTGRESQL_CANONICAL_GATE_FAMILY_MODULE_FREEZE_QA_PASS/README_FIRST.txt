G02 SQL + PostgreSQL - CANONICAL GATE FAMILY MODULE FREEZE QA CANDIDATE

This package is rebuilt from the exact M02 14-lesson and M03 16-lesson canonical registries. It does not inherit the old G02 percentage-pass rule.

ORDINARY ROUTE
1. Open 00_START_HERE.
2. Use 07_EVIDENCE_RECORD to create a fresh Gate A attempt row.
3. Open only 01_GATE_A and its two source SQL files. Keep Reviews/B/C/AI solving/Teaching Books closed.
4. Save the entire Gate A attempt before opening Review A.
5. If weak, open Review A and perform only the assigned changed targeted repair.
6. Gate B remains sealed unless a reviewer explicitly assigns a full fresh reassessment. Gate C follows the same rule after Gate B.
7. A later retest NEVER erases an earlier weak/failed attempt.

PASS RULE
No numeric percentage. K1-K7 must all be DEMONSTRATED with saved evidence and no unresolved critical defect.

RUNTIME HONESTY
Source fixtures and objective controls are statically revalidated in the artifact environment. Live MySQL/PostgreSQL server execution remains part of later course-wide runtime QA.
