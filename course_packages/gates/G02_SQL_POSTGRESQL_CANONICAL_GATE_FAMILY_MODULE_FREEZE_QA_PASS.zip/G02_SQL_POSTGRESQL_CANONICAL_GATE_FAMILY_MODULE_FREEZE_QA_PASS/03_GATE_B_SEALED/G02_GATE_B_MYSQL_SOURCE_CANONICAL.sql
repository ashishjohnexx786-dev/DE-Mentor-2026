-- G02 Gate protected MySQL source - Clinic Supply Deliveries + Quality Cases
-- Assessment fixture only. Do not inspect a protected Review before saving the matching attempt.
DROP DATABASE IF EXISTS g02b_clinic;
CREATE DATABASE g02b_clinic;
USE g02b_clinic;

CREATE TABLE clinics (
  clinic_id varchar(12) PRIMARY KEY, entity_name varchar(60) NOT NULL, zone varchar(20) NOT NULL, entity_type varchar(30) NOT NULL
);

CREATE TABLE deliveries (
  delivery_id varchar(12) PRIMARY KEY, clinic_id varchar(12) NOT NULL, delivery_date date NOT NULL,
  supply_raw varchar(40) NOT NULL, state varchar(20) NOT NULL, units int NOT NULL,
  unit_cost decimal(12,2) NOT NULL, rebate_rate decimal(6,4) NOT NULL DEFAULT 0, coordinator varchar(40) NULL,
  CONSTRAINT fk_deliveries_entity FOREIGN KEY (clinic_id) REFERENCES clinics(clinic_id)
);

CREATE TABLE quality_events (
  case_id varchar(12) PRIMARY KEY, delivery_id varchar(12) NOT NULL, case_ts datetime NOT NULL, case_type varchar(40) NOT NULL,
  CONSTRAINT fk_quality_events_fact FOREIGN KEY (delivery_id) REFERENCES deliveries(delivery_id)
);

CREATE TABLE delivery_exceptions (
  exception_id varchar(12) PRIMARY KEY, delivery_id varchar(12) NOT NULL, reason varchar(60) NOT NULL,
  CONSTRAINT fk_delivery_exceptions_fact FOREIGN KEY (delivery_id) REFERENCES deliveries(delivery_id)
);

INSERT INTO clinics VALUES
('CL01','Aster Clinic','North','Hospital'),
('CL02','Beacon Clinic','South','Clinic'),
('CL03','Cura Center','East','Clinic'),
('CL04','Daya Hospital','West','Hospital'),
('CL05','Elara Care','North','Clinic'),
('CL06','Fenix Health','South','Hospital');

INSERT INTO deliveries VALUES
('D201','CL01','2026-08-10',' Gloves ','Received',10,180,0.05,'Isha'),
('D202','CL02','2026-08-10','Masks','Received',20,80,0,NULL),
('D203','CL03','2026-08-11','gloves','OnRoute',12,170,0,'Kabir'),
('D204','CL04','2026-08-11','Cold Pack','Received',6,300,0.1,'Leena'),
('D205','CL05','2026-08-12','GLOVES','Received',15,160,0,'Isha'),
('D206','CL02','2026-08-12','Masks ','Recalled',10,90,0,NULL),
('D207','CL03','2026-08-13','cold pack','Received',8,240,0.05,'Kabir'),
('D208','CL04','2026-08-13','Gloves','Received',9,200,0,'Leena'),
('D209','CL01','2026-08-14','Masks','Recalled',5,100,0,'Isha'),
('D210','CL02','2026-08-14','Cold Pack','Received',7,260,0.05,NULL),
('D211','CL03','2026-08-15','Gloves ','Received',11,190,0,'Kabir'),
('D212','CL04','2026-08-15','Masks','Received',18,90,0,'Leena'),
('D213','CL05','2026-08-16','gloves','Received',10,240,0,'Isha'),
('D214','CL06','2026-08-16','Cold Pack','Cancelled',5,280,0,'Mona');

INSERT INTO quality_events VALUES
('Q01','D201','2026-08-10 09:00','TempChecked'),
('Q02','D201','2026-08-10 18:00','Accepted'),
('Q03','D202','2026-08-10 17:00','Accepted'),
('Q04','D203','2026-08-11 12:00','InTransit'),
('Q05','D204','2026-08-11 19:00','Accepted'),
('Q06','D205','2026-08-12 08:00','TempChecked'),
('Q07','D205','2026-08-12 16:00','Accepted'),
('Q08','D206','2026-08-12 14:00','RecallOpened'),
('Q09','D207','2026-08-13 17:00','Accepted'),
('Q10','D208','2026-08-13 10:00','TempChecked'),
('Q11','D208','2026-08-13 18:00','Accepted'),
('Q12','D209','2026-08-14 13:00','RecallOpened'),
('Q13','D210','2026-08-14 09:00','TempChecked'),
('Q14','D210','2026-08-14 20:00','Accepted'),
('Q15','D211','2026-08-15 19:00','Accepted'),
('Q16','D212','2026-08-15 11:00','TempChecked'),
('Q17','D212','2026-08-15 19:00','Accepted'),
('Q18','D213','2026-08-16 08:00','TempChecked'),
('Q19','D213','2026-08-16 18:00','Accepted');

INSERT INTO delivery_exceptions VALUES
('X01','D206','Recall'),
('X02','D209','Recall');

SELECT COUNT(*) AS entity_rows FROM clinics;
SELECT COUNT(*) AS fact_rows FROM deliveries;
SELECT COUNT(*) AS event_rows FROM quality_events;
SELECT COUNT(*) AS exception_rows FROM delivery_exceptions;
