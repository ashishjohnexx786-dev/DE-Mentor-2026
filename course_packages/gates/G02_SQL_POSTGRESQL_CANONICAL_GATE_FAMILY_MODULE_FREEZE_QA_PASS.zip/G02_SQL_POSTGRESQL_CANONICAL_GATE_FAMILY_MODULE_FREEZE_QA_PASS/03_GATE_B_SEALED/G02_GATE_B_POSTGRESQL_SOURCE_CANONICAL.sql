-- G02 Gate protected PostgreSQL source - Clinic Supply Deliveries + Quality Cases
-- Creates only schema g02b. The learner performs transaction/index/view tasks after setup.
DROP SCHEMA IF EXISTS g02b CASCADE;
CREATE SCHEMA g02b;

CREATE TABLE g02b.vendors (
  vendor_id text PRIMARY KEY, entity_name text NOT NULL
);

CREATE TABLE g02b.receipts (
  receipt_id text PRIMARY KEY, vendor_id text NOT NULL REFERENCES g02b.vendors(vendor_id),
  state text NOT NULL CHECK (state IN ('Posted','Pending','Voided')),
  amount numeric(12,2) NOT NULL CHECK (amount >= 0)
);

INSERT INTO g02b.vendors VALUES
('VN1','Vendor One'),
('VN2','Vendor Two'),
('VN3','Vendor Three');

INSERT INTO g02b.receipts VALUES
('RC1','VN1','Posted',2100),
('RC2','VN2','Posted',1700),
('RC3','VN3','Posted',2500),
('RC4','VN1','Pending',800),
('RC5','VN2','Posted',1300),
('RC6','VN3','Voided',600),
('RC7','VN1','Posted',1900),
('RC8','VN2','Posted',1200);

SELECT COUNT(*) AS entity_rows FROM g02b.vendors;
SELECT COUNT(*) AS transaction_rows FROM g02b.receipts;
-- Gate instructions define the ROLLBACK, EXPLAIN/index and normal-view proofs.
