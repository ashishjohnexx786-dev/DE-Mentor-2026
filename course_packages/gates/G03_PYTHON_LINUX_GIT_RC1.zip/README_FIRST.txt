G03 Python + Linux + Git - Protected Gate RC1
Attempt Gate A first. Open its review only after saving a genuine attempt. Gate B is a different fresh reassessment, not a second copy.
