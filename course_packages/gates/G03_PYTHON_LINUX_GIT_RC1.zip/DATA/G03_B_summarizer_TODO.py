# Gate B learner file: build independent validation + summary; do not copy Gate A.
