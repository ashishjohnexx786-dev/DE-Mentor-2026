# Gate A learner file: implement CSV contract validation, rejected reasons, summary and exit behavior.
