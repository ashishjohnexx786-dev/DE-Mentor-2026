CREATE TABLE IF NOT EXISTS gate04_trips (trip_id text PRIMARY KEY, updated_at timestamptz NOT NULL, route_id text NOT NULL, passengers int CHECK (passengers>=0), fare numeric(12,2) CHECK (fare>=0));
