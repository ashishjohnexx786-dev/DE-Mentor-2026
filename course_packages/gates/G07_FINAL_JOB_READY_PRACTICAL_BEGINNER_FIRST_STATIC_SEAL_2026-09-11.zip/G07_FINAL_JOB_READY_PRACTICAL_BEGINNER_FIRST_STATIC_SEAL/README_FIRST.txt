G07 FINAL JOB-READY PRACTICAL - BEGINNER-FIRST STATIC-CONTENT REBUILD
Prerequisite: M19 complete.
Start: 00_START_HERE/G07_START_HERE.pdf
Normal route: Gate A only. Reviews open only after saved genuine attempt. Gate B/C remain sealed until explicit reassessment assignment.
Pass: all K1-K8 technically demonstrated with evidence + human/Mentor confirmation + zero unresolved critical failures. No numeric shortcut.
Static-content seal never pre-awards a learner Gate pass and never certifies production Mentor/device/runtime behavior.
