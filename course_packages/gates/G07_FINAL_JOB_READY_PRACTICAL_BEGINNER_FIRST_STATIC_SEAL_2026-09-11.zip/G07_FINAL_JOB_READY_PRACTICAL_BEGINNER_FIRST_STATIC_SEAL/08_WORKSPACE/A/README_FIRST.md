# Gate A workspace

READY only after M19 and Gate A activation. Create `attempt-01/` only when the genuine first attempt begins.
