# G07 learner workspace

Do not pre-create a fake completed attempt.

Normal route: A only. When a genuine Gate A attempt begins, create `A/attempt-01/` and copy the A `evidence_template.json` to `A/attempt-01/evidence.json`. Keep source files read-only or copy them into your attempt workspace.

B and C remain sealed until explicit assignment. Reviews remain closed until the matching attempt is saved. Original attempts are append-only.
