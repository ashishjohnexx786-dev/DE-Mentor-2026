import csv,sys,json
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else 'serving_current.csv')
if not p.exists(): print(json.dumps({'status':'MISSING_OUTPUT','path':str(p)})); raise SystemExit(2)
rows=list(csv.DictReader(p.open(encoding='utf-8')))
fields=set(rows[0].keys()) if rows else set()
forbidden={'contact_email','email','person_email','patient_email','service_email'}
missing={'business_id','event_id','status','region','value'}-fields
dup=len({r.get('business_id') for r in rows}) != len(rows)
leaked=bool(fields & forbidden)
bad_value=[]
for i,r in enumerate(rows,2):
    try:
        if float(r.get('value',''))<=0: bad_value.append(i)
    except Exception: bad_value.append(i)
result={'status':'STRUCTURE_OK' if not(missing or dup or leaked or bad_value) else 'STRUCTURE_FAIL','missing_fields':sorted(missing),'duplicate_business_id':dup,'pii_field_present':leaked,'invalid_value_rows':bad_value,'note':'This checker does not reveal expected counts/totals and cannot decide Gate pass.'}
print(json.dumps(result,indent=2)); raise SystemExit(0 if result['status']=='STRUCTURE_OK' else 2)
