"""G07 assessment skeleton. Implement independently; protected reviews stay closed.
Required behavior: load sources, choose deterministic latest event, validate, reconcile,
quarantine defects, publish PII-safe current serving rows, and write run/validation evidence.
The starter deliberately contains no solution logic.
"""
from pathlib import Path
import csv, json, hashlib
ROOT=Path(__file__).parent

def load_sources():
    raise NotImplementedError("YOUR CODE: load CSV/JSONL inputs and preserve source evidence")

def choose_latest(events):
    raise NotImplementedError("YOUR CODE: latest updated_at; deterministic event_id tie-break")

def validate_and_reconcile(latest_rows, parties, settlements, eligible_statuses):
    raise NotImplementedError("YOUR CODE: explicit accept/quarantine reasons; no silent drop")

def publish(accepted, quarantine):
    raise NotImplementedError("YOUR CODE: deterministic outputs, no contact_email in serving")

def main():
    raise NotImplementedError("YOUR CODE: orchestrate steps, manifest, validation, safe rerun")

if __name__ == '__main__':
    main()
