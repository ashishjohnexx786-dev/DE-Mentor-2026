import json,sys
p=sys.argv[1]
d=json.load(open(p,encoding="utf-8"))
def present(x):
    if isinstance(x,bool): return x
    if isinstance(x,(list,dict)): return len(x)>0
    return bool(str(x).strip()) if x is not None else False
need=[
('attempt.variant',d.get('attempt',{}).get('variant')),('attempt.attempt_id',d.get('attempt',{}).get('attempt_id')),('attempt.first_attempt_saved_at',d.get('attempt',{}).get('first_attempt_saved_at')),
('requirements_summary',d.get('requirements_summary')),('source_inventory>=3',len(d.get('source_inventory',[]))>=3),('source_lineage>=2',len(d.get('source_lineage_and_checksums',[]))>=2),
('implementation.python_path',d.get('implementation',{}).get('python_path')),('implementation.sql_path',d.get('implementation',{}).get('sql_path')),('implementation.serving_output',d.get('implementation',{}).get('serving_output')),('implementation.quarantine_output',d.get('implementation',{}).get('quarantine_output')),('implementation.run_manifest',d.get('implementation',{}).get('run_manifest')),('implementation.validation_report',d.get('implementation',{}).get('validation_report')),
('grain.source',d.get('grain',{}).get('source_event_grain')),('grain.latest',d.get('grain',{}).get('latest_state_grain')),('grain.serving',d.get('grain',{}).get('serving_grain')),
('validation.source_counts',d.get('validation',{}).get('source_counts')),('validation.latest',d.get('validation',{}).get('latest_state_control')),('validation.accept_quarantine',d.get('validation',{}).get('accepted_quarantine_control')),('validation.settlement',d.get('validation',{}).get('settlement_reconciliation')),('validation.independent',d.get('validation',{}).get('independent_control')),
('rerun.idempotence',d.get('rerun',{}).get('idempotence_proof')),('incident.evidence>=2',len(d.get('incident_response',{}).get('evidence_inspected',[]))>=2),('incident.recovery',d.get('incident_response',{}).get('safe_recovery_action')),('incident.post',d.get('incident_response',{}).get('post_recovery_validation')),
('change.implementation',d.get('controlled_change',{}).get('implementation')),('change.post',d.get('controlled_change',{}).get('post_change_validation')),('security.pii',d.get('security',{}).get('pii_handling')),
('translation.orchestration',d.get('production_translation',{}).get('orchestration_quality')),('translation.storage',d.get('production_translation',{}).get('storage_spark_lakehouse')),('translation.streaming',d.get('production_translation',{}).get('streaming_kafka')),('translation.cloud',d.get('production_translation',{}).get('cloud_fabric')),
('architecture.decisions>=3',len(d.get('architecture_defense',{}).get('decisions',[]))>=3),('architecture.alternatives>=2',len(d.get('architecture_defense',{}).get('rejected_alternatives',[]))>=2),('architecture.limitations>=2',len(d.get('architecture_defense',{}).get('limitations',[]))>=2),('architecture.runbook',d.get('architecture_defense',{}).get('handoff_runbook')),
('job.m18',d.get('job_ready_defense',{}).get('m18_project_evidence_reference')),('job.m19',d.get('job_ready_defense',{}).get('m19_interview_evidence_reference')),('job.english',d.get('job_ready_defense',{}).get('technical_english_explanation')),('job.followups>=4',len(d.get('job_ready_defense',{}).get('random_followup_answers',[]))>=4),
('runtime.observed',d.get('runtime_truth',{}).get('locally_observed')),('runtime.claims_boundary',d.get('runtime_truth',{}).get('claims_boundary'))]
for k,v in d.get('competencies',{}).items():
    need.append((f'{k}.demonstrated',v.get('demonstrated') is True)); need.append((f'{k}.evidence',len(v.get('evidence',[]))>=1))
missing=[k for k,v in need if not present(v)]
critical=d.get('critical_failures',[])
status='EVIDENCE_COMPLETE_FOR_HUMAN_GATE_REVIEW' if not missing and not critical else 'INCOMPLETE_OR_CRITICAL'
print(json.dumps({'status':status,'missing':missing,'critical_failures':critical,'note':'Completeness only; this checker never decides technical correctness or Gate pass.'},indent=2))
raise SystemExit(0 if status=='EVIDENCE_COMPLETE_FOR_HUMAN_GATE_REVIEW' else 2)
