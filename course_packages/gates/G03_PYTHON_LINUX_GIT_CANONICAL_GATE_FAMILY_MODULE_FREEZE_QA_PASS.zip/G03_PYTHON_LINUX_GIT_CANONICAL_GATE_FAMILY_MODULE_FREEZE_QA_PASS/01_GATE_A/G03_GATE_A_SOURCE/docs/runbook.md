Operational rule placeholder - your branches will create a deliberate conflict here.
