#!/usr/bin/env bash
set -u
python3 src/gate_pipeline.py --input-dir "${INPUT_DIR:-data}"
