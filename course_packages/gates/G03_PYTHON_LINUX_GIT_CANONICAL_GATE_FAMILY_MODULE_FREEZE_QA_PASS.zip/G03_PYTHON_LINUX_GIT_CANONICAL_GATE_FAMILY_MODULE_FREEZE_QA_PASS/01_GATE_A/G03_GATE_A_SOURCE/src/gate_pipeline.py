"""G03 assessment starter. Deliberately incomplete: build your own pipeline."""
from pathlib import Path
import argparse
def main():
    p=argparse.ArgumentParser(); p.add_argument('--input-dir',default='data'); args=p.parse_args()
    input_dir=Path(args.input_dir)
    print(f'input_dir={input_dir}')
    raise SystemExit('TODO: implement after saving your plan; Review remains closed')
if __name__=='__main__': main()
