# G03 Gate B: Clinic Supply Intake

Build your solution in src/. Do not use a review file before saving the Gate attempt.
