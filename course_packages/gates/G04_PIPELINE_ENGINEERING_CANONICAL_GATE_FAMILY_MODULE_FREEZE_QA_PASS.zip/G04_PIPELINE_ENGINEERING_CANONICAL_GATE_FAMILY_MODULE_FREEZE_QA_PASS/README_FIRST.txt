G04 CANONICAL PIPELINE ENGINEERING GATE FAMILY

Dependency: M07 + M08 + M09 + M10 = 62 formal lessons.
Ordinary route: Start Here -> Gate A -> save attempt -> Review A if needed -> targeted repair. Gate B/C stay sealed until explicit assignment.
After Gate-family PASS, continue to M11. No percentage-based pass. This is a module/gate freeze candidate, not whole-course FINAL.
