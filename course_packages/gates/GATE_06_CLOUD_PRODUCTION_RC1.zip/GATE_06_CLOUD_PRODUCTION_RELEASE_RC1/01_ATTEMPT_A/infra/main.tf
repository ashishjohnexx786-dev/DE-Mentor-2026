variable "environment" { type = string }
# TODO: provider-light resource/tag/config foundation; never hardcode credentials.
