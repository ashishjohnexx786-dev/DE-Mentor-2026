# Deliberately weak current architecture

- Raw files are copied directly into the reporting warehouse and overwritten each day.
- A developer manually runs one production notebook whenever someone remembers.
- Every run reloads all historical data with no watermark or merge key.
- The storage account key is pasted into notebook source code.
- All analysts have Contributor access to the production workspace.
- Customer email is copied into every layer and report table.
- There are no automated data tests or deployment checks.
- Changes are pushed directly to production with no dev/test separation or rollback.
- No one monitors freshness, row-count drift, failures or cost.
- Tables are partitioned by unique order_id.
