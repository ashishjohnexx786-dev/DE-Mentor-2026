import csv, json
from pathlib import Path
# TODO: read data/input.csv, validate required business key order_id, reject negative numeric amount/usage,
# deduplicate exact records, produce result_summary.json and quarantine.csv.
raise SystemExit('TODO: implement quality gate')
