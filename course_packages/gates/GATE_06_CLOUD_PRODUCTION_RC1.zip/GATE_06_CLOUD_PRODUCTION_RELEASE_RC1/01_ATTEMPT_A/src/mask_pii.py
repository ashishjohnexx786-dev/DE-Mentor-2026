import csv
# TODO: read data/input.csv and write masked_output.csv with customer_email masked.
raise SystemExit('TODO: implement PII masking')
