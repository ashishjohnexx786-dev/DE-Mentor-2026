Gate 6 - Cloud + Production Engineering | Conditional RC1

1. Attempt A first and save the first checker output.
2. Open Review A only after the attempt is saved; repair weak competencies in a copy.
3. Take fresh retest B without copying A field names or outputs.
4. Open Review B only after saving B.
5. Offline checks prove local data/security/architecture evidence. A genuine Microsoft Fabric runtime pass remains mandatory before course-wide FINAL.
6. Never place real credentials in the learner files.
