# Deliberately weak current architecture

- Meter CSV files are deleted from landing storage after each successful-looking load.
- A shared admin account is used by notebooks, pipelines and analysts.
- The full history is truncated and rebuilt every night.
- Account addresses are exposed to all report consumers.
- Pipeline schedules are edited manually in production.
- No quality rule checks negative usage or missing reading IDs.
- No deployment review or rollback record exists.
- No alert fires when a zone stops delivering readings.
- Infrastructure settings live only in screenshots and tribal knowledge.
- Data is partitioned by unique reading_id.
