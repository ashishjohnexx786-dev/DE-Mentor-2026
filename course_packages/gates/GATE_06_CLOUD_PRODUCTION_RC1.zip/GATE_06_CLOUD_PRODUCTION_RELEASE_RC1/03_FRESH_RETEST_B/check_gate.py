import csv, json, re, subprocess, sys
from pathlib import Path
checks=[]
def c(name, ok):
    checks.append((name,bool(ok))); print(f"{name}={'PASS' if ok else 'FAIL'}")
# Execute learner-local controls.
q=subprocess.run([sys.executable,'src/quality_gate.py'],capture_output=True,text=True)
c('quality_gate_runs',q.returncode==0)
m=subprocess.run([sys.executable,'src/mask_pii.py'],capture_output=True,text=True)
c('masker_runs',m.returncode==0)
exp={'source_rows':8,'valid_rows':7,'dedup_rows':6,'accepted_rows':5,'quarantined_rows':2,'accepted_amount':181.0}
got=json.loads(Path('result_summary.json').read_text() or '{}') if Path('result_summary.json').exists() else {}
c('summary_matches',got==exp)
c('masked_output_exists',Path('masked_output.csv').exists())
if Path('masked_output.csv').exists():
    txt=Path('masked_output.csv').read_text()
    c('pii_masked','@' not in txt if 'account_address'=='customer_email' else all(x not in txt for x in ['Lake Rd','Hill St','Park Ln','River Rd','Main St','Pine Ave','Oak St']))
else: c('pii_masked',False)
# Architecture findings
rows=list(csv.DictReader(open('architecture_findings.csv',newline='',encoding='utf-8'))) if Path('architecture_findings.csv').exists() else []
c('risk_count',len(rows)>=8)
sev={str(r.get('severity','')).upper() for r in rows}; c('risk_priorities','P0' in sev and 'P1' in sev)
text=' '.join(' '.join(map(str,r.values())) for r in rows).lower(); c('risk_security','secret' in text or 'credential' in text or 'access' in text); c('risk_reliability','monitor' in text or 'rollback' in text or 'rerun' in text)
# Target architecture
def loadj(name):
    try:return json.loads(Path(name).read_text())
    except:return {}
a=loadj('target_architecture.json'); required=['landing','bronze','silver','gold','serving','orchestration','identity','ci_cd','monitoring']; c('architecture_complete',all(a.get(k) not in [None,'','TODO'] for k in required)); arch=json.dumps(a).lower(); c('fabric_components',all(x in arch for x in ['onelake','lakehouse','delta','sql'])); c('managed_orchestration','pipeline' in arch or 'orchestrat' in arch)
inc=loadj('incremental_plan.json'); incs=json.dumps(inc).lower(); c('incremental_key',inc.get('business_key')=='reading_id'); c('watermark',len(str(inc.get('watermark','')))>3); c('merge_idempotency','merge' in incs and ('idempot' in incs or 'rerun' in incs)); c('late_data','late' in incs or 'backfill' in incs)
sec=loadj('security_plan.json'); secs=json.dumps(sec).lower(); c('secret_handling',('key vault' in secs or 'managed identity' in secs or 'connection' in secs)); c('least_privilege','least privilege' in secs or 'read-only' in secs or 'viewer' in secs); c('pii_control','mask' in secs and 'account_address'.lower() in secs)
mon=loadj('monitoring_plan.json'); mons=json.dumps(mon).lower(); c('monitoring_core',all(x in mons for x in ['fresh','quality','fail','cost']))
wf=Path('.github/workflows/ci.yml').read_text().lower() if Path('.github/workflows/ci.yml').exists() else ''; c('ci_workflow','pull_request' in wf and ('pytest' in wf or 'quality_gate' in wf) and ('secret' in wf or 'scan' in wf)); c('ci_no_literal_secret',not re.search(r'(password|token|secret)\s*:\s*["\']?[^${{\n][^\n]*',wf))
tf=Path('infra/main.tf').read_text().lower() if Path('infra/main.tf').exists() else ''; c('iac_foundation','variable' in tf and ('environment' in tf or 'env' in tf) and ('tags' in tf or 'locals' in tf)); c('iac_no_creds',not any(x in tf for x in ['password =','client_secret =','access_key =']))
run=Path('runbook.md').read_text().lower() if Path('runbook.md').exists() else ''; c('runbook',all(x in run for x in ['detect','diagnose','contain','recover','validate','communicate','rollback']))
defense=Path('defense.md').read_text().lower() if Path('defense.md').exists() else ''; c('defense',all(x in defense for x in ['trade-off','10x','cost','security','recovery']))
print(f"TOTAL={sum(v for _,v in checks)}/{len(checks)}")
raise SystemExit(0 if all(v for _,v in checks) else 1)
