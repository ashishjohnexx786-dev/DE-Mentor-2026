# Gate 6B - municipal water metering

Start with the PDF brief. Preserve the first attempt. Implement the TODO files, run `python check_gate.py`, and save evidence. This package does not contain the internal known-good solution. Live Microsoft Fabric execution is required later before FINAL.
