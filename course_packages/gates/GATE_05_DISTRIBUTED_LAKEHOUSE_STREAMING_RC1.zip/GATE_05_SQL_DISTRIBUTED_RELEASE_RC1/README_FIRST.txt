Gate 5 - Distributed / Lakehouse / Streaming | Conditional RC1

1. Complete 01_ATTEMPT_A without opening the review folder.
2. Save the attempt and checker output.
3. Open 02_REVIEW_AFTER_A only after the attempt is saved; repair weak skills without overwriting original evidence.
4. Complete 03_FRESH_RETEST_B on the different fleet-sensor domain.
5. Use 04_REVIEW_AFTER_B only after saving the retest.
6. The Gate is conditional until real Spark/Delta/Kafka runtime evidence is collected before course-wide FINAL.

The learner package intentionally does NOT contain the internal executable reference solution.
