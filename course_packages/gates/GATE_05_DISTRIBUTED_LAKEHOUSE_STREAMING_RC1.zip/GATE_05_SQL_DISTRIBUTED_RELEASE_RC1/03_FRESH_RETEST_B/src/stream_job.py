from pyspark.sql import SparkSession, functions as F
spark=SparkSession.builder.appName("gate5_stream_B").getOrCreate()
# TODO: spark.readStream.format("kafka")
# TODO: option subscribe=fleet_telemetry
# TODO: parse event JSON/schema and preserve event key
# TODO: checkpointLocation must be durable/stable across restart
# TODO: writeStream start
