from delta.tables import DeltaTable
# TODO load incremental update as DataFrame
# TODO DeltaTable.forPath(...)
# TODO merge on target.vehicle_id = source.vehicle_id
# TODO whenMatchedUpdateAll + whenNotMatchedInsertAll
# TODO prove second run does not create extra logical vehicles
