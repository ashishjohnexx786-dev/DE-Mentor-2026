import json, re, subprocess, sys
from pathlib import Path
checks=[]
def c(n,o):checks.append((n,bool(o)));print(f'{n}={"PASS" if o else "FAIL"}')
exp={'source_rows':6,'valid_rows':5,'dedup_rows':4,'latest_entities_before_update':3,'latest_entities_after_update':4,'delivered_or_alert_count':1}; got=json.loads(Path('result_summary.json').read_text() or '{}')
c('summary_matches',got==exp)
b=Path('src/batch_job.py').read_text(); c('spark_session','SparkSession' in b); c('explicit_schema','StructType' in b or 'T.StructType' in b); c('window_latest','Window.partitionBy' in b and ('row_number' in b or 'rank' in b)); c('join','.join(' in b); c('parquet_delta_write','parquet' in b.lower() or 'delta' in b.lower());
p=json.loads(Path('partition_plan.json').read_text()); c('partition_not_unique',p.get('partition_column') not in ['', 'TODO', 'vehicle_id']); c('partition_reason',len(str(p.get('why','')))>40); c('small_file_plan',len(str(p.get('small_file_plan','')))>25); c('shuffle_risk',len(str(p.get('shuffle_risk','')))>25)
d=Path('src/delta_merge.py').read_text(); c('delta_merge','DeltaTable' in d and '.merge' in d); c('merge_key','vehicle_id' in d); c('merge_actions','whenMatched' in d and 'whenNotMatched' in d)
k=json.loads(Path('kafka_design.json').read_text()); c('topic',k.get('topic')=='fleet_telemetry'); c('message_key',k.get('message_key')=='vehicle_id'); c('consumer_group',k.get('consumer_group') not in ['', 'TODO']); c('offset_reason',len(str(k.get('offset_commit_strategy','')))>35); c('replay_reason',len(str(k.get('replay_strategy','')))>35)
s=Path('src/stream_job.py').read_text(); c('read_stream','readStream' in s and 'kafka' in s.lower()); c('checkpoint','checkpointLocation' in s); c('write_stream','writeStream' in s)
defense=Path('defense.md').read_text().lower(); c('defense',all(x in defense for x in ['grain','partition','merge','offset','checkpoint','performance']))
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}'); raise SystemExit(0 if all(v for _,v in checks) else 1)
