# TODO
Explain schema/grain, latest-record logic, partition choice, merge rerun, one performance risk, Kafka offsets/groups/replay, and streaming checkpoint recovery.
