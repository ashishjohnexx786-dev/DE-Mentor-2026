from pyspark.sql import SparkSession, functions as F, types as T
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("gate5_A").getOrCreate()
# TODO: explicit schema for history.csv
# TODO: reject missing shipment_id, deduplicate exact business events
# TODO: join reference.csv
# TODO: latest record per shipment_id using Window.partitionBy(...).orderBy(desc(event_time))
# TODO: aggregate trusted metrics
# TODO: write Parquet/Delta with justified partitioning (do not partition by unique shipment_id)
