G01 DATA + EXCEL - CANONICAL GATE FAMILY MODULE FREEZE - QA PASS
WHOLE-COURSE FINAL / LIVE RUNTIME STILL PENDING

Normal route:
1) Open 00_START_HERE.
2) Use Gate A as the normal protected assessment.
3) Save/freeze the attempt before opening Review A.
4) Repair only the exact weak competency and complete a changed micro-proof with Review closed.
5) Gate B/C stay sealed unless a reviewer explicitly assigns a fresh full reassessment.
6) Pass is competency-based: K1-K6 all DEMONSTRATED + zero unresolved critical defects. There is no percentage shortcut.

The three Gate domains/data are physically distinct: Retail Orders, Clinic Shipments, Customer Support Tickets.
