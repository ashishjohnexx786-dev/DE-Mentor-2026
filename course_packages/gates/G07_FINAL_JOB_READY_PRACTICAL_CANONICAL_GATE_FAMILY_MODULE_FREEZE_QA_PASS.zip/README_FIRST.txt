G07 FINAL JOB-READY SIMULATION - CANONICAL GATE FAMILY
Prerequisite: M19 complete.
Start: 00_START_HERE/G07_START_HERE.pdf
Gate A normal. Review A only after saved attempt. Gate B/C sealed until explicit assignment.
Pass: all K1-K8 demonstrated with evidence + zero unresolved critical failures. No numeric shortcut.
