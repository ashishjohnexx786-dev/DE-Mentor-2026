"""Stage 04 module practice. Complete TODOs before checking review."""

def calculate_sales(qty, unit_price):
    # TODO
    pass


def clean_region(region):
    # TODO: strip spaces and title-case the value
    pass


def is_large_order(sales, threshold=2000):
    # TODO: return True when sales >= threshold
    pass
