from pathlib import Path
import csv

def read_rows(path):
    # TODO return list of dict rows
    pass

def validate_rows(rows):
    # TODO require order_id, region, qty, unit_price, status
    pass

def completed_sales_by_region(rows):
    # TODO return dict region -> completed sales
    pass

if __name__ == '__main__':
    path=Path(__file__).with_name('module_practical_orders.csv')
    rows=read_rows(path)
    validate_rows(rows)
    print(completed_sales_by_region(rows))
