# DE04-08 MODULE PRACTICE
# Complete stage04_helpers.py first.

from stage04_helpers import calculate_sales, clean_region, is_large_order

print(calculate_sales(3, 850))
print(clean_region(" east "))
print(is_large_order(2550))
