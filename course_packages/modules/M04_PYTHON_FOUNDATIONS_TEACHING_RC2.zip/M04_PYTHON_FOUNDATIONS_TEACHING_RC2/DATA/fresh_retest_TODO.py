from pathlib import Path
import csv

def inventory_value_by_warehouse(path):
    # TODO return dict warehouse -> qty*unit_cost total
    pass

if __name__ == '__main__':
    print(inventory_value_by_warehouse(Path(__file__).with_name('fresh_retest_inventory.csv')))
