# DE04-09 DEBUGGING LAB
# Goal: fix every bug WITHOUT replacing the whole file from an answer key.

orders = [
    {"id": "O1", "qty": 2, "price": 850},
    {"id": "O2", "qty": "3", "price": 450},
    {"id": "O3", "qty": 5, "price": None},
]


def order_sales(order):
    return order["qty"] * order["price"]


total = 0
for order in orders:
    total += order_sales(order)

print("Total sales:", total)

# Your job:
# 1) Run it and READ the traceback.
# 2) Fix one failure at a time.
# 3) Decide what to do with a missing price instead of silently guessing.
# 4) Add a useful exception/message for invalid quantity/price values.
