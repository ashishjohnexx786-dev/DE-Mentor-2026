M04 DATA ASSETS - TEACHING RC2

M04_PYTHON_PRACTICE_TEACHING_RC2.py
  Main lesson practice prompts with expected checks.

M04_CODING_DRILLS_TEACHING_RC2.py
  P13/P14 + linear-search drills. Solutions intentionally blank.

M04_DEBUG_ME_v1.0.py
  Deliberately broken debugging lab. Do not replace wholesale.

stage04_helpers.py + M04_MODULE_DEMO_v1.0.py
  Module/import practice.

M04_RETAIL_ORDERS_v1.0.csv
  25-row retail dataset for file/pandas work.

module_practical_TODO.py + module_practical_orders.csv
  Final practical. Do not open review before saved attempt.

fresh_retest_TODO.py + fresh_retest_inventory.csv
  Fresh domain after remediation only.
