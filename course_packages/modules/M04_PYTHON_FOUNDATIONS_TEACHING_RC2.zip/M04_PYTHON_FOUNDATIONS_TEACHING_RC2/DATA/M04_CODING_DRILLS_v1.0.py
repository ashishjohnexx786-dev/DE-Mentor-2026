# STAGE 04 - LIGHTWEIGHT CODING DRILLS
# These are NOT competitive-programming puzzles. They protect basic interview fluency.

# Q1 - 10 min
# Return the first repeated order ID from a list, or None if there is no repeat.
def first_duplicate(ids):
    # TODO
    pass

# Q2 - 10 min
# Count words in a sentence, case-insensitive. Return a dictionary.
def word_counts(text):
    # TODO
    pass

# Q3 - 10 min
# Return True if two strings are anagrams after ignoring spaces/case.
def are_anagrams(a, b):
    # TODO
    pass

# Q4 - 15 min
# Given a list of dictionaries with region and sales, return totals by region.
def sales_by_region(rows):
    # TODO
    pass

# Q5 - 15 min
# Linear search: return the index of target or -1.
def linear_search(values, target):
    # TODO
    pass
