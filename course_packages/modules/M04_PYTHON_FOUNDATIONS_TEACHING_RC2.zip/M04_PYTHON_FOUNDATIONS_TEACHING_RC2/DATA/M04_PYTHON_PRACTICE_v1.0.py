# STAGE 04 - PYTHON FOUNDATIONS PRACTICE
# Run one section at a time. Type code yourself where marked TODO.
# Do not open the Review Pack until you save your own attempt.

from pathlib import Path

DATA_FILE = Path(__file__).with_name("STAGE_04_RETAIL_ORDERS_v1.0.csv")

# DE04-01 FIRST PROGRAM
print("Stage 04 started")

# DE04-02 VARIABLES / TYPES / OPERATORS
product = "Keyboard"
qty = 2
unit_price = 850
# TODO: calculate sales = qty * unit_price and print its value + type

# DE04-03 STRINGS
customer_name = "  ravi retail  "
# TODO: clean the spaces, convert to title case, and create:
# "Customer: Ravi Retail"

# DE04-04 CONDITIONS
status = "Completed"
amount = 2400
# TODO: print "priority" only when status is Completed AND amount >= 2000;
# otherwise print "normal".

# DE04-05 COLLECTIONS
products = ["Keyboard", "Mouse", "USB Cable", "Keyboard"]
prices = {"Keyboard": 850, "Mouse": 450, "USB Cable": 220}
regions = {"East", "West", "East", "North"}
# TODO 1: append "Laptop Stand" to products.
# TODO 2: print the Mouse price from prices.
# TODO 3: explain why regions stores East once.

# DE04-06 LOOPS
sales_values = [1700, 1350, 1100, 850, 1800]
# TODO: use a loop to calculate the total WITHOUT sum().

# DE04-07 FUNCTIONS
def net_sales(qty, unit_price, discount_pct=0):
    # TODO: return qty * unit_price * (1 - discount_pct)
    pass

# TODO: call net_sales(2, 1200, 0.10) and print the result.

# DE04-08 MODULES
# TODO: import mean from statistics and calculate the mean of sales_values.

# DE04-09 EXCEPTIONS / DEBUGGING
bad_qty = "five"
try:
    converted = int(bad_qty)
    print(converted)
except ValueError as exc:
    # TODO: replace this with a useful message that includes the bad value.
    print("conversion failed")

# DE04-10 PANDAS
# TODO:
# 1) import pandas as pd
# 2) read DATA_FILE
# 3) show shape, columns, head, dtypes
# 4) create sales = qty * unit_price
# 5) filter Completed orders
# 6) calculate Completed sales by region
# 7) identify missing sales_rep values

# DE04-11 PRACTICAL BIG-O
# A list membership check scans until it finds a match: O(n) in the general case.
# A set membership check is typically O(1) average-case.
# TODO: write 2-3 sentences explaining why a set is useful for repeated ID lookups.

# DE04-12 LIST / STRING DRILLS
# 1) Return a new list containing only even values from [3, 8, 2, 9, 10, 5].
# 2) Count vowels in "data engineering".
# 3) Reverse the words in "build reliable data pipelines" -> "pipelines data reliable build".

# DE04-13 DICTIONARY / SET DRILLS
order_regions = ["East", "West", "East", "North", "West", "East"]
# 1) Build a dictionary counting how many times each region appears.
# 2) Get unique regions with a set.
# 3) Given ids = ["O1","O2","O2","O3","O1"], return duplicate IDs only once.

# DE04-14 STACK / QUEUE BASICS
# Use a list as a simple stack:
stack = []
# TODO: push "extract", "transform", "load"; then pop one item and print it.
# Explain LIFO in one sentence.
# Queue concept: explain FIFO; no special library required yet.

# DE04-15 SEARCH / SORT / RECURSION AWARENESS
nums = [7, 2, 9, 1, 5]
# 1) Sort ascending WITHOUT changing nums; store in sorted_nums.
# 2) Write a simple linear search function that returns the index of target or -1.
# 3) OPTIONAL: write factorial(n) recursively for n >= 0, then explain the base case.

# STAGE 04 CHECKPOINT - CLOSED BOOK AFTER FIRST ATTEMPT
# C1. Write a function summarize_order(product, qty, unit_price) returning a dictionary
#     with product, qty and sales.
# C2. From ["east","East "," WEST","west","North"], create clean unique title-case regions.
# C3. Given ["O1","O2","O2","O3","O1","O4"], return duplicate IDs only once.
# C4. Read the CSV with pandas and return the top 3 Completed orders by sales.
# C5. Debug a ValueError caused by int("12.5") and explain the safest fix for decimal input.
