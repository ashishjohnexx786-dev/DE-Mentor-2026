# M04 CODING DRILLS - TEACHING RC2
# Not competitive-programming puzzles.
# For EACH function:
# - write the function
# - add at least 2 tests
# - explain the input and returned output
# - do not open review before a genuine attempt

# P13-1: first repeated ID, else None
def first_duplicate(ids):
    # TODO
    pass

# P13-2: case-insensitive word counts
def word_counts(text):
    # TODO
    pass

# P13-3: anagram ignoring spaces/case
def are_anagrams(a, b):
    # TODO
    pass

# P14-1: list of dict rows -> total sales by region
def sales_by_region(rows):
    # TODO
    pass

# DE04-15: linear search -> index or -1
def linear_search(values, target):
    # TODO
    pass

# Example tests YOU may run after implementing:
# assert first_duplicate(["O1","O2","O2"]) == "O2"
# assert first_duplicate(["O1","O2"]) is None
# Add your own edge cases too.
