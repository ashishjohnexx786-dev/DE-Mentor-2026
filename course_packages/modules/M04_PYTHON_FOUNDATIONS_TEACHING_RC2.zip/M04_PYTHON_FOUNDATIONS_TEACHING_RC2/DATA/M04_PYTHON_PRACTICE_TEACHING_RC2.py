# M04 PYTHON PRACTICE - TEACHING RC2
# HOW TO USE:
# 1) Work on ONE lesson section only.
# 2) Type your solution under TODO.
# 3) Run the file after each small change.
# 4) Compare with the lesson's expected check.
# 5) Save your attempt before opening Review.
# This file contains prompts, not hidden solutions.

from pathlib import Path
DATA_FILE = Path(__file__).with_name("M04_RETAIL_ORDERS_v1.0.csv")

# DE04-01
# Create a separate first_program.py for the deliberate syntax-error exercise.
print("M04 practice file started")

# DE04-02
product = "Keyboard"
qty = 2
unit_price = 850
# TODO calculate sales and print value + type.
# Expected arithmetic check: 2 * 850 = 1700.

# DE04-03
customer_name = "  ravi retail  "
# TODO create cleaned name and exact message "Customer: Ravi Retail".
# Self-check with repr(raw) and repr(clean).

# DE04-04
status = "Completed"
amount = 2400
# TODO implement the rule from Learner Book; then test boundary values.

# DE04-05
products = ["Keyboard","Mouse","USB Cable","Keyboard"]
prices = {"Keyboard":850,"Mouse":450,"USB Cable":220}
regions = {"East","West","East","North"}
# TODO append product, retrieve Mouse price, explain unique East in set.

# DE04-06
sales_values = [1700,1350,1100,850,1800]
# TODO loop total without sum(). Expected total 6800.
# TODO count values >=1500. Expected 2.

# DE04-07
def net_sales(qty, unit_price, discount_pct=0):
    # TODO return the calculated value
    pass
# Self-check: net_sales(2,1200,0.10) -> 2160.0

# DE04-08
# Use stage04_helpers.py + M04_MODULE_DEMO_v1.0.py.

# DE04-09
# Use M04_DEBUG_ME_v1.0.py. SAVE the traceback before repair.

# DE04-10
# Use pathlib + csv on DATA_FILE. Write derived output to a new output/ folder.
# Never overwrite DATA_FILE.

# DE04-11
# pandas task:
# - import pandas as pd
# - read DATA_FILE
# - inspect shape/columns/head/dtypes
# - create sales
# - filter Completed
# - sales by region
# - top 3 Completed
# - missing sales_rep
# - reconcile grouped total to overall Completed total

# DE04-12
# Explain list membership vs set membership in 3-5 sentences.

# DE04-13 / DE04-14
# Continue in M04_CODING_DRILLS_TEACHING_RC2.py.

# DE04-15
# Demonstrate stack push/pop, sorted() vs .sort(), and linear_search.

# DE04-16
# Complete module practical only after lessons/practice.
