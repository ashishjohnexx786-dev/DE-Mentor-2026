M04 PYTHON FOUNDATIONS - TEACHING RC2

START:
00_START_HERE_TEACHING_RC2.pdf

Then:
Learner Book -> Guided Lab -> close guidance -> Independent Practice -> saved validation.
Review material is under ASSESSMENTS/REVIEW_AFTER_ATTEMPT and is opened only after a genuine attempt.

At DE04-01, install Python only if needed.
Official Python Windows: https://www.python.org/downloads/windows/
Official VS Code Python tutorial: https://code.visualstudio.com/docs/python/python-tutorial
