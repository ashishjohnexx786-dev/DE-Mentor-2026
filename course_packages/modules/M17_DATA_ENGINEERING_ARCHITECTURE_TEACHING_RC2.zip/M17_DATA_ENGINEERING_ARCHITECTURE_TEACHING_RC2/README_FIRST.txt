M17 Data Engineering Architecture & System Design TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf
No new software is required. This module is reasoning/workbook driven; use project JSON/Markdown cases and earlier technical modules as evidence.
Architecture answers are scenario-dependent. The practical checker validates required artifacts, not one universally correct architecture.
