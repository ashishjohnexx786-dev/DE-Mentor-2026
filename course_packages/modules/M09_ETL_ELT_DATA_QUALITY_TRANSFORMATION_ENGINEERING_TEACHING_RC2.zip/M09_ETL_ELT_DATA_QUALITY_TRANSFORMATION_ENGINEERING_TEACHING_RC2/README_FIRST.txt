M09 - ETL ELT Data Quality Transformation Engineering - TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf.
Learner Book -> Guided -> close guidance -> Independent -> evidence -> Review only after attempt.
Reuse Python/VS Code/PostgreSQL from earlier modules. Create a fresh virtual environment for the supplied stage09 project if needed; do not reinstall system tools.
The supplied batch project contains TODO and reference implementations plus tests. Reference solution stays closed until a genuine attempt.
