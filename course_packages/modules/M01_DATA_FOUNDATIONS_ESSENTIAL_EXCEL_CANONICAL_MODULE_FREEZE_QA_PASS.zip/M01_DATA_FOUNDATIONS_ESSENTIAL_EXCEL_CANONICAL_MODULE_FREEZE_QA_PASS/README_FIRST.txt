M01 MODULE CONTENT FREEZE - QA PASS (COURSE-WIDE FINAL PENDING)

Freeze date: 2026-09-10
Completion rule: competency evidence only; no percentage shortcut.
Protected review remains attempt-locked. Repair is targeted; fresh retest uses changed evidence.
Live runtime/device behavior remains pending for course-wide final validation.

--- Preserved learner instructions ---

ZERO TO JOB-READY DATA ENGINEER 2026 - M01 CLEAN REBUILD - INTERNAL QA

OPEN ORDER
1. 00_START_HERE/M01_START_HERE_CANONICAL_REBUILD.pdf
2. 01_LESSONS/M01_LEARNER_BOOK_CANONICAL_REBUILD.pdf
3. Matching guided + independent practice and the canonical workbook.
4. Save a genuine attempt before protected review/repair.
5. Complete module practical.
6. Fresh retest only when targeted repair requires it.
7. After stable M01 completion, proceed to separate protected G01.

LOCKED COUNT: 15 formal lessons (DE01-01 through DE01-15).
IMPORTANT REPAIR: old Stage 01 learner pack stopped at DE01-12. This rebuild restores DE01-13/14/15 consistently across book, practice and Mentor data.
INSTALL RULE: do not install WSL/PostgreSQL/Docker/Spark/Kafka/Fabric here; install only when the later module asks.
STATUS: INTERNAL QA. Not course-wide FINAL.
