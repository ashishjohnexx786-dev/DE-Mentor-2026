-- STAGE 03 - QUERY WORKSPACE
-- Rule: type your own SQL below each task. Do not paste from the Review Pack.

USE stage03_retail_lab;

-- DE03-01 JOIN
-- Independent: list completed West orders with order_id, customer_name, tier and net_sales.

-- DE03-02 CARDINALITY
-- 1) Count sales_orders rows.
-- 2) LEFT JOIN customer_contacts by customer_id and count rows again.
-- 3) Identify order_ids that appear more than once after the join.
-- 4) Explain WHY the count changed.

-- DE03-03 UNION / UNION ALL
-- Create one activity stream:
-- completed orders -> event_id, customer_id, event_date, event_type='Order'
-- support tickets  -> event_id, customer_id, DATE(created_at), event_type='Ticket'
-- Use UNION ALL and sort by event_date, event_id.

-- DE03-04 STRING FUNCTIONS
-- Return customer_id, original customer_name, UPPER(customer_name),
-- and a label built with CONCAT(customer_name, ' - ', tier).
-- Then filter names containing 'Retail'.

-- DE03-05 DATE/TIME
-- Join returns to orders and calculate days_to_return with DATEDIFF(return_date, order_date).
-- Sort longest wait first.

-- DE03-06 SUBQUERY
-- Find completed orders whose net_sales is above the average completed-order net_sales.

-- DE03-07 CTE
-- Rewrite DE03-06 with a CTE that first calculates order-level net_sales.

-- DE03-08 WINDOW FUNCTIONS
-- For completed orders show order_id, region, net_sales and
-- AVG(net_sales) OVER (PARTITION BY region) as region_avg_sales.

-- DE03-09 ROW_NUMBER / LAG
-- A) Latest support ticket per customer using ROW_NUMBER.
-- B) Show each order_date plus the previous order_date using LAG.

-- DE03-10 MULTI-GRAIN
-- By region calculate:
-- orders_count, returned_orders, return_rate_pct.
-- Use COUNT(DISTINCT ...) so the grain stays region.

-- DE03-11 EXPLAIN
-- Run EXPLAIN on a customer_id lookup BEFORE and AFTER creating:
-- CREATE INDEX idx_sales_orders_customer_id ON sales_orders(customer_id);
-- Record what changed. Do not memorize exact planner wording.

-- DE03-12 INTEGRATED CHALLENGE (NO REVIEW UNTIL ATTEMPT)
-- Find the top 2 COMPLETED, NON-RETURNED orders in each region by net_sales.
-- Output: order_id, region, customer_name, net_sales, rank_in_region.
-- Tie-break with order_id.

-- DE03-13 TIMED SQL INTERVIEW SET - 45 MIN
-- Q1. Which region has the highest completed net_sales?
-- Q2. List customers who have at least 2 support tickets.
-- Q3. Return the latest support ticket per customer.
-- Q4. Find the top sales_rep by completed net_sales, excluding NULL sales_rep.

-- FOUNDATION GATE - 60 MIN, CLOSED BOOK
-- G1. Explain why joining orders to customer_contacts changes 30 rows to 35.
-- G2. Write a safe LEFT JOIN that lists all orders and optional return_id.
-- G3. Write a CTE + window query for top 2 non-returned completed orders per region.
-- G4. Explain WHERE vs HAVING, INNER vs LEFT JOIN, and CTE vs subquery in your own words.
-- G5. Use EXPLAIN before/after an index and describe evidence, not guesses.
