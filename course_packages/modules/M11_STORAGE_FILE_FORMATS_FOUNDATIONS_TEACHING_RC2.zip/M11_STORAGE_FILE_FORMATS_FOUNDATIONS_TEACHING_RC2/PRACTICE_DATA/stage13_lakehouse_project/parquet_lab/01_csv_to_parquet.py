from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/"source/orders.csv"
out=ROOT/"parquet_lab/orders.parquet"

df=pd.read_csv(source,parse_dates=["order_date","updated_at"])
df["qty"]=df["qty"].astype("int32")
df["unit_price"]=df["unit_price"].astype("float64")
df.to_parquet(out,index=False,engine="pyarrow",compression="snappy")

pf=pq.ParquetFile(out)
print("rows:",pf.metadata.num_rows)
print("columns:",pf.metadata.num_columns)
print("row_groups:",pf.num_row_groups)
print("schema:")
print(pf.schema_arrow)
