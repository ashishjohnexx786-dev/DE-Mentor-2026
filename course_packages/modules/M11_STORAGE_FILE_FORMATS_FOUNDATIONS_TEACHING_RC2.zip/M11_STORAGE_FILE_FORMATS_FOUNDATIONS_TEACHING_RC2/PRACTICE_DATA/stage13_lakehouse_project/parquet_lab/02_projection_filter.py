from pathlib import Path
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parents[1]
path=ROOT/"parquet_lab/orders.parquet"

# Projection: only read selected columns.
table=pq.read_table(path,columns=["order_id","region","qty","unit_price"])
print(table.to_pandas())

# For this tiny single-file lab, filtering is shown through PyArrow dataset API.
import pyarrow.dataset as ds
dataset=ds.dataset(path,format="parquet")
filtered=dataset.to_table(
    columns=["order_id","region","qty"],
    filter=(ds.field("region")=="East")
)
print("East rows:")
print(filtered.to_pandas())
