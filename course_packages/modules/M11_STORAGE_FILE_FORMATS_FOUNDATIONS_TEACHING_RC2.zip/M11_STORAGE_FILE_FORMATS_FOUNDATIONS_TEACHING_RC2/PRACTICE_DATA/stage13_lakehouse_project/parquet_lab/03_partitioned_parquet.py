from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/"source/orders.csv"
out=ROOT/"parquet_lab/partitioned_orders"

df=pd.read_csv(source)
table=pa.Table.from_pandas(df,preserve_index=False)
pq.write_to_dataset(
    table,
    root_path=out,
    partition_cols=["order_date"]
)

print("partition directories:")
for p in sorted(out.rglob("*")):
    if p.is_dir():
        print(p.relative_to(out))
