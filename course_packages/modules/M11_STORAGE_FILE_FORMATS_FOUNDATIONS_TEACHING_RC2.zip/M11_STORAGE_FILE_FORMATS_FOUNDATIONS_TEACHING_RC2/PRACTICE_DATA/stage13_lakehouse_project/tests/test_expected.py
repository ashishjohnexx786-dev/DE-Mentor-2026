import unittest
import csv
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class TestExpected(unittest.TestCase):
    def test_source_business_total(self):
        with (ROOT/"source/orders.csv").open(newline="",encoding="utf-8") as f:
            rows=list(csv.DictReader(f))
        completed=[r for r in rows if r["status"]=="Completed"]
        total=sum(int(r["qty"])*float(r["unit_price"]) for r in completed)
        self.assertEqual(len(rows),12)
        self.assertEqual(len(completed),11)
        self.assertEqual(total,16830.0)

if __name__=="__main__":
    unittest.main()
