from pathlib import Path
import csv, json
from collections import defaultdict

ROOT=Path(__file__).resolve().parents[1]

def read(name):
    with (ROOT/"source"/name).open(newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))

base=read("orders.csv")
updates=read("orders_updates.csv")
v2=read("orders_schema_v2.csv")

completed=[r for r in base if r["status"]=="Completed"]
total=round(sum(int(r["qty"])*float(r["unit_price"]) for r in completed),2)

by_region=defaultdict(float)
for r in completed:
    by_region[r["region"]]+=int(r["qty"])*float(r["unit_price"])

current={r["order_id"]:r for r in base}
for r in updates:
    old=current.get(r["order_id"])
    if old is None or r["updated_at"]>old["updated_at"]:
        current[r["order_id"]]=r
for r in v2:
    current[r["order_id"]]=r

expected={
  "base_rows":len(base),
  "base_completed_rows":len(completed),
  "base_completed_gross_sales":total,
  "base_region_sales":{k:round(v,2) for k,v in sorted(by_region.items())},
  "after_merge_rows":13,
  "after_schema_evolution_rows":15,
  "updated_O8002_qty":4
}
print(json.dumps(expected,indent=2))
assert expected=={
  "base_rows":12,
  "base_completed_rows":11,
  "base_completed_gross_sales":16830.0,
  "base_region_sales":{
    "East":4250.0,
    "North":4180.0,
    "South":4800.0,
    "West":3600.0
  },
  "after_merge_rows":13,
  "after_schema_evolution_rows":15,
  "updated_O8002_qty":4
}
