from pathlib import Path
import pyarrow.dataset as ds
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parents[1]
src=ROOT/"small_files/files"
out=ROOT/"small_files/compacted.parquet"

dataset=ds.dataset(src,format="parquet")
table=dataset.to_table()
pq.write_table(table,out,compression="snappy")

print("input files:",len(list(src.glob("*.parquet"))))
print("output files:",1)
print("rows:",table.num_rows)
