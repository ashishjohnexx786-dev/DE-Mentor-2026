from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/"source/orders.csv"
out=ROOT/"small_files/files"
out.mkdir(parents=True,exist_ok=True)

df=pd.read_csv(source)
for i,row in df.iterrows():
    pd.DataFrame([row]).to_parquet(
        out/f"row_{i:03d}.parquet",
        index=False,
        engine="pyarrow"
    )

print("small parquet files:",len(list(out.glob("*.parquet"))))
