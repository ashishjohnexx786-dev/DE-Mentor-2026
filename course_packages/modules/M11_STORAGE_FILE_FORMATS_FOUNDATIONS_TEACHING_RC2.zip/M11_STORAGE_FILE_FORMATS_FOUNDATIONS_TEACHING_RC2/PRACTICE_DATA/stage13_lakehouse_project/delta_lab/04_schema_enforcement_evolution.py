from pathlib import Path
import pandas as pd
import pyarrow as pa
from deltalake import write_deltalake, DeltaTable

ROOT=Path(__file__).resolve().parents[1]
table_path=ROOT/"delta_lab/orders_delta"
source=ROOT/"source/orders_schema_v2.csv"
data=pa.Table.from_pandas(pd.read_csv(source),preserve_index=False)

print("1) Strict append should fail because source_system is new.")
try:
    write_deltalake(table_path,data,mode="append")
except Exception as exc:
    print("EXPECTED FAILURE:",type(exc).__name__,str(exc)[:250])

print("\n2) Explicit schema evolution:")
write_deltalake(
    table_path,
    data,
    mode="append",
    schema_mode="merge"
)

dt=DeltaTable(table_path)
print("version:",dt.version())
print("schema:",dt.schema().to_arrow())
print("rows:",dt.count())
