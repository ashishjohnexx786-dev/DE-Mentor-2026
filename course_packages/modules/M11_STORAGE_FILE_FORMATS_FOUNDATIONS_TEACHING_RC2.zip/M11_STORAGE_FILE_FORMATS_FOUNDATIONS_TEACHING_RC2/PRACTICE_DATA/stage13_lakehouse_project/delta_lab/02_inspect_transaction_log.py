from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
log_dir=ROOT/"delta_lab/orders_delta/_delta_log"

files=sorted(log_dir.glob("*.json"))
print("json commits:",[p.name for p in files])

for p in files:
    print("\nCOMMIT",p.name)
    for line in p.read_text(encoding="utf-8").splitlines():
        action=json.loads(line)
        print("action:",next(iter(action.keys())))
