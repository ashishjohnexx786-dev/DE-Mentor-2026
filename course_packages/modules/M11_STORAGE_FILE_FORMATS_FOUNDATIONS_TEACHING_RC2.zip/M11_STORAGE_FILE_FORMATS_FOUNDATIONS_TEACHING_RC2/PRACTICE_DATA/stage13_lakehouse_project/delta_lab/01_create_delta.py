from pathlib import Path
import pandas as pd
import pyarrow as pa
from deltalake import write_deltalake, DeltaTable

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/"source/orders.csv"
table_path=ROOT/"delta_lab/orders_delta"

df=pd.read_csv(source)
arrow=pa.Table.from_pandas(df,preserve_index=False)
write_deltalake(table_path,arrow,mode="overwrite")

dt=DeltaTable(table_path)
print("version:",dt.version())
print("rows:",dt.count())
print("schema:",dt.schema().to_arrow())
print("parquet files:",len(dt.file_uris()))
print("history:",dt.history(1))
