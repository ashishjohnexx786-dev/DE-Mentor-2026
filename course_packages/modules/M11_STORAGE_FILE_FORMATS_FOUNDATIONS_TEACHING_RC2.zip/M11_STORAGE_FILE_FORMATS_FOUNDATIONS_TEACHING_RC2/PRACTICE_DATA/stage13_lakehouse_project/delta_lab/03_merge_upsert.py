from pathlib import Path
import pandas as pd
import pyarrow as pa
from deltalake import DeltaTable

ROOT=Path(__file__).resolve().parents[1]
table_path=ROOT/"delta_lab/orders_delta"
updates=ROOT/"source/orders_updates.csv"

source=pa.Table.from_pandas(pd.read_csv(updates),preserve_index=False)
dt=DeltaTable(table_path)

metrics=(
    dt.merge(
        source=source,
        predicate="target.order_id = source.order_id",
        source_alias="source",
        target_alias="target"
    )
    .when_matched_update_all(
        predicate="source.updated_at > target.updated_at"
    )
    .when_not_matched_insert_all()
    .execute()
)

dt=DeltaTable(table_path)
print("merge metrics:",metrics)
print("version:",dt.version())
print(dt.to_pandas().sort_values("order_id").tail(5))
