from pathlib import Path
from deltalake import DeltaTable

ROOT=Path(__file__).resolve().parents[1]
table_path=ROOT/"delta_lab/orders_delta"

current=DeltaTable(table_path)
print("current version:",current.version())
print("history:")
for item in current.history():
    print(item.get("version"),item.get("operation"),item.get("timestamp"))

print("\nVersion 0 row count:")
v0=DeltaTable(table_path,version=0)
print(v0.count())

print("\nCurrent row count:")
print(current.count())
