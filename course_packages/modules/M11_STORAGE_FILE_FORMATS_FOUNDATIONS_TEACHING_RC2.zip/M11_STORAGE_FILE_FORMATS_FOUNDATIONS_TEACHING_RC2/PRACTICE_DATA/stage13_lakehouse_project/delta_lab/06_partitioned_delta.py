from pathlib import Path
import pandas as pd
import pyarrow as pa
from deltalake import write_deltalake, DeltaTable

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/"source/orders.csv"
table_path=ROOT/"delta_lab/orders_by_date"

data=pa.Table.from_pandas(pd.read_csv(source),preserve_index=False)
write_deltalake(
    table_path,
    data,
    mode="overwrite",
    partition_by=["order_date"]
)

dt=DeltaTable(table_path)
print("partition columns:",dt.metadata().partition_columns)
print("files:",len(dt.file_uris()))
