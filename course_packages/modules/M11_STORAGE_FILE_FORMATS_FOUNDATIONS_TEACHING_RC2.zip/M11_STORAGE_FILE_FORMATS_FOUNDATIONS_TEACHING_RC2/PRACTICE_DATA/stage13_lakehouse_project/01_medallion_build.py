from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parent
source=ROOT/"source/orders.csv"

bronze=ROOT/"bronze/orders"
silver=ROOT/"silver/orders_clean"
gold=ROOT/"gold/region_sales"

# Bronze: preserve raw values with minimal change.
raw=pd.read_csv(source)
bronze.mkdir(parents=True,exist_ok=True)
raw.to_parquet(bronze/"part-000.parquet",index=False)

# Silver: validate/clean + typed business measure.
clean=raw.copy()
clean=clean[
    clean["order_id"].notna()
    & clean["customer_id"].notna()
    & (clean["qty"]>0)
    & (clean["unit_price"]>=0)
].copy()
clean["gross_sales"]=clean["qty"]*clean["unit_price"]
silver.mkdir(parents=True,exist_ok=True)
clean.to_parquet(silver/"part-000.parquet",index=False)

# Gold: business-facing aggregate from validated silver.
completed=clean[clean["status"]=="Completed"]
summary=(
    completed.groupby("region",as_index=False)
    .agg(orders=("order_id","nunique"),gross_sales=("gross_sales","sum"))
    .sort_values("region")
)
gold.mkdir(parents=True,exist_ok=True)
summary.to_parquet(gold/"part-000.parquet",index=False)

print(summary)
