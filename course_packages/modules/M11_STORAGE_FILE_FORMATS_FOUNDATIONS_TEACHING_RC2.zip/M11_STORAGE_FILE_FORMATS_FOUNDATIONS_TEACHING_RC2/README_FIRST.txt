M11 - Storage & File Formats Foundations - TEACHING RC2
START: 00_START_HERE_TEACHING_RC2.pdf
Reuse M05 Python. Create a module venv and install the supplied requirements only when the lab asks. No system reinstall.
Parquet/pure validation can run locally; Delta operations here use the deltalake Python library in the supplied project and must be tested in the learner environment.
