M07 CURRENT LEARNER BOOK - RC5 POST-DEPLOY SEMANTIC REPAIR

The 2026-09-11 RC5 learner book supersedes the RC4 learner-book semantic acceptance.
Use 01_LESSONS first. It now follows the explicit 16-stage beginner-first teacher route and makes external source links visibly discoverable.
All protected review / fresh retry rules remain attempt-first. Whole-course FINAL still requires runtime/device evidence.

--- Historical module instructions retained below ---

M07 CANONICAL MODULE FREEZE - QA PASS

Start: 00_START_HERE/M07_START_HERE_CANONICAL_FREEZE.pdf

This is a module-level freeze, NOT the whole-course FINAL release. Final standalone Mentor and environment/device/browser QA occur only after M00-M19 and all seven Gate families are frozen.
