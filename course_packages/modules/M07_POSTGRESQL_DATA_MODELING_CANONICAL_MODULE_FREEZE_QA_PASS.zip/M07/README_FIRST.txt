M07 CANONICAL MODULE FREEZE - QA PASS

Start: 00_START_HERE/M07_START_HERE_CANONICAL_FREEZE.pdf

This is a module-level freeze, NOT the whole-course FINAL release. Final standalone Mentor and environment/device/browser QA occur only after M00-M19 and all seven Gate families are frozen.
