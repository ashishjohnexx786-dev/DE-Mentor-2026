-- M07 MODULE PRACTICAL - UNSEEN DOMAIN: SERVICE SUBSCRIPTIONS
-- Create/connect to stage07_practical. No solution is included here.
DROP SCHEMA IF EXISTS source CASCADE; DROP SCHEMA IF EXISTS warehouse CASCADE; CREATE SCHEMA source; CREATE SCHEMA warehouse;
CREATE TABLE source.accounts(account_id text PRIMARY KEY,account_name text NOT NULL,region text NOT NULL,segment text NOT NULL);
CREATE TABLE source.plans(plan_id text PRIMARY KEY,plan_name text NOT NULL,list_price numeric(12,2) NOT NULL CHECK(list_price>=0));
CREATE TABLE source.invoices(invoice_id text PRIMARY KEY,invoice_date date NOT NULL,account_id text NOT NULL REFERENCES source.accounts(account_id),status text NOT NULL CHECK(status IN ('Paid','Open','Void')));
CREATE TABLE source.invoice_lines(invoice_id text NOT NULL REFERENCES source.invoices(invoice_id),line_no int NOT NULL CHECK(line_no>0),plan_id text NOT NULL REFERENCES source.plans(plan_id),units int NOT NULL CHECK(units>0),unit_price numeric(12,2) NOT NULL CHECK(unit_price>=0),PRIMARY KEY(invoice_id,line_no));
INSERT INTO source.accounts VALUES ('A01','Orbit Labs','India','SMB'),
('A02','CloudNine','SEA','Enterprise'),
('A03','Helix Works','EMEA','SMB'),
('A04','Vertex Co','India','Enterprise'),
('A05','Nova Systems','SEA','SMB'),
('A06','Pine Tech','EMEA','Enterprise');
INSERT INTO source.plans VALUES ('P1','Starter',500.0),
('P2','Growth',1200.0),
('P3','Scale',2500.0);
INSERT INTO source.invoices VALUES ('I401','2026-08-01','A01','Paid'),
('I402','2026-08-02','A02','Paid'),
('I403','2026-08-03','A03','Open'),
('I404','2026-08-04','A04','Paid'),
('I405','2026-08-05','A05','Void'),
('I406','2026-08-06','A06','Paid'),
('I407','2026-08-07','A01','Paid');
INSERT INTO source.invoice_lines VALUES ('I401',1,'P1',1,500.0),
('I401',2,'P1',1,100.0),
('I402',1,'P2',1,1200.0),
('I403',1,'P1',1,500.0),
('I404',1,'P3',1,2500.0),
('I404',2,'P1',2,450.0),
('I405',1,'P2',1,1200.0),
('I406',1,'P2',2,1100.0),
('I407',1,'P1',1,500.0);
-- Build a trustworthy analytical database using ONLY the Module Practical brief.
