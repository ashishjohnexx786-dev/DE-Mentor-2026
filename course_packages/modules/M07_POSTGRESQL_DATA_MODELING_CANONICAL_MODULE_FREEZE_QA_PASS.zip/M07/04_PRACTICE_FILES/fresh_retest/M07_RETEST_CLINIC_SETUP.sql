-- M07 FRESH RETEST - CHANGED DOMAIN: CLINIC DISPATCH
-- Create/connect to stage07_retest before running. This is NOT the normal retail lab.
DROP SCHEMA IF EXISTS source CASCADE; DROP SCHEMA IF EXISTS warehouse CASCADE; CREATE SCHEMA source; CREATE SCHEMA warehouse;
CREATE TABLE source.clinics(clinic_id text PRIMARY KEY,clinic_name text NOT NULL,region text NOT NULL);
CREATE TABLE source.medicines(medicine_id text PRIMARY KEY,medicine_name text NOT NULL,category text NOT NULL,list_cost numeric(12,2) NOT NULL CHECK(list_cost>=0));
CREATE TABLE source.shipments(shipment_id text PRIMARY KEY,shipment_date date NOT NULL,clinic_id text NOT NULL REFERENCES source.clinics(clinic_id),status text NOT NULL CHECK(status IN ('Delivered','Pending','Cancelled')));
CREATE TABLE source.shipment_lines(shipment_id text NOT NULL REFERENCES source.shipments(shipment_id),line_no int NOT NULL CHECK(line_no>0),medicine_id text NOT NULL REFERENCES source.medicines(medicine_id),qty int NOT NULL CHECK(qty>0),unit_cost numeric(12,2) NOT NULL CHECK(unit_cost>=0),PRIMARY KEY(shipment_id,line_no));
INSERT INTO source.clinics VALUES ('CL01','Asha Clinic','East'),
('CL02','Mitra Health','West'),
('CL03','Sanjeevani','North'),
('CL04','Nova Care','South'),
('CL05','Unity Clinic','East');
INSERT INTO source.medicines VALUES ('M01','Saline','Fluid',120.0),
('M02','Bandage','Consumable',45.0),
('M03','Gloves','Consumable',18.0),
('M04','Mask Pack','Consumable',80.0);
INSERT INTO source.shipments VALUES ('S201','2026-09-01','CL01','Delivered'),
('S202','2026-09-01','CL02','Delivered'),
('S203','2026-09-02','CL03','Pending'),
('S204','2026-09-02','CL04','Delivered'),
('S205','2026-09-03','CL05','Cancelled'),
('S206','2026-09-03','CL01','Delivered'),
('S207','2026-09-04','CL03','Delivered');
INSERT INTO source.shipment_lines VALUES ('S201',1,'M01',3,120.0),
('S201',2,'M03',10,18.0),
('S202',1,'M02',8,45.0),
('S202',2,'M04',2,80.0),
('S203',1,'M01',1,120.0),
('S204',1,'M03',20,18.0),
('S205',1,'M04',3,80.0),
('S206',1,'M02',5,45.0),
('S207',1,'M01',2,120.0),
('S207',2,'M03',5,18.0);
-- YOUR RETEST WORK BEGINS HERE: design warehouse dimensions/fact at one row per DELIVERED shipment line, then complete DE07-01..13 changed tasks from the Fresh Retest PDF.
