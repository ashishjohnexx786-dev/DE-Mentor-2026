-- DE07-05 index/EXPLAIN evidence lab
EXPLAIN SELECT * FROM source.orders WHERE customer_id='C003';
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON source.orders(customer_id);
EXPLAIN SELECT * FROM source.orders WHERE customer_id='C003';
-- Small tables may still choose Seq Scan. Record what you observe; do not force an Index Scan.
