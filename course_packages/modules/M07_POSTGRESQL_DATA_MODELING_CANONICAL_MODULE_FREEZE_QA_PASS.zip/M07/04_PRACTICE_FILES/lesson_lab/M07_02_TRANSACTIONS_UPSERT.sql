-- DE07-04 controlled transaction + UPSERT lab
BEGIN;
SELECT customer_id,region FROM source.customers WHERE customer_id='C001';
UPDATE source.customers SET region='South',updated_at=now() WHERE customer_id='C001';
SELECT customer_id,region FROM source.customers WHERE customer_id='C001';
ROLLBACK;
SELECT customer_id,region FROM source.customers WHERE customer_id='C001';

INSERT INTO source.customers(customer_id,customer_name,region,segment) VALUES ('C002','Maya Stores','West','Enterprise')
ON CONFLICT(customer_id) DO UPDATE SET customer_name=EXCLUDED.customer_name,region=EXCLUDED.region,segment=EXCLUDED.segment,updated_at=now();
