M19 Interview, Technical English & Job Launch TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf
No new engineering software is required. Use your completed independent portfolio artifacts; do not publish reference solutions or invent experience.
Job-market outcomes vary. The module trains evidence, targeting, interview performance and feedback loops; it cannot guarantee an offer or salary.
