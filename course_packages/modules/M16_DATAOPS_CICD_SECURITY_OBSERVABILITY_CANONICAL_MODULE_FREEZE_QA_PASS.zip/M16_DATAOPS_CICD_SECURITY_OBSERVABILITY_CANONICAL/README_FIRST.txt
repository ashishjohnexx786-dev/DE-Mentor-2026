M16 CANONICAL REBUILD - MODULE QA CANDIDATE

Open 00_START_HERE/M16_START_HERE.pdf first.
Do not open protected Review before a genuine saved attempt.
Live GitHub Actions and Terraform runtime are NOT claimed by package QA.
M16 -> M17 -> G06.
