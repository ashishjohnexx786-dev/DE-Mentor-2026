M09 CURRENT LEARNER BOOK - RC5 POST-DEPLOY SEMANTIC REPAIR

The 2026-09-11 RC5 learner book supersedes the RC4 learner-book semantic acceptance.
Use 01_LESSONS first. It now follows the explicit 16-stage beginner-first teacher route and makes external source links visibly discoverable.
All protected review / fresh retry rules remain attempt-first. Whole-course FINAL still requires runtime/device evidence.

--- Historical module instructions retained below ---

M09 canonical standalone module. Start at 00_START_HERE. Protected review and protected expected controls stay closed until a genuine attempt exists. Module-level freeze only; whole course is not FINAL.
