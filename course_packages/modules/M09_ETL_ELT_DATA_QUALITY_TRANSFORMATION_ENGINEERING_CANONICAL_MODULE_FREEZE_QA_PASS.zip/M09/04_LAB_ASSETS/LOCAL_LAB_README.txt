M09 local executable lab
1) Open a terminal in 04_LAB_ASSETS/scripts
2) Run: python m09_pipeline.py
3) Inspect normal/output/M09_SMOKE_RESULT.json, retailpulse.db, lineage.json, state.json
4) Baseline controls must match the Teaching Book.
5) The dbt_style_project folder is for real syntax/DAG inspection; dbt itself was not executed in this sandbox.
