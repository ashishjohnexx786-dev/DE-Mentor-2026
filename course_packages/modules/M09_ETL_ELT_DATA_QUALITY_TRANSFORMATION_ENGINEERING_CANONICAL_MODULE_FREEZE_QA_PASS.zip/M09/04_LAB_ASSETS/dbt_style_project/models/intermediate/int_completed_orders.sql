select *, qty * unit_price as line_revenue from {{ ref('stg_orders') }} where status = 'Completed'
