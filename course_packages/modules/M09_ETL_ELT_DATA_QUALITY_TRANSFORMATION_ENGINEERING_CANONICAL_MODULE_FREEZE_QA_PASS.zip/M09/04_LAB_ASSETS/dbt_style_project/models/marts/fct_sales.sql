{{ config(materialized='incremental', unique_key='order_id', on_schema_change='fail') }}
select * from {{ ref('int_completed_orders') }}
{% if is_incremental() %}
where updated_at >= (select coalesce(max(updated_at),'1900-01-01') from {{ this }})
{% endif %}
