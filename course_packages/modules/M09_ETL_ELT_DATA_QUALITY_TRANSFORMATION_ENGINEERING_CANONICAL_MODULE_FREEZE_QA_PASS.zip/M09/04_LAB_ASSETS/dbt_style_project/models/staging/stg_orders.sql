select order_id, customer_id, order_date, region, status, cast(qty as integer) as qty, cast(unit_price as real) as unit_price, updated_at from {{ source('raw','raw_orders') }}
