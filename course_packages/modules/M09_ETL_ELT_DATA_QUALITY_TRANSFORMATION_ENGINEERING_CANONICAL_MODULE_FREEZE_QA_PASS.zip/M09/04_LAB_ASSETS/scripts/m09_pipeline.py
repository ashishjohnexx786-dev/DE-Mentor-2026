#!/usr/bin/env python3
from pathlib import Path
import csv, json, sqlite3, hashlib, sys
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]
IN=ROOT/'normal/input'; OUT=ROOT/'normal/output'; OUT.mkdir(parents=True,exist_ok=True)
DB=OUT/'retailpulse.db'; STATE=OUT/'state.json'; RUNS=OUT/'run_metadata.jsonl'
SCHEMA=['order_id','customer_id','order_date','region','status','qty','unit_price','updated_at']
REGIONS={'East','West','North','South'}; STATUSES={'Completed','Cancelled'}
def iso(s): return datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(timezone.utc)
def valid_date(s):
    try: datetime.strptime(s,'%Y-%m-%d'); return True
    except: return False
def load_csv(path):
    with path.open(newline='',encoding='utf-8') as f:
      r=csv.DictReader(f); return r.fieldnames,list(r)
def validate_row(row):
    errs=[]
    if not row.get('order_id'): errs.append('order_id_required')
    if not row.get('customer_id'): errs.append('customer_id_required')
    if not valid_date(row.get('order_date','')): errs.append('order_date_invalid')
    if row.get('region') not in REGIONS: errs.append('region_invalid')
    if row.get('status') not in STATUSES: errs.append('status_invalid')
    try:
      q=int(row.get('qty','')); p=float(row.get('unit_price',''))
      if q<=0: errs.append('qty_nonpositive')
      if p<0: errs.append('price_negative')
    except: errs.append('numeric_invalid')
    try: iso(row.get('updated_at',''))
    except: errs.append('updated_at_invalid')
    return errs
def init_db():
    if DB.exists(): DB.unlink()
    con=sqlite3.connect(DB); c=con.cursor()
    c.executescript('''
    CREATE TABLE raw_orders(order_id TEXT,customer_id TEXT,order_date TEXT,region TEXT,status TEXT,qty TEXT,unit_price TEXT,updated_at TEXT,source_file TEXT);
    CREATE TABLE quarantine(order_id TEXT,reason TEXT,source_file TEXT);
    CREATE TABLE stg_orders(order_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,order_date TEXT NOT NULL,region TEXT NOT NULL,status TEXT NOT NULL,qty INTEGER NOT NULL,unit_price REAL NOT NULL,updated_at TEXT NOT NULL,line_revenue REAL NOT NULL);
    CREATE TABLE fct_sales(order_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,order_date TEXT NOT NULL,region TEXT NOT NULL,qty INTEGER NOT NULL,line_revenue REAL NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE run_audit(run_id TEXT PRIMARY KEY,source_file TEXT,source_rows INTEGER,accepted_rows INTEGER,quarantine_rows INTEGER,serving_rows INTEGER,serving_revenue REAL,state_before TEXT,state_after TEXT,status TEXT);
    '''); con.commit(); con.close()
def transform_file(path, run_id, incremental=False, fail_on_quarantine=False):
    fields,rows=load_csv(path)
    schema_ok=fields==SCHEMA
    if not schema_ok: raise ValueError('schema_mismatch')
    state=json.loads(STATE.read_text()) if STATE.exists() else {'watermark':'1900-01-01T00:00:00Z'}
    state_before=state['watermark']; wm=iso(state_before)
    selected=[r for r in rows if (not incremental or iso(r['updated_at'])>wm)]
    # do validation before state advance
    accepted=[]; quarantine=[]; seen=set()
    for r in selected:
      fingerprint=tuple(r[k] for k in SCHEMA)
      if fingerprint in seen: quarantine.append((r,'exact_duplicate')); continue
      seen.add(fingerprint)
      errs=validate_row(r)
      if errs: quarantine.append((r,'|'.join(errs))); continue
      accepted.append(r)
    if fail_on_quarantine and quarantine:
      # Proven atomic-state rule: no destination/state mutation.
      return {'run_id':run_id,'status':'FAILED_VALIDATION','selected':len(selected),'accepted':len(accepted),'quarantine':len(quarantine),'state_before':state_before,'state_after':state_before}
    con=sqlite3.connect(DB); c=con.cursor(); c.execute('BEGIN')
    for r in selected:
      c.execute('INSERT INTO raw_orders VALUES (?,?,?,?,?,?,?,?,?)',tuple(r[k] for k in SCHEMA)+(path.name,))
    for r,reason in quarantine:
      c.execute('INSERT INTO quarantine VALUES (?,?,?)',(r.get('order_id'),reason,path.name))
    for r in accepted:
      q=int(r['qty']); price=float(r['unit_price']); rev=round(q*price,2)
      c.execute('''INSERT INTO stg_orders VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET customer_id=excluded.customer_id,order_date=excluded.order_date,region=excluded.region,status=excluded.status,qty=excluded.qty,unit_price=excluded.unit_price,updated_at=excluded.updated_at,line_revenue=excluded.line_revenue''',(r['order_id'],r['customer_id'],r['order_date'],r['region'],r['status'],q,price,r['updated_at'],rev))
      if r['status']=='Completed':
        c.execute('''INSERT INTO fct_sales VALUES (?,?,?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET customer_id=excluded.customer_id,order_date=excluded.order_date,region=excluded.region,qty=excluded.qty,line_revenue=excluded.line_revenue,updated_at=excluded.updated_at''',(r['order_id'],r['customer_id'],r['order_date'],r['region'],q,rev,r['updated_at']))
      else: c.execute('DELETE FROM fct_sales WHERE order_id=?',(r['order_id'],))
    new_state=max([state_before]+[r['updated_at'] for r in accepted])
    serving=c.execute('SELECT COUNT(*),ROUND(COALESCE(SUM(line_revenue),0),2) FROM fct_sales').fetchone()
    c.execute('INSERT INTO run_audit VALUES (?,?,?,?,?,?,?,?,?,?)',(run_id,path.name,len(selected),len(accepted),len(quarantine),serving[0],serving[1],state_before,new_state,'PASS'))
    con.commit(); con.close(); STATE.write_text(json.dumps({'watermark':new_state},indent=2))
    return {'run_id':run_id,'status':'PASS','selected':len(selected),'accepted':len(accepted),'quarantine':len(quarantine),'state_before':state_before,'state_after':new_state,'serving_rows':serving[0],'serving_revenue':serving[1]}
def tests():
    con=sqlite3.connect(DB); c=con.cursor(); out={}
    out['unique_order_id']=c.execute('SELECT COUNT(*)=COUNT(DISTINCT order_id) FROM fct_sales').fetchone()[0]==1
    out['not_null_customer']=c.execute("SELECT COUNT(*)=0 FROM fct_sales WHERE customer_id IS NULL OR TRIM(customer_id)='' ").fetchone()[0]==1
    out['positive_revenue']=c.execute('SELECT COUNT(*)=0 FROM fct_sales WHERE line_revenue < 0').fetchone()[0]==1
    out['reconcile_rows']=c.execute("SELECT (SELECT COUNT(*) FROM fct_sales)=(SELECT COUNT(*) FROM stg_orders WHERE status='Completed')").fetchone()[0]==1
    out['reconcile_revenue']=c.execute("SELECT ROUND((SELECT SUM(line_revenue) FROM fct_sales),2)=ROUND((SELECT SUM(line_revenue) FROM stg_orders WHERE status='Completed'),2)").fetchone()[0]==1
    con.close(); return out
def lineage():
  return {'nodes':['raw_orders','stg_orders','fct_sales'],'edges':[['retail_orders_raw.csv','raw_orders'],['raw_orders','stg_orders'],['stg_orders','fct_sales']], 'grain':{'raw_orders':'one received source row','stg_orders':'one accepted current row per order_id','fct_sales':'one completed current row per order_id'}}
def main():
    init_db();
    if STATE.exists(): STATE.unlink()
    baseline=transform_file(IN/'retail_orders_raw.csv','RUN_BASELINE',False)
    incr=transform_file(IN/'retail_orders_incremental.csv','RUN_INCREMENTAL',True)
    rerun=transform_file(IN/'retail_orders_incremental.csv','RUN_INCREMENTAL_RERUN',True)
    state_before=json.loads(STATE.read_text())['watermark']
    fail=transform_file(IN/'retail_orders_failure_batch.csv','RUN_FAILURE',True,True)
    state_after=json.loads(STATE.read_text())['watermark']
    con=sqlite3.connect(DB); c=con.cursor()
    summary={'baseline':baseline,'incremental':incr,'rerun':rerun,'failure':fail,'failure_state_unchanged':state_before==state_after,'tests':tests(),'lineage':lineage(),'quarantine_total':c.execute('SELECT COUNT(*) FROM quarantine').fetchone()[0],'serving_by_region':c.execute('SELECT region,COUNT(*),ROUND(SUM(line_revenue),2) FROM fct_sales GROUP BY region ORDER BY region').fetchall(),'audit_runs':c.execute('SELECT COUNT(*) FROM run_audit').fetchone()[0]}
    con.close()
    (OUT/'M09_SMOKE_RESULT.json').write_text(json.dumps(summary,indent=2))
    (OUT/'lineage.json').write_text(json.dumps(summary['lineage'],indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
