from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
spark=build_spark("DE14-01")
try:
    sc=spark.sparkContext
    print("master:",sc.master)
    print("defaultParallelism:",sc.defaultParallelism)
    df=spark.range(0,20,1,numPartitions=4)
    print("partitions:",df.rdd.getNumPartitions())
    print(df.rdd.mapPartitionsWithIndex(lambda idx,it: [(idx,sum(1 for _ in it))]).collect())
finally:
    spark.stop()
