from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
from pyspark.sql import functions as F
spark=build_spark("DE14-Cache")
try:
    base=spark.range(0,500000,1,numPartitions=4).withColumn("bucket",F.col("id") % 100)
    reused=base.filter(F.col("id") % 2 == 0).cache()
    print("storage level after cache call:",reused.storageLevel)
    print("action 1:",reused.count())
    print("action 2:",reused.groupBy("bucket").count().count())
    reused.unpersist()
    print("storage level after unpersist:",reused.storageLevel)
finally:
    spark.stop()
