from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
spark=build_spark("DE14-Partitions")
try:
    df=spark.range(0,1000,1,numPartitions=4)
    print("start:",df.rdd.getNumPartitions())
    r=df.repartition(8)
    print("repartition(8):",r.rdd.getNumPartitions())
    r.explain(mode="formatted")
    c=r.coalesce(2)
    print("coalesce(2):",c.rdd.getNumPartitions())
    c.explain(mode="formatted")
finally:
    spark.stop()
