"""DE14 driver-safety exercise.

Do NOT start by calling collect() on a huge dataset.

1. Create spark.range(0, 10_000_000).
2. Explain why collecting every row moves all result data to the DRIVER.
3. Use count(), show(), take(20) or bounded aggregate instead.
4. Only collect when the result is known to be small.

Write your safer code below.
"""
