from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
from pyspark.sql import functions as F
spark=build_spark("DE14-Lazy")
try:
    df=spark.range(0,100000,1,numPartitions=4)
    transformed=(
        df.filter((F.col("id") % 2)==0)
          .withColumn("bucket",F.col("id") % 10)
          .groupBy("bucket").count()
    )
    print("No action has been requested yet.")
    transformed.explain(mode="formatted")
    print("ACTION: collect")
    print(transformed.orderBy("bucket").collect())
finally:
    spark.stop()
