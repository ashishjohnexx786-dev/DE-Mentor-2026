from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from pathlib import Path
from pyspark.sql import functions as F, types as T
from src.spark_session import build_spark
ROOT=Path(__file__).resolve().parents[1]
schema=T.StructType([
 T.StructField("order_id",T.StringType(),False),
 T.StructField("order_date",T.DateType(),False),
 T.StructField("customer_id",T.StringType(),False),
 T.StructField("product_id",T.StringType(),False),
 T.StructField("qty",T.IntegerType(),False),
 T.StructField("unit_price",T.DoubleType(),False),
 T.StructField("status",T.StringType(),False),
])
spark=build_spark("DE14-03")
try:
    df=spark.read.option("header",True).schema(schema).csv(str(ROOT/"data/raw/orders.csv"))
    df.printSchema()
    df.createOrReplaceTempView("orders")
    (
      df.select("order_id","status","qty","unit_price")
        .filter(F.col("status")=="Completed")
        .withColumn("gross_sales",F.col("qty")*F.col("unit_price"))
        .show(5,truncate=False)
    )
    spark.sql("""
      SELECT order_id, qty * unit_price AS gross_sales
      FROM orders
      WHERE status='Completed'
      ORDER BY order_id
      LIMIT 5
    """).show()
finally:
    spark.stop()
