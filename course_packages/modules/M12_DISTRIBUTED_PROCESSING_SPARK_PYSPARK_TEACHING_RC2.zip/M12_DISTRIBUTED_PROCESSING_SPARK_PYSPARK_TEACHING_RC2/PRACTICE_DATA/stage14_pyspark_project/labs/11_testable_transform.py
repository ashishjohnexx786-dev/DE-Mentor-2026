from pyspark.sql import functions as F

def completed_sales(df):
    return (
        df
        .filter(F.col("status")=="Completed")
        .filter((F.col("qty")>0) & (F.col("unit_price")>=0))
        .withColumn("gross_sales",F.round(F.col("qty")*F.col("unit_price"),2))
    )
