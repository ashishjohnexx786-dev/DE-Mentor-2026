from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
from pyspark.sql import functions as F
spark=build_spark("DE14-Skew")
try:
    df=(
        spark.range(0,20000,1,numPartitions=4)
        .withColumn(
            "join_key",
            F.when(F.col("id") < 18000,F.lit("HOT"))
             .otherwise(F.concat(F.lit("COLD-"),(F.col("id") % 20).cast("string")))
        )
    )
    df.groupBy("join_key").count().orderBy(F.desc("count")).show(25,truncate=False)
    print("AQE enabled:",spark.conf.get("spark.sql.adaptive.enabled"))
    print("skew join enabled:",spark.conf.get("spark.sql.adaptive.skewJoin.enabled"))
finally:
    spark.stop()
