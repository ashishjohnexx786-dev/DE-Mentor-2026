from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
from pyspark.sql import functions as F
spark=build_spark("DE14-Join")
try:
    fact=spark.range(0,100000,1,numPartitions=4).withColumn("key",(F.col("id") % 100).cast("int"))
    dim=spark.createDataFrame([(i,f"label-{i}") for i in range(100)],["key","label"])
    joined=fact.join(F.broadcast(dim),on="key",how="left")
    joined.groupBy("label").count().explain(mode="formatted")
    print("rows:",joined.count())
finally:
    spark.stop()
