from pathlib import Path as _BootstrapPath
import sys as _bootstrap_sys
_PROJECT_ROOT=_BootstrapPath(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0,str(_PROJECT_ROOT))

from src.spark_session import build_spark
from pyspark.sql import functions as F
spark=build_spark("DE14-Shuffle")
try:
    df=spark.range(0,100000,1,numPartitions=4).withColumn("group_key",F.col("id") % 20)
    agg=df.groupBy("group_key").count()
    agg.explain(mode="formatted")
    print(agg.orderBy("group_key").collect())
finally:
    spark.stop()
