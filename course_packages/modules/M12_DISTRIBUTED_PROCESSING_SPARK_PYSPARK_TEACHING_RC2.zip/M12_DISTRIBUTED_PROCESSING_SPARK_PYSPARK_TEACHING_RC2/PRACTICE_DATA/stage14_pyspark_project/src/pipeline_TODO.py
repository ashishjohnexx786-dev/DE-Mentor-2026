"""DE14-12 independent project.

Requirements:
- explicit schemas; no inferSchema in final solution
- filter Completed only
- validate qty > 0 and unit_price >= 0
- gross_sales = qty * unit_price
- join customer and product dimensions
- use broadcast only after explaining why dimensions are small
- no null region/category after joins
- aggregate revenue by region and category
- write enriched output as partitioned Parquet by order_date
- inspect partitions + explain(mode="formatted")
- prove 16 completed rows and total gross sales 25230.00
"""
