from pathlib import Path
import sys

_PROJECT_ROOT=Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0,str(_PROJECT_ROOT))
from pyspark.sql import functions as F
from pyspark.sql import types as T
from src.spark_session import build_spark

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/"data/raw"
OUT=ROOT/"data/output"

ORDER_SCHEMA=T.StructType([
    T.StructField("order_id",T.StringType(),False),
    T.StructField("order_date",T.DateType(),False),
    T.StructField("customer_id",T.StringType(),False),
    T.StructField("product_id",T.StringType(),False),
    T.StructField("qty",T.IntegerType(),False),
    T.StructField("unit_price",T.DoubleType(),False),
    T.StructField("status",T.StringType(),False),
])
CUSTOMER_SCHEMA=T.StructType([
    T.StructField("customer_id",T.StringType(),False),
    T.StructField("customer_name",T.StringType(),False),
    T.StructField("region",T.StringType(),False),
    T.StructField("segment",T.StringType(),False),
])
PRODUCT_SCHEMA=T.StructType([
    T.StructField("product_id",T.StringType(),False),
    T.StructField("product_name",T.StringType(),False),
    T.StructField("category",T.StringType(),False),
    T.StructField("list_price",T.DoubleType(),False),
])

def main():
    spark=build_spark("Stage14IntegratedPipeline")
    try:
        orders=spark.read.option("header",True).schema(ORDER_SCHEMA).csv(str(RAW/"orders.csv"))
        customers=spark.read.option("header",True).schema(CUSTOMER_SCHEMA).csv(str(RAW/"customers.csv"))
        products=spark.read.option("header",True).schema(PRODUCT_SCHEMA).csv(str(RAW/"products.csv"))

        clean=(
            orders
            .filter(F.col("status")=="Completed")
            .filter((F.col("qty")>0) & (F.col("unit_price")>=0))
            .withColumn("gross_sales",F.round(F.col("qty")*F.col("unit_price"),2))
        )

        enriched=(
            clean
            .join(F.broadcast(customers),on="customer_id",how="left")
            .join(F.broadcast(products),on="product_id",how="left")
        )

        if enriched.filter(F.col("region").isNull() | F.col("category").isNull()).limit(1).count():
            raise RuntimeError("dimension lookup failed")

        region_summary=(
            enriched.groupBy("region")
            .agg(
                F.countDistinct("order_id").alias("orders"),
                F.round(F.sum("gross_sales"),2).alias("gross_sales")
            )
            .orderBy("region")
        )
        category_summary=(
            enriched.groupBy("category")
            .agg(F.round(F.sum("gross_sales"),2).alias("gross_sales"))
            .orderBy("category")
        )

        OUT.mkdir(parents=True,exist_ok=True)
        (
            enriched
            .repartition("order_date")
            .write
            .mode("overwrite")
            .partitionBy("order_date")
            .parquet(str(OUT/"orders_enriched"))
        )
        region_summary.coalesce(1).write.mode("overwrite").parquet(str(OUT/"region_summary"))
        category_summary.coalesce(1).write.mode("overwrite").parquet(str(OUT/"category_summary"))

        completed_rows=clean.count()
        total=clean.agg(F.round(F.sum("gross_sales"),2)).first()[0]
        if completed_rows != 16 or float(total) != 25230.0:
            raise RuntimeError(f"reconciliation failed rows={completed_rows} total={total}")

        print("completed_rows=",completed_rows)
        print("total_sales=",total)
        print("enriched_partitions=",enriched.rdd.getNumPartitions())
        print("REGION SUMMARY")
        region_summary.show(truncate=False)
        print("CATEGORY SUMMARY")
        category_summary.show(truncate=False)
        print("PHYSICAL PLAN")
        enriched.groupBy("region").agg(F.sum("gross_sales")).explain(mode="formatted")
    finally:
        spark.stop()

if __name__=="__main__":
    main()
