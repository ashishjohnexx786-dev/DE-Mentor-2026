from pathlib import Path
import csv,json
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]

def read(name):
    with (ROOT/"data/raw"/name).open(newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))

orders=read("orders.csv")
customers={r["customer_id"]:r for r in read("customers.csv")}
products={r["product_id"]:r for r in read("products.csv")}
completed=[r for r in orders if r["status"]=="Completed" and int(r["qty"])>0 and float(r["unit_price"])>=0]

region=defaultdict(float); category=defaultdict(float)
for r in completed:
    gross=int(r["qty"])*float(r["unit_price"])
    region[customers[r["customer_id"]]["region"]]+=gross
    category[products[r["product_id"]]["category"]]+=gross

expected={
  "source_rows":len(orders),
  "completed_rows":len(completed),
  "total_gross_sales":round(sum(int(r["qty"])*float(r["unit_price"]) for r in completed),2),
  "region_sales":{k:round(v,2) for k,v in sorted(region.items())},
  "category_sales":{k:round(v,2) for k,v in sorted(category.items())},
}
print(json.dumps(expected,indent=2))
assert expected=={
  "source_rows":18,
  "completed_rows":16,
  "total_gross_sales":25230.0,
  "region_sales":{"East":5950.0,"North":6380.0,"South":6000.0,"West":6900.0},
  "category_sales":{"Accessories":16830.0,"Office":8400.0}
}
