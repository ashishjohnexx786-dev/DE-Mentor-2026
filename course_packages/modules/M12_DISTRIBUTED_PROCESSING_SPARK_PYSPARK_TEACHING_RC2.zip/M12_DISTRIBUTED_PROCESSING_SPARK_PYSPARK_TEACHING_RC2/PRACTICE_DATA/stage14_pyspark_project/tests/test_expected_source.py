import unittest,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class TestSourceExpected(unittest.TestCase):
    def test_expected(self):
        with (ROOT/"data/raw/orders.csv").open(newline="",encoding="utf-8") as f:
            rows=list(csv.DictReader(f))
        completed=[r for r in rows if r["status"]=="Completed"]
        total=sum(int(r["qty"])*float(r["unit_price"]) for r in completed)
        self.assertEqual(len(rows),18)
        self.assertEqual(len(completed),16)
        self.assertEqual(total,25230.0)
if __name__=="__main__":
    unittest.main()
