"""DE14 testing task.

Create a tiny input DataFrame with:
- one Completed valid row
- one Cancelled row
- one invalid qty row

Apply labs/11_testable_transform.completed_sales.
Assert only the valid Completed row remains and gross_sales is correct.
"""
