M12 - Distributed Processing with Spark & PySpark - TEACHING RC2
START: 00_START_HERE_TEACHING_RC2.pdf
Create a fresh module venv and install the supplied PySpark requirement. Verify Java/PySpark with a tiny local[2] session before changing Java/system setup.
Spark live runtime depends on local Java/PySpark compatibility. Independent source-control totals are included so correctness can be checked separately from Spark reference code.
