-- M03 MySQL Advanced SQL workspace - DE03-01 through DE03-10
USE stage03_retail_lab;
-- Save genuine first attempts before opening the protected review.

-- DE03-01 INNER JOIN and LEFT JOIN
-- TASK: List Completed West orders with order_id, customer_name, tier and net_sales. Then LEFT JOIN returns and show all Completed orders with optional return_id.
-- VALIDATE: No non-West/non-Completed rows in the first query. Second query preserves the Completed order count; returned orders have return_id and others are NULL.
-- YOUR SQL / EVIDENCE:


-- DE03-02 Cardinality, row multiplication and join validation
-- TASK: Build a one-row-per-customer contact_count CTE/subquery, join it to orders, and prove the order row count stays 30.
-- VALIDATE: Output key order_id remains unique; row count is 30; contact_count can exceed 1 without duplicating orders.
-- YOUR SQL / EVIDENCE:


-- DE03-03 UNION and UNION ALL
-- TASK: Create a second two-branch result with intentionally duplicated labels, compare UNION with UNION ALL, and record the row-count difference.
-- VALIDATE: You can explain exactly which duplicate combination UNION removed and why.
-- YOUR SQL / EVIDENCE:


-- DE03-04 String functions for cleaning and standardization
-- TASK: Create customer_name_clean and a display label while preserving raw customer_name. Filter names containing Stores or Traders.
-- VALIDATE: Raw and transformed names remain visible; the filter returns only names matching the intended text rule.
-- YOUR SQL / EVIDENCE:


-- DE03-05 Dates, timestamps and time analysis
-- TASK: Summarize Completed net_sales by order_date and identify the dates with the highest daily total. Explain what would change if order timestamps arrived from multiple timezones.
-- VALIDATE: Daily groups reconcile back to the Completed net-sales total; timezone limitation is stated rather than guessed.
-- YOUR SQL / EVIDENCE:


-- DE03-06 Subqueries and nested logic
-- TASK: Find customers whose Completed net_sales total is above the average customer Completed total. Build/validate the customer-total layer first.
-- VALIDATE: State inner and outer grain separately and reconcile customer totals to overall Completed net_sales.
-- YOUR SQL / EVIDENCE:


-- DE03-07 CTEs and readable multi-step SQL
-- TASK: Rewrite your DE03-06 customer-above-average solution with named CTEs and add a final validation CTE/result.
-- VALIDATE: Every CTE has a written grain comment and totals reconcile.
-- YOUR SQL / EVIDENCE:


-- DE03-08 Window functions and PARTITION BY
-- TASK: Add each customer's Completed order count and customer net-sales total beside each of their Completed orders.
-- VALIDATE: Detail row count stays 27; a separate GROUP BY customer query matches the window totals.
-- YOUR SQL / EVIDENCE:


-- DE03-09 ROW_NUMBER, ranking and LAG/LEAD
-- TASK: Rank Completed orders by net_sales within region and return top 2 per region with deterministic order_id tie-breaker.
-- VALIDATE: At most 2 rows/region; order ranking is reproducible; compare each region maximum manually/separately.
-- YOUR SQL / EVIDENCE:


-- DE03-10 Advanced aggregation and multi-grain reasoning
-- TASK: Create region metrics: Completed orders, Completed net_sales, returned orders, ticket count. Use separate grain-safe CTEs and combine at one row/region.
-- VALIDATE: 4 final rows; each component total reconciles independently; document any customer-to-region assumption.
-- YOUR SQL / EVIDENCE:

