-- ZERO TO JOB-READY DATA ENGINEER 2026
-- M03 PostgreSQL mini-lab - DE03-11 through DE03-14 only
-- Purpose: setup/dialect awareness + constraints/transactions + EXPLAIN/index + views.
-- M07 later owns deeper PostgreSQL data modeling, star schema, SCD and surrogate-key work.
-- Run inside a PostgreSQL database you create for the course (recommended name: m03_de).

CREATE SCHEMA IF NOT EXISTS m03pg;
DROP VIEW IF EXISTS m03pg.v_customer_order_summary;
DROP VIEW IF EXISTS m03pg.v_completed_order_value;
DROP TABLE IF EXISTS m03pg.support_cases CASCADE;
DROP TABLE IF EXISTS m03pg.order_items CASCADE;
DROP TABLE IF EXISTS m03pg.orders CASCADE;
DROP TABLE IF EXISTS m03pg.customers CASCADE;

CREATE TABLE m03pg.customers (
  customer_id text PRIMARY KEY,
  customer_name text NOT NULL,
  region text NOT NULL CHECK (region IN ('East','West','North','South'))
);

CREATE TABLE m03pg.orders (
  order_id text PRIMARY KEY,
  order_date date NOT NULL,
  customer_id text NOT NULL REFERENCES m03pg.customers(customer_id),
  status text NOT NULL CHECK (status IN ('Completed','Pending','Cancelled'))
);

CREATE TABLE m03pg.order_items (
  order_id text NOT NULL REFERENCES m03pg.orders(order_id),
  line_no integer NOT NULL CHECK (line_no > 0),
  product text NOT NULL,
  qty integer NOT NULL CHECK (qty > 0),
  unit_price numeric(10,2) NOT NULL CHECK (unit_price >= 0),
  PRIMARY KEY (order_id,line_no)
);

CREATE TABLE m03pg.support_cases (
  case_id text PRIMARY KEY,
  customer_id text NOT NULL REFERENCES m03pg.customers(customer_id),
  opened_at timestamptz NOT NULL,
  severity text NOT NULL CHECK (severity IN ('Low','Medium','High','Critical')),
  status text NOT NULL CHECK (status IN ('Open','Closed'))
);

INSERT INTO m03pg.customers VALUES
('PC001','Aarav Traders','East'),('PC002','Maya Stores','West'),
('PC003','Ravi Retail','North'),('PC004','Neha Mart','South'),
('PC005','Sona Shop','East'),('PC006','Kiran Enterprises','West'),
('PC007','Om Retail','North'),('PC008','Tara Stores','South');

INSERT INTO m03pg.orders VALUES
('P1001','2026-08-01','PC001','Completed'),('P1002','2026-08-01','PC002','Completed'),
('P1003','2026-08-02','PC003','Completed'),('P1004','2026-08-02','PC004','Pending'),
('P1005','2026-08-03','PC005','Completed'),('P1006','2026-08-03','PC006','Completed'),
('P1007','2026-08-04','PC001','Completed'),('P1008','2026-08-04','PC003','Cancelled'),
('P1009','2026-08-05','PC007','Completed'),('P1010','2026-08-05','PC008','Completed'),
('P1011','2026-08-06','PC003','Completed'),('P1012','2026-08-06','PC005','Completed');

INSERT INTO m03pg.order_items VALUES
('P1001',1,'Keyboard',2,850),('P1001',2,'Mouse',1,450),
('P1002',1,'Laptop Stand',2,1200),('P1003',1,'USB Cable',5,220),
('P1004',1,'Keyboard',1,850),('P1005',1,'Mouse',4,450),
('P1006',1,'Laptop Stand',1,1200),('P1007',1,'Keyboard',2,850),
('P1008',1,'Mouse',3,450),('P1009',1,'USB Cable',8,220),
('P1010',1,'Keyboard',1,850),('P1011',1,'Laptop Stand',2,1200),
('P1012',1,'Mouse',5,450),('P1012',2,'USB Cable',2,220);

INSERT INTO m03pg.support_cases VALUES
('S001','PC001','2026-08-01 09:00+05:30','High','Closed'),
('S002','PC003','2026-08-02 10:30+05:30','Critical','Open'),
('S003','PC003','2026-08-05 15:00+05:30','Medium','Closed'),
('S004','PC005','2026-08-04 11:15+05:30','High','Open'),
('S005','PC008','2026-08-06 16:30+05:30','Low','Closed');

-- Baseline verification; record observed results.
SELECT COUNT(*) AS customers FROM m03pg.customers;      -- expected 8
SELECT COUNT(*) AS orders FROM m03pg.orders;            -- expected 12
SELECT COUNT(*) AS order_lines FROM m03pg.order_items;  -- expected 14
SELECT COUNT(*) AS support_cases FROM m03pg.support_cases; -- expected 5
