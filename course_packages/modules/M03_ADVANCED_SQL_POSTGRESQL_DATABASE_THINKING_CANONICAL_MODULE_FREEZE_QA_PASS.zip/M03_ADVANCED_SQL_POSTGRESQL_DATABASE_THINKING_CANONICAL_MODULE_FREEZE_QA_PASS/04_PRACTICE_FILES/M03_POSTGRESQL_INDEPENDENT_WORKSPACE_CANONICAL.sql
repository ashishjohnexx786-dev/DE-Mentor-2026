-- M03 PostgreSQL mini-lab workspace - DE03-11 through DE03-14
SET search_path TO m03pg, public;
-- Do not copy solutions from the review.

-- DE03-11 PostgreSQL setup, schemas and dialect awareness
-- TASK: In a fresh query tab, set search_path and return order_id,customer_id,status from m03pg.orders. Write two syntax/function differences you have actually observed or verified between the MySQL and PostgreSQL labs.
-- VALIDATE: Query runs in PostgreSQL, not MySQL; result has 12 rows; dialect notes are evidence-based rather than invented.
-- YOUR SQL / EVIDENCE:


-- DE03-12 Constraints and transactions
-- TASK: Insert one valid support_case inside BEGIN; inspect it; ROLLBACK; prove row count returns to the baseline. Explain which constraint protects each critical field.
-- VALIDATE: Baseline row count restored after rollback; no invalid row persists.
-- YOUR SQL / EVIDENCE:


-- DE03-13 Indexes and EXPLAIN basics
-- TASK: Choose one repeated filter/join column from the mini-lab, justify whether an index is sensible, create it only if justified, and save before/after EXPLAIN plus one downside.
-- VALIDATE: Evidence includes the actual index definition and plans; explanation does not equate “index exists” with “query is faster.”
-- YOUR SQL / EVIDENCE:


-- DE03-14 Views and reusable database logic
-- TASK: Create a view m03pg.v_customer_order_summary at one row/customer with order_count and gross_sales. State dependencies and one limitation.
-- VALIDATE: One row/customer with activity; sum of gross_sales matches an independent aggregate over eligible source rows.
-- YOUR SQL / EVIDENCE:

