-- M03 PROTECTED INTEGRATED / TIMED ASSESSMENT WORKSPACE
-- DE03-15 and DE03-16. Keep videos, review and AI solving closed during the attempt.
-- Preserve first attempt. Do not overwrite failure evidence.

-- DE03-15 INTEGRATED UNSEEN CHALLENGE
-- A. MySQL: one-row/customer priority table using order totals + ticket metrics; no fan-out.
-- B. Include latest ticket deterministically and rank customers by Completed net_sales.
-- C. Save at least two independent reconciliations.
-- D. PostgreSQL: prove one rollback; one justified index/EXPLAIN comparison; one reusable view.
-- E. Write a 3-minute defense note: grain, fan-out risk, validation, PostgreSQL choice, limitation.

-- DE03-16 TIMED SET (45 MIN SQL + explanation)
-- 1. Diagnose why a raw order-to-contact join can inflate rows and money.
-- 2. Top 2 Completed non-returned orders per region by net_sales; deterministic tie-break.
-- 3. Latest support ticket per customer.
-- 4. Region Completed net_sales + returned-order rate without multiplication.
-- 5. Explain ROLLBACK and one observed EXPLAIN difference.
-- 6. Defend when a view is useful and when it is not a performance solution.
