M13 - Delta Lakehouse - TEACHING RC2
START: 00_START_HERE_TEACHING_RC2.pdf
Use the supplied pinned PySpark 4.0.0 + delta-spark 4.0.0 training requirements in a fresh venv. Run delta_runtime_probe.py before reinstalling/changing versions.
Offline script validation is possible in this build environment; live Delta/Spark commits, history and replay must be executed on learner PC before runtime completion.
