from pathlib import Path
import json,sys,py_compile
p=Path(sys.argv[1] if len(sys.argv)>1 else '.');checks=[];code=(p/'delta_job.py').read_text() if (p/'delta_job.py').exists() else ''
try:py_compile.compile(str(p/'delta_job.py'),doraise=True);checks.append(('syntax',True))
except:checks.append(('syntax',False))
for tok in ['format','delta','DeltaTable','merge','whenMatched','whenNotMatched','bronze','silver','gold','history']:checks.append((tok,tok.lower() in code.lower()))
try:s=json.loads((p/'result_summary.json').read_text())
except:s={}
exp={'update_rows':2,'update_unique_members':2,'silver_members':4,'gold_plans':2,'rerun_silver_members':4,'latest_table_version':2}
for k,v in exp.items():checks.append((f'{k}={v}',s.get(k)==v))
r=(p/'reasoning.md').read_text().lower() if (p/'reasoning.md').exists() else ''
for tok in ['merge','schema','rerun','layer']:checks.append((f'reason {tok}',tok in r and len(r)>220))
checks.append(('history evidence',len((p/'history.txt').read_text())>80 if (p/'history.txt').exists() else False))
print(f'{sum(v for _,v in checks)}/{len(checks)} checks passed');[print(('PASS' if v else 'FAIL'),n) for n,v in checks];raise SystemExit(0 if all(v for _,v in checks) else 1)
