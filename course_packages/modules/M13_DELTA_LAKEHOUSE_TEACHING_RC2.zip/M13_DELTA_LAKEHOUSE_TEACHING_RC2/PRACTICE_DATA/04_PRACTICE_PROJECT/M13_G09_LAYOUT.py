from delta_session import get_spark
from pathlib import Path
import shutil
s=get_spark('G09');p='output/g09';shutil.rmtree(p,ignore_errors=True);df=s.range(100).withColumnRenamed('id','event_id');df.repartition(4).write.format('delta').save(p);files=list(Path(p).glob('*.parquet'));print('DATA_FILES',len(files));print('LOG_FILES',len(list(Path(p,'_delta_log').glob('*'))));s.stop()
