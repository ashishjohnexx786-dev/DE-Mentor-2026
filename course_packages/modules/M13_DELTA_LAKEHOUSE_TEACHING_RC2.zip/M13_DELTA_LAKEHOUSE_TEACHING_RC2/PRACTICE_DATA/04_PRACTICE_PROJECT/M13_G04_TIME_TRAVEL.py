from delta_session import get_spark
import shutil
s=get_spark('G04');p='output/g04';shutil.rmtree(p,ignore_errors=True);s.createDataFrame([(1,'A')],['id','value']).write.format('delta').save(p);s.createDataFrame([(1,'B'),(2,'C')],['id','value']).write.format('delta').mode('overwrite').save(p);print('CURRENT');s.read.format('delta').load(p).show();print('VERSION0');s.read.format('delta').option('versionAsOf',0).load(p).show();s.stop()
