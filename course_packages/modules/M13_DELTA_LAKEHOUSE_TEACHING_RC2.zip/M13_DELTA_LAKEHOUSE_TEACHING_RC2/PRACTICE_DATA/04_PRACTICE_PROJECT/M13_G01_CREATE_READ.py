from delta_session import get_spark
from pathlib import Path
import shutil
s=get_spark('G01');p='output/g01_table';shutil.rmtree(p,ignore_errors=True);df=s.createDataFrame([(1,'A'),(2,'B')],['id','code']);df.write.format('delta').save(p);s.read.format('delta').load(p).show();print('LOG_EXISTS',Path(p,'_delta_log').exists());s.stop()
