from delta_session import get_spark
from delta.tables import DeltaTable
import shutil
s=get_spark('G02');p='output/g02';shutil.rmtree(p,ignore_errors=True);s.range(3).write.format('delta').save(p);s.range(5).write.format('delta').mode('overwrite').save(p);DeltaTable.forPath(s,p).history().select('version','operation').show();s.stop()
