from delta_session import get_spark
from pathlib import Path
import shutil
p=Path('output/probe_delta');shutil.rmtree(p,ignore_errors=True)
s=get_spark('M13Probe');s.createDataFrame([(1,'ok'),(2,'ok')],['id','status']).write.format('delta').save(str(p));print('DELTA_RUNTIME_OK',s.read.format('delta').load(str(p)).count());s.stop()
