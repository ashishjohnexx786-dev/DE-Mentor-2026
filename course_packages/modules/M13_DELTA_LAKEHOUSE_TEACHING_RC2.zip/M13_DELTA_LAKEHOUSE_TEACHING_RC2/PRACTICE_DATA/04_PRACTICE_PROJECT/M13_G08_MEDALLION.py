from delta_session import get_spark
from pyspark.sql import functions as F
import shutil
s=get_spark('G08');base='output/g08';shutil.rmtree(base,ignore_errors=True);raw=s.read.option('header',True).csv('data/customers.csv');raw.write.format('delta').save(base+'/bronze');silver=raw.filter(F.col('customer_id').isNotNull()).dropDuplicates(['customer_id']);silver.write.format('delta').save(base+'/silver');gold=silver.groupBy('tier').count();gold.write.format('delta').save(base+'/gold');print('COUNTS',raw.count(),silver.count(),gold.count());s.stop()
