from delta_session import get_spark
import shutil
s=get_spark('G05');p='output/g05';shutil.rmtree(p,ignore_errors=True);s.createDataFrame([(1,'A')],['id','name']).write.format('delta').save(p);new=s.createDataFrame([(2,'B','INR')],['id','name','currency']);new.write.format('delta').option('mergeSchema','true').mode('append').save(p);s.read.format('delta').load(p).printSchema();s.stop()
