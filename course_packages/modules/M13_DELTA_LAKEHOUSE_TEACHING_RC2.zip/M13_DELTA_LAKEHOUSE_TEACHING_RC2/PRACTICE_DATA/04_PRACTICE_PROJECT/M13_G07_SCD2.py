from delta_session import get_spark
from pyspark.sql import functions as F
import shutil
s=get_spark('G07');p='output/g07';shutil.rmtree(p,ignore_errors=True);base=s.createDataFrame([('C1','Deoghar','Silver','2026-01-01',None,True),('C2','Ranchi','Gold','2026-01-01',None,True)],['customer_id','city','tier','effective_from','effective_to','is_current']);base.write.format('delta').save(p);# guided teaching performs expire+insert in separate deterministic steps
current=s.read.format('delta').load(p);changes=s.createDataFrame([('C1','Ranchi','Gold','2026-08-27'),('C3','Bokaro','Silver','2026-08-27')],['customer_id','city','tier','effective_date']);print('CURRENT_BEFORE',current.filter('is_current').count());print('CHANGES',changes.count());s.stop()
