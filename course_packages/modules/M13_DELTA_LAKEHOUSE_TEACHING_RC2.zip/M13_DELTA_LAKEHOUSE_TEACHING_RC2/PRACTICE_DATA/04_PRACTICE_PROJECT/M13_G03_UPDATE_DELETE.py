from delta_session import get_spark
from delta.tables import DeltaTable
from pyspark.sql import functions as F
import shutil
s=get_spark('G03');p='output/g03';shutil.rmtree(p,ignore_errors=True);s.createDataFrame([(1,'OLD',False),(2,'ACTIVE',False),(3,'ACTIVE',True)],['id','status','is_test']).write.format('delta').save(p);dt=DeltaTable.forPath(s,p);dt.update(F.col('status')=='OLD',{'status':F.lit('ARCHIVED')});dt.delete(F.col('is_test')==True);dt.toDF().orderBy('id').show();dt.history().select('version','operation').show();s.stop()
