from pathlib import Path
import py_compile,sys
req={
'M13_G01_CREATE_READ.py':['format','delta','_delta_log'],
'M13_G02_LOG_HISTORY.py':['DeltaTable','history'],
'M13_G03_UPDATE_DELETE.py':['update','delete','history'],
'M13_G04_TIME_TRAVEL.py':['versionAsOf'],
'M13_G05_SCHEMA.py':['mergeSchema'],
'M13_G06_MERGE.py':['merge','whenMatchedUpdateAll','whenNotMatchedInsertAll'],
'M13_G07_SCD2.py':['is_current','effective_from','effective_to'],
'M13_G08_MEDALLION.py':['bronze','silver','gold'],
'M13_G09_LAYOUT.py':['_delta_log','repartition']}
checks=[]
for f,toks in req.items():
 try:py_compile.compile(f,doraise=True);ok=True
 except:ok=False
 checks.append((f+' syntax',ok));txt=Path(f).read_text();checks += [(f+' '+t,t in txt) for t in toks]
print(f'{sum(v for _,v in checks)}/{len(checks)} checks passed');[print(('PASS' if v else 'FAIL'),n) for n,v in checks];raise SystemExit(0 if all(v for _,v in checks) else 1)
