from delta_session import get_spark
from delta.tables import DeltaTable
import shutil
s=get_spark('G06');p='output/g06';shutil.rmtree(p,ignore_errors=True);s.createDataFrame([(1,'A',10),(2,'B',20)],['id','name','amount']).write.format('delta').save(p);src=s.createDataFrame([(2,'B2',25),(3,'C',30)],['id','name','amount']);dt=DeltaTable.forPath(s,p);dt.alias('t').merge(src.alias('s'),'t.id=s.id').whenMatchedUpdateAll().whenNotMatchedInsertAll().execute();dt.alias('t').merge(src.alias('s'),'t.id=s.id').whenMatchedUpdateAll().whenNotMatchedInsertAll().execute();print('ROWS',dt.toDF().count(),'DISTINCT',dt.toDF().select('id').distinct().count());dt.toDF().orderBy('id').show();s.stop()
