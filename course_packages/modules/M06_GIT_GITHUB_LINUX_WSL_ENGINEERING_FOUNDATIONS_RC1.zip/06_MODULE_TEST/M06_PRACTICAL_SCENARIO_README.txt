A small logistics team has a Python CSV summary utility, a messy local folder and no safe collaboration workflow. Prepare it as a reproducible engineering repository.

Use only synthetic/course data. Save the first attempt before any review.
