from pathlib import Path

def input_path() -> Path:
    return Path("data/raw/orders.csv")

def describe_run() -> str:
    return "Stage 06 seed pipeline"

if __name__ == "__main__":
    print(describe_run())
    print(input_path())
