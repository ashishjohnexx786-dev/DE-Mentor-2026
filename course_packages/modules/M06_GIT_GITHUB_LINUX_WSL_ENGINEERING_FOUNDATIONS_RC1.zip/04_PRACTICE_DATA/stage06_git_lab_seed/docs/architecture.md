# Architecture

Source CSV -> Python script -> later engineering stages.

This file is intentionally simple so you can edit it on a branch.
