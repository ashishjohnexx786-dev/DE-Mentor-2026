# Stage 06 Git/Linux Lab Seed

This small project exists only for Stage 06 practice.

Goals:
- navigate it from WSL/Linux
- initialize Git
- make meaningful commits
- create a branch
- create and resolve one merge conflict
- connect to GitHub
- open a pull request
- prove secrets/runtime files are ignored

Do not put passwords, tokens, API keys, `.env`, virtual environments, logs, or generated outputs into Git.
