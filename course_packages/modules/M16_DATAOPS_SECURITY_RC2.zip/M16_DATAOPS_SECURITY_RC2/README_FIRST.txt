M16 - DataOps + CI/CD + Security + Observability | RC2

Start in 00_START_HERE/M16_START_HERE.pdf.
PC is required for labs and assessments.
Protected reviews belong in 07_REVIEW_AND_REPAIR and should be opened only after the attempt is saved.
Real GitHub Actions and optional Terraform runtime evidence remain conditional before course-wide FINAL; never fabricate run IDs/screenshots.
