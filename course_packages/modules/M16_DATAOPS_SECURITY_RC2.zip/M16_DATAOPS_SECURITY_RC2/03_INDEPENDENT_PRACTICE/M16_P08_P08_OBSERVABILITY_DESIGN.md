# M16 P08 - P08 Observability Design

## Scenario
A daily pipeline needs freshness, row-volume, rejection, duration and downstream-success signals. Define thresholds/owners/actions.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
