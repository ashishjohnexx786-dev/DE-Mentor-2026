# M16 P04 - P04 Deployment Rollback

## Scenario
A Gold-model change is approved for production. Define commit/version evidence, pre-checks, deployment validation and rollback/forward-fix path.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
