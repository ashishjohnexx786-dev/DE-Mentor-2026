# M16 P10 - P10 Terraform Review

## Scenario
A plan proposes 1 create, 2 updates and 1 destroy in prod. Define what you inspect before approval, what would block apply, and how state/drift affect the decision.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
