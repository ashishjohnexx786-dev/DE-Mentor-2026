# M16 P09 - P09 Incident Rca

## Scenario
A bad schema change caused a six-hour outage. Write timeline, technical cause, contributing controls, recovery validation and preventive actions without blaming individuals.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
