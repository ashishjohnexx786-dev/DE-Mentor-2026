# M16 P05 - P05 Least Privilege

## Scenario
Analyst, pipeline service and platform admin need different actions. Build an access matrix and reject broad admin where unnecessary.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
