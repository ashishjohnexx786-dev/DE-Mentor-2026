# M16 P06 - P06 Pii Minimization

## Scenario
A Gold mart includes raw email, phone, age band and region. Decide what to retain/mask/drop and document business justification.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
