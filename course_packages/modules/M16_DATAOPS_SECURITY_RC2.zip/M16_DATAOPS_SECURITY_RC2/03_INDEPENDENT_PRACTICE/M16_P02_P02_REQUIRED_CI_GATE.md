# M16 P02 - P02 Required Ci Gate

## Scenario
A team can merge when tests fail because checks are optional. Define required PR checks and the failure behavior without making every slow production test part of every commit.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
