# M16 P01 - P01 Test Strategy

## Scenario
A pipeline has parsing, API load, SQL publish and data-quality rules. Design a layered test plan and state which defect each level catches.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
