# M16 P07 - P07 Lineage Impact

## Scenario
A Silver field is renamed. Identify impacted Gold tables, jobs and consumers using a lineage manifest and propose a safe change sequence.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
