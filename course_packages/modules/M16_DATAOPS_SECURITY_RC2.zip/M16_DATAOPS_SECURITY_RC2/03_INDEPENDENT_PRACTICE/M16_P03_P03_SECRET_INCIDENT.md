# M16 P03 - P03 Secret Incident

## Scenario
A token was committed then removed in the next commit. Define containment, revocation/rotation, history remediation and prevention steps.

## Required evidence
- Decision or implementation artifact.
- Validation or failure evidence.
- One risk and safe response.
- 3-5 sentence explanation without notes.

## Failure condition
Fails if the answer removes the control merely to make deployment/runtime green, exposes secrets, grants unnecessary admin, or cannot prove the intended result.
