M13 CURRENT LEARNER BOOK - RC5 POST-DEPLOY SEMANTIC REPAIR

The 2026-09-11 RC5 learner book supersedes the RC4 learner-book semantic acceptance.
Use 01_LESSONS first. It now follows the explicit 16-stage beginner-first teacher route and makes external source links visibly discoverable.
All protected review / fresh retry rules remain attempt-first. Whole-course FINAL still requires runtime/device evidence.

--- Historical module instructions retained below ---

M13 Delta Lake + Lakehouse - canonical standalone rebuild. Start with 00_START_HERE/M13_START_HERE.pdf. Review remains protected until a saved attempt. Real Delta runtime is not claimed by artifact QA. Next: M14; G05 only after M14.
