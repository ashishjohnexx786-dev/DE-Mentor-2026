#!/usr/bin/env python3
"""Course-owned table semantics simulator. NOT a Delta Lake engine."""
from pathlib import Path
import csv,json,shutil,sys
ROOT=Path(__file__).resolve().parent
IN=ROOT/'input'; OUT=ROOT/'output'; LOG=ROOT/'log'
for d in [OUT,LOG]:
    if d.exists(): shutil.rmtree(d)
    d.mkdir(parents=True)
def read(name):
    with (IN/name).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def val(rows): return round(sum(float(r['value']) for r in rows),2)
def commit(version,op,rows,schema,extra=None):
    payload={'version':version,'operation':op,'rows':rows,'schema':schema,'metrics':{'rows':len(rows),'value':val(rows)}}
    if extra: payload.update(extra)
    (OUT/f'version_{version}.json').write_text(json.dumps(payload,indent=2))
    (LOG/f'{version:020d}.json').write_text(json.dumps({'version':version,'operation':op,'metrics':payload['metrics']},indent=2))
    return payload
base=read('base.csv'); updates=read('updates.csv'); dup=read('duplicate_source.csv')
schema=list(base[0])
# v0 CREATE
v0=commit(0,'CREATE',base,schema)
# v1 MERGE with one source row per id
assert len({r['id'] for r in updates})==len(updates)
cur={r['id']:dict(r) for r in base}
updated=[]; inserted=[]
for r in updates:
    (updated if r['id'] in cur else inserted).append(r['id']); cur[r['id']]=dict(r)
rows1=[cur[k] for k in sorted(cur)]
v1=commit(1,'MERGE',rows1,schema,{'updated':updated,'inserted':inserted})
# rerun same merge: current state must not gain rows or change totals
cur2={r['id']:dict(r) for r in rows1}
for r in updates: cur2[r['id']]=dict(r)
rows1b=[cur2[k] for k in sorted(cur2)]
assert rows1b==rows1
# source uniqueness failure demonstration
ambiguous=updates+dup
ambiguous_ids=[x for x in {r['id'] for r in ambiguous} if sum(1 for r in ambiguous if r['id']==x)>1]
assert ambiguous_ids, 'duplicate-source fixture must be ambiguous'
# v2 additive schema evolution
rows2=[dict(r,quality_band=('HIGH' if float(r['value'])>=300 else 'STANDARD')) for r in rows1]
schema2=schema+['quality_band']
v2=commit(2,'ADD_COLUMN',rows2,schema2)
# v3 update/delete demonstration from current state
rows3=[]
for r in rows2:
    if r['id']==sorted([x['id'] for x in rows2])[-1]:
        continue
    x=dict(r)
    if x['id']==sorted([q['id'] for q in rows2])[0]: x['active']='N'
    rows3.append(x)
v3=commit(3,'UPDATE_DELETE',rows3,schema2)
# SCD2: history for keys changed by updates
hist=[]
for r in base: hist.append({'business_id':r['id'],'tier':r['tier'],'valid_from':'2026-01-01','valid_to':'9999-12-31','is_current':'Y'})
for u in updates:
    old=next((h for h in hist if h['business_id']==u['id'] and h['is_current']=='Y'),None)
    if old and old['tier']!=u['tier']:
        old['valid_to']='2026-09-10'; old['is_current']='N'
        hist.append({'business_id':u['id'],'tier':u['tier'],'valid_from':'2026-09-10','valid_to':'9999-12-31','is_current':'Y'})
    elif not old:
        hist.append({'business_id':u['id'],'tier':u['tier'],'valid_from':'2026-09-10','valid_to':'9999-12-31','is_current':'Y'})
# Bronze/Silver/Gold classroom controls
bronze=base+updates
silver=[dict(r) for r in rows1]
gold={}
for r in silver: gold[r['region']]=gold.get(r['region'],0)+float(r['value'])
report={
 'IMPORTANT':'CLASSROOM SEMANTICS SIMULATOR ONLY - NOT DELTA LAKE.',
 'versions':[0,1,2,3],
 'v0_rows':len(v0['rows']),'v0_value':v0['metrics']['value'],
 'v1_rows':len(v1['rows']),'v1_value':v1['metrics']['value'],'merge_updated':updated,'merge_inserted':inserted,
 'idempotent_rerun_same_state':rows1b==rows1,
 'ambiguous_merge_duplicate_ids':sorted(ambiguous_ids),
 'v2_rows':len(v2['rows']),'v2_schema':schema2,
 'v3_rows':len(v3['rows']),'v3_value':v3['metrics']['value'],
 'time_travel_changed_id':updated[0],
 'time_travel_old_tier':next(r['tier'] for r in v0['rows'] if r['id']==updated[0]),
 'time_travel_current_tier':next(r['tier'] for r in v2['rows'] if r['id']==updated[0]),
 'scd2_rows':len(hist),'scd2_current_rows':sum(h['is_current']=='Y' for h in hist),
 'bronze_rows':len(bronze),'silver_rows':len(silver),'silver_value':val(silver),'gold_regions':len(gold),'gold_value':round(sum(gold.values()),2),
 'vacuum_action':'DRY_RUN_ONLY','retention_note':'VACUUM can remove old data files needed by older snapshots; do not disable safety checks in this course.'}
(OUT/'controls.json').write_text(json.dumps(report,indent=2))
(OUT/'scd2_history.json').write_text(json.dumps(hist,indent=2))
(OUT/'gold_by_region.json').write_text(json.dumps(gold,indent=2))
print(json.dumps(report,indent=2))
