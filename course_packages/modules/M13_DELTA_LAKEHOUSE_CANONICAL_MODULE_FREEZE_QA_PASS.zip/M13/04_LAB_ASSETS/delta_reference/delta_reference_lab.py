#!/usr/bin/env python3
"""Real Delta Lake 4.4 / Spark 4.2 reference path. Run in M13 learner environment."""
from pathlib import Path
from pyspark.sql import SparkSession, functions as F
from delta import configure_spark_with_delta_pip
from delta.tables import DeltaTable
root=Path(__file__).resolve().parent
builder=(SparkSession.builder.appName('M13DeltaLab').master('local[2]')
         .config('spark.driver.memory','2g')
         .config('spark.sql.shuffle.partitions','4')
         .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
         .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog'))
spark=configure_spark_with_delta_pip(builder).getOrCreate()
path=str(root/'delta_table')
base=spark.createDataFrame([
 ('C101','Asha','East','Silver',200.0,'Y'),('C102','Ravi','North','Gold',350.0,'Y'),
 ('C103','Mina','West','Silver',180.0,'Y'),('C104','Kabir','South','Bronze',90.0,'Y')],
 ['id','name','region','tier','value','active'])
base.write.format('delta').mode('overwrite').save(path)
t=DeltaTable.forPath(spark,path)
updates=spark.createDataFrame([
 ('C102','Ravi','North','Platinum',420.0,'Y'),('C105','Isha','East','Silver',160.0,'Y')],base.schema)
(t.alias('t').merge(updates.alias('s'),'t.id=s.id')
 .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute())
# Rerun must leave one row per id.
(t.alias('t').merge(updates.alias('s'),'t.id=s.id')
 .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute())
current=spark.read.format('delta').load(path)
assert current.count()==5
assert current.select(F.sum('value')).first()[0]==1050.0
history=t.history().select('version','operation').collect()
print('CURRENT',current.orderBy('id').collect())
print('HISTORY',history)
print('VERSION0',spark.read.format('delta').option('versionAsOf',0).load(path).orderBy('id').collect())
spark.stop()
