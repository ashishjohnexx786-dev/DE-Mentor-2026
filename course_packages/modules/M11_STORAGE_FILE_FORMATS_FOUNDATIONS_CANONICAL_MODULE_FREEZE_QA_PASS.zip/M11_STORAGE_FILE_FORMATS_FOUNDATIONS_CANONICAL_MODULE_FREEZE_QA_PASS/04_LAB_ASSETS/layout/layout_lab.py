#!/usr/bin/env python3
from pathlib import Path
import csv,json,shutil
ROOT=Path(__file__).resolve().parent; src=ROOT/'input/orders.csv'; out=ROOT/'output'
if out.exists(): shutil.rmtree(out)
out.mkdir(parents=True)
with src.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
# Classroom file-layout experiment. These are CSV partitions, not Parquet.
parts=out/'partitioned_by_region'
for r in rows:
    p=parts/f"region={r['region']}"; p.mkdir(parents=True,exist_ok=True)
    fp=p/'part.csv'; new=not fp.exists()
    with fp.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());
        if new:w.writeheader()
        w.writerow(r)
# Deliberately create tiny-file anti-pattern.
tiny=out/'tiny_files'; tiny.mkdir()
for i,r in enumerate(rows,1):
    with (tiny/f'part-{i:03d}.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerow(r)
# Compact to one file preserving rows.
compact=out/'compacted.csv'
with compact.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
report={
 'rows':len(rows),'source_bytes':src.stat().st_size,
 'tiny_file_count':len(list(tiny.glob('*.csv'))),
 'partition_count':len([p for p in parts.iterdir() if p.is_dir()]),
 'compacted_file_count':1,
 'east_candidate_files':1,
 'all_partition_files':len(list(parts.rglob('*.csv'))),
 'note':'CSV is used only to make file-count/partition trade-offs visible. This does not simulate Parquet pruning or Delta OPTIMIZE.'}
(out/'layout_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
