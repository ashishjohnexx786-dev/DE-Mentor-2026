#!/usr/bin/env python3
from pathlib import Path
import json, struct, sys
p=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name("apache_alltypes_plain.snappy.parquet"))
b=p.read_bytes()
if len(b)<12 or b[:4]!=b"PAR1" or b[-4:]!=b"PAR1":
    raise SystemExit("FAIL: not a standard Parquet envelope (PAR1 header/footer missing)")
footer_len=struct.unpack("<I",b[-8:-4])[0]
meta_start=len(b)-8-footer_len
result={"file":p.name,"bytes":len(b),"header_magic":"PAR1","footer_magic":"PAR1","footer_metadata_bytes":footer_len,"footer_metadata_start":meta_start,"basic_envelope_valid":meta_start>=4}
try:
    import pyarrow.parquet as pq
    pf=pq.ParquetFile(p)
    result["pyarrow_available"]=True
    result["row_groups"]=pf.metadata.num_row_groups
    result["rows"]=pf.metadata.num_rows
    result["schema"]=str(pf.schema_arrow)
except Exception as e:
    result["pyarrow_available"]=False
    result["pyarrow_note"]="Install pyarrow 25.0.* for full schema/row-group inspection: "+str(e)
print(json.dumps(result,indent=2))
