#!/usr/bin/env python3
from pathlib import Path
import csv
try:
    import pyarrow as pa
    import pyarrow.parquet as pq
except ImportError:
    raise SystemExit("Install first: python -m pip install 'pyarrow==25.0.*'")
root=Path(__file__).resolve().parents[1]
src=root/'layout/input/orders.csv'; out=Path(__file__).with_name('orders_from_course.parquet')
with src.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
table=pa.Table.from_pylist(rows)
pq.write_table(table,out,compression='snappy',row_group_size=4)
pf=pq.ParquetFile(out)
print({'file':str(out),'rows':pf.metadata.num_rows,'row_groups':pf.metadata.num_row_groups,'columns':pf.schema_arrow.names})
