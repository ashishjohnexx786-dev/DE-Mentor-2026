#!/usr/bin/env python3
from pathlib import Path
import csv,json,shutil
ROOT=Path(__file__).resolve().parent; IN=ROOT/'input'; OUT=ROOT/'output'; LOG=ROOT/'log'
for d in (OUT,LOG):
    if d.exists(): shutil.rmtree(d)
    d.mkdir(parents=True)
base=[{'id':'C1','name':'Asha','tier':'Silver','spend':200.0},{'id':'C2','name':'Ravi','tier':'Gold','spend':350.0},{'id':'C3','name':'Mina','tier':'Silver','spend':180.0},{'id':'C4','name':'Kabir','tier':'Bronze','spend':90.0}]
updates=[{'id':'C2','name':'Ravi','tier':'Platinum','spend':420.0},{'id':'C5','name':'Isha','tier':'Silver','spend':160.0}]

def snap(ver,rows,schema):
    (OUT/f'version_{ver}.json').write_text(json.dumps({'schema':schema,'rows':rows},indent=2))
    (LOG/f'{ver:020d}.json').write_text(json.dumps({'version':ver,'operation':'WRITE' if ver==0 else 'MERGE' if ver==1 else 'SCHEMA_EVOLUTION','rows':len(rows),'schema':schema},indent=2))

schema0=['id','name','tier','spend']; snap(0,base,schema0)
current={r['id']:dict(r) for r in base}
for u in updates: current[u['id']]=dict(u)
rows1=[current[k] for k in sorted(current)]; snap(1,rows1,schema0)
# controlled additive schema evolution
rows2=[dict(r,segment=('High' if r['spend']>=300 else 'Standard')) for r in rows1]
schema2=schema0+['segment']; snap(2,rows2,schema2)
# time travel proof and vacuum dry-run only
report={
 'IMPORTANT':'CLASSROOM SIMULATOR ONLY - not a Delta engine and not a substitute for M13 runtime.',
 'versions':[0,1,2],
 'v0_rows':len(base),'v0_spend':sum(r['spend'] for r in base),
 'v1_rows':len(rows1),'v1_spend':sum(r['spend'] for r in rows1),
 'v2_rows':len(rows2),'v2_schema':schema2,
 'merge_updated':['C2'],'merge_inserted':['C5'],
 'time_travel_v0_C2_tier':next(r['tier'] for r in base if r['id']=='C2'),
 'current_v2_C2_tier':next(r['tier'] for r in rows2 if r['id']=='C2'),
 'vacuum_action':'DRY_RUN_ONLY','vacuum_safety':'Do not delete historical files while learning; retention can remove time-travel reachability.'}
(OUT/'delta_foundation_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
