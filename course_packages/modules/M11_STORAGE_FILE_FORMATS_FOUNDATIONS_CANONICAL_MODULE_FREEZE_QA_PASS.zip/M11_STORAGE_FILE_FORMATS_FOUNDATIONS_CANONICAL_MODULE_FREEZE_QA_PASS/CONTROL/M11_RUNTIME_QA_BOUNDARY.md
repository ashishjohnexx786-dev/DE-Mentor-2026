# M11 runtime QA boundary

- Executed here: real Parquet PAR1 envelope/footer-length probe, file-layout simulator, classroom transaction-log/version simulator, Python AST checks, PDF/render/package QA.
- Not executed here: PyArrow full Parquet decode (package absent), Spark, or an actual Delta Lake engine.
- Learner-machine M11: install PyArrow 25.0.* and execute full Parquet schema/row-group/projection labs.
- M12 owns Spark/PySpark first use. M13 owns deeper Delta Lake runtime engineering.
- The classroom Delta simulator is intentionally not represented as a Delta engine.
