import sqlite3
from pathlib import Path
DB=Path('serving/warehouse.sqlite')
if not DB.exists(): raise SystemExit('warehouse does not exist yet')
con=sqlite3.connect(DB)
print('rows,total_net_sales')
print(con.execute('SELECT COUNT(*),ROUND(SUM(net_sales),2) FROM orders_serving').fetchone())
print('orders')
for r in con.execute('SELECT order_id,updated_at,region,product,qty,net_sales,source_run_id FROM orders_serving ORDER BY order_id'):
    print(r)
con.close()
