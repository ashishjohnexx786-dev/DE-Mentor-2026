from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, tempfile

EXPECTED_FIELDS=["order_id","updated_at","customer_id","region","product","qty","unit_price","discount_pct","currency"]
EXPECTED_SET=set(EXPECTED_FIELDS)

class ContractError(ValueError): pass
class QualityGateError(RuntimeError): pass


def utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def safe_run_id():
    return utc_now_iso().replace(":","").replace("-","").replace(".","")

def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def atomic_json(path,payload):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=p.name+".",suffix=".tmp",dir=p.parent)
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as f:
            json.dump(payload,f,indent=2,ensure_ascii=False)
        Path(tmp).replace(p)
    except Exception:
        Path(tmp).unlink(missing_ok=True); raise

def parse_utc(value):
    if not str(value).endswith("Z"):
        raise ValueError("updated_at must be UTC with Z")
    return datetime.fromisoformat(str(value)[:-1]+"+00:00")

def normalize(row):
    missing=EXPECTED_SET-set(row)
    extra=set(row)-EXPECTED_SET
    if missing or extra:
        raise ContractError(f"schema drift missing={sorted(missing)} extra={sorted(extra)}")
    order_id=str(row['order_id']).strip(); customer_id=str(row['customer_id']).strip()
    region=str(row['region']).strip().title(); product=str(row['product']).strip()
    currency=str(row['currency']).strip().upper()
    if not order_id or not customer_id or not product: raise ValueError("required text field empty")
    if region not in {'East','West','North','South'}: raise ValueError("invalid region")
    parse_utc(row['updated_at'])
    qty=int(row['qty']); unit=float(row['unit_price']); disc=float(row['discount_pct'])
    if qty<=0: raise ValueError("qty must be > 0")
    if unit<0: raise ValueError("unit_price must be >= 0")
    if not 0<=disc<=1: raise ValueError("discount_pct must be between 0 and 1")
    if currency!='INR': raise ValueError("currency must be INR for this serving contract")
    net=round(qty*unit*(1-disc),2)
    return {'order_id':order_id,'updated_at':str(row['updated_at']),'customer_id':customer_id,
            'region':region,'product':product,'qty':qty,'unit_price':unit,'discount_pct':disc,
            'currency':currency,'net_sales':net}

def row_fingerprint(row):
    return json.dumps(row,sort_keys=True,separators=(",",":"),ensure_ascii=False)
