from __future__ import annotations
import argparse, csv, json, logging, shutil, sqlite3, time
from collections import defaultdict
from pathlib import Path
from src.common import *

DB=Path('serving/warehouse.sqlite')
STATE=Path('state/processed_batches.json')


def logger_for(run_id):
    Path('logs').mkdir(exist_ok=True)
    logger=logging.getLogger(run_id); logger.setLevel(logging.INFO)
    if not logger.handlers:
        fmt=logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        fh=logging.FileHandler(Path('logs')/f'{run_id}.log',encoding='utf-8'); fh.setFormatter(fmt)
        sh=logging.StreamHandler(); sh.setFormatter(fmt)
        logger.addHandler(fh); logger.addHandler(sh)
    return logger


def load_state():
    if not STATE.exists(): return {'processed_sha256':[]}
    return json.loads(STATE.read_text(encoding='utf-8'))


def read_source(source_path,raw_copy):
    with raw_copy.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f)
        actual=reader.fieldnames or []
        if actual!=EXPECTED_FIELDS:
            raise ContractError(f'header mismatch expected={EXPECTED_FIELDS} actual={actual}')
        return list(reader)


def validate_and_dedupe(rows):
    valid=[]; quarantine=[]
    for source_row,row in enumerate(rows,start=2):
        try:
            valid.append({'source_row':source_row,'record':normalize(row)})
        except Exception as exc:
            quarantine.append({'source_row':source_row,'error':str(exc),'record':row})

    by_id=defaultdict(list)
    for item in valid: by_id[item['record']['order_id']].append(item)
    staged=[]; dedup_discarded=0
    for order_id,items in by_id.items():
        items=sorted(items,key=lambda x:(x['record']['updated_at'],x['source_row']))
        max_ts=max(x['record']['updated_at'] for x in items)
        top=[x for x in items if x['record']['updated_at']==max_ts]
        if len(top)>1:
            fps={row_fingerprint(x['record']) for x in top}
            if len(fps)>1:
                for x in items:
                    quarantine.append({'source_row':x['source_row'],'error':f'ambiguous duplicate {order_id} at same latest timestamp','record':x['record']})
                continue
        winner=top[-1]
        staged.append(winner['record'])
        dedup_discarded += len(items)-1
    staged.sort(key=lambda r:r['order_id'])
    quarantine.sort(key=lambda r:r['source_row'])
    return staged,quarantine,dedup_discarded


def init_db(con):
    con.executescript('''
    CREATE TABLE IF NOT EXISTS orders_serving(
      order_id TEXT PRIMARY KEY,
      updated_at TEXT NOT NULL,
      customer_id TEXT NOT NULL,
      region TEXT NOT NULL,
      product TEXT NOT NULL,
      qty INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      discount_pct REAL NOT NULL,
      currency TEXT NOT NULL,
      net_sales REAL NOT NULL,
      source_run_id TEXT NOT NULL,
      loaded_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS pipeline_runs(
      run_id TEXT PRIMARY KEY,
      source_file TEXT NOT NULL,
      source_sha256 TEXT NOT NULL,
      status TEXT NOT NULL,
      source_rows INTEGER NOT NULL,
      staged_rows INTEGER NOT NULL,
      quarantined_rows INTEGER NOT NULL,
      dedup_discarded INTEGER NOT NULL,
      inserted_rows INTEGER NOT NULL,
      updated_rows INTEGER NOT NULL,
      staged_net_sales REAL NOT NULL,
      target_net_sales_for_keys REAL NOT NULL,
      started_at TEXT NOT NULL,
      finished_at TEXT NOT NULL
    );
    ''')


def load_with_retry(staged,run_id,simulate_transient=False,attempts=3):
    last=None
    for attempt in range(1,attempts+1):
        try:
            if simulate_transient and attempt==1:
                raise sqlite3.OperationalError('simulated transient database lock')
            DB.parent.mkdir(parents=True,exist_ok=True)
            con=sqlite3.connect(DB)
            try:
                init_db(con)
                existing={}
                if staged:
                    q='SELECT order_id,updated_at,customer_id,region,product,qty,unit_price,discount_pct,currency,net_sales FROM orders_serving WHERE order_id IN (%s)' % ','.join('?'*len(staged))
                    for row in con.execute(q,[r['order_id'] for r in staged]):
                        existing[row[0]]={
                          'order_id':row[0],'updated_at':row[1],'customer_id':row[2],'region':row[3],
                          'product':row[4],'qty':row[5],'unit_price':row[6],'discount_pct':row[7],
                          'currency':row[8],'net_sales':row[9]
                        }
                inserted=updated=stale_or_same_ignored=0
                expected_target={}
                now=utc_now_iso()
                con.execute('BEGIN')
                for r in staged:
                    old=existing.get(r['order_id'])
                    if old is None:
                        action='insert'; inserted+=1; expected_target[r['order_id']]=r
                    elif r['updated_at'] > old['updated_at']:
                        action='update'; updated+=1; expected_target[r['order_id']]=r
                    elif r['updated_at'] == old['updated_at']:
                        comparable=['customer_id','region','product','qty','unit_price','discount_pct','currency','net_sales']
                        if any(r[k] != old[k] for k in comparable):
                            raise RuntimeError(f"same-timestamp conflict for {r['order_id']}")
                        action='ignore'; stale_or_same_ignored+=1; expected_target[r['order_id']]=old
                    else:
                        action='ignore'; stale_or_same_ignored+=1; expected_target[r['order_id']]=old

                    if action=='insert':
                        con.execute('''INSERT INTO orders_serving
                        (order_id,updated_at,customer_id,region,product,qty,unit_price,discount_pct,currency,net_sales,source_run_id,loaded_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
                        [r[k] for k in ['order_id','updated_at','customer_id','region','product','qty','unit_price','discount_pct','currency','net_sales']]+[run_id,now])
                    elif action=='update':
                        con.execute('''UPDATE orders_serving SET
                          updated_at=?,customer_id=?,region=?,product=?,qty=?,unit_price=?,discount_pct=?,currency=?,net_sales=?,source_run_id=?,loaded_at=?
                          WHERE order_id=?''',
                        [r[k] for k in ['updated_at','customer_id','region','product','qty','unit_price','discount_pct','currency','net_sales']]+[run_id,now,r['order_id']])

                if staged:
                    q='SELECT order_id,ROUND(net_sales,2) FROM orders_serving WHERE order_id IN (%s)' % ','.join('?'*len(staged))
                    actual=dict(con.execute(q,[r['order_id'] for r in staged]).fetchall())
                else: actual={}
                expected={k:round(float(v['net_sales']),2) for k,v in expected_target.items()}
                if set(actual)!=set(expected):
                    raise RuntimeError(f'reconciliation failed target keys={sorted(actual)} expected={sorted(expected)}')
                for k,v in expected.items():
                    if round(float(actual[k]),2)!=v:
                        raise RuntimeError(f'reconciliation failed {k} target={actual[k]} expected={v}')
                target_sum=round(sum(float(x) for x in actual.values()),2)
                expected_sum=round(sum(expected.values()),2)
                if target_sum!=expected_sum:
                    raise RuntimeError(f'reconciliation failed target_sum={target_sum} expected={expected_sum}')
                con.commit()
                return inserted,updated,stale_or_same_ignored,target_sum
            except Exception:
                con.rollback(); raise
            finally:
                con.close()
        except sqlite3.OperationalError as exc:
            last=exc
            if attempt==attempts: raise
            time.sleep(0.1*(2**(attempt-1)))
    raise last


def run_pipeline(source,max_quarantine_rate=0.25,replay=False,simulate_transient_load=False,fail_after=None):
    source=Path(source); run_id=safe_run_id(); started=utc_now_iso(); log=logger_for(run_id)
    sha=sha256_file(source); state=load_state()
    if sha in state.get('processed_sha256',[]) and not replay:
        return {'run_id':run_id,'status':'SKIPPED_ALREADY_PROCESSED','source_file':source.name,'source_sha256':sha}

    run_dir=Path('raw')/f'run_id={run_id}'; run_dir.mkdir(parents=True,exist_ok=True)
    raw_copy=run_dir/source.name; shutil.copy2(source,raw_copy)
    manifest={'run_id':run_id,'source_file':source.name,'source_sha256':sha,'started_at':started,'status':'STARTED'}
    (run_dir/'_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

    try:
        rows=read_source(source,raw_copy)
        staged,quarantine,dedup_discarded=validate_and_dedupe(rows)
        staging_path=Path('staging')/f'{run_id}.jsonl'; staging_path.parent.mkdir(exist_ok=True)
        staging_path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\\n' for r in staged),encoding='utf-8')
        quarantine_path=Path('quarantine')/f'{run_id}.jsonl'; quarantine_path.parent.mkdir(exist_ok=True)
        quarantine_path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\\n' for r in quarantine),encoding='utf-8')
        if fail_after=='staging': raise RuntimeError('simulated failure after staging before load')
        rate=(len(quarantine)/len(rows)) if rows else 0
        if rate>max_quarantine_rate:
            raise QualityGateError(f'quarantine rate {rate:.1%} exceeds {max_quarantine_rate:.1%}')
        manifest.update(source_rows=len(rows),staged_rows=len(staged),quarantined_rows=len(quarantine),dedup_discarded=dedup_discarded)
        (run_dir/'_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        inserted,updated,stale_or_same_ignored,target_sum=load_with_retry(staged,run_id,simulate_transient=simulate_transient_load)
        staged_sum=round(sum(r['net_sales'] for r in staged),2)
        # Source-row accounting: every source row must be staged, quarantined, or explicitly dedup-discarded.
        if len(rows) != len(staged)+len(quarantine)+dedup_discarded:
            raise RuntimeError('source row accounting reconciliation failed')
        if fail_after=='load': raise RuntimeError('simulated failure after load before state commit')
        finished=utc_now_iso()
        manifest.update(status='SUCCESS',source_rows=len(rows),staged_rows=len(staged),quarantined_rows=len(quarantine),
                        dedup_discarded=dedup_discarded,inserted_rows=inserted,updated_rows=updated,stale_or_same_ignored=stale_or_same_ignored,
                        staged_net_sales=staged_sum,target_net_sales_for_keys=target_sum,finished_at=finished,
                        staging_file=str(staging_path),quarantine_file=str(quarantine_path),target='serving/warehouse.sqlite:orders_serving')
        (run_dir/'_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        Path('metadata').mkdir(exist_ok=True)
        (Path('metadata')/f'{run_id}_lineage.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        if not replay:
            hashes=set(state.get('processed_sha256',[])); hashes.add(sha); atomic_json(STATE,{'processed_sha256':sorted(hashes),'updated_at':finished})
        log.info('SUCCESS source=%s rows=%s staged=%s quarantine=%s dedup=%s inserted=%s updated=%s',source.name,len(rows),len(staged),len(quarantine),dedup_discarded,inserted,updated)
        return manifest
    except Exception as exc:
        manifest.update(status='FAILED',finished_at=utc_now_iso(),error=str(exc))
        (run_dir/'_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        log.exception('FAILED %s',exc)
        raise


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input',required=True)
    p.add_argument('--max-quarantine-rate',type=float,default=0.25)
    p.add_argument('--replay',action='store_true')
    p.add_argument('--simulate-transient-load',action='store_true')
    p.add_argument('--fail-after',choices=['staging','load'])
    args=p.parse_args()
    out=run_pipeline(args.input,args.max_quarantine_rate,args.replay,args.simulate_transient_load,args.fail_after)
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
