"""Stage 09 learner workspace.
Build your pipeline before opening pipeline_reference.py.

Required boundaries:
1. copy source into raw/run_id=... and write manifest
2. validate exact source contract
3. deterministic transform (trim/title-case/types/net_sales)
4. deterministic duplicate handling + explicit metrics
5. invalid rows -> quarantine with error/source row
6. quality gate before serving load
7. serving SQLite insert/update inside a transaction; ignore stale/same versions and reject same-timestamp conflicting payloads
8. bounded retry for transient sqlite OperationalError only
9. reconcile source row accounting and staged-key target totals
10. state/file-hash mark only AFTER full success
11. lineage metadata from source hash -> staging/quarantine -> target
12. --replay does not mark normal processed state
"""
