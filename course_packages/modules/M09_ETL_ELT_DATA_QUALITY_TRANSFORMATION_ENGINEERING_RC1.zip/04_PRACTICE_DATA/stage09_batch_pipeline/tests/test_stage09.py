import unittest
from src.common import normalize
from src.pipeline_reference import validate_and_dedupe

GOOD={'order_id':'X1','updated_at':'2026-08-01T00:00:00Z','customer_id':'C1','region':'east','product':' Keyboard ','qty':'2','unit_price':'850','discount_pct':'0.10','currency':'INR'}

class TestStage09(unittest.TestCase):
    def test_transform_deterministic(self):
        a=normalize(GOOD); b=normalize(dict(GOOD))
        self.assertEqual(a,b)
        self.assertEqual(a['region'],'East')
        self.assertEqual(a['product'],'Keyboard')
        self.assertEqual(a['net_sales'],1530.0)

    def test_latest_duplicate_wins(self):
        rows=[
          {'order_id':'X1','updated_at':'2026-08-01T00:00:00Z','customer_id':'C1','region':'East','product':'P','qty':'1','unit_price':'10','discount_pct':'0','currency':'INR'},
          {'order_id':'X1','updated_at':'2026-08-02T00:00:00Z','customer_id':'C1','region':'East','product':'P','qty':'2','unit_price':'10','discount_pct':'0','currency':'INR'},
        ]
        staged,q,d=validate_and_dedupe(rows)
        self.assertEqual(len(staged),1); self.assertEqual(staged[0]['qty'],2); self.assertEqual(d,1); self.assertEqual(q,[])

    def test_ambiguous_duplicate_quarantined(self):
        rows=[
          {'order_id':'X2','updated_at':'2026-08-02T00:00:00Z','customer_id':'C1','region':'East','product':'P','qty':'1','unit_price':'10','discount_pct':'0','currency':'INR'},
          {'order_id':'X2','updated_at':'2026-08-02T00:00:00Z','customer_id':'C1','region':'East','product':'P','qty':'2','unit_price':'10','discount_pct':'0','currency':'INR'},
        ]
        staged,q,d=validate_and_dedupe(rows)
        self.assertEqual(staged,[]); self.assertEqual(len(q),2); self.assertEqual(d,0)

if __name__=='__main__': unittest.main()
