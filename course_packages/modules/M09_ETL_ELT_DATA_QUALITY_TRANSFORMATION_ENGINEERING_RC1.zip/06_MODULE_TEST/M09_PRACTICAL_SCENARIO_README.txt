A batch ingestion layer has landed order records, including duplicates, drift and late updates. Build the transformation/serving layer and prove data quality/recovery behavior.

Use only synthetic/course data. Save the first attempt before any review.
