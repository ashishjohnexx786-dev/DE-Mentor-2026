from datetime import datetime, timedelta
from airflow.sdk import dag, task

@dag(
    dag_id="daily_orders_training",
    schedule="@daily",
    start_date=datetime(2026, 8, 1),
    catchup=False,
    tags=["m10", "training"],
)
def daily_orders_training():
    @task(retries=2, retry_delay=timedelta(seconds=30))
    def extract():
        return {"source_path": "/opt/airflow/data/orders.csv", "source_rows": 4}

    @task
    def validate(meta):
        if meta["source_rows"] <= 0:
            raise ValueError("empty source")
        return {**meta, "validation": "PASS"}

    @task
    def transform(meta):
        return {**meta, "valid_rows": 2, "rejected_rows": 2}

    @task
    def load(meta):
        if meta["valid_rows"] + meta["rejected_rows"] != meta["source_rows"]:
            raise ValueError("reconciliation mismatch")
        print("load_ready", meta)

    load(transform(validate(extract())))

daily_orders_training()
