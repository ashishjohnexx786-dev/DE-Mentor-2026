from pathlib import Path
import csv,json,os
ROOT=Path('/app/data') if Path('/app/data').exists() else Path(__file__).resolve().parents[2]/'data'
source=ROOT/'orders.csv'; out=ROOT/'output'; out.mkdir(exist_ok=True)
rows=list(csv.DictReader(source.open())); valid=[]; rejected=[]; seen=set()
for r in rows:
    reasons=[]
    if not r['customer_id']: reasons.append('missing customer_id')
    if r['order_id'] in seen: reasons.append('duplicate order_id')
    seen.add(r['order_id'])
    try:
        if float(r['amount'])<0: reasons.append('negative amount')
    except ValueError: reasons.append('invalid amount')
    (rejected if reasons else valid).append({**r,**({'reason':'; '.join(reasons)} if reasons else {})})
def write(path,rows,fields):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
write(out/'valid_orders.csv',valid,['order_id','customer_id','amount','status'])
write(out/'rejected_orders.csv',rejected,['order_id','customer_id','amount','status','reason'])
(out/'audit.json').write_text(json.dumps({'source_rows':len(rows),'valid_rows':len(valid),'rejected_rows':len(rejected),'status':'SUCCESS'},indent=2))
print('source',len(rows),'valid',len(valid),'rejected',len(rejected),'db_host',os.getenv('DB_HOST','not-set'))
