from pathlib import Path
import yaml,re
root=Path(__file__).resolve().parents[1]
y=yaml.safe_load((root/'compose.yaml').read_text()); checks=[]
services=y.get('services',{}); checks += [('db_service','db' in services),('pipeline_service','pipeline' in services)]
p=services.get('pipeline',{}); db=services.get('db',{})
checks += [('pipeline_build',p.get('build')=='./app'),('db_host_service_name',p.get('environment',{}).get('DB_HOST')=='db'),('depends_healthy',str(p.get('depends_on',{})).find('service_healthy')>=0),('db_volume',bool(db.get('volumes'))),('secret_declared','db_password' in y.get('secrets',{})),('pipeline_secret','db_password' in p.get('secrets',[])),('db_secret','db_password' in db.get('secrets',[]))]
d=(root/'app/Dockerfile').read_text(); checks += [('docker_from',re.search(r'^FROM\s+python:',d,re.M) is not None),('docker_workdir','WORKDIR' in d),('requirements_before_source',d.find('COPY requirements.txt')<d.find('COPY src')),('pip_install','pip install' in d),('non_root','USER appuser' in d),('cmd','CMD [' in d)]
for n,ok in checks:print(n,'PASS' if ok else 'FAIL')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
