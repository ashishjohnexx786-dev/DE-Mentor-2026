from pathlib import Path
import ast,re,yaml
root=Path(__file__).resolve().parents[1]; f=root/'airflow/dags/daily_orders_training.py';txt=f.read_text();ast.parse(txt)
checks=[('sdk_import','from airflow.sdk import dag, task' in txt),('dag_id','daily_orders_training' in txt),('schedule','schedule="@daily"' in txt.replace(' ','')),('catchup_false','catchup=False' in txt.replace(' ','')),('extract_task','def extract' in txt),('validate_task','def validate' in txt),('transform_task','def transform' in txt),('load_task','def load' in txt),('retry','retries=2' in txt.replace(' ','')),('dependency_chain','load(transform(validate(extract())))' in txt.replace(' ',''))]
a=yaml.safe_load((root/'airflow/compose.airflow.yaml').read_text());svc=a.get('services',{}).get('airflow',{}); checks += [('airflow_image',str(svc.get('image','')).startswith('apache/airflow:3.3')),('standalone',svc.get('command')=='standalone'),('dag_mount',any('dags:/opt/airflow/dags' in x for x in svc.get('volumes',[])))]
for n,ok in checks:print(n,'PASS' if ok else 'FAIL')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
