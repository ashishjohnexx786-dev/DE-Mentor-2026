M10 DOCKER + AIRFLOW RC2
Start: 00_START_HERE/M10_START_HERE.pdf
PC/WSL + real Docker/Airflow execution is required for full labs. Offline validators do not replace live runtime evidence.
