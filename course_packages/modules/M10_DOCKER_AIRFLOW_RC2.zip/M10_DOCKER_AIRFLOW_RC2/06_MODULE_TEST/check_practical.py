from pathlib import Path
import sys,yaml,re,ast,subprocess,json,csv,tempfile,shutil
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'m10_helpdesk_platform'
req=['app/Dockerfile','compose.yaml','airflow/dags/helpdesk_daily.py','app/src/pipeline.py','data/tickets.csv','.gitignore','secrets/db_password.txt.example']
checks=[(f,(root/f).exists()) for f in req]
if not all(ok for _,ok in checks):
 [print(n,'PASS' if ok else 'FAIL') for n,ok in checks]; raise SystemExit(1)
d=(root/'app/Dockerfile').read_text();checks += [('docker_from',re.search(r'^FROM\s+python:',d,re.M)!=None),('workdir','WORKDIR' in d),('nonroot',re.search(r'^USER\s+',d,re.M)!=None),('cmd','CMD [' in d)]
y=yaml.safe_load((root/'compose.yaml').read_text()) or {}; sv=y.get('services',{});checks += [('db_service','db' in sv),('pipeline_service','pipeline' in sv),('secret','db_password' in y.get('secrets',{})),('db_host',sv.get('pipeline',{}).get('environment',{}).get('DB_HOST')=='db'),('volume',bool(y.get('volumes')))]
dag=(root/'airflow/dags/helpdesk_daily.py').read_text();ast.parse(dag);compact=re.sub(r'\s+','',dag);checks += [('airflow_sdk','fromairflow.sdkimportdag,task' in compact),('dag_id','helpdesk_daily' in dag),('schedule','schedule=' in dag),('catchup_false','catchup=False' in compact),('extract','defextract' in compact),('validate','defvalidate' in compact),('load','defload' in compact),('retry','retries=' in compact)]
# run actual pipeline locally in isolated copy
with tempfile.TemporaryDirectory() as td:
 tmp=Path(td);shutil.copy2(root/'data/tickets.csv',tmp/'tickets.csv');res=subprocess.run([sys.executable,str(root/'app/src/pipeline.py'),str(tmp)],capture_output=True,text=True);checks.append(('pipeline_exit',res.returncode==0));a=json.loads((tmp/'output/audit.json').read_text());checks += [('audit_counts',(a['source_rows'],a['valid_rows'],a['rejected_rows'])==(4,2,2))]
for n,ok in checks:print(n,'PASS' if ok else 'FAIL')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
