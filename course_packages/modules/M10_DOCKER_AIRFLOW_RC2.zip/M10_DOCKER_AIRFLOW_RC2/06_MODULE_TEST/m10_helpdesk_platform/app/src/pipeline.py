from pathlib import Path
import csv,json,sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[2]/'data'
rows=list(csv.DictReader((root/'tickets.csv').open())); valid=[];bad=[]
for r in rows:
    reasons=[]
    if not r['customer_id']: reasons.append('missing customer_id')
    if r['priority'] not in {'LOW','MEDIUM','HIGH'}: reasons.append('invalid priority')
    (bad if reasons else valid).append({**r,**({'reason':'; '.join(reasons)} if reasons else {})})
out=root/'output';out.mkdir(exist_ok=True)
def w(p,rows,fields):
    with p.open('w',newline='') as f: ww=csv.DictWriter(f,fieldnames=fields);ww.writeheader();ww.writerows(rows)
w(out/'valid_tickets.csv',valid,['ticket_id','customer_id','priority','status']);w(out/'rejected_tickets.csv',bad,['ticket_id','customer_id','priority','status','reason']);(out/'audit.json').write_text(json.dumps({'source_rows':len(rows),'valid_rows':len(valid),'rejected_rows':len(bad)},indent=2));print(len(rows),len(valid),len(bad))
