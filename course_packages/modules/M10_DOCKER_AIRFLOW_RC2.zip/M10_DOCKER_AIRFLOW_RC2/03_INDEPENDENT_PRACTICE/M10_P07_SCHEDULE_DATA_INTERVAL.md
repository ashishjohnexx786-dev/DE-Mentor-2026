# M10 P07 - Schedule/data interval

## Scenario
Define which data interval a daily Dag triggered after midnight should process and why wall-clock now is unsafe.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

