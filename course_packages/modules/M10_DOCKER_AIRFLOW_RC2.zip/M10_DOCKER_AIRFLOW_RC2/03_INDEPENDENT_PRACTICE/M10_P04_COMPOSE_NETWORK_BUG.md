# M10 P04 - Compose network bug

## Scenario
A pipeline container uses DB_HOST=localhost. Diagnose and repair without changing PostgreSQL itself.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

