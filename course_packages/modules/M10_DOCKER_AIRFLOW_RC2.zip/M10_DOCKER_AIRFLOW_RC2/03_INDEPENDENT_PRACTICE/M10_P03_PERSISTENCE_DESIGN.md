# M10 P03 - Persistence design

## Scenario
Choose named volume vs bind mount for PostgreSQL data, learner source CSVs and generated reports.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

