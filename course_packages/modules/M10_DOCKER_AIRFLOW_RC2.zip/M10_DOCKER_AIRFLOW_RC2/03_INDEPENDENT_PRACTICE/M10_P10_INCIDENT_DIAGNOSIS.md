# M10 P10 - Incident diagnosis

## Scenario
Given a failed load task after transform success, write the inspection order and safe rerun decision.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

