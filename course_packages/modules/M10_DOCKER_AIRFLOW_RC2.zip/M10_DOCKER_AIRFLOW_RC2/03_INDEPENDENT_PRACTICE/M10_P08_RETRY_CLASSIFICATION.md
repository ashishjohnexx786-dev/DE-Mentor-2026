# M10 P08 - Retry classification

## Scenario
Classify timeout, HTTP 500, invalid API key, schema loss and duplicate-key target failure as retry/fail/repair cases.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

