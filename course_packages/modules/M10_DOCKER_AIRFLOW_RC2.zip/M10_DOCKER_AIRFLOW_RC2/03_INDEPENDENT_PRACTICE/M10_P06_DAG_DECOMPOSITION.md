# M10 P06 - Dag decomposition

## Scenario
Split a one-task monolithic pipeline into operationally meaningful Airflow tasks with safe retry boundaries.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

