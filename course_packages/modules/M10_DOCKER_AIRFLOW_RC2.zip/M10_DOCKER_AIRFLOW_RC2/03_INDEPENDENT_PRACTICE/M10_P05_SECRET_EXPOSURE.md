# M10 P05 - Secret exposure

## Scenario
A password is committed in compose.yaml. Define immediate repair and future secret-handling rule.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

