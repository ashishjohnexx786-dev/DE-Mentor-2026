# M10 P02 - Port mapping

## Scenario
Map a service listening on container 8080 to host 18080 and document host vs container access.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

