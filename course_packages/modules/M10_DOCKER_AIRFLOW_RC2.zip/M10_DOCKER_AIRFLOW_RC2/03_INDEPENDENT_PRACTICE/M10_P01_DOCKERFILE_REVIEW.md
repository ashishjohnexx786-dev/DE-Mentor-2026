# M10 P01 - Dockerfile review

## Scenario
Given a Dockerfile that copies secrets and runs as root, rewrite it safely and explain the build-cache order.

## Your design/change

## Expected result

## Failure behavior

## Rerun/backfill proof

## Evidence

