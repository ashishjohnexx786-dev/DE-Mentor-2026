M06 GIT + GITHUB + LINUX/WSL ENGINEERING FOUNDATIONS - TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf.
Use only the supplied Stage 06 seed and a separate GitHub practice repository for conflicts/reverts/history exercises.
Never practise destructive Git exercises inside the deployed DE Mentor course repository.
