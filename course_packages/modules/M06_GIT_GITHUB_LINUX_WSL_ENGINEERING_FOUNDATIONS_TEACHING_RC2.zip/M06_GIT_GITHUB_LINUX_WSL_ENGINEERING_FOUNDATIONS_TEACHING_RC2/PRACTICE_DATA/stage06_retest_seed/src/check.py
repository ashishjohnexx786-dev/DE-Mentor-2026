from pathlib import Path
def input_path():
    return Path("data/raw/inventory.csv")
if __name__ == "__main__":
    print("fresh retest inventory checker")
    print(input_path())
