# Flow
Raw inventory -> Python validation -> summary.
