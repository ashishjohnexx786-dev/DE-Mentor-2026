#!/usr/bin/env bash
set -euo pipefail

PROJECT_ENV="${PROJECT_ENV:-development}"
echo "environment=$PROJECT_ENV"

test -f README.md || {
  echo "ERROR: README.md missing" >&2
  exit 2
}

python3 -m py_compile src/pipeline.py
python3 src/pipeline.py
echo "repository check passed"
