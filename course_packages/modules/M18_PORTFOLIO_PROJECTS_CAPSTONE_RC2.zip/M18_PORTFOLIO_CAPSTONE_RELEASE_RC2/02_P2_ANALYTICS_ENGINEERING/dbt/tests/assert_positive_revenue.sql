-- TODO custom business test
select 1 where false
