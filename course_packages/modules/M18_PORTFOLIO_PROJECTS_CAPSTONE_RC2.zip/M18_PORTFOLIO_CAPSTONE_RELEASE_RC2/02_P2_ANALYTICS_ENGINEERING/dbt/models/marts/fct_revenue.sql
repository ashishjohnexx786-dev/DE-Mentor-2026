-- TODO incremental fact model with grain/incremental safety
select 1 as todo
