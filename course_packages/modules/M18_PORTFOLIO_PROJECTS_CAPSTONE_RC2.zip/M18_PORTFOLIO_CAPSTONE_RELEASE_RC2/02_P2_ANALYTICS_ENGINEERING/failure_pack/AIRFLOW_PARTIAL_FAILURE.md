Simulate source load success followed by dbt test failure. Verify downstream publish does not run and rerun starts from a safe task boundary.
