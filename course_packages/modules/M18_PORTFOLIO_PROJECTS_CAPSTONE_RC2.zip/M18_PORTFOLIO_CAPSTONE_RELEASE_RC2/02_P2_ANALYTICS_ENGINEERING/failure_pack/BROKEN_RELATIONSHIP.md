Add a billing row with customer_id C999. The dbt relationship test must fail and publish must stop.
