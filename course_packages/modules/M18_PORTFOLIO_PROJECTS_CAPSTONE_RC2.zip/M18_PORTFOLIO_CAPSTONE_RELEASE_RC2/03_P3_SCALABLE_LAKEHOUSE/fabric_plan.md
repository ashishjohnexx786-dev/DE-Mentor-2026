# Fabric deployment
TODO OneLake, Lakehouse, notebook/Spark, pipeline, monitoring, identity.
