# Performance evidence
TODO explain plan, shuffle, skew, small files, caching.
