# P3 Scalable Lakehouse
TODO run, architecture, failures, limitations.
