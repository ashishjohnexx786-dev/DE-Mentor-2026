Anti-pattern: partition by shipment_id. Explain why it creates excessive partitions/files and replace it with a bounded workload-aligned choice.
