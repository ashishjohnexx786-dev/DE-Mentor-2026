Force many tiny output partitions. Inspect file counts and repair with an evidence-based repartition/coalesce/compaction strategy.
