# TODO DeltaTable MERGE keyed by shipment_id and event_time logic.
