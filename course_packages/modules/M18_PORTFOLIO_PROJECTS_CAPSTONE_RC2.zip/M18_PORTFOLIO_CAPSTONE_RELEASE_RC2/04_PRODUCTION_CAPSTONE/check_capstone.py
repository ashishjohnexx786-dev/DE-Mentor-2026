from pathlib import Path
import re
checks=[]
def c(n,o):checks.append((n,bool(o))); print(f'{n}={"PASS" if o else "FAIL"}')
files={n:Path(n).read_text().lower() for n in ['README.md','architecture.md','source_contracts.md','quality_rules.md','runbook.md','security.md','monitoring.md','defense.md','src/ingest.py','dbt/models/gold_orders.sql','dags/capstone_dag.py','spark/lakehouse_job.py','.github/workflows/ci.yml']}
c('architecture',all(x in files['architecture.md'] for x in ['raw','trusted','orchestration','serving']))
c('contracts',all(x in files['source_contracts.md'] for x in ['api','csv','database','grain']))
c('ingestion',len(files['src/ingest.py'])>900 and all(x in files['src/ingest.py'] for x in ['raw','pagination','idempot']))
c('quality',all(x in files['quality_rules.md'] for x in ['required','duplicate','reconciliation']))
c('dbt_model',len(files['dbt/models/gold_orders.sql'])>200 and ('ref(' in files['dbt/models/gold_orders.sql'] or 'source(' in files['dbt/models/gold_orders.sql']))
c('dag',len(files['dags/capstone_dag.py'])>350 and ('dag' in files['dags/capstone_dag.py']) and ('retry' in files['dags/capstone_dag.py'] or 'retries' in files['dags/capstone_dag.py']))
c('spark_judgment',len(files['spark/lakehouse_job.py'])>250)
c('security',all(x in files['security.md'] for x in ['least','secret','pii']))
c('monitoring',all(x in files['monitoring.md'] for x in ['fresh','quality','fail','cost']))
c('runbook',all(x in files['runbook.md'] for x in ['backfill','rollback','recover','rerun']))
c('ci','pull_request' in files['.github/workflows/ci.yml'] and ('secret' in files['.github/workflows/ci.yml']) and ('test' in files['.github/workflows/ci.yml']))
c('source_bundle',all(Path(x).exists() for x in ['data/api_pages/page1.json','data/api_pages/page2.json','data/csv_drop/delivery_2026-08-20.csv','data/csv_drop/refunds_2026-08-21.csv','sql/seller_seed.sql']))
c('incident_assets',len(list(Path('incidents').glob('*')))>=8)
c('readme',all(x in files['README.md'] for x in ['run','architecture','incident','limitation']))
c('defense',all(x in files['defense.md'] for x in ['trade-off','10x','recovery','cost','security']))
alltext='\n'.join(files.values()); c('no_literal_secret',not re.search(r'(password|token|api_key|secret)\s*=\s*["\'][^"\']+["\']',alltext))
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}'); raise SystemExit(0 if all(v for _,v in checks) else 1)
