# TODO API + CSV + database ingestion; raw preservation; idempotent batch metadata.
