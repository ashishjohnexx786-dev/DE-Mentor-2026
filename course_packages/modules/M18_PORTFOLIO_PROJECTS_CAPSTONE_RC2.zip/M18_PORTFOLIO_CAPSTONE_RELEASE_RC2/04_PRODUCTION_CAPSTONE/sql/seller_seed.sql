CREATE TABLE sellers(seller_id TEXT PRIMARY KEY, seller_name TEXT, email TEXT);
INSERT INTO sellers VALUES ('S1','Alpha Seller','alpha@example.com'),('S2','Beta Seller','beta@example.com');
