Extraction succeeds, transformation fails. Preserve successful upstream evidence; retry only safe tasks; do not duplicate trusted data.
