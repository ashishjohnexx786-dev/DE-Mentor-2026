Inject a duplicate trusted business key so a uniqueness test fails. Downstream Gold publish must stop.
