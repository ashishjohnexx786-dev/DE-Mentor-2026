Simulate authentication failure. Do not print the secret. Mark source freshness failed and block trusted publish.
