# P1 Reliable Batch Pipeline
Start with P1_BRIEF.pdf.
