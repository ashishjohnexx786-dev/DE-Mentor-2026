# TODO: implement source ingestion, raw preservation, validation/quarantine, reconciliation and safe trusted load.
