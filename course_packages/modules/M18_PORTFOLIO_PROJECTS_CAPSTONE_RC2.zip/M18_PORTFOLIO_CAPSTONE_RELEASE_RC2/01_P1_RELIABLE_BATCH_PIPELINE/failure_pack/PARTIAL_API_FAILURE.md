# Partial API failure
Simulate page 2 returning HTTP 500 after page 1 was preserved. Downstream trusted publish must not pretend the customer snapshot is complete. Save first failure evidence, retry safely, then reconcile.
