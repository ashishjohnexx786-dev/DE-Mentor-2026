CREATE TABLE source_payments(payment_id TEXT PRIMARY KEY, order_id TEXT, method TEXT);
INSERT INTO source_payments VALUES ('P1','O1','CARD'),('P2','O2','UPI'),('P3','O5','CARD'),('P4','O6','COD');
