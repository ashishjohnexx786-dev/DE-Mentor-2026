M18 - Portfolio Projects + Production Capstone | RC2

Order: 00_START_HERE -> P1 -> P2 -> P3 -> Production Capstone -> Completion.
Project review folders are opened only after a complete saved project attempt.
For the capstone, do not open 90_OPEN_AFTER_FIRST_ATTEMPT until a first end-to-end implementation is saved.
Live tool/runtime evidence remains conditional where the build environment cannot execute PostgreSQL/dbt/Docker/Airflow/Spark/Delta/Fabric.
Internal known-good solutions are intentionally not included.
