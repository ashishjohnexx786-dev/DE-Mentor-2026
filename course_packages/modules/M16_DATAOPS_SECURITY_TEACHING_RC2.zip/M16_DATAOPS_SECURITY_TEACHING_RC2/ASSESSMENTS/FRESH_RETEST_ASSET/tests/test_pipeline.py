import unittest
from src.pipeline import classify_claim
class TestClaim(unittest.TestCase):
    def test_valid(self):
        out=classify_claim({'claim_id':'CL1','amount':'125.5','status':' approved ','claimant_email':'x@example.com'})
        self.assertEqual(out['status'],'APPROVED'); self.assertNotIn('claimant_email',out)
    def test_negative(self):
        with self.assertRaises(ValueError): classify_claim({'claim_id':'CL2','amount':'-1','status':'NEW','claimant_email':'x@example.com'})
if __name__=='__main__': unittest.main()
