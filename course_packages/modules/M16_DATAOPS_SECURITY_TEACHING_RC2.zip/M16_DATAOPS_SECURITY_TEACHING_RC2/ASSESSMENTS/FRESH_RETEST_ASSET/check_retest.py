import json, subprocess, sys, re
from pathlib import Path
checks=[]
def c(n,o): checks.append((n,bool(o))); print(f'{n}={"PASS" if o else "FAIL"}')
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],capture_output=True,text=True); c('unit_tests',r.returncode==0)
try:
 from src.pipeline import classify_claim
 x=classify_claim({'claim_id':'CL9','amount':'20','status':' paid ','claimant_email':'a@example.com'})
 c('claim_normalization',x.get('claim_id')=='CL9' and x.get('status')=='PAID' and 'claimant_email' not in x)
except: c('claim_normalization',False)
wf=Path('.github/workflows/ci.yml').read_text(); c('ci_pr','pull_request:' in wf); c('ci_tests','unittest discover' in wf); c('ci_checker','check_retest.py' in wf); c('ci_permissions','contents: read' in wf and 'write-all' not in wf)
text='\n'.join(p.read_text(errors='ignore') for p in Path('.').rglob('*') if p.is_file() and '.git' not in p.parts); c('no_secret',not re.search(r'(?i)(password|secret|token|api[_-]?key)\s*[:=]\s*["\'][^"\']{12,}["\']',text))
try:
 rb=json.loads(Path('rbac.json').read_text()); c('rbac',set(rb.get('claim_analyst',[]))=={'read_gold'} and set(rb.get('claim_pipeline',[]))=={'read_raw','write_silver','write_gold'})
except: c('rbac',False)
try:
 ln=json.loads(Path('lineage.json').read_text()); c('lineage',len(ln.get('datasets',[]))>=3 and all(d.get('owner') and d.get('grain') for d in ln['datasets']))
except: c('lineage',False)
try:
 m=json.loads(Path('metrics.json').read_text()); c('metrics',all(k in m for k in ['run_id','duration_seconds','source_rows','loaded_rows','rejected_rows','freshness_minutes','status']))
except: c('metrics',False)
run=Path('RUNBOOK.md').read_text().lower(); c('runbook',all(x in run for x in ['detect','triage','contain','recover','validat']))
main=Path('terraform/main.tf').read_text(); c('terraform','resource "terraform_data"' in main and 'variable "environment"' in main); c('state_ignore','tfstate' in Path('terraform/.gitignore').read_text())
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}')
raise SystemExit(0 if all(v for _,v in checks) else 1)
