def classify_claim(row: dict) -> dict:
    # TODO validate claim_id, amount >= 0, allowed status and minimize claimant_email from published output
    raise NotImplementedError
