import json, subprocess, sys, re
from pathlib import Path
root=Path('.')
checks=[]
def c(name,ok): checks.append((name,bool(ok))); print(f'{name}={"PASS" if ok else "FAIL"}')
# executable tests
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],capture_output=True,text=True); c('unit_tests',r.returncode==0)
# pipeline semantics
try:
    from src.pipeline import classify_event
    x=classify_event({'delivery_id':'D9','status':' in_transit ','event_time':'2026-08-27T09:00:00Z'})
    c('normalization',x.get('status')=='IN_TRANSIT' and x.get('delivery_id')=='D9')
except Exception: c('normalization',False)
# CI
wf=Path('.github/workflows/ci.yml').read_text(); c('ci_pull_request','pull_request:' in wf); c('ci_tests','unittest discover' in wf); c('ci_required_checker','check_practical.py' in wf); c('ci_min_permissions','contents: read' in wf and 'write-all' not in wf)
# configs/secrets
blob=(Path('config/dev.json').read_text()+Path('config/prod.json').read_text()).lower(); c('config_no_secret_keys',not any(x in blob for x in ['password','secret','token','api_key']))
all_text='\n'.join(p.read_text(errors='ignore') for p in root.rglob('*') if p.is_file() and '.git' not in p.parts)
c('no_hardcoded_secret',not re.search(r'(?i)(password|secret|token|api[_-]?key)\s*[:=]\s*["\'][^"\']{12,}["\']',all_text))
# rbac
try:
    rb=json.loads(Path('rbac.json').read_text()); c('rbac_analyst_read_only',set(rb.get('analyst',[]))=={'read_gold'}); c('rbac_service_minimal',set(rb.get('pipeline_service',[]))=={'read_raw','write_silver','write_gold'})
except: c('rbac_analyst_read_only',False); c('rbac_service_minimal',False)
# classification
try:
    cl=json.loads(Path('classification.json').read_text()); c('pii_classified',cl.get('driver_email') in {'pii','sensitive'} and cl.get('customer_phone') in {'pii','sensitive'})
except: c('pii_classified',False)
# lineage
try:
    ln=json.loads(Path('lineage.json').read_text()); ds=ln.get('datasets',[]); c('lineage_complete',len(ds)>=3 and all(d.get('name') and d.get('owner') and d.get('grain') for d in ds))
except: c('lineage_complete',False)
# metrics
try:
    m=json.loads(Path('metrics.json').read_text()); c('observability_metrics',all(k in m for k in ['run_id','duration_seconds','source_rows','loaded_rows','rejected_rows','freshness_minutes','status']))
except: c('observability_metrics',False)
# runbook
run=Path('RUNBOOK.md').read_text().lower(); c('runbook',all(x in run for x in ['detect','triage','contain','recover','validat']))
# terraform
main=Path('terraform/main.tf').read_text(); c('terraform_data','resource "terraform_data"' in main); c('terraform_variables','variable "environment"' in main); gi=Path('terraform/.gitignore').read_text(); c('terraform_state_ignored','tfstate' in gi)
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}')
raise SystemExit(0 if all(v for _,v in checks) else 1)
