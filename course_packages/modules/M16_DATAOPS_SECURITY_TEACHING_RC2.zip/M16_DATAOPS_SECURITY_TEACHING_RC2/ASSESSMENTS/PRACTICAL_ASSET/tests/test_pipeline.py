import unittest
from src.pipeline import classify_event
class TestPipeline(unittest.TestCase):
    def test_delivered(self):
        row={'delivery_id':'D1','status':' delivered ','event_time':'2026-08-27T08:00:00Z'}
        self.assertEqual(classify_event(row)['status'],'DELIVERED')
    def test_missing_id(self):
        with self.assertRaises(ValueError): classify_event({'delivery_id':'','status':'IN_TRANSIT','event_time':'x'})
if __name__=='__main__': unittest.main()
