# TODO: detection -> triage -> containment -> recovery -> validation
