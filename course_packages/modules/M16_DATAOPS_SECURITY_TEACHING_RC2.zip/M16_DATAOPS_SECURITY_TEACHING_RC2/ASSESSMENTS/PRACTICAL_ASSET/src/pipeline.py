"""Complete the production hardening functions. Do not hardcode secrets."""
def classify_event(row: dict) -> dict:
    # TODO: validate delivery_id, status, event_time; return normalized row
    raise NotImplementedError
