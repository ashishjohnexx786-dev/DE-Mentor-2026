from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class Order:
    order_id: str
    customer_id: str
    amount: float
    status: str

ALLOWED_STATUS = {"NEW", "PAID", "SHIPPED"}

def normalize_status(value: str) -> str:
    return value.strip().upper()

def validate_order(row: dict) -> tuple[bool, str]:
    oid = str(row.get("order_id", "")).strip()
    cid = str(row.get("customer_id", "")).strip()
    if not oid: return False, "missing order_id"
    if not cid: return False, "missing customer_id"
    try:
        amount=float(row.get("amount", ""))
    except (TypeError, ValueError):
        return False, "amount is not numeric"
    if amount < 0: return False, "negative amount"
    status=normalize_status(str(row.get("status", "")))
    if status not in ALLOWED_STATUS: return False, "invalid status"
    return True, "ok"

def deduplicate(rows: list[dict]) -> list[dict]:
    seen=set(); out=[]
    for row in rows:
        oid=str(row.get("order_id", "")).strip()
        if oid in seen: continue
        seen.add(oid); out.append(row)
    return out
