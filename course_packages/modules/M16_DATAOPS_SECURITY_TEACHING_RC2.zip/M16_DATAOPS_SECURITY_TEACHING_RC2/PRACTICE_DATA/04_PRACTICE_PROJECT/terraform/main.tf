terraform {
  required_version = ">= 1.5.0"
}
variable "environment" { type = string }
variable "dataset_name" { type = string }
resource "terraform_data" "pipeline_config" {
  input = {
    environment = var.environment
    dataset     = var.dataset_name
  }
}
output "pipeline_config" { value = terraform_data.pipeline_config.output }
