from pathlib import Path
text=Path('main.tf').read_text()
checks={
 'required_version':'required_version' in text,
 'terraform_data':'resource "terraform_data"' in text,
 'variables':'variable "environment"' in text and 'variable "dataset_name"' in text,
 'output':'output "pipeline_config"' in text,
}
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
raise SystemExit(0 if all(checks.values()) else 1)
