import unittest
from src.pipeline import normalize_status, validate_order, deduplicate

class PipelineTests(unittest.TestCase):
    def test_normalize_status(self):
        self.assertEqual(normalize_status(' paid '), 'PAID')
    def test_negative_amount_rejected(self):
        ok, reason = validate_order({'order_id':'O1','customer_id':'C1','amount':'-2','status':'PAID'})
        self.assertFalse(ok); self.assertIn('negative', reason)
    def test_good_order(self):
        ok, reason = validate_order({'order_id':'O1','customer_id':'C1','amount':'12.5','status':'shipped'})
        self.assertTrue(ok); self.assertEqual(reason,'ok')
    def test_dedupe(self):
        rows=[{'order_id':'O1'},{'order_id':'O1'},{'order_id':'O2'}]
        self.assertEqual([r['order_id'] for r in deduplicate(rows)], ['O1','O2'])

if __name__ == '__main__': unittest.main()
