import csv, sys
from pathlib import Path
from src.pipeline import validate_order

def run(path: str) -> int:
    rows=list(csv.DictReader(open(path, newline='', encoding='utf-8')))
    errors=[]; seen=set()
    for i,row in enumerate(rows, start=2):
        oid=row.get('order_id','').strip()
        if oid in seen: errors.append(f'row {i}: duplicate order_id {oid}')
        seen.add(oid)
        ok, reason=validate_order(row)
        if not ok: errors.append(f'row {i}: {reason}')
    if errors:
        print('QUALITY_GATE=FAIL')
        for e in errors: print(e)
        return 1
    print(f'QUALITY_GATE=PASS rows={len(rows)}')
    return 0

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: python G02_QUALITY_GATE.py data/orders_good.csv')
    raise SystemExit(run(sys.argv[1]))
