# Daily Orders Incident Runbook
1. Preserve the failing run id, logs, input identifiers, metrics and deployed commit.
2. Stop unsafe downstream publication if correctness is uncertain.
3. Classify: source missing/schema, quality, code/config, permission, capacity/performance.
4. Repair the smallest verified cause; do not delete good historical data.
5. Rerun/backfill the affected period using the normal idempotent path.
6. Validate source/loaded/rejected totals and downstream freshness.
7. Record cause, contributing controls, action owner and prevention work.
