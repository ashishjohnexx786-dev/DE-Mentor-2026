import re, sys
from pathlib import Path
SKIP={'.git','.venv','__pycache__'}
PATTERNS=[
 re.compile(r'(?i)(password|passwd|secret|token|api[_-]?key)\s*[:=]\s*["\']([^"\']{12,})["\']'),
 re.compile(r'gh[pousr]_[A-Za-z0-9_]{20,}'),
]
def scan(root: Path):
    hits=[]
    for p in root.rglob('*'):
        if not p.is_file() or any(part in SKIP for part in p.parts): continue
        if p.suffix.lower() not in {'.py','.yml','.yaml','.json','.env','.txt','.md','.tf','.toml','.ini'}: continue
        try: text=p.read_text(errors='ignore')
        except Exception: continue
        if p.name.endswith('.example'): continue
        for n,line in enumerate(text.splitlines(),1):
            if any(rx.search(line) for rx in PATTERNS): hits.append((str(p),n))
    return hits
if __name__=='__main__':
    root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
    hits=scan(root)
    if hits:
        print('SECRET_SCAN=FAIL')
        for p,n in hits: print(f'{p}:{n}: secret-like assignment')
        raise SystemExit(1)
    print('SECRET_SCAN=PASS')
