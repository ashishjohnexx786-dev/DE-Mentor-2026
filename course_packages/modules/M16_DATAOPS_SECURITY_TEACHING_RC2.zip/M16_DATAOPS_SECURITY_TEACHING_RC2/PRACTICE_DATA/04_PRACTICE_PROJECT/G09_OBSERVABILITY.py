import argparse, json, time
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--scenario',choices=['normal','bad'],default='normal'); p.add_argument('--out',default='evidence/metrics.json'); a=p.parse_args()
metrics = {'run_id':'m16-demo','status':'success','duration_seconds':12,'source_rows':100,'loaded_rows':99,'rejected_rows':1,'freshness_minutes':8}
if a.scenario=='bad': metrics.update({'status':'degraded','duration_seconds':95,'loaded_rows':72,'rejected_rows':28,'freshness_minutes':145})
metrics['alert']= metrics['duration_seconds']>60 or metrics['rejected_rows']>10 or metrics['freshness_minutes']>60
out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(metrics,indent=2)+'\n')
print(json.dumps(metrics,sort_keys=True))
raise SystemExit(1 if metrics['alert'] else 0)
