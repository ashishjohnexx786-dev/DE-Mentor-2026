import json, os
from pathlib import Path
env=os.getenv('APP_ENV','dev')
if env not in {'dev','test','prod'}: raise SystemExit('APP_ENV must be dev/test/prod')
cfg=json.loads((Path('config')/f'{env}.json').read_text())
for forbidden in ('password','secret','token','key'):
    if forbidden in json.dumps(cfg).lower(): raise SystemExit('secret-like config key detected')
print(json.dumps(cfg, sort_keys=True))
