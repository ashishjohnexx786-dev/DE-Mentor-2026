import json, subprocess, sys
from pathlib import Path
root=Path('.')
checks=[]
def c(name, ok): checks.append((name,bool(ok))); print(f'{name}={"PASS" if ok else "FAIL"}')
# tests
r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],capture_output=True,text=True); c('unit_tests',r.returncode==0)
# quality pass/fail
r1=subprocess.run([sys.executable,'G02_QUALITY_GATE.py','data/orders_good.csv'],capture_output=True,text=True); c('quality_good_pass',r1.returncode==0)
r2=subprocess.run([sys.executable,'G02_QUALITY_GATE.py','data/orders_bad.csv'],capture_output=True,text=True); c('quality_bad_fail',r2.returncode!=0)
# workflow simple text checks (no PyYAML dependency requirement)
wf=(root/'.github/workflows/ci.yml').read_text(); c('ci_pr_trigger','pull_request:' in wf); c('ci_tests','unittest discover' in wf); c('ci_quality','G02_QUALITY_GATE.py' in wf); c('ci_permissions','contents: read' in wf)
# env configs no secret key names
blob=''.join(p.read_text() for p in (root/'config').glob('*.json')).lower(); c('config_no_secrets',not any(x in blob for x in ['password','secret','token','api_key']))
# scanner clean
rs=subprocess.run([sys.executable,'G05_SECRET_SCAN.py','.'],capture_output=True,text=True); c('secret_scan',rs.returncode==0)
# rbac
rb=json.loads((root/'G06_RBAC.json').read_text()); c('rbac_least_privilege',rb['roles']['analyst']['actions']==['read'] and 'admin' not in rb['roles']['pipeline_service']['actions'])
# pii
rp=subprocess.run([sys.executable,'G07_MASK_PII.py'],capture_output=True,text=True); c('mask_runs',rp.returncode==0)
pub=(root/'evidence/customers_published.csv').read_text(); c('raw_email_not_published','@example.com' not in pub)
# lineage
ln=json.loads((root/'G08_LINEAGE.json').read_text()); c('lineage_owners',all(x.get('owner') and x.get('grain') for x in ln['datasets']))
# observability normal/bad
rn=subprocess.run([sys.executable,'G09_OBSERVABILITY.py','--scenario','normal','--out','evidence/normal.json']); c('obs_normal_pass',rn.returncode==0)
rbad=subprocess.run([sys.executable,'G09_OBSERVABILITY.py','--scenario','bad','--out','evidence/bad.json']); c('obs_bad_alert',rbad.returncode!=0)
# runbook
runbook=(root/'RUNBOOK.md').read_text().lower(); c('runbook_recovery',all(x in runbook for x in ['preserve','rerun','validate']))
# terraform static
rt=subprocess.run([sys.executable,'offline_validate_hcl.py'],cwd=root/'terraform'); c('terraform_static',rt.returncode==0)
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}')
raise SystemExit(0 if all(v for _,v in checks) else 1)
