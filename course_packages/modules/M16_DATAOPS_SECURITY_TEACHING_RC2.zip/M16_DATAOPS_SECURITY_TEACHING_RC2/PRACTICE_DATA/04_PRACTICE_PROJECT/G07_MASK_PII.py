import csv, hashlib
from pathlib import Path
src=Path('data/customers.csv'); out=Path('evidence/customers_published.csv'); out.parent.mkdir(exist_ok=True)
rows=list(csv.DictReader(src.open(newline='',encoding='utf-8')))
fields=['customer_id','region','email_token']
with out.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=fields); wr.writeheader()
    for r in rows:
        token=hashlib.sha256(('m16-training|'+r['email'].strip().lower()).encode()).hexdigest()[:12]
        wr.writerow({'customer_id':r['customer_id'],'region':r['region'],'email_token':token})
print(f'published={len(rows)} path={out}')
