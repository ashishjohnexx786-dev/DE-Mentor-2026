M16 DataOps, Security & Production Operations TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf
Reuse Git/Python project tools. GitHub Actions can be understood locally from YAML/tests; Terraform is offline/static unless you have a deliberately safe cloud sandbox. Never use real secrets/PII in security exercises.
Offline validators/tests are included. Live GitHub/cloud/IaC deployment evidence remains environment-dependent and must never be fabricated.
