M14 KAFKA + STREAMING RC1

Start with 00_START_HERE/M14_START_HERE.pdf after learner PDFs are produced. Kafka/Docker/Python-client/Spark-Kafka live execution is mandatory before course-wide FINAL. Do not mark broker labs complete from static code reading.
