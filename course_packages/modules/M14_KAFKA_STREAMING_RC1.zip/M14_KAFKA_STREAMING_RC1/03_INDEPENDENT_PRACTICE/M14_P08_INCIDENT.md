# P08 - Lag incident

## Scenario
Only partition 3 has large lag; CPU is moderate; downstream calls slow for keys in that partition.

## My solution

## Required evidence
Lag by partition + processing metrics + downstream/key hypothesis.

## Validation / reasoning

## Failure condition to avoid
Fails if offsets are reset to latest to make lag disappear.
