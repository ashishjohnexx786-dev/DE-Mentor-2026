# P07 - Poison event

## Scenario
One malformed record repeats forever and blocks useful work.

## My solution

## Required evidence
Retry budget + quarantine/DLQ-style record + alert/runbook.

## Validation / reasoning

## Failure condition to avoid
Fails if the event is silently skipped with no durable evidence.
