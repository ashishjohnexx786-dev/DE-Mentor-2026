# P03 - Replay plan

## Scenario
A bug corrupted downstream records for one partition between known offsets.

## My solution

## Required evidence
Partition/offset boundaries + sink rule + checks.

## Validation / reasoning

## Failure condition to avoid
Fails if the plan blindly resets the entire consumer group.
