# P02 - Partition key design

## Scenario
Payment events must preserve account-level order; one enterprise account generates 40% of traffic.

## My solution

## Required evidence
Ordering domain + skew evidence/mitigation plan.

## Validation / reasoning

## Failure condition to avoid
Fails if keying solves order but ignores a known hot-key risk.
