# P09 - Streaming checkpoint change

## Scenario
A stateful Spark query needs a schema/logic change.

## My solution

## Required evidence
Old/new query contract + migration/restart strategy.

## Validation / reasoning

## Failure condition to avoid
Fails if checkpoint deletion is the default fix.
