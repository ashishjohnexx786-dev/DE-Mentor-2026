# P04 - Consumer group capacity

## Scenario
Topic has 6 partitions; consumers average 100 msg/s; input is 450 msg/s.

## My solution

## Required evidence
Capacity calculation + worker/partition plan.

## Validation / reasoning

## Failure condition to avoid
Fails if proposing 20 active consumers as if all can own a partition.
