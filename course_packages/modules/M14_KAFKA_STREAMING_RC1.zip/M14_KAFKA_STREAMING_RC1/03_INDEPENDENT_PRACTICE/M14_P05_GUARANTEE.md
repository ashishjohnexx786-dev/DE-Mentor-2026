# P05 - Delivery guarantee

## Scenario
Consumer writes to PostgreSQL then commits Kafka offset. Crash can occur between them.

## My solution

## Required evidence
Failure timeline + unique/upsert key + commit rule.

## Validation / reasoning

## Failure condition to avoid
Fails if “manual commit = exactly once” is claimed.
