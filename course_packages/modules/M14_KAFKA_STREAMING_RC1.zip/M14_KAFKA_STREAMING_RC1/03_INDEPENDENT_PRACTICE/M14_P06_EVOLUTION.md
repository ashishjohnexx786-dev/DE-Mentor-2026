# P06 - Schema evolution

## Scenario
Producer adds optional device_model; later changes temperature from numeric to free text.

## My solution

## Required evidence
Compatibility table + quarantine/fail rule.

## Validation / reasoning

## Failure condition to avoid
Fails if parseable JSON is treated as compatible semantics.
