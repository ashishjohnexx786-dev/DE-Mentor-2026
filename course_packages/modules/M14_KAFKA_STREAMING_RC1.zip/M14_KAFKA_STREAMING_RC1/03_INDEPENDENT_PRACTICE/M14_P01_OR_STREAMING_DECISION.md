# P01 - Batch or streaming decision

## Scenario
A supplier sends one 20MB file nightly; operations needs results by 7AM.

## My solution

## Required evidence
Decision memo + rejected alternative.

## Validation / reasoning

## Failure condition to avoid
Fails if streaming is chosen only because it is newer.
