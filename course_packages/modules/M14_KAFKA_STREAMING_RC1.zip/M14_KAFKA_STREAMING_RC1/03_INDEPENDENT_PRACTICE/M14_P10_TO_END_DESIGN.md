# P10 - End-to-end design

## Scenario
Website click events need 30-second freshness and hourly curated aggregates.

## My solution

## Required evidence
Architecture diagram + key/topic/group + quality + lag/recovery plan.

## Validation / reasoning

## Failure condition to avoid
Fails if consumer/sink idempotency is omitted.
