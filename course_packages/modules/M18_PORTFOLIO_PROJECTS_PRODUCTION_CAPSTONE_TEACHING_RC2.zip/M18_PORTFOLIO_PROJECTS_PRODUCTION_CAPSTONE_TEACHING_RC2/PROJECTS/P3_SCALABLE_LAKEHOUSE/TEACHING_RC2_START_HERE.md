# P3 Scalable Lakehouse Pipeline - Teaching RC2

Read ../../04_P3_SCALABLE_LAKEHOUSE_PROJECT_BOOK_TEACHING_RC2.pdf before coding.
The Spark/Delta files are deliberately incomplete starter assets. Do not claim local tiny-data performance as production-scale proof.
Expected logical summary after a correct build: source_rows=8, valid_rows=6, latest_shipments=5, quarantined_rows=2.
