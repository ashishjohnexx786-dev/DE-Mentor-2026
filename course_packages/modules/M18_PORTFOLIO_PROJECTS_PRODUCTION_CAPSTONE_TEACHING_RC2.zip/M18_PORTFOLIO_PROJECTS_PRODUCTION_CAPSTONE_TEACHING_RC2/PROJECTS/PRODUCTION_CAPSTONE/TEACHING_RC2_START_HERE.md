# Production Capstone - Teaching RC2

Read ../../05_PRODUCTION_CAPSTONE_BUILD_BOOK_TEACHING_RC2.pdf, then CAPSTONE_BRIEF.pdf.
Create evidence/attempt-01 and build an end-to-end first attempt BEFORE opening 90_OPEN_AFTER_FIRST_ATTEMPT.
The capstone intentionally contains incomplete starter files; there is no protected full solution in this package.
