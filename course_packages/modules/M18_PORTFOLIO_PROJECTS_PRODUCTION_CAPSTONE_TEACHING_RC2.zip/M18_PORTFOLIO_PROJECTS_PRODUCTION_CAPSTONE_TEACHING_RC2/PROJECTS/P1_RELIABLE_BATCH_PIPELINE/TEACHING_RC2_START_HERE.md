# P1 Reliable Batch Pipeline - Teaching RC2

1. Read ../../02_P1_RELIABLE_BATCH_PIPELINE_PROJECT_BOOK_TEACHING_RC2.pdf first.
2. Then read P1_BRIEF.pdf.
3. Create evidence/attempt-01 BEFORE implementation.
4. Build phase-by-phase. The starter TODO code is intentionally incomplete.
5. Open 90_REVIEW_AFTER_SUBMISSION only after a complete saved attempt.

Expected checker control summary after a correct build: source_rows=8, dedup_rows=7, valid_orders=4, quarantined_orders=3, valid_amount=5800.0, customers_loaded=7, payments_loaded=4.
