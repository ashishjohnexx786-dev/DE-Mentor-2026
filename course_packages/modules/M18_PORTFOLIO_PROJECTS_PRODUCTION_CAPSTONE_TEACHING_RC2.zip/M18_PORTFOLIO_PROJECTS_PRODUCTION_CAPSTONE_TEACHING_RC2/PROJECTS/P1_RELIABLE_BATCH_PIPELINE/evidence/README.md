Save small evidence: commands, logs, control totals, failing/repair notes. Do not commit secrets or huge raw extracts.
