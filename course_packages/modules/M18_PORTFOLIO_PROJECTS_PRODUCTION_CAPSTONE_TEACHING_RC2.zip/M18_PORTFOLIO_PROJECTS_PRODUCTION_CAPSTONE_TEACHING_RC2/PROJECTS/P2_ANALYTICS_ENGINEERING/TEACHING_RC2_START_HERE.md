# P2 Analytics Engineering Platform - Teaching RC2

Read ../../03_P2_ANALYTICS_ENGINEERING_PROJECT_BOOK_TEACHING_RC2.pdf before coding.
The dbt/DAG files are deliberately incomplete starter assets. Create evidence/attempt-01 and preserve first failures.
