# Runbook
Normal run:
Expected inputs/outputs:
Rerun procedure:
Late-data procedure:
Backfill range procedure:
Partial failure recovery:
Rollback/revert procedure:
Quality failure response:
Credential/source outage response:
Known manual steps:
