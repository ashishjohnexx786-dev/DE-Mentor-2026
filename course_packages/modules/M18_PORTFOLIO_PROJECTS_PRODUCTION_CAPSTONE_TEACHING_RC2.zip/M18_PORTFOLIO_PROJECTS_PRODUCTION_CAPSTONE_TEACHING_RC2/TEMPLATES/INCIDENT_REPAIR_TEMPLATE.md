# Incident repair evidence
Incident:
First failing evidence path:
Observed symptom:
Root cause:
Why trusted publish/result was or was not protected:
Smallest safe repair:
Rerun steps:
Post-repair control totals/tests:
Why another rerun remains safe:
Remaining limitation:
