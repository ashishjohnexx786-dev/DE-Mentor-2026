# Source contract
Source owner:
Delivery method:
Grain (one row/object means):
Business key:
Required fields/types:
Optional fields:
Event/update timestamp:
Freshness expectation:
Duplicate/redelivery semantics:
Late data policy:
Schema-change policy:
Failure/escalation behavior:
