# Project title - business outcome

## Business problem
Who needs what result and why?

## Architecture
Source -> Raw -> Quality/Quarantine -> Trusted -> Gold/Serving

## Data contracts and grain
- Source grain/key:
- Trusted output grain/key:

## Setup and run
Exact reproducible commands.

## Quality and reconciliation
Rules + control totals.

## Rerun, incremental, late data and backfill
State actual behavior.

## Failure tested
First failure -> root cause -> repair -> proof.

## Security
Secrets/PII/access.

## Known limitations
Be specific and honest.

## 10x scale
What would change and why?
