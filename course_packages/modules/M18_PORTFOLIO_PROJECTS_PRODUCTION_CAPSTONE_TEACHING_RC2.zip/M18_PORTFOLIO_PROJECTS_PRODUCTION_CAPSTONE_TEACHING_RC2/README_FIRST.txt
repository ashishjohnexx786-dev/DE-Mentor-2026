M18 PORTFOLIO PROJECTS + PRODUCTION CAPSTONE - TEACHING RC2
START with 00_START_HERE_PROJECT_MODE_TEACHING_RC2.pdf.
Then read 01_PROJECT_HANDBOOK_TEACHING_RC2.pdf.
Order: P1 -> P2 -> P3 -> Production Capstone.
Project books explain expectations and provide toy demonstrations, but project starter implementation remains intentionally incomplete.
Open protected Review/Incident material only after saved attempts as stated.
