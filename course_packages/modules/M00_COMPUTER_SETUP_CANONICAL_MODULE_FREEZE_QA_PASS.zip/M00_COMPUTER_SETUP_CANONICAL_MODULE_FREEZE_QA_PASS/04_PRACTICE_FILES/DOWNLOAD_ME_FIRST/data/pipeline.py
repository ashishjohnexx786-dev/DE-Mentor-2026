print("M00 practice file")
