This text file is intentionally named to discuss extensions.
