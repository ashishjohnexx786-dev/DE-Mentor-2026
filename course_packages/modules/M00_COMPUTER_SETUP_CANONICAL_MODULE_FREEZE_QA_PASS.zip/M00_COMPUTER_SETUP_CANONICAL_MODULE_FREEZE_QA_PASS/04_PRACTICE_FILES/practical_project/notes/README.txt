Practice project for M00 integrated proof.
