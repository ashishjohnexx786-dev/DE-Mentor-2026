M00 CURRENT LEARNER BOOK - RC5 POST-DEPLOY SEMANTIC REPAIR

The 2026-09-11 RC5 learner book supersedes the RC4 learner-book semantic acceptance.
Use 01_LESSONS first. It now follows the explicit 16-stage beginner-first teacher route and makes external source links visibly discoverable.
All protected review / fresh retry rules remain attempt-first. Whole-course FINAL still requires runtime/device evidence.

--- Historical module instructions retained below ---

M00 MODULE CONTENT FREEZE - QA PASS (COURSE-WIDE FINAL PENDING)

Freeze date: 2026-09-10
Completion rule: competency evidence only; no percentage shortcut.
Protected review remains attempt-locked. Repair is targeted; fresh retest uses changed evidence.
Live runtime/device behavior remains pending for course-wide final validation.

--- Preserved learner instructions ---

ZERO TO JOB-READY DATA ENGINEER 2026
M00 CANONICAL REBUILD

OPEN IN THIS ORDER
1. 00_START_HERE/M00_START_HERE_CANONICAL_REBUILD.pdf
2. 01_LESSONS/M00_LEARNER_BOOK_CANONICAL_REBUILD.pdf
3. Matching Guided Lab -> Independent Practice -> protected Repair only after attempt -> Fresh Retest if needed
4. 05_MODULE_TEST/M00_MODULE_PRACTICAL_CANONICAL_REBUILD.pdf
5. 09_COMPLETION_RECORD/M00_COMPLETION_RECORD_CANONICAL_REBUILD.pdf

INSTALL BOUNDARY
Do NOT install the engineering stack in M00. Install a tool only when its first-use lesson asks for it.
First-use map: M02 MySQL/Workbench; M03 PostgreSQL first install + mini-lab; M05 Python-to-PostgreSQL via SQLAlchemy; M06 WSL/Linux + Git workflow; M07 PostgreSQL modeling re-verification/deeper modeling; M10 Docker/Airflow; later tools in their own modules.

SOURCE OF TRUTH
CONTROL/M00_CANONICAL_LESSON_MANIFEST.json
Mentor routes and all learner artifacts are generated/validated against the same 8-lesson identity.
