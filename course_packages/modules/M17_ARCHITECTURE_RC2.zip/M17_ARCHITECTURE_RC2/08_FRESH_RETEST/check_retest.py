
import json
from pathlib import Path
checks=[]
def c(n,o): checks.append((n,bool(o))); print(f'{n}={"PASS" if o else "FAIL"}')
def load(name,default=None):
 try:return json.loads(Path(name).read_text())
 except:return default
req=load('requirements.json',{}); dec=load('architecture_decision.json',{}); risks=load('risk_register.json',[]); sec=load('security_model.json',{}); cost=load('cost_plan.json',{})
c('requirements_core',all(k in req for k in ['sources','volume','latency','consumers','security','team_constraints']))
c('decision_pattern',dec.get('ingestion_mode') in ['batch','micro-batch','streaming','hybrid'])
c('decision_platform',dec.get('analytical_pattern') in ['warehouse','lakehouse','hybrid'])
c('decision_reason',len(str(dec.get('why','')))>=80)
c('alternative',len(str(dec.get('rejected_alternative','')))>=40)
c('risks',isinstance(risks,list) and len(risks)>=3 and all(all(k in r for k in ['risk','detection','mitigation','recovery']) for r in risks[:3]))
c('security_identity',isinstance(sec.get('identity_action_scope'),list) and len(sec.get('identity_action_scope',[]))>=2)
c('security_sensitive',len(sec.get('sensitive_data_controls',[]))>=2)
c('cost_drivers',len(cost.get('top_cost_drivers',[]))>=2)
c('cost_tradeoff',len(str(cost.get('optimization_tradeoff','')))>=40)
arch=Path('architecture.md').read_text(); c('architecture_flow',all(x in arch.lower() for x in ['source','raw','curated']))
defense=Path('defense.md').read_text(); c('defense_10x','10x' in defense.lower()); c('defense_failure','fail' in defense.lower()); c('defense_alternative','alternative' in defense.lower())
c('latency_fit', dec.get('ingestion_mode') in ['streaming', 'hybrid'])
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}')
raise SystemExit(0 if all(v for _,v in checks) else 1)
