M17 Architecture + Promotion Foundations | RC2
Start in 00_START_HERE. Requirements first, tools second. Human reasoning quality matters in addition to machine-checkable structure.
