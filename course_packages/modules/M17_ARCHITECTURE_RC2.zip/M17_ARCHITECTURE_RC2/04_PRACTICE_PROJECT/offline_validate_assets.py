import json
from pathlib import Path
checks=[]
def c(n,o): checks.append((n,bool(o))); print(f'{n}={"PASS" if o else "FAIL"}')
for f in ['latency_cases.json','workload_matrix.json','responsibility_matrix.json','scale_metrics.json','failure_modes.json','cost_drivers.json','security_case.json','architecture_workbook.json']:
 try: json.loads(Path(f).read_text()); c(f,True)
 except: c(f,False)
c('requirements_case',Path('requirements_case.md').exists()); c('candidate_designs',Path('candidate_designs.md').exists())
print(f'TOTAL={sum(v for _,v in checks)}/{len(checks)}')
raise SystemExit(0 if all(v for _,v in checks) else 1)
