# Candidate designs

## A - Everything streaming
Kafka + streaming compute for all sources including daily finance; many always-on services.

## B - Requirements-fit hybrid
Batch/micro-batch for hourly BI and daily finance; scalable lakehouse processing for clickstream; curated SQL marts.

## C - Single relational database
Load raw clickstream into the operational PostgreSQL database and run BI/data-science queries there.
