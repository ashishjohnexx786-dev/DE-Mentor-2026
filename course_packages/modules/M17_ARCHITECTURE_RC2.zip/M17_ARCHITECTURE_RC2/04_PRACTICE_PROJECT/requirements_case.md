# Retail architecture case
Sources: PostgreSQL orders/customers; clickstream files/events.
Scale: 120 GB/day clickstream; 3M order rows/day.
Consumers: BI hourly; data science raw history daily.
Latency: operations <60 min; finance daily.
Security: customer email/phone restricted.
Team: six engineers; prefer managed services.
Retention: 2 years raw clickstream.
