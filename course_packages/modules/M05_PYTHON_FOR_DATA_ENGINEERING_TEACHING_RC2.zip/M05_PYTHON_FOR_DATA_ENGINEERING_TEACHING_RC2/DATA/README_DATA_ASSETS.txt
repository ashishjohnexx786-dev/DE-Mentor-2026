M05 DATA ASSETS
orders.csv - dirty CSV (6 rows, duplicate O02, blank O03 amount, invalid O04 amount).
customers.json - 5-customer master.
events.jsonl - three event records.
batch/ - three dated files.
M05_LOCAL_API_SERVER.py - local API on 127.0.0.1:8765.
M05_CUSTOMERS.csv - module practical master.
M05_SUPPLIERS.csv - fresh retest master.
Never put a real credential into source files.
