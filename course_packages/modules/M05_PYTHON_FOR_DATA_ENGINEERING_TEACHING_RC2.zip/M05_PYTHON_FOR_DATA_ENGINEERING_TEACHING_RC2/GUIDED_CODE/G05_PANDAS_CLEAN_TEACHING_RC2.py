import pandas as pd
df=pd.read_csv("DATA/orders.csv",dtype=str)
df["amount_num"]=pd.to_numeric(df["amount"],errors="coerce")
df["duplicate_id"]=df.duplicated("order_id",keep=False)
def reason(r):
    x=[]
    if pd.isna(r["amount_num"]): x.append("invalid_or_missing_amount")
    if r["duplicate_id"]: x.append("duplicate_order_id")
    return "|".join(x)
df["reject_reason"]=df.apply(reason,axis=1)
valid=df[df["reject_reason"]==""]
rejected=df[df["reject_reason"]!=""]
print("raw",len(df),"valid",len(valid),"rejected",len(rejected))
print(rejected[["order_id","amount","reject_reason"]].to_string(index=False))
