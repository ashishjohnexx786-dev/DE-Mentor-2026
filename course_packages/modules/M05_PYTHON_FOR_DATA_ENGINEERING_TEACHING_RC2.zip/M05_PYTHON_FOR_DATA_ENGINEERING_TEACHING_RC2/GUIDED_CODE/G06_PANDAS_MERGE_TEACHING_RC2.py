import json,pandas as pd
from pathlib import Path
orders=pd.read_csv("DATA/orders.csv",dtype=str)
customers=pd.DataFrame(json.loads(Path("DATA/customers.json").read_text(encoding="utf-8"))["customers"])
merged=orders.merge(customers,on="customer_id",how="left",validate="many_to_one",indicator=True)
print("before",len(orders),"after",len(merged),"unmatched",int((merged["_merge"]!="both").sum()))
