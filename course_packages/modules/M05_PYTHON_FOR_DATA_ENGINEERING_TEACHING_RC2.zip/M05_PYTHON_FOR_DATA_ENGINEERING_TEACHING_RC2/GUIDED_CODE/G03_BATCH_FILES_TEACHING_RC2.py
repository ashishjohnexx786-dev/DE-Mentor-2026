import csv
from pathlib import Path
total=0
for p in sorted(Path("DATA/batch").glob("items_*.csv")):
    with p.open("r",encoding="utf-8",newline="") as f: n=sum(1 for _ in csv.DictReader(f))
    total+=n; print(p.name,n)
print("total_rows",total)
