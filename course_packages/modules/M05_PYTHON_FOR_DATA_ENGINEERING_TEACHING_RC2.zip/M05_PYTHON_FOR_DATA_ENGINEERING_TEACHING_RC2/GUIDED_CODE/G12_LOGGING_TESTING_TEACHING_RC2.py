import logging
logging.basicConfig(level=logging.INFO,format="%(levelname)s %(message)s")
def is_valid_amount(x): return x>=0
def test_zero(): assert is_valid_amount(0)
def test_positive(): assert is_valid_amount(10)
def test_negative(): assert not is_valid_amount(-1)
if __name__=="__main__":
    logging.info("Run: pytest -q GUIDED_CODE/G12_LOGGING_TESTING_TEACHING_RC2.py")
