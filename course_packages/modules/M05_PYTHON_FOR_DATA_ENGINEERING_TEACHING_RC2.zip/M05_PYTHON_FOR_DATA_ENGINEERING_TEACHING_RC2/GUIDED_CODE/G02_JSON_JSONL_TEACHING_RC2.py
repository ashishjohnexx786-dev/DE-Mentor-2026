import json
from pathlib import Path
doc=json.loads(Path("DATA/customers.json").read_text(encoding="utf-8"))
lookup={c["customer_id"]:c["region"] for c in doc["customers"]}
counts={}
for line in Path("DATA/events.jsonl").read_text(encoding="utf-8").splitlines():
    e=json.loads(line); counts[e["order_id"]]=counts.get(e["order_id"],0)+1
print("lookup",lookup); print("event_counts",counts)
