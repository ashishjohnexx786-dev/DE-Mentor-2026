import csv
from pathlib import Path
p=Path("DATA/orders.csv")
with p.open("r",encoding="utf-8",newline="") as f:
    rows=list(csv.DictReader(f))
print("raw_rows",len(rows))
print("blank_amounts",sum(r["amount"]=="" for r in rows))
counts={}
for r in rows: counts[r["order_id"]]=counts.get(r["order_id"],0)+1
print("duplicates",{k:v for k,v in counts.items() if v>1})
