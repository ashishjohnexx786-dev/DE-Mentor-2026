import time,requests
def fetch_with_retry(url,max_attempts=3):
    for attempt in range(1,max_attempts+1):
        r=requests.get(url,timeout=2); print("attempt",attempt,"status",r.status_code)
        if r.status_code==429:
            time.sleep(float(r.headers.get("Retry-After","1"))); continue
        if 500<=r.status_code<600:
            if attempt==max_attempts: r.raise_for_status()
            time.sleep(0.2*attempt); continue
        r.raise_for_status(); return r.json()
    raise RuntimeError("No successful response")
print(fetch_with_retry("http://127.0.0.1:8765/flaky-orders"))
print(fetch_with_retry("http://127.0.0.1:8765/rate-limited"))
