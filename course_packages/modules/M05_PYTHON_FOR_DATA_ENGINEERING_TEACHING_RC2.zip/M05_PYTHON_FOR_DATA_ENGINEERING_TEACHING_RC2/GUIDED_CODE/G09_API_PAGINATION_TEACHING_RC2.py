import requests
BASE="http://127.0.0.1:8765"
def fetch_page(page):
    r=requests.get(f"{BASE}/orders",params={"page":page},timeout=5); r.raise_for_status(); return r.json()
page=1; items=[]
while page is not None:
    data=fetch_page(page); items.extend(data["items"]); page=data["next_page"]
print("total_items",len(items)); print([x["order_id"] for x in items])
