import os
from sqlalchemy import create_engine,text
engine=create_engine(os.environ["DATABASE_URL"])
create_sql=text("CREATE TABLE IF NOT EXISTS m05_lab_orders(order_id TEXT PRIMARY KEY, amount NUMERIC NOT NULL CHECK (amount >= 0))")
upsert_sql=text("INSERT INTO m05_lab_orders(order_id,amount) VALUES (:id,:amt) ON CONFLICT (order_id) DO UPDATE SET amount=EXCLUDED.amount")
with engine.begin() as c:
    c.execute(create_sql); c.execute(upsert_sql,{"id":"LAB1","amt":100})
with engine.connect() as c:
    print("row_count",c.execute(text("SELECT COUNT(*) FROM m05_lab_orders")).scalar_one())
