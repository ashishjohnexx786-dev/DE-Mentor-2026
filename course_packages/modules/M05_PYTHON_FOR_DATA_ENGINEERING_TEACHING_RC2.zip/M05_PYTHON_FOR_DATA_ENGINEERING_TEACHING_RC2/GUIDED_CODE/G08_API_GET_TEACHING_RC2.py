import requests
r=requests.get("http://127.0.0.1:8765/orders",params={"page":1},timeout=5)
print("status",r.status_code)
r.raise_for_status()
data=r.json()
print("items",len(data["items"]),"next_page",data["next_page"])
