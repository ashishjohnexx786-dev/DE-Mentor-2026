import pandas as pd
def require_columns(df,required):
    missing=set(required)-set(df.columns)
    if missing: raise ValueError(f"Missing required columns: {sorted(missing)}")
def duplicate_key_report(df,key):
    return df.loc[df.duplicated(key,keep=False),[key]]
df=pd.read_csv("DATA/orders.csv")
require_columns(df,["order_id","customer_id","amount","order_date"])
print(duplicate_key_report(df,"order_id"))
