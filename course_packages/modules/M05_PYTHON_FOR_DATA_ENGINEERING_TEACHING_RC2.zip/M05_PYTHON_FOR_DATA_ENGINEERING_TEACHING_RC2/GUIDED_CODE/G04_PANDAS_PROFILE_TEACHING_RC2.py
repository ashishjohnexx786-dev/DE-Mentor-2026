import pandas as pd
df=pd.read_csv("DATA/orders.csv")
print("shape",df.shape)
print("columns",df.columns.tolist())
print("dtypes",df.dtypes.astype(str).to_dict())
print("nulls",df.isna().sum().to_dict())
print("duplicate_ids",df.loc[df.duplicated("order_id",keep=False),"order_id"].tolist())
