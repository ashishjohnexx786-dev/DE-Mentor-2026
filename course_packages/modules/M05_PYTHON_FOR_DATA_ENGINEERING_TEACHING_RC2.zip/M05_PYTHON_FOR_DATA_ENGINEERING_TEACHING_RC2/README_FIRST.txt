M05 PYTHON FOR DATA ENGINEERING - TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf.
Order: Learner Book -> Guided Lab -> close guidance -> Independent -> save evidence -> Review only after attempt.
Reuse Python/VS Code from M04 and PostgreSQL from M03. Do not reinstall blindly.
