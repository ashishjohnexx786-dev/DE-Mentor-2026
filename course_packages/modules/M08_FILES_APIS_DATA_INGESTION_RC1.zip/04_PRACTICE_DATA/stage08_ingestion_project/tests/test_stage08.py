import unittest
from src.common import normalize_record, watermark_tuple

GOOD={
"order_id":"X1","updated_at":"2026-08-01T00:00:00Z","customer_id":"C1",
"product_id":"P1","qty":2,"unit_price":10.0,"currency":"INR"
}

class TestStage08(unittest.TestCase):
    def test_normalize_good(self):
        self.assertEqual(normalize_record(GOOD)["qty"],2)

    def test_schema_drift_rejected(self):
        bad=dict(GOOD); bad["price"]=bad.pop("unit_price")
        with self.assertRaises(ValueError):
            normalize_record(bad)

    def test_watermark_tiebreak(self):
        a=dict(GOOD,order_id="A")
        b=dict(GOOD,order_id="B")
        self.assertLess(watermark_tuple(a),watermark_tuple(b))

if __name__=="__main__":
    unittest.main()
