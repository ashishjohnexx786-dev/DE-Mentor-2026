"""DE08-08 safe database extraction.
Uses SQLite only so the lab is fully local; the same boundaries map to PostgreSQL.
"""
from pathlib import Path
import sqlite3

DB="source/db/orders_source.sqlite"
watermark=("2026-08-06T08:15:00Z","D5002")
limit=100

# URI mode=ro prevents accidental writes during extraction.
con=sqlite3.connect(f"file:{DB}?mode=ro",uri=True)
query="""
SELECT order_id, updated_at, customer_id, product_id, qty, unit_price
FROM orders
WHERE (updated_at > ?)
   OR (updated_at = ? AND order_id > ?)
ORDER BY updated_at, order_id
LIMIT ?
"""
rows=con.execute(query,(watermark[0],watermark[0],watermark[1],limit)).fetchall()
con.close()
for row in rows:
    print(row)
