from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, tempfile

EXPECTED_FIELDS = {
    "order_id","updated_at","customer_id",
    "product_id","qty","unit_price","currency"
}

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def sha256_file(path: str | Path) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def atomic_write_json(path: str | Path, payload: dict) -> None:
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp_name=tempfile.mkstemp(prefix=p.name+".", suffix=".tmp", dir=p.parent)
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as f:
            json.dump(payload,f,indent=2,ensure_ascii=False)
        Path(tmp_name).replace(p)
    except Exception:
        try:
            Path(tmp_name).unlink(missing_ok=True)
        finally:
            raise

def parse_utc(value: str) -> datetime:
    if not value.endswith("Z"):
        raise ValueError("timestamp must end with Z (UTC)")
    dt=datetime.fromisoformat(value[:-1]+"+00:00")
    if dt.utcoffset().total_seconds()!=0:
        raise ValueError("timestamp must be UTC")
    return dt

def normalize_record(row: dict) -> dict:
    missing=EXPECTED_FIELDS-set(row)
    extra=set(row)-EXPECTED_FIELDS
    if missing or extra:
        raise ValueError(f"schema drift missing={sorted(missing)} extra={sorted(extra)}")

    order_id=str(row["order_id"]).strip()
    customer_id=str(row["customer_id"]).strip()
    product_id=str(row["product_id"]).strip()
    currency=str(row["currency"]).strip().upper()
    if not order_id or not customer_id or not product_id:
        raise ValueError("order_id/customer_id/product_id cannot be empty")

    parse_utc(str(row["updated_at"]))
    qty=int(row["qty"])
    unit_price=float(row["unit_price"])
    if qty<=0:
        raise ValueError("qty must be > 0")
    if unit_price<0:
        raise ValueError("unit_price must be >= 0")
    if currency!="INR":
        raise ValueError("course staging contract currently expects INR")

    return {
        "order_id":order_id,
        "updated_at":str(row["updated_at"]),
        "customer_id":customer_id,
        "product_id":product_id,
        "qty":qty,
        "unit_price":unit_price,
        "currency":currency
    }

def watermark_tuple(row: dict) -> tuple[str,str]:
    return (row["updated_at"], row["order_id"])
