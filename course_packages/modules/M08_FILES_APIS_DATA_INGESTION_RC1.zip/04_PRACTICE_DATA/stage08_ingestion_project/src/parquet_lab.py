"""DE08-04 Parquet lab.
Requires: pandas + pyarrow.
Install in the project environment:
    python -m pip install pandas pyarrow
"""
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq

csv_path=Path("source/files/orders_for_parquet.csv")
parquet_path=Path("source/files/orders_for_parquet.parquet")

df=pd.read_csv(csv_path)
df.to_parquet(parquet_path,index=False,engine="pyarrow")

pf=pq.ParquetFile(parquet_path)
print("schema:")
print(pf.schema_arrow)
print("row_groups:",pf.num_row_groups)
print("rows:",pf.metadata.num_rows)
print("columns:",pf.metadata.num_columns)

subset=pd.read_parquet(parquet_path,columns=["order_id","updated_at","qty"])
print(subset.head())
