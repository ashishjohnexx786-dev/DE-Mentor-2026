"""DE08-02 learner workspace.
Build defensive CSV ingestion before opening ingest_csv_reference.py.

Required:
- copy raw file into a unique landing run folder
- calculate SHA256 + row count
- validate exact staging contract
- reject duplicate order_id in the same source file
- good rows -> staging JSONL
- bad rows -> quarantine JSONL with error + source row
- write _manifest.json
"""
