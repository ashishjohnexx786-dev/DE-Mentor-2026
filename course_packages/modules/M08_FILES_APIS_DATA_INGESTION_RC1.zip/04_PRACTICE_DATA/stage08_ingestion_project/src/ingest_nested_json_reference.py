from __future__ import annotations
import json, argparse
from pathlib import Path
from src.common import normalize_record

def flatten_orders(payload: list[dict]) -> list[dict]:
    out=[]
    for order in payload:
        for line_no, item in enumerate(order["items"], start=1):
            out.append(normalize_record({
                "order_id": f"{order['order_id']}:{line_no:03d}",
                "updated_at": order["updated_at"],
                "customer_id": order["customer"]["id"],
                "product_id": item["product_id"],
                "qty": item["qty"],
                "unit_price": item["unit_price"],
                "currency": order["currency"]
            }))
    return out

if __name__=="__main__":
    p=argparse.ArgumentParser(); p.add_argument("path"); args=p.parse_args()
    payload=json.loads(Path(args.path).read_text(encoding="utf-8"))
    rows=flatten_orders(payload)
    print(json.dumps(rows,indent=2))
