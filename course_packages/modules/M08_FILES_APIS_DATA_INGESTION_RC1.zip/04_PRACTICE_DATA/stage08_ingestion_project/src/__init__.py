"""Package marker for course lab assets."""
