"""DE08-06/07/09/10/11/12 learner workspace.

Build API ingestion with:
- bearer token from STAGE08_API_TOKEN (never hard-code it)
- timeout
- pagination until next_page is None
- 429 handling using Retry-After
- retry transient 5xx/timeout/connection errors with bounded backoff
- raw page landing files + run manifest
- normalized staging contract
- quarantine schema-drift records
- checkpoint = (updated_at, order_id), updated ONLY after successful complete run
- --no-commit-state + --ignore-checkpoint style backfill/replay option
"""
