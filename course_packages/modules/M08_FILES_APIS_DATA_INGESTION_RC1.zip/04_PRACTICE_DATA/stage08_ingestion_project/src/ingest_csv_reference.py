from __future__ import annotations
import csv, json, argparse
from pathlib import Path
from src.common import normalize_record, sha256_file, utc_now_iso

def ingest_csv(path: str | Path, landing_root="landing", staging_root="staging", quarantine_root="quarantine"):
    source=Path(path)
    run_id=utc_now_iso().replace(":","").replace("-","")
    landing_dir=Path(landing_root)/"source=csv"/f"run_id={run_id}"
    landing_dir.mkdir(parents=True,exist_ok=True)
    raw_copy=landing_dir/source.name
    raw_copy.write_bytes(source.read_bytes())

    with raw_copy.open(newline="",encoding="utf-8-sig") as f:
        reader=csv.DictReader(f)
        rows=list(reader)
        actual_fields=set(reader.fieldnames or [])

    good=[]; bad=[]; seen=set()
    for n,row in enumerate(rows,start=2):
        try:
            norm=normalize_record(row)
            if norm["order_id"] in seen:
                raise ValueError(f"duplicate order_id {norm['order_id']} in file")
            seen.add(norm["order_id"])
            good.append(norm)
        except Exception as exc:
            bad.append({"source_row":n,"error":str(exc),"record":row})

    staging_path=Path(staging_root)/f"{source.stem}.jsonl"
    staging_path.parent.mkdir(parents=True,exist_ok=True)
    with staging_path.open("w",encoding="utf-8") as f:
        for row in good:
            f.write(json.dumps(row,ensure_ascii=False)+"\n")

    quarantine_path=None
    if bad:
        quarantine_path=Path(quarantine_root)/f"{source.stem}_quarantine.jsonl"
        quarantine_path.parent.mkdir(parents=True,exist_ok=True)
        with quarantine_path.open("w",encoding="utf-8") as f:
            for row in bad:
                f.write(json.dumps(row,ensure_ascii=False)+"\n")

    manifest={
        "source_type":"csv",
        "source_file":source.name,
        "retrieved_at":utc_now_iso(),
        "sha256":sha256_file(raw_copy),
        "source_rows":len(rows),
        "staged_rows":len(good),
        "quarantined_rows":len(bad),
        "actual_columns":sorted(actual_fields)
    }
    (landing_dir/"_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return manifest

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("path")
    args=p.parse_args()
    print(json.dumps(ingest_csv(args.path),indent=2))
