"""DE08-03 learner workspace.
Read source/json/orders_nested.json.
Flatten ONE order with multiple items into ONE ROW PER ORDER ITEM.
Keep customer_id, product_id, qty, unit_price, currency and order updated_at.
Choose and explain a deterministic line/business key.
"""
