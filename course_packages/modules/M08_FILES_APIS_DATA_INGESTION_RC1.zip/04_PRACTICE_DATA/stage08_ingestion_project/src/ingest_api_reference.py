from __future__ import annotations
import argparse, hashlib, json, os, time
from pathlib import Path
import requests
from src.common import normalize_record, atomic_write_json, utc_now_iso, watermark_tuple

BASE_URL="http://127.0.0.1:8008"
STATE_PATH=Path("state/api_checkpoint.json")

def request_with_retry(session, url, *, headers, params, attempts=4, timeout=5):
    last=None
    for attempt in range(1,attempts+1):
        try:
            r=session.get(url,headers=headers,params=params,timeout=timeout)
            if r.status_code==429:
                wait=float(r.headers.get("Retry-After","1"))
                if attempt==attempts:
                    r.raise_for_status()
                time.sleep(wait)
                continue
            if 500 <= r.status_code < 600:
                if attempt==attempts:
                    r.raise_for_status()
                time.sleep(0.5*(2**(attempt-1)))
                continue
            r.raise_for_status()
            return r
        except (requests.Timeout, requests.ConnectionError) as exc:
            last=exc
            if attempt==attempts:
                raise
            time.sleep(0.5*(2**(attempt-1)))
    if last:
        raise last
    raise RuntimeError("request failed")

def load_checkpoint():
    if not STATE_PATH.exists():
        return {"updated_at":"","order_id":""}
    return json.loads(STATE_PATH.read_text(encoding="utf-8"))

def safe_run_id():
    return utc_now_iso().replace(":","").replace("-","").replace(".","")

def ingest(endpoint="/v1/orders", commit_state=True, extra_params=None, ignore_checkpoint=False):
    token=os.getenv("STAGE08_API_TOKEN")
    if not token:
        raise RuntimeError("Set STAGE08_API_TOKEN before running")

    checkpoint={"updated_at":"","order_id":""} if ignore_checkpoint else load_checkpoint()
    run_id=safe_run_id()
    landing_dir=Path("landing/source=api")/f"run_id={run_id}"
    landing_dir.mkdir(parents=True,exist_ok=True)
    quarantine=Path("quarantine")/f"api_{run_id}.jsonl"
    staging=Path("staging")/"api_orders.jsonl"
    staging.parent.mkdir(parents=True,exist_ok=True)

    headers={"Authorization":f"Bearer {token}"}
    page=1; staged=[]; bad=[]; pages=[]
    with requests.Session() as session:
        while True:
            params={
                "page":page,"page_size":3,
                "after_updated_at":checkpoint.get("updated_at",""),
                "after_order_id":checkpoint.get("order_id","")
            }
            params.update(extra_params or {})
            r=request_with_retry(session,BASE_URL+endpoint,headers=headers,params=params)
            payload=r.json()
            raw_path=landing_dir/f"page_{page:03d}.json"
            raw_path.write_text(json.dumps(payload,indent=2),encoding="utf-8")
            from src.common import sha256_file
            pages.append({
                "page":page,
                "status":r.status_code,
                "records":len(payload.get("items",[])),
                "file":raw_path.name,
                "sha256":sha256_file(raw_path)
            })

            for item in payload.get("items",[]):
                try:
                    staged.append(normalize_record(item))
                except Exception as exc:
                    bad.append({"error":str(exc),"record":item})

            if payload.get("next_page") is None:
                break
            page=payload["next_page"]

    # Landing is immutable evidence. Staging contains valid normalized rows only.
    if staged:
        existing_ids=set()
        if staging.exists():
            for line in staging.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    existing_ids.add(json.loads(line)["order_id"])
        with staging.open("a",encoding="utf-8") as f:
            for row in staged:
                if row["order_id"] not in existing_ids:
                    f.write(json.dumps(row,ensure_ascii=False)+"\n")
                    existing_ids.add(row["order_id"])

    if bad:
        with quarantine.open("w",encoding="utf-8") as f:
            for row in bad:
                f.write(json.dumps(row,ensure_ascii=False)+"\n")

    manifest={
        "run_id":run_id,
        "endpoint":endpoint,
        "started_from_checkpoint":checkpoint,
        "pages":pages,
        "valid_records":len(staged),
        "quarantined_records":len(bad),
        "retrieved_at_utc":utc_now_iso()
    }
    (landing_dir/"_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")

    # Critical safety rule: advance state only after a successful complete run,
    # and only based on VALID staged records.
    if commit_state and staged and not bad:
        new_pair=max(watermark_tuple(r) for r in staged)
        atomic_write_json(STATE_PATH,{"updated_at":new_pair[0],"order_id":new_pair[1]})
    elif commit_state and bad:
        manifest["checkpoint_not_advanced_reason"] = "quarantined records exist"
        (landing_dir/"_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")

    return manifest

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--endpoint",default="/v1/orders")
    p.add_argument("--no-commit-state",action="store_true")
    p.add_argument("--rate-limit-once",action="store_true")
    p.add_argument("--fail-once",action="store_true")
    p.add_argument("--ignore-checkpoint",action="store_true")
    args=p.parse_args()
    extra={}
    if args.rate_limit_once: extra["rate_limit_once"]="1"
    if args.fail_once: extra["fail_once"]="1"
    print(json.dumps(ingest(
        endpoint=args.endpoint,
        commit_state=not args.no_commit_state,
        extra_params=extra,
        ignore_checkpoint=args.ignore_checkpoint
    ),indent=2))
