from pathlib import Path
import json, shutil
from src.common import sha256_file, utc_now_iso

def land_historical(files):
    run_id=utc_now_iso().replace(":","").replace("-","").replace(".","")
    target=Path("landing/source=historical_csv")/f"run_id={run_id}"
    target.mkdir(parents=True,exist_ok=True)
    manifest={"run_id":run_id,"retrieved_at_utc":utc_now_iso(),"files":[]}
    for item in files:
        src=Path(item)
        dst=target/src.name
        shutil.copy2(src,dst)
        with dst.open(encoding="utf-8") as f:
            row_count=max(sum(1 for _ in f)-1,0)
        manifest["files"].append({
            "name":src.name,
            "bytes":dst.stat().st_size,
            "sha256":sha256_file(dst),
            "data_rows":row_count
        })
    (target/"_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return target

if __name__=="__main__":
    print(land_historical([
        "source/files/orders_2026-08-01.csv",
        "source/files/orders_2026-08-02.csv"
    ]))
