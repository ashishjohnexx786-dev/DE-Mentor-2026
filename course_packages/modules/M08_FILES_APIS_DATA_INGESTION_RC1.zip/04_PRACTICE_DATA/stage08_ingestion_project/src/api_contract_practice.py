"""DE08-05/06 learner practice."""
import os, requests

TOKEN=os.getenv("STAGE08_API_TOKEN","")
headers={"Authorization":f"Bearer {TOKEN}"}

# TODO:
# 1. GET http://127.0.0.1:8008/health
# 2. GET /v1/orders without token -> observe 401
# 3. set token and GET /v1/orders?page=1&page_size=3
# 4. follow next_page until None
# 5. request page 2 with rate_limit_once=1 and inspect Retry-After on 429
# 6. request fail_once=1 twice and compare first/second result
# Always use timeout.
