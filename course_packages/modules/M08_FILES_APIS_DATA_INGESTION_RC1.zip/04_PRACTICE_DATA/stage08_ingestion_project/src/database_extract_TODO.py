"""DE08-08 learner task.
Create the SQLite source with: python create_source_db.py

Then extract safely:
- read-only connection
- explicit columns (not SELECT *)
- bounded watermark using updated_at + order_id
- deterministic ORDER BY
- LIMIT during development
- no UPDATE/DELETE in the extraction function

PostgreSQL mapping:
- use a read-only role/transaction where appropriate
- bounded SELECT
- client-side `\\copy (SELECT ...) TO ...` for controlled extracts when useful
"""
