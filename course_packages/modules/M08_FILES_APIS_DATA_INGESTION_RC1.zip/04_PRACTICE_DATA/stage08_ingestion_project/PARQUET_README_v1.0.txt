DE08-04 PARQUET

This package intentionally ships the source CSV and the script that creates the Parquet file.
Reason: Parquet requires an engine such as `pyarrow` or `fastparquet`; pandas itself does not write Parquet without one.

Install:
  python -m pip install pandas pyarrow

Run:
  python src/parquet_lab.py

Inspect:
- Arrow schema
- row groups
- number of rows
- number of columns
- reading only selected columns

Official pandas reference:
https://pandas.pydata.org/docs/reference/api/pandas.read_parquet.html
