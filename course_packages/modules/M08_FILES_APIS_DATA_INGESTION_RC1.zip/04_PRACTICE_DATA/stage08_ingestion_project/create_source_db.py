from pathlib import Path
import sqlite3

path=Path("source/db/orders_source.sqlite")
path.parent.mkdir(parents=True,exist_ok=True)
path.unlink(missing_ok=True)

rows=[
("D5001","2026-08-06T08:00:00Z","C301","P001",1,850.0),
("D5002","2026-08-06T08:15:00Z","C302","P002",2,450.0),
("D5003","2026-08-06T08:30:00Z","C303","P003",3,220.0),
("D5004","2026-08-06T08:45:00Z","C304","P004",1,1200.0),
("D5005","2026-08-06T09:00:00Z","C305","P001",2,850.0),
]

con=sqlite3.connect(path)
con.execute("""CREATE TABLE orders(
 order_id TEXT PRIMARY KEY,
 updated_at TEXT NOT NULL,
 customer_id TEXT NOT NULL,
 product_id TEXT NOT NULL,
 qty INTEGER NOT NULL,
 unit_price REAL NOT NULL
)""")
con.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?)",rows)
con.commit(); con.close()
print(path)
