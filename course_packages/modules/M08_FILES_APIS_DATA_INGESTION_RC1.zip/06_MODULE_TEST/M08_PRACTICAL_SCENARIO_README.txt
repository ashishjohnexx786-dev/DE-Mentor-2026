A supply team sends daily CSV files, a paginated REST API and a database extract. Build one reliable ingestion service that lands raw evidence and stages trustworthy records.

Use only synthetic/course data. Save the first attempt before any review.
