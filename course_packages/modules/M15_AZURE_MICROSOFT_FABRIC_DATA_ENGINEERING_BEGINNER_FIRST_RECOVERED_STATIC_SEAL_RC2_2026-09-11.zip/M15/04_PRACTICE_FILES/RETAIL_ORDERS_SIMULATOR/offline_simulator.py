from pathlib import Path
import csv,json,datetime
B=Path(__file__).parent
def read(n):
    with open(B/'data'/n,newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def valid(r):
    try:
        datetime.date.fromisoformat(r['order_date']); return bool(r['order_id'] and r['region'] and float(r['amount'])>=0)
    except Exception:return False
def run():
    raw=read('base.csv'); accepted=[r for r in raw if valid(r)]; quarantine=[r for r in raw if not valid(r)]
    state={r['order_id']:dict(r) for r in accepted}; base_total=sum(float(r['amount']) for r in state.values())
    for r in read('incremental.csv'):
        if valid(r): state[r['order_id']]=dict(r)
    final_total=sum(float(r['amount']) for r in state.values())
    return {'raw_rows':len(raw),'accepted_rows':len(accepted),'quarantined_rows':len(quarantine),'accepted_amount':base_total,'final_rows':len(state),'final_amount':final_total,'keys':sorted(state)}
if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
