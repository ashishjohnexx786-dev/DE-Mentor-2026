Deterministic local control only. It does NOT prove Microsoft Fabric execution. Run: python offline_simulator.py
Expected: 7 raw, 4 accepted, 3 quarantined, accepted amount 3300; after update+insert: 5 rows, amount 4250.
