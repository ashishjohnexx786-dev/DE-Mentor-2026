M15 DE15-11 - Medallion architecture in Fabric

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Design a changed medallion flow for clinic appointments.

Validation
Prove: medallion architecture.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 12 if needed -> close Review -> changed retry page 12.

Next route
DE15-12
