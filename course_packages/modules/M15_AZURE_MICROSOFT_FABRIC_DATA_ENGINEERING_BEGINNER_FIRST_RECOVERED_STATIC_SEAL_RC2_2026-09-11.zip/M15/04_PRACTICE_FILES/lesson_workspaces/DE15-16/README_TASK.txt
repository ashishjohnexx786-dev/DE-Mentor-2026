M15 DE15-16 - End-to-end Fabric data engineering case

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Produce the complete clinic changed-case architecture/evidence plan from a blank template.

Validation
Prove: end-to-end Fabric evidence index.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 17 if needed -> close Review -> changed retry page 17.

Next route
G06 after M17
