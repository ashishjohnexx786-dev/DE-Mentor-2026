M15 DE15-06 - Fabric Lakehouse and Delta tables

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Define the same contract for a fresh clinic-events table with explicit bad-row reasons.

Validation
Prove: Lakehouse/Delta contract.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 7 if needed -> close Review -> changed retry page 7.

Next route
DE15-07
