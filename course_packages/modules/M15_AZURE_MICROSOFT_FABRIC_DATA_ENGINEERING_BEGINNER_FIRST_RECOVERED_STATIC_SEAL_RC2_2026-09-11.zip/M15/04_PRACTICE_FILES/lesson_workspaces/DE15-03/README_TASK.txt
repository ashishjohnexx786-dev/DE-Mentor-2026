M15 DE15-03 - Azure Storage concepts and OneLake

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Evaluate a fresh source where the producer controls lifecycle and you need near-current reads.

Validation
Prove: copy vs shortcut decision.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 4 if needed -> close Review -> changed retry page 4.

Next route
DE15-04
