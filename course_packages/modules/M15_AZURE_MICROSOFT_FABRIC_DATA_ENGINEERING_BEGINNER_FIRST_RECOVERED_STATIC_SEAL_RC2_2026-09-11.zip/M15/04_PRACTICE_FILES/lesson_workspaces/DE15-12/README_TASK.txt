M15 DE15-12 - Incremental loads and MERGE in cloud

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Design a changed incremental load where a failed publish must not advance its watermark.

Validation
Prove: incremental MERGE state transition.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 13 if needed -> close Review -> changed retry page 13.

Next route
DE15-13
