M15 DE15-13 - Permissions, connections and secrets

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Create a fresh cross-workspace connection plan without embedding credentials.

Validation
Prove: permissions, connections and secrets.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 14 if needed -> close Review -> changed retry page 14.

Next route
DE15-14
