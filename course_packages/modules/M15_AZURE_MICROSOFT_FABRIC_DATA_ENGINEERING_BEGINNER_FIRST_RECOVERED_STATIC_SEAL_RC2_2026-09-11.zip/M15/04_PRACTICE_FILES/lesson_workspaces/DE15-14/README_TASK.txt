M15 DE15-14 - Monitoring, reliability and cost awareness

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Create a fresh runbook for a slow pipeline whose output totals still reconcile.

Validation
Prove: monitoring/reliability/cost runbook.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 15 if needed -> close Review -> changed retry page 15.

Next route
DE15-15
