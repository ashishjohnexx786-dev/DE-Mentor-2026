M15 DE15-05 - OneLake paths, files, tables and shortcuts

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Design a changed path map for a vendor-owned external data source.

Validation
Prove: OneLake path and shortcut map.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 6 if needed -> close Review -> changed retry page 6.

Next route
DE15-06
