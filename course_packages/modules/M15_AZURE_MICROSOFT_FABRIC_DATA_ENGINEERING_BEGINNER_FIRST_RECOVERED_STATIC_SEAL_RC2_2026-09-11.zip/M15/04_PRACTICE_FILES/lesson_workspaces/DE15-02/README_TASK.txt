M15 DE15-02 - Identity, IAM and least privilege

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Build a fresh matrix for a contractor who can monitor runs but must not edit production data.

Validation
Prove: least-privilege permission matrix.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 3 if needed -> close Review -> changed retry page 3.

Next route
DE15-03
