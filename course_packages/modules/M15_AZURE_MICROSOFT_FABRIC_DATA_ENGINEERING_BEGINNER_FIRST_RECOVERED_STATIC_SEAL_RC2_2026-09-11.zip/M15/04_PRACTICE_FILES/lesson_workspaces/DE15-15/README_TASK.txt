M15 DE15-15 - Git, deployment and environment separation

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Introduce a changed test environment with different IDs and revise promotion.

Validation
Prove: Git/deployment/environment separation.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 16 if needed -> close Review -> changed retry page 16.

Next route
DE15-16
