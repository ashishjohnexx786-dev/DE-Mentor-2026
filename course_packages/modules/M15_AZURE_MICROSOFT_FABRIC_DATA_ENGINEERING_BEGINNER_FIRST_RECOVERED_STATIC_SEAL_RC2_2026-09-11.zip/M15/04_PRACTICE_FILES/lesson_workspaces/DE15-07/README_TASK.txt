M15 DE15-07 - Fabric notebooks

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Design a fresh notebook flow for device telemetry without relying on hidden session state.

Validation
Prove: rerunnable notebook flow.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 8 if needed -> close Review -> changed retry page 8.

Next route
DE15-08
