M15 DE15-09 - Fabric Data Pipelines

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Create a fresh graph where validation fails and prove publish is blocked.

Validation
Prove: pipeline dependency and failure graph.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 10 if needed -> close Review -> changed retry page 10.

Next route
DE15-10
