M15 DE15-04 - Fabric workspace and item model

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Create a fresh inventory for a support-analytics workload.

Validation
Prove: workspace/item inventory.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 5 if needed -> close Review -> changed retry page 5.

Next route
DE15-05
