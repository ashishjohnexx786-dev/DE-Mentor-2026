M15 DE15-01 - Cloud fundamentals for data engineers

CREATE vs FILL
- CREATE attempt.md after doing the independent task. It is intentionally not supplied.
- CREATE evidence/ files only from actual observations.
- CREATE retry.md only after targeted repair; never overwrite attempt 1.

Independent task
Create the same map for a clinic ingestion case without copying the guided layout.

Validation
Prove: architecture map.

Evidence truth
LIVE FABRIC = actually executed/observed in your authorized workspace.
OFFLINE PLAN = design only.
SIMULATOR = deterministic local check only.

Review path
Save attempt first -> open matching protected Review page 2 if needed -> close Review -> changed retry page 2.

Next route
DE15-02
