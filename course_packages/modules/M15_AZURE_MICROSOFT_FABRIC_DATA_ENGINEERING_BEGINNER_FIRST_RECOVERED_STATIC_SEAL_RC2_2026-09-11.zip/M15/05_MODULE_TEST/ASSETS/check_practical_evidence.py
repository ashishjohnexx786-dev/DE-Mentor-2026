import json,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else 'attempt.json')
if not p.exists(): print('REJECT no saved attempt');sys.exit(2)
d=json.load(open(p)); exp={'raw_rows':7,'accepted_rows':4,'quarantined_rows':3,'accepted_amount':3300,'final_rows':5,'final_amount':4250,'rerun_no_op':True,'checkpoint_safe_on_failed_publish':True}
fail=[]
for k,v in exp.items():
    if d.get(k)!=v: fail.append(k)
for k in ['evidence_kind','least_privilege_evidence','monitoring_evidence','runtime_claim']:
    if not str(d.get(k,'')).strip(): fail.append(k)
if d.get('evidence_kind') not in ['LIVE FABRIC','OFFLINE PLAN','SIMULATOR','MIXED']: fail.append('evidence_kind_invalid')
print('PASS' if not fail else 'FAIL '+','.join(fail));sys.exit(0 if not fail else 1)
