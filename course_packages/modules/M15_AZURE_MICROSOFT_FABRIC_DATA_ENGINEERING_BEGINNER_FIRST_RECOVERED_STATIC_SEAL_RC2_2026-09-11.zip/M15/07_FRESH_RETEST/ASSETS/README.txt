Fresh module reassessment inputs only. CREATE your own solution/evidence. No solved result_summary, reasoning, SQL, or job code is supplied here.
