STANDALONE DE 2026 - M15 RECOVERED SUCCESSOR RC2

This is a new successor static-content build created because the historical sealed M15 archive bytes (SHA-256 39613dc1...) were not retained. It preserves the authoritative M15 curriculum and current route/source controls, corrects the stale Runtime 2.0 GA sentence, and must receive its own new seal/hash. It is not claimed byte-identical to the historical seal.
