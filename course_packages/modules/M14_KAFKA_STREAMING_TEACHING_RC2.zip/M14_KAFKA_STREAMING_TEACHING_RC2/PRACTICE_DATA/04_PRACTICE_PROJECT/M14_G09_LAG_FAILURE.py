parts={0:(995,1000),1:(300,900),2:(450,455)}
lag={p:max(0,end-current) for p,(current,end) in parts.items()}
print('LAG_BY_PARTITION',lag,'TOTAL_LAG',sum(lag.values()),'HOTTEST',max(lag,key=lag.get))
