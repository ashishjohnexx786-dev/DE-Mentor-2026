from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType,StructField,StringType
spark=SparkSession.builder.appName('M14KafkaStreaming').getOrCreate()
schema=StructType([StructField('event_id',StringType()),StructField('order_id',StringType()),StructField('event_type',StringType()),StructField('event_time',StringType())])
raw=(spark.readStream.format('kafka').option('kafka.bootstrap.servers','localhost:9092').option('subscribe','m14-events').option('startingOffsets','earliest').load())
parsed=(raw.selectExpr('CAST(key AS STRING) AS key','CAST(value AS STRING) AS value','partition','offset').withColumn('event',from_json(col('value'),schema)).select('key','event.*','partition','offset'))
q=(parsed.writeStream.format('console').outputMode('append').option('checkpointLocation','./output/g10-checkpoint').option('truncate','false').start())
q.awaitTermination(30)
