events=[('O1',0,0,'CREATED'),('O2',2,0,'CREATED'),('O1',0,1,'PAID'),('O2',2,1,'CANCELLED'),('O1',0,2,'SHIPPED')]
by={}
for key,p,o,status in events: by.setdefault(p,[]).append(o)
print('PARTITION_OFFSETS',by)
print('ORDERED_WITHIN_PARTITION',all(v==sorted(v) for v in by.values()))
