import json
required={'event_id','order_id','event_type','event_time'}
raw=['{"event_id":"E1","order_id":"O1","event_type":"PAID","event_time":"2026-08-27T09:00:00Z"}','{"event_id":"E2","event_type":"PAID"}','not-json']
valid=[]; rejects=[]
for s in raw:
    try:
        e=json.loads(s); missing=required-set(e)
        if missing: raise ValueError('missing:'+','.join(sorted(missing)))
        valid.append(e)
    except Exception as exc: rejects.append(str(exc))
print('VALID',len(valid),'REJECTED',len(rejects),rejects)
