import os,time
from confluent_kafka import Consumer, TopicPartition
topic='m14-events'; part=int(os.getenv('M14_PARTITION','0')); start=int(os.getenv('M14_START_OFFSET','0'))
c=Consumer({'bootstrap.servers':'localhost:9092','group.id':'m14-replay-guided','enable.auto.commit':False,'auto.offset.reset':'earliest'})
c.assign([TopicPartition(topic,part,start)])
read=[]; deadline=time.time()+8
try:
    while time.time()<deadline and len(read)<3:
        m=c.poll(1.0)
        if m is None: continue
        if m.error(): raise RuntimeError(m.error())
        read.append(m.offset()); print('REPLAY',m.partition(),m.offset())
finally: c.close()
print('REPLAY_OFFSETS',read)
