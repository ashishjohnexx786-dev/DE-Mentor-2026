from pathlib import Path
import ast, subprocess, sys
checks=[]
requirements={
'M14_G01_BATCH_VS_STREAM.py':['BATCH_ROWS','STREAM_EVENTS'],
'M14_G02_PARTITION_ORDER.py':['PARTITION_OFFSETS','ORDERED_WITHIN_PARTITION'],
'M14_G03_PRODUCER.py':['Producer','produce','key=','flush'],
'M14_G04_CONSUMER.py':['Consumer','group.id','enable.auto.commit','subscribe','commit'],
'M14_G05_OFFSETS_REPLAY.py':['TopicPartition','assign','offset'],
'M14_G06_CONSUMER_GROUPS.py':['Consumer','group.id','subscribe'],
'M14_G07_DELIVERY_SEMANTICS.py':['processed','SAFE_WRITES'],
'M14_G08_SERIALIZATION_SCHEMA.py':['json.loads','required','REJECTED'],
'M14_G09_LAG_FAILURE.py':['TOTAL_LAG','HOTTEST'],
"M14_G10_SPARK_KAFKA.py":["readStream","format(\'kafka\')","checkpointLocation","writeStream"]
}
for f,toks in requirements.items():
    txt=Path(f).read_text();
    try: ast.parse(txt); ok=True
    except SyntaxError: ok=False
    checks.append((f+' syntax',ok))
    checks += [(f+' '+t,t in txt) for t in toks]
# execute pure-python labs only
for f in ['M14_G01_BATCH_VS_STREAM.py','M14_G02_PARTITION_ORDER.py','M14_G07_DELIVERY_SEMANTICS.py','M14_G08_SERIALIZATION_SCHEMA.py','M14_G09_LAG_FAILURE.py']:
    r=subprocess.run([sys.executable,f],capture_output=True,text=True)
    checks.append((f+' offline-run',r.returncode==0 and bool(r.stdout.strip())))
passed=sum(v for _,v in checks); print(f'{passed}/{len(checks)} checks passed')
for n,v in checks: print(('PASS ' if v else 'FAIL ')+n)
raise SystemExit(0 if passed==len(checks) else 1)
