deliveries=['E1','E2','E2','E3']
naive=[]
for e in deliveries: naive.append(e)
processed=set(); safe=[]
for e in deliveries:
    if e in processed: continue
    safe.append(e); processed.add(e)
print('NAIVE_WRITES',len(naive),'SAFE_WRITES',len(safe),'DUPLICATES_AVOIDED',len(naive)-len(safe))
