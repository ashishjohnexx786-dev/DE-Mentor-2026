events=[{'id':i} for i in range(1,6)]
batch=[e['id'] for e in events]
stream=[]
for e in events: stream.append(e['id'])
print('BATCH_ROWS',len(batch),'STREAM_EVENTS',len(stream),'SAME_RECORDS',batch==stream)
