import json
from confluent_kafka import Producer
TOPIC='m14-events'
p=Producer({'bootstrap.servers':'localhost:9092'})
def delivered(err,msg):
    if err: raise RuntimeError(err)
    print('DELIVERED',msg.topic(),msg.partition(),msg.offset())
events=[
 {'event_id':'E1','order_id':'O1','event_type':'CREATED','event_time':'2026-08-27T09:00:00Z'},
 {'event_id':'E2','order_id':'O1','event_type':'PAID','event_time':'2026-08-27T09:01:00Z'},
 {'event_id':'E3','order_id':'O2','event_type':'CREATED','event_time':'2026-08-27T09:02:00Z'},
 {'event_id':'E4','order_id':'O2','event_type':'CANCELLED','event_time':'2026-08-27T09:03:00Z'},
]
for e in events:
    p.produce(TOPIC,key=e['order_id'],value=json.dumps(e),callback=delivered)
p.flush()
