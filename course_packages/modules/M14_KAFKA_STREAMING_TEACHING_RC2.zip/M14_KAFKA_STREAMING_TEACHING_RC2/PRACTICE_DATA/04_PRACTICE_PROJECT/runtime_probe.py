from confluent_kafka.admin import AdminClient
admin=AdminClient({'bootstrap.servers':'localhost:9092'})
md=admin.list_topics(timeout=10)
print('KAFKA_RUNTIME_OK', md.cluster_id, len(md.brokers))
