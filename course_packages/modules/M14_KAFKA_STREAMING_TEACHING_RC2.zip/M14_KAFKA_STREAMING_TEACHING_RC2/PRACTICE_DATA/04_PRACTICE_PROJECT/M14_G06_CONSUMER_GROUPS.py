import os,time
from confluent_kafka import Consumer
gid=os.getenv('M14_GROUP','m14-scale-guided')
c=Consumer({'bootstrap.servers':'localhost:9092','group.id':gid,'auto.offset.reset':'earliest','enable.auto.commit':False})
c.subscribe(['m14-events']); deadline=time.time()+12
try:
    while time.time()<deadline:
        m=c.poll(1.0)
        if m is None: continue
        if m.error(): raise RuntimeError(m.error())
        print('GROUP_RECORD',gid,m.partition(),m.offset())
finally: c.close()
