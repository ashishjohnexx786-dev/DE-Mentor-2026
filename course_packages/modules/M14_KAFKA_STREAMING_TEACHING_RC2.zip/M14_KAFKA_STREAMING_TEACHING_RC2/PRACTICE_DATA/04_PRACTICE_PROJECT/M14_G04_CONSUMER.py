import json, time
from confluent_kafka import Consumer
conf={'bootstrap.servers':'localhost:9092','group.id':'m14-guided-consumer','auto.offset.reset':'earliest','enable.auto.commit':False}
c=Consumer(conf); c.subscribe(['m14-events'])
seen=0; deadline=time.time()+15
try:
    while time.time()<deadline and seen<4:
        msg=c.poll(1.0)
        if msg is None: continue
        if msg.error(): raise RuntimeError(msg.error())
        event=json.loads(msg.value().decode())
        if not event.get('event_id'): raise ValueError('missing event_id')
        print('PROCESSED',event['event_id'],msg.partition(),msg.offset())
        c.commit(message=msg,asynchronous=False)
        seen+=1
finally:
    c.close()
print('CONSUMED',seen)
