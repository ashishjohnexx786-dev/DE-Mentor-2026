M14 - Kafka Streaming - TEACHING RC2
START: 00_START_HERE_TEACHING_RC2.pdf
Verify Docker first. Use the supplied Compose/Kafka training project and pinned Python requirements. Do not install a separate broker manually unless the verified project setup actually requires repair.
Pure/offline labs and syntax validation can run without Kafka. Live broker producer/consumer/offset/group and Spark streaming evidence must be collected on learner PC.
