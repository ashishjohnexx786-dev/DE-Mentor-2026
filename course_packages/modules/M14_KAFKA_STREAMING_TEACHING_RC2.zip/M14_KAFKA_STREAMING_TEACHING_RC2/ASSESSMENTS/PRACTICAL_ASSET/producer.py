# TODO protected producer: publish order_events.jsonl keyed by order_id
