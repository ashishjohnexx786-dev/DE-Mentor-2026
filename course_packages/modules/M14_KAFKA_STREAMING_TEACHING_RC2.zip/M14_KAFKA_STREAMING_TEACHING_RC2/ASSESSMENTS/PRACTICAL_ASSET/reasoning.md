# Partition key

# Delivery / commit safety

# Replay / idempotency

# Schema / invalid events

# Lag / monitoring
