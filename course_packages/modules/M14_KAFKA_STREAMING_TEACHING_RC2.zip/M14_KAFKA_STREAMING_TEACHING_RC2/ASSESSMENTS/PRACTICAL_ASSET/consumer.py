# TODO protected consumer: validate, process, commit after success
