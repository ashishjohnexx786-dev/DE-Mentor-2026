# Broker/topic evidence

# Produced delivery evidence

# Consumed partition/offset evidence

# Replay evidence

