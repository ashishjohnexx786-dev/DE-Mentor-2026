from pathlib import Path
import json,ast
checks=[]
def has(file,toks):
 txt=Path(file).read_text();
 try: ast.parse(txt); checks.append((file+' syntax',True))
 except: checks.append((file+' syntax',False))
 for t in toks: checks.append((file+' '+t,t in txt))
has('producer.py',['Producer','produce','key=','flush'])
has('consumer.py',['Consumer','group.id','enable.auto.commit','subscribe','commit'])
has('stream_logic.py',['event_id','device_id','invalid','duplicate','alert'])
try: s=json.loads(Path('result_summary.json').read_text())
except: s={}
expected={'raw_events':7,'valid_events':6,'invalid_events':1,'duplicate_events':1,'unique_events':5,'unique_devices':3}
for k,v in expected.items(): checks.append((f'{k}={v}',s.get(k)==v))
checks.append(('alert_events',s.get('alert_events')==2))
checks.append(('partition_key',s.get('partition_key')=='device_id'))
checks.append(('replay_safe',s.get('replay_safe') is True))
checks.append(('commit_after_success',s.get('commit_after_success') is True))
r=Path('reasoning.md').read_text().lower(); e=Path('runtime_evidence.md').read_text().lower()
for term in ['partition','commit','replay','schema','lag']: checks.append(('reason '+term,term in r and len(r)>120))
for term in ['topic','offset','replay']: checks.append(('runtime '+term,term in e and len(e)>100))
p=sum(v for _,v in checks); print(f'{p}/{len(checks)} checks passed'); [print(('PASS ' if v else 'FAIL ')+n) for n,v in checks]; raise SystemExit(0 if p==len(checks) else 1)
