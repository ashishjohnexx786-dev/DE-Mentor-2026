# TODO fresh telemetry validation/dedupe/alert logic
