# TODO fresh producer keyed by device_id
