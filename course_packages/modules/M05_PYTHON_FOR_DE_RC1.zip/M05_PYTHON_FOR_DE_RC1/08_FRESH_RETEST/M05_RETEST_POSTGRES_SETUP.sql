DROP TABLE IF EXISTS m05_retest_inventory;
CREATE TABLE m05_retest_inventory(
 sku VARCHAR(20) PRIMARY KEY, supplier_id VARCHAR(20) NOT NULL, qty INTEGER NOT NULL CHECK(qty>=0), unit_cost NUMERIC(12,2) NOT NULL CHECK(unit_cost>=0), region VARCHAR(30) NOT NULL
);
