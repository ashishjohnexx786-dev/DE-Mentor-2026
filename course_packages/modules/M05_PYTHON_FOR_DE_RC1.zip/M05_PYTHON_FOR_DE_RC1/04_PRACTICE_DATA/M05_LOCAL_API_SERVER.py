from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json, time

HOST='127.0.0.1'; PORT=8765
state={'flaky':0,'rate':0}
ORDERS=[
 {'order_id':'O01','customer_id':'C01','amount':1200.0,'status':'COMPLETED','updated_at':'2026-08-20T10:00:00'},
 {'order_id':'O02','customer_id':'C02','amount':800.0,'status':'COMPLETED','updated_at':'2026-08-20T11:00:00'},
 {'order_id':'O03','customer_id':'C03','amount':-50.0,'status':'COMPLETED','updated_at':'2026-08-21T09:00:00'},
 {'order_id':'O04','customer_id':'C99','amount':600.0,'status':'PENDING','updated_at':'2026-08-21T10:00:00'},
 {'order_id':'O05','customer_id':'C01','amount':1500.0,'status':'COMPLETED','updated_at':'2026-08-22T12:00:00'},
 {'order_id':'O06','customer_id':'C04','amount':500.0,'status':'CANCELLED','updated_at':'2026-08-23T15:00:00'},
 {'order_id':'O07','customer_id':'C05','amount':2200.0,'status':'COMPLETED','updated_at':'2026-08-24T09:30:00'}]
MODULE_ORDERS=[
 {'order_id':'MO01','customer_id':'C01','amount':1250.0,'status':'COMPLETED','updated_at':'2026-08-25T09:00:00'},
 {'order_id':'MO02','customer_id':'C02','amount':900.0,'status':'COMPLETED','updated_at':'2026-08-25T09:30:00'},
 {'order_id':'MO03','customer_id':'C03','amount':-20.0,'status':'COMPLETED','updated_at':'2026-08-25T10:00:00'},
 {'order_id':'MO04','customer_id':'C99','amount':700.0,'status':'PENDING','updated_at':'2026-08-25T10:30:00'},
 {'order_id':'MO05','customer_id':'C04','amount':1600.0,'status':'COMPLETED','updated_at':'2026-08-25T11:00:00'},
 {'order_id':'MO06','customer_id':'C02','amount':450.0,'status':'CANCELLED','updated_at':'2026-08-25T11:30:00'},
 {'order_id':'MO07','customer_id':'C05','amount':2100.0,'status':'COMPLETED','updated_at':'2026-08-25T12:00:00'},
 {'order_id':'MO08','customer_id':'C06','amount':1300.0,'status':'COMPLETED','updated_at':'2026-08-25T12:30:00'},
 {'order_id':'MO08','customer_id':'C06','amount':1300.0,'status':'COMPLETED','updated_at':'2026-08-25T12:30:00'}]
RETEST_INV=[
 {'sku':'S01','supplier_id':'SUP1','qty':10,'unit_cost':100.0},
 {'sku':'S02','supplier_id':'SUP2','qty':0,'unit_cost':80.0},
 {'sku':'S03','supplier_id':'SUP9','qty':4,'unit_cost':150.0},
 {'sku':'S04','supplier_id':'SUP1','qty':-1,'unit_cost':90.0},
 {'sku':'S05','supplier_id':'SUP3','qty':6,'unit_cost':200.0},
 {'sku':'S06','supplier_id':'SUP2','qty':3,'unit_cost':50.0}]
PRODUCTS=[{'product_id':'P1','name':'Mouse'},{'product_id':'P2','name':'Keyboard'}]

def paged(items,page,size=3):
    start=(page-1)*size; chunk=items[start:start+size]
    next_page=page+1 if start+size < len(items) else None
    return {'items':chunk,'next_page':next_page}

class H(BaseHTTPRequestHandler):
    def send_json(self,obj,status=200,headers=None):
        body=json.dumps(obj).encode('utf-8'); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body)))
        if headers:
            for k,v in headers.items(): self.send_header(k,str(v))
        self.end_headers(); self.wfile.write(body)
    def log_message(self,fmt,*args): pass
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query); page=int(q.get('page',['1'])[0])
        if u.path=='/orders': return self.send_json(paged(ORDERS,page))
        if u.path=='/module-orders': return self.send_json(paged(MODULE_ORDERS,page))
        if u.path=='/retest-inventory': return self.send_json(paged(RETEST_INV,page))
        if u.path=='/secure-products':
            if self.headers.get('X-API-Key')!='training-key-2026': return self.send_json({'error':'unauthorized'},401)
            return self.send_json({'items':PRODUCTS})
        if u.path=='/flaky-orders':
            state['flaky']+=1
            if state['flaky']==1: return self.send_json({'error':'temporary failure'},500)
            return self.send_json(paged(ORDERS,page))
        if u.path=='/rate-limited':
            state['rate']+=1
            if state['rate']==1: return self.send_json({'error':'slow down'},429,{'Retry-After':'1'})
            return self.send_json({'items':[{'ok':True}]})
        if u.path=='/slow':
            time.sleep(3); return self.send_json({'ok':True})
        return self.send_json({'error':'not found'},404)

if __name__=='__main__':
    print(f'Local M05 API listening on http://{HOST}:{PORT}')
    HTTPServer((HOST,PORT),H).serve_forever()
