import json
from pathlib import Path
customers=json.loads(Path("04_PRACTICE_DATA/customers.json").read_text())
lookup={c["customer_id"]:c["region"] for c in customers["customers"]}
counts={}
for line in Path("04_PRACTICE_DATA/events.jsonl").read_text().splitlines():
    e=json.loads(line); counts[e["order_id"]]=counts.get(e["order_id"],0)+1
print("lookup",lookup)
print("event_counts",counts)
