import pandas as pd
df=pd.read_csv("04_PRACTICE_DATA/orders.csv",dtype=str)
df["amount_num"]=pd.to_numeric(df["amount"],errors="coerce")
dup=df.duplicated("order_id",keep=False)
invalid=df["amount_num"].isna() | dup
print("valid",int((~invalid).sum()))
print("rejected",int(invalid.sum()))
print(df.loc[invalid,["order_id","amount"]].to_dict("records"))
