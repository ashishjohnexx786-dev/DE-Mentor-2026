import json, pandas as pd
from pathlib import Path
orders=pd.read_csv("04_PRACTICE_DATA/orders.csv",dtype=str)
orders["amount_num"]=pd.to_numeric(orders["amount"],errors="coerce")
customers=pd.DataFrame(json.loads(Path("04_PRACTICE_DATA/customers.json").read_text())["customers"])
merged=orders.merge(customers,on="customer_id",how="left",validate="many_to_one",indicator=True)
print("rows_before",len(orders),"rows_after",len(merged))
print("unmatched",int((merged["_merge"]!="both").sum()))
