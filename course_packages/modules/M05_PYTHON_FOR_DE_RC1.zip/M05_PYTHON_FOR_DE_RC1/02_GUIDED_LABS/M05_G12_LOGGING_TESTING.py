import logging
logging.basicConfig(level=logging.INFO,format="%(levelname)s %(message)s")
def is_valid_amount(x): return x >= 0
assert is_valid_amount(0)
assert not is_valid_amount(-1)
logging.info("validation tests passed")
