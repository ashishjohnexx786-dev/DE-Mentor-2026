import csv
from pathlib import Path
for p in sorted(Path("04_PRACTICE_DATA/batch").glob("items_*.csv")):
    with p.open(newline="",encoding="utf-8") as f: n=sum(1 for _ in csv.DictReader(f))
    print(p.name,n)
