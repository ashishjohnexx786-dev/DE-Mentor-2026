import pandas as pd
df=pd.read_csv("04_PRACTICE_DATA/orders.csv")
print("shape",df.shape)
print("null_amount",int(df["amount"].isna().sum()))
print("duplicate_ids",int(df.duplicated("order_id").sum()))
print(df.dtypes.astype(str).to_dict())
