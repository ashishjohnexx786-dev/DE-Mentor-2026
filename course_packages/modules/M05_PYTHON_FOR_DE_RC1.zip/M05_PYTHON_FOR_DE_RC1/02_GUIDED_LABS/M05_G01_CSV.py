import csv
from pathlib import Path
p=Path("04_PRACTICE_DATA/orders.csv")
rows=[]
with p.open(newline="",encoding="utf-8") as f:
    rows=list(csv.DictReader(f))
print("raw_rows",len(rows))
print("blank_amounts",sum(r["amount"]=="" for r in rows))
print("order_ids",[r["order_id"] for r in rows])
