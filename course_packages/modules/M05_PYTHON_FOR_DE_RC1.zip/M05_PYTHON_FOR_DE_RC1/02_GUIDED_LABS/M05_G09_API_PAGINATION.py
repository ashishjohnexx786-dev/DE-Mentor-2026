import requests
base="http://127.0.0.1:8765/orders"
page=1; items=[]
while page is not None:
    r=requests.get(base,params={"page":page},timeout=5); r.raise_for_status(); data=r.json()
    items.extend(data["items"]); page=data["next_page"]
print("total_items",len(items))
print("ids",[x["order_id"] for x in items])
