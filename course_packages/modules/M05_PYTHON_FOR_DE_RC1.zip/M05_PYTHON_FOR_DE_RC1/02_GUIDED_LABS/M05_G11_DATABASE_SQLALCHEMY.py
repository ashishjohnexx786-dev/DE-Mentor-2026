import os
from sqlalchemy import create_engine, text
url=os.getenv("DATABASE_URL","sqlite:///m05_lab.db")
engine=create_engine(url)
with engine.begin() as c:
    c.execute(text("CREATE TABLE IF NOT EXISTS m05_lab_orders(order_id VARCHAR(20) PRIMARY KEY, amount NUMERIC NOT NULL)"))
    c.execute(text("INSERT INTO m05_lab_orders(order_id,amount) VALUES (:id,:amt) ON CONFLICT(order_id) DO UPDATE SET amount=excluded.amount"),{"id":"LAB1","amt":100})
    n=c.execute(text("SELECT COUNT(*) FROM m05_lab_orders")).scalar_one()
print("row_count",n)
