import pandas as pd
def require_columns(df,required):
    missing=set(required)-set(df.columns)
    if missing: raise ValueError(f"Missing columns: {sorted(missing)}")
def duplicate_count(df,key):
    return int(df.duplicated(key).sum())
df=pd.read_csv("04_PRACTICE_DATA/orders.csv")
require_columns(df,["order_id","customer_id","amount","order_date"])
print("duplicates",duplicate_count(df,"order_id"))
