M05 - PYTHON FOR DATA ENGINEERING - RC1

Start with 00_START_HERE/M05_START_HERE.pdf.
Create/activate a virtual environment and install 00_START_HERE/requirements.txt.
Start the offline API simulator: python 04_PRACTICE_DATA/M05_LOCAL_API_SERVER.py
Run labs from the module root.
PostgreSQL learner tasks use your local M03 database through DATABASE_URL; never commit the password.
Review files open only after the corresponding attempt is saved.
