M13 DELTA LAKEHOUSE RC2

RC1 was rejected as too compressed for a zero-beginner. RC2 expands the learner book, guided build-alongs, independent practice, setup and repair pack. M13 intentionally uses a separate Spark 4.0 + Delta 4.0 environment; do not reuse the M12 PySpark 4.2 environment. Start with 00_START_HERE/M13_START_HERE.pdf. Live Delta runtime execution remains mandatory before course-wide FINAL.
