# P01 - Architecture decision

Given BI-heavy structured finance data and mixed raw IoT data, decide where warehouse/lakehouse strengths differ; do not answer “lakehouse always.”

## Evidence

## Failure mode
