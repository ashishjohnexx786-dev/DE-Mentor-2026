# P04 - Time travel safety

Design an investigation of a bad update using history/version comparison plus a retention warning.

## Evidence

## Failure mode
