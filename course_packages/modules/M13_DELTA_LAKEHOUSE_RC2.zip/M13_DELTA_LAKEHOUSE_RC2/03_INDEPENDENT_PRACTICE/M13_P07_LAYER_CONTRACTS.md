# P07 - Layer contracts

Define Bronze/Silver/Gold contracts for clickstream data including rejects and consumer grain.

## Evidence

## Failure mode
