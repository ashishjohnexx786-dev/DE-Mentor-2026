# P02 - Transaction reasoning

Explain what a reader should see if a multi-file table update fails before commit.

## Evidence

## Failure mode
