# P08 - File maintenance

A Delta table receives 1-minute microbatches and has 40,000 tiny files/day. Propose evidence and maintenance strategy without coalesce(1).

## Evidence

## Failure mode
