# P05 - MERGE rerun

Write a merge strategy for daily product updates and prove replaying the same batch does not duplicate products.

## Evidence

## Failure mode
