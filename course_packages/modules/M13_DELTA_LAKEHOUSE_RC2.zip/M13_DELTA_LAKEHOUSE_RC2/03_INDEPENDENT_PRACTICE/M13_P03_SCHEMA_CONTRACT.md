# P03 - Schema contract

Design response to an unexpected new `currency` field and an incompatible text `amount` value.

## Evidence

## Failure mode
