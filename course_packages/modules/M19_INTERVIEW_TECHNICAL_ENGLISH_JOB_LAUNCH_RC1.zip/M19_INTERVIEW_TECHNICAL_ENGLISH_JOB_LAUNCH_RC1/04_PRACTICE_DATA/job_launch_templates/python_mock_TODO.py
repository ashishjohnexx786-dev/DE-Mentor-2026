def normalize_orders(rows):
    raise NotImplementedError

def latest_by_id(events):
    raise NotImplementedError

def paginate(fetch_page):
    raise NotImplementedError
