Use these blank templates for first attempts. Review files remain closed until attempts are saved.
