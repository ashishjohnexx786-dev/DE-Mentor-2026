# Exact phase route

## P01-01 - Read the batch-pipeline brief and define business questions
Artifact: business_questions.md + assumptions.md
Evidence: evidence/P01-01/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P01-02 - Profile every source; state grain, keys and defects
Artifact: source_profile/ + grain_key_defects.md
Evidence: evidence/P01-02/attempt.json
Validation: Record row counts, grain, keys, null/duplicate/schema defects; independently sample-check at least one finding.

## P01-03 - Draw architecture and create the repository scaffold
Artifact: architecture.md/diagram + ADRs
Evidence: evidence/P01-03/attempt.json
Validation: Trace every source to trusted/serving output; identify one failure boundary and replay/recovery path.

## P01-04 - Preserve raw landing evidence and source/run metadata
Artifact: raw/landing evidence + run_metadata.json
Evidence: evidence/P01-04/attempt.json
Validation: Source rows/events reconcile to raw + quarantine + deliberate duplicate handling; raw evidence remains replayable.

## P01-05 - Build ingestion with validation and quarantine
Artifact: ingestion code + validation/quarantine outputs
Evidence: evidence/P01-05/attempt.json
Validation: Source rows/events reconcile to raw + quarantine + deliberate duplicate handling; raw evidence remains replayable.

## P01-06 - Add incremental state and rerun-safe identity
Artifact: state ledger/watermark + rerun/backfill evidence
Evidence: evidence/P01-06/attempt.json
Validation: Run same input twice and prove trusted logical result is stable; then add a changed/new record and prove only intended state changes.

## P01-07 - Build trusted PostgreSQL/dbt-style transformations
Artifact: models/SQL/dbt + lineage + row-count controls
Evidence: evidence/P01-07/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## P01-08 - Add tests and source-to-target reconciliation
Artifact: tests/ + reconciliation report + quarantine evidence
Evidence: evidence/P01-08/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P01-09 - Automate the repeatable run/orchestration path
Artifact: DAG/workflow + run log + dependency evidence
Evidence: evidence/P01-09/attempt.json
Validation: Run dependency path end-to-end; prove failed task does not falsely advance downstream state; rerun only required work.

## P01-10 - Inject failure, diagnose, repair and prove recovery
Artifact: first-failure evidence + root_cause.md + repair + fresh retry evidence
Evidence: evidence/P01-10/attempt.json
Validation: Save first failing evidence before repair; identify root cause; apply smallest safe repair; fresh retry must pass all prior controls.

## P01-11 - Finish README, runbook, architecture and evidence index
Artifact: architecture.md/diagram + ADRs
Evidence: evidence/P01-11/attempt.json
Validation: Trace every source to trusted/serving output; identify one failure boundary and replay/recovery path.

## P01-12 - Clean-clone rerun and project defense
Artifact: state ledger/watermark + rerun/backfill evidence
Evidence: evidence/P01-12/attempt.json
Validation: Run same input twice and prove trusted logical result is stable; then add a changed/new record and prove only intended state changes.
