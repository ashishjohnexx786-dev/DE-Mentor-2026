# Exact phase route

## CAP-01 - Read capstone requirements and write source contracts
Artifact: source_contracts.md
Evidence: evidence/CAP-01/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## CAP-02 - Design architecture and record major ADRs
Artifact: architecture.md/diagram + ADRs
Evidence: evidence/CAP-02/attempt.json
Validation: Trace every source to trusted/serving output; identify one failure boundary and replay/recovery path.

## CAP-03 - Build multi-source ingestion and raw evidence
Artifact: raw/landing evidence + run_metadata.json
Evidence: evidence/CAP-03/attempt.json
Validation: Source rows/events reconcile to raw + quarantine + deliberate duplicate handling; raw evidence remains replayable.

## CAP-04 - Implement critical quality, quarantine and reconciliation
Artifact: tests/ + reconciliation report + quarantine evidence
Evidence: evidence/CAP-04/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## CAP-05 - Build trusted warehouse/dbt serving layer
Artifact: models/SQL/dbt + lineage + row-count controls
Evidence: evidence/CAP-05/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## CAP-06 - Orchestrate dependencies, retries and bounded backfills
Artifact: cap_phase_artifact + evidence note
Evidence: evidence/CAP-06/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## CAP-07 - Use Spark/Delta where scale justifies it
Artifact: Spark job/notebook + explain plan + partition/performance evidence
Evidence: evidence/CAP-07/attempt.json
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.

## CAP-08 - Design Fabric deployment, access and secret boundaries
Artifact: Fabric deployment design + connection/access/secret boundary notes
Evidence: evidence/CAP-08/attempt.json
Validation: Map identities/connections/access/secret boundaries; prove no plaintext secret or broad unsafe access is required.

## CAP-09 - Add CI/CD, monitoring, alerts and runbook
Artifact: README.md + runbook.md + evidence_index.md
Evidence: evidence/CAP-09/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## CAP-10 - Open incident pack, diagnose and recover safely
Artifact: first-failure evidence + root_cause.md + repair + fresh retry evidence
Evidence: evidence/CAP-10/attempt.json
Validation: Save first failing evidence before repair; identify root cause; apply smallest safe repair; fresh retry must pass all prior controls.

## CAP-11 - Reproduce from clean state and freeze evidence bundle
Artifact: state ledger/watermark + rerun/backfill evidence
Evidence: evidence/CAP-11/attempt.json
Validation: Run same input twice and prove trusted logical result is stable; then add a changed/new record and prove only intended state changes.

## CAP-12 - Final technical defense and Gate 7 readiness
Artifact: defense_notes.md + reviewer checklist
Evidence: evidence/CAP-12/attempt.json
Validation: Reviewer can locate every evidence artifact and challenge one design trade-off; learner explains limitation and recovery path without reading a script.
