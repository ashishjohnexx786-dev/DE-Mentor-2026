# Exact phase route

## P03-01 - Read the scalable-lakehouse brief and define scale risks
Artifact: business_questions.md + assumptions.md
Evidence: evidence/P03-01/attempt.json
Validation: Read outputs back, verify schema/counts/keys, and prove partition/schema-evolution behavior on a changed input.

## P03-02 - Profile event schema, grain, keys and timestamps
Artifact: source_profile/ + grain_key_defects.md
Evidence: evidence/P03-02/attempt.json
Validation: Record row counts, grain, keys, null/duplicate/schema defects; independently sample-check at least one finding.

## P03-03 - Create Spark environment and explicit schemas
Artifact: Spark job/notebook + explain plan + partition/performance evidence
Evidence: evidence/P03-03/attempt.json
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.

## P03-04 - Build deterministic distributed transformations
Artifact: models/SQL/dbt + lineage + row-count controls
Evidence: evidence/P03-04/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## P03-05 - Join reference data and validate cardinality
Artifact: p03_phase_artifact + evidence note
Evidence: evidence/P03-05/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P03-06 - Reason about partitions, shuffle and skew
Artifact: Spark job/notebook + explain plan + partition/performance evidence
Evidence: evidence/P03-06/attempt.json
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.

## P03-07 - Write Parquet with justified partition strategy
Artifact: Spark job/notebook + explain plan + partition/performance evidence
Evidence: evidence/P03-07/attempt.json
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.

## P03-08 - Apply Delta-style incremental merge/idempotency
Artifact: state ledger/watermark + rerun/backfill evidence
Evidence: evidence/P03-08/attempt.json
Validation: Run same input twice and prove trusted logical result is stable; then add a changed/new record and prove only intended state changes.

## P03-09 - Define Bronze/Silver/Gold lakehouse contracts
Artifact: source_contracts.md
Evidence: evidence/P03-09/attempt.json
Validation: Read outputs back, verify schema/counts/keys, and prove partition/schema-evolution behavior on a changed input.

## P03-10 - Handle schema evolution and supplied failure cases
Artifact: first-failure evidence + root_cause.md + repair + fresh retry evidence
Evidence: evidence/P03-10/attempt.json
Validation: Save first failing evidence before repair; identify root cause; apply smallest safe repair; fresh retry must pass all prior controls.

## P03-11 - Inspect plans/performance and prove equivalent results
Artifact: Spark job/notebook + explain plan + partition/performance evidence
Evidence: evidence/P03-11/attempt.json
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.

## P03-12 - Map the design to Fabric/cloud deployment
Artifact: Fabric deployment design + connection/access/secret boundary notes
Evidence: evidence/P03-12/attempt.json
Validation: Map identities/connections/access/secret boundaries; prove no plaintext secret or broad unsafe access is required.

## P03-13 - Clean rerun, reconcile outputs and defend trade-offs
Artifact: business_questions.md + assumptions.md
Evidence: evidence/P03-13/attempt.json
Validation: Run same input twice and prove trusted logical result is stable; then add a changed/new record and prove only intended state changes.
