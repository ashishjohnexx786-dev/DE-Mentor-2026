# Exact phase route

## P02-01 - Read the analytics-engineering brief and define outputs
Artifact: business_questions.md + assumptions.md
Evidence: evidence/P02-01/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P02-02 - Profile billing/customer sources and state grains
Artifact: source_profile/ + grain_key_defects.md
Evidence: evidence/P02-02/attempt.json
Validation: Record row counts, grain, keys, null/duplicate/schema defects; independently sample-check at least one finding.

## P02-03 - Design facts, dimensions, keys and serving grain
Artifact: p02_phase_artifact + evidence note
Evidence: evidence/P02-03/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P02-04 - Create dbt project, sources and dependency graph
Artifact: models/SQL/dbt + lineage + row-count controls
Evidence: evidence/P02-04/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## P02-05 - Build thin staging models with explicit contracts
Artifact: source_contracts.md
Evidence: evidence/P02-05/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## P02-06 - Build dimensional marts without fan-out
Artifact: models/SQL/dbt + lineage + row-count controls
Evidence: evidence/P02-06/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## P02-07 - Add data tests and critical quality gates
Artifact: tests/ + reconciliation report + quarantine evidence
Evidence: evidence/P02-07/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P02-08 - Implement incremental model/update behavior
Artifact: state ledger/watermark + rerun/backfill evidence
Evidence: evidence/P02-08/attempt.json
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.

## P02-09 - Preserve history with snapshot/SCD reasoning
Artifact: p02_phase_artifact + evidence note
Evidence: evidence/P02-09/attempt.json
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.

## P02-10 - Add orchestration and reproducible run order
Artifact: DAG/workflow + run log + dependency evidence
Evidence: evidence/P02-10/attempt.json
Validation: Run dependency path end-to-end; prove failed task does not falsely advance downstream state; rerun only required work.

## P02-11 - Inject duplicate/relationship/partial-run failures
Artifact: first-failure evidence + root_cause.md + repair + fresh retry evidence
Evidence: evidence/P02-11/attempt.json
Validation: Save first failing evidence before repair; identify root cause; apply smallest safe repair; fresh retry must pass all prior controls.

## P02-12 - Document lineage, runbook, limitations and evidence
Artifact: README.md + runbook.md + evidence_index.md
Evidence: evidence/P02-12/attempt.json
Validation: Reviewer can locate every evidence artifact and challenge one design trade-off; learner explains limitation and recovery path without reading a script.

## P02-13 - Clean-clone build and analytics-platform defense
Artifact: clean-clone transcript/log + frozen evidence bundle
Evidence: evidence/P02-13/attempt.json
Validation: Rebuild from documented clean state using only declared dependencies/config; reviewer can reproduce declared outputs.
