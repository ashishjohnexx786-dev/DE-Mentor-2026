M02 - SQL FOUNDATIONS - BEGINNER-FIRST TEACHING RC2

START HERE:
00_START_HERE_TEACHING_RC2.pdf

ORDER:
1. Install MySQL Server + Workbench only when M02 asks.
2. Run DATA/M02_MYSQL_LAB_SETUP_TEACHING_RC2.sql once.
3. Study each lesson in 01_LEARNER_BOOK_TEACHING_RC2.pdf.
4. Do matching Guided Lab then Independent Practice.
5. Save genuine attempts before any review.
6. Use checkpoints and module practical only when routed.

IMPORTANT:
- The Learner Book is the teacher, not a revision checklist.
- Independent tasks are explicit; you never have to guess what the author expects.
- Phone is for reading; MySQL execution is PC-required.
- Never share your MySQL password in screenshots or chat.
