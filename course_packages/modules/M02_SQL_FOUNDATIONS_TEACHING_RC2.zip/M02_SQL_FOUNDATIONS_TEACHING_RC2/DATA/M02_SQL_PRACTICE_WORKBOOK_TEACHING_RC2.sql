-- M02 SQL FOUNDATIONS - PRACTICE WORKBOOK TEACHING RC2
-- This file is the SQL equivalent of a workbook.
-- Rule: setup first, then type YOUR query under each task. Guided sections tell you exact checks.
-- Independent sections tell you the assignment and self-check, but do not give the answer.
-- Save genuine wrong attempts before repair.

USE stage02_retail_lab;

-- ============================================================
-- A. FIRST-USE CHECK
-- ============================================================
-- A1. Run this. Expected: stage02_retail_lab
SELECT DATABASE() AS current_database;
-- A2. Run this. Expected: 30
SELECT COUNT(*) AS total_rows FROM sales_orders;
-- A3. Run this. Expected: 1
SELECT COUNT(*) - COUNT(sales_rep) AS missing_sales_rep FROM sales_orders;

-- ============================================================
-- B. GUIDED WORKSPACE - type your queries under each heading
-- ============================================================
-- G01 First SELECT: return order_id, region, status for 5 rows.
-- Expected: exactly 3 columns, 5 rows.


-- G02 Calculated alias: order_id, qty, unit_price, gross_sales for 10 rows.
-- Expected: O1001 gross_sales 1700; O1002 1350.


-- G03 WHERE: Completed AND qty >= 2.
-- Expected row count: 22.


-- G04 Boolean logic: Completed AND (East OR North).
-- Expected row count: 13.


-- G05 DISTINCT regions alphabetically; then separate top-5 gross query.
-- Unique regions: East, North, South, West. Highest gross: O1020 = 3600.


-- G06 NULL: compare COUNT(*) and COUNT(sales_rep); find NULL row; COALESCE for display.
-- Expected: 30 vs 29; one NULL row O1030.


-- G07 Arithmetic: gross_sales and net_sales. Manually verify O1002 = 1282.50 net.


-- G08 Aggregates: row count, SUM(qty), AVG(unit_price), total gross.
-- Expected: 30, 105, about 666.33, 50000.


-- G09 Completed GROUP BY region.
-- Expected gross: East 12800, North 9310, South 12010, West 10930.


-- G10 HAVING: region SUM(qty) >= 25.
-- Expected: East 29, North 27, West 25.


-- G11 CASE gross buckets: High >=2500, Medium >=1500, else Small.
-- Expected counts: High 3, Medium 14, Small 13.


-- G12 Dates: July 10 through July 12 inclusive + UPPER(TRIM(region)).
-- Expected row count: 6.


-- ============================================================
-- C. INDEPENDENT WORKSPACE - assignment is explicit; answers are not
-- ============================================================
-- P01 Return exactly order_id, order_date, product for every row.
-- Self-check: 30 rows, 3 columns.


-- P02 Non-Cancelled orders in East OR North, with correct parentheses.
-- Self-check: no Cancelled, no South/West. Save row count.


-- P03 Unique status values alphabetically. Explain why DISTINCT is valid.
-- Self-check: exactly 3 status labels.


-- P04 True NULL sales_rep rows + COUNT(*) vs COUNT(sales_rep).
-- Self-check: counts differ by exactly 1.


-- P05 gross_sales + net_sales. Manually validate 2 records in comments.


-- P06 Completed order count + total net_sales in one summary row.
-- Add separate COUNT(*) control using the identical filter.


-- P07 Completed gross_sales by region, highest first.
-- Reconcile grouped total to separate Completed overall total.


-- P08 Completed by payment_method: order_count, total_qty, gross_sales;
-- keep only groups total_qty >=25. Self-check: Cash and UPI survive.


-- P09 net_sales bucket: High >=2200, Medium >=1200, else Low.
-- Add separate bucket-count validation; counts must sum to 30.


-- P10 July 8 through July 11 inclusive, sorted by date then order_id.
-- Record count and endpoint inspection.


-- P11 Unique standardized payment methods using TRIM + UPPER.
-- Do not edit source data.


-- P12 Above-average gross_sales using a scalar subquery.
-- Run inner AVG alone first and save the value as a comment.
-- Self-check: outer result has 16 rows.


-- P13 Completed Keyboard/Mouse orders using IN.
-- Spot-check one of each and prove no other product appears.


-- P14 Debug these intentionally broken queries.
-- For each: write failure type first, then repair, then add a validation.

-- Broken 1: text value not quoted
SELECT * FROM sales_orders WHERE status = Completed;

-- Broken 2: aggregate threshold in wrong stage
SELECT region, SUM(qty) AS total_qty
FROM sales_orders
WHERE SUM(qty) >= 25
GROUP BY region;

-- Broken 3: plausible but wrong "top 5" because no descending sort
SELECT order_id, qty * unit_price AS gross_sales
FROM sales_orders
LIMIT 5;
