from __future__ import annotations
from datetime import timedelta
import pendulum
from airflow.sdk import dag, task, Param, get_current_context

@dag(
    dag_id="m10_daily_orders",
    schedule="@daily",
    start_date=pendulum.datetime(2026, 9, 1, tz="UTC"),
    catchup=False,
    params={"min_amount": Param(0, type="number", minimum=0)},
    tags=["m10", "training"],
)
def m10_daily_orders():
    @task(retries=2, retry_delay=timedelta(seconds=30), execution_timeout=timedelta(minutes=5))
    def extract():
        return [{"order_id":"O1","amount":120.0},{"order_id":"O2","amount":80.0}]

    @task
    def validate(rows):
        if not rows:
            raise ValueError("empty input")
        return rows

    @task
    def transform(rows):
        ctx=get_current_context()
        minimum=float(ctx["params"]["min_amount"])
        return [r for r in rows if float(r["amount"]) >= minimum]

    @task
    def load(rows):
        return {"loaded_rows": len(rows), "loaded_value": sum(r["amount"] for r in rows)}

    @task
    def reconcile(summary):
        if summary["loaded_rows"] < 0:
            raise ValueError("invalid row count")
        return summary

    reconcile(load(transform(validate(extract()))))

m10_daily_orders()
