#!/usr/bin/env python3
from pathlib import Path
import csv,json,time
ROOT=Path(__file__).resolve().parents[1]; IN=ROOT/'input'; OUT=ROOT/'output'; OUT.mkdir(parents=True,exist_ok=True)

def run_day(day, min_amount=0, transient_failures=0, sensor_max_polls=3, file_present=True, inject_bad=False):
    tasks={k:{'state':'PENDING','attempts':0} for k in ['wait_input','extract','validate','transform','load','reconcile']}
    xcom={}; logs=[]; state_before=(OUT/'checkpoint.txt').read_text().strip() if (OUT/'checkpoint.txt').exists() else 'NONE'
    # sensor/wait semantics
    for poll in range(1,sensor_max_polls+1):
        tasks['wait_input']['attempts']=poll
        if file_present and (IN/f'orders_{day}.csv').exists(): tasks['wait_input']['state']='SUCCESS'; logs.append(f'wait_input success poll={poll}'); break
    else:
        tasks['wait_input']['state']='FAILED'; logs.append('wait_input timeout');
        for k in ['extract','validate','transform','load','reconcile']: tasks[k]['state']='UPSTREAM_FAILED'
        return {'day':day,'status':'FAILED_SENSOR_TIMEOUT','tasks':tasks,'state_before':state_before,'state_after':state_before,'logs':logs}
    # extract with transient retries: max 3 attempts (2 retries)
    for attempt in range(1,4):
        tasks['extract']['attempts']=attempt
        if attempt <= transient_failures: logs.append(f'extract transient failure attempt={attempt}'); continue
        with (IN/f'orders_{day}.csv').open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
        if inject_bad: rows.append({'order_id':'BAD','amount':'oops'})
        tasks['extract']['state']='SUCCESS'; xcom['extract_rows']=rows; break
    else:
        tasks['extract']['state']='FAILED'
        for k in ['validate','transform','load','reconcile']: tasks[k]['state']='UPSTREAM_FAILED'
        return {'day':day,'status':'FAILED_RETRIES_EXHAUSTED','tasks':tasks,'state_before':state_before,'state_after':state_before,'logs':logs}
    tasks['validate']['attempts']=1
    try:
        clean=[]
        for r in xcom['extract_rows']:
            if not r['order_id'].strip(): raise ValueError('missing order_id')
            amt=float(r['amount'])
            if amt<0: raise ValueError('negative amount')
            clean.append({'order_id':r['order_id'],'amount':amt})
        tasks['validate']['state']='SUCCESS'; xcom['valid_rows']=clean
    except Exception as e:
        tasks['validate']['state']='FAILED'; logs.append('validate '+str(e))
        for k in ['transform','load','reconcile']: tasks[k]['state']='UPSTREAM_FAILED'
        return {'day':day,'status':'FAILED_VALIDATION','tasks':tasks,'state_before':state_before,'state_after':state_before,'logs':logs}
    tasks['transform']['attempts']=1; filtered=[r for r in clean if r['amount']>=float(min_amount)]; tasks['transform']['state']='SUCCESS'; xcom['filtered']=filtered
    tasks['load']['attempts']=1; summary={'rows':len(filtered),'value':round(sum(r['amount'] for r in filtered),2)}; tasks['load']['state']='SUCCESS'; xcom['summary']=summary
    tasks['reconcile']['attempts']=1
    if summary['rows'] != len(filtered): tasks['reconcile']['state']='FAILED'; return {'day':day,'status':'FAILED_RECONCILIATION','tasks':tasks,'state_before':state_before,'state_after':state_before,'logs':logs}
    tasks['reconcile']['state']='SUCCESS'; (OUT/'checkpoint.txt').write_text(day); state_after=day
    return {'day':day,'status':'PASS','tasks':tasks,'summary':summary,'state_before':state_before,'state_after':state_after,'logs':logs,'xcom_keys':sorted(xcom)}

def main():
    # Clean checkpoint so the smoke result is deterministic.
    p=OUT/'checkpoint.txt'
    if p.exists(): p.unlink()
    daily=run_day('2026-09-01',min_amount=100,transient_failures=2)
    timeout=run_day('2026-09-02',file_present=False,sensor_max_polls=2)
    failure=run_day('2026-09-02',inject_bad=True)
    backfill=[run_day(d,min_amount=100) for d in ['2026-09-01','2026-09-02','2026-09-03']]
    result={'daily_retry':daily,'sensor_timeout':timeout,'validation_failure':failure,'backfill':backfill}
    (OUT/'M10_SIMULATOR_RESULT.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
