Training placeholder only. Before a real local run, replace db_password.example.txt with a local secret file that is excluded from Git. Never reuse a real password from another system.
