from http.server import BaseHTTPRequestHandler, HTTPServer
import json, os
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        body=json.dumps({"service":"m10-lab","status":"ok","db_host":os.getenv("DB_HOST","db")}).encode()
        self.send_response(200); self.send_header("Content-Type","application/json"); self.end_headers(); self.wfile.write(body)
if __name__=="__main__": HTTPServer(("0.0.0.0",8080),H).serve_forever()
