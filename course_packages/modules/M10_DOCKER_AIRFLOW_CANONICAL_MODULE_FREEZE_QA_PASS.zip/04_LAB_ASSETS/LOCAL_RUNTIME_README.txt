M10 local lab
STATIC NOW: Dockerfile/compose and Airflow DAG are included and statically validated.
EXECUTABLE NOW: cd 04_LAB_ASSETS/simulator/scripts && python orchestration_simulator.py
REAL LEARNER-PC CHECK: install/use the course-approved Docker Desktop/WSL2 + Airflow environment, then build/up the Compose stack and run/inspect the Airflow DAG. Record actual version, commands, task states, logs and rerun/backfill evidence. Do not claim real runtime from this package QA.
