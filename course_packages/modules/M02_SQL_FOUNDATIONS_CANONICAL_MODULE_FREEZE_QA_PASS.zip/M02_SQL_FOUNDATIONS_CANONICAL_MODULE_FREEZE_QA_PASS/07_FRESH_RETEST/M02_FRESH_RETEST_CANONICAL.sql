-- M02 FRESH RETEST - use only after targeted repair / when assigned
USE stage02_retail_lab;

-- R1 Boolean + NULL
-- Return non-Cancelled Card orders from West or South, using explicit parentheses; display Unassigned for NULL sales_rep without changing source.


-- R2 Calculation + group
-- For Completed orders, calculate net_sales by category and payment_method. Reconcile grouped net to an overall Completed net control.


-- R3 HAVING
-- Keep only Completed region groups whose SUM(net_sales) exceeds 10000. State result grain.


-- R4 Subquery
-- Return orders whose gross_sales is above the average gross_sales of Card orders; run the inner average alone first.


-- R5 Debug
-- Repair a query whose WHERE clause accidentally admits Pending North orders because OR is not parenthesized. Save before/after counts and English rule.


