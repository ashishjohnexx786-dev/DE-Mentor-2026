M02 MODULE CONTENT FREEZE - QA PASS (COURSE-WIDE FINAL PENDING)

Freeze date: 2026-09-10
Completion rule: competency evidence only; no percentage shortcut.
Protected review remains attempt-locked. Repair is targeted; fresh retest uses changed evidence.
Live runtime/device behavior remains pending for course-wide final validation.

--- Preserved learner instructions ---

ZERO TO JOB-READY DATA ENGINEER 2026 - M02 SQL Foundations
CANONICAL REBUILD - INTERNAL QA

This replaces the inconsistent old M02 learner surfaces (9 lesson pages / 12 guided labs) with one canonical 14-lesson system.
Study order: 00_START_HERE -> Lesson Book -> Guided -> Independent -> Module Practical -> protected Review if needed -> Fresh Retest if assigned.

Setup: M02 uses MySQL 8+ / MySQL Workbench. WSL is NOT an M02 prerequisite.

Do not call this the whole-course FINAL release until the standalone DE cross-module/Gate/Mentor/runtime/device audits are complete.
