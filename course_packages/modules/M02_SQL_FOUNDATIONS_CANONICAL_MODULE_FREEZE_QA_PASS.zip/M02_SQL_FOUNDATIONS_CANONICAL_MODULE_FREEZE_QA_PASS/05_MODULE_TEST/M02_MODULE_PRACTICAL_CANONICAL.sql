-- M02 MODULE PRACTICAL - CLOSED RESOURCE - INTERNAL QA
-- Do not open Review while attempting.
USE stage02_retail_lab;

-- A. State source grain and key
-- Write in comments what one sales_orders row represents; identify primary key; identify nullable field.


-- B. Eligibility + totals
-- For Completed orders only, return order_count, qty, gross_sales and net_sales. Save one independent control.


-- C. Grouped business view
-- Return Completed net_sales by region and payment_method; state result grain and reconcile to B.


-- D. Quality
-- Prove the missing-sales_rep count and show a presentation label without changing source data.


-- E. Subquery
-- Return Completed orders above the average Completed net_sales; validate the inner average separately.


-- F. Debug + repair
-- Start from a query that includes Pending by using status <> Cancelled; diagnose and repair to Completed-only, preserving both outputs.


-- G. Explain
-- 2-3 minute defense: WHERE vs HAVING, source grain vs grouped grain, NULL vs zero, and how you validated totals.


