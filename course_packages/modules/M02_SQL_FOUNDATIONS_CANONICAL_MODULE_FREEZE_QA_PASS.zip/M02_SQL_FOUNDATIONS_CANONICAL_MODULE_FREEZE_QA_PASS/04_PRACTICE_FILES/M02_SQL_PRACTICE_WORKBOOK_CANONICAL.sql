-- M02 SQL FOUNDATIONS - FINAL-EDITION CANONICAL PRACTICE WORKBOOK - INTERNAL QA
-- Setup: run STAGE_02_MYSQL_LAB_SETUP_CANONICAL.sql once.
-- Rule: keep first attempts. Do not open protected review until attempt saved.

USE stage02_retail_lab;

-- ============================================================
-- G01 / DE02-01 - Database, table, row, column and query mental model
-- GUIDED: Run the setup script. Confirm the active database is stage02_retail_lab and the table has exactly 30 rows. Open DESCRIBE sales_orders and point to order_id, qty, status and sales_rep.
-- CHECK: Database = stage02_retail_lab; row count = 30; order_id is the primary key; sales_rep can be NULL.


-- P01 / INDEPENDENT
-- TASK: With the video closed, open a new query tab and return order_id, region and product for any 5 rows. In a SQL comment, state the result grain.
-- VALIDATE: Exactly 3 selected columns and 5 rows. Grain statement says one result row represents one order from sales_orders.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G02 / DE02-02 - SELECT, aliases and LIMIT
-- GUIDED: Return order_id, qty, unit_price and gross_sales for 10 rows. Rename product as item_name in a second query.
-- CHECK: O1001 gross_sales = 1700; O1002 = 1350. First query returns 10 rows and 4 columns.


-- P02 / INDEPENDENT
-- TASK: Return order_id, order_date and product for every row, then create a separate query returning 7 rows with product renamed item_name.
-- VALIDATE: First query returns 30 rows / 3 columns. Second returns 7 rows and has a column named item_name.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G03 / DE02-03 - WHERE and comparison operators
-- GUIDED: Run the Completed AND qty >= 2 filter and a separate COUNT(*) using the identical WHERE clause.
-- CHECK: 22 rows; no Pending or Cancelled rows survive.


-- P03 / INDEPENDENT
-- TASK: Return orders dated 2026-07-10 through 2026-07-12 inclusive, then return only West orders with unit_price >= 850.
-- VALIDATE: Date-range result = 6 rows. West/high-price result contains only West and unit_price >= 850.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G04 / DE02-04 - AND, OR, NOT and parentheses
-- GUIDED: Return Completed orders from East or North with explicit parentheses. Count the rows separately.
-- CHECK: 13 rows. Regions are only East/North and every status is Completed.


-- P04 / INDEPENDENT
-- TASK: Return non-Cancelled orders from East or North. Then write a logically equivalent version using NOT status = 'Cancelled'.
-- VALIDATE: Both independent queries return the same order_ids. Save a set/count comparison.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G05 / DE02-05 - ORDER BY, DISTINCT and result inspection
-- GUIDED: List unique regions alphabetically. In a separate query return the five highest gross-sales orders.
-- CHECK: Regions = East, North, South, West. Highest gross order = O1020 at 3600.


-- P05 / INDEPENDENT
-- TASK: Return distinct payment methods alphabetically. Then return the three largest-quantity orders with a deterministic tie-break on order_id.
-- VALIDATE: Exactly Card, Cash, UPI. Top qty begins O1021=10, O1026=9, O1007=8.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G06 / DE02-06 - NULL, IS NULL and COALESCE
-- GUIDED: Compare COUNT(*) with COUNT(sales_rep), find the NULL row, and display Unassigned with COALESCE without updating the table.
-- CHECK: 30 total rows; 29 non-NULL sales_rep; O1030 is the one NULL sales_rep row.


-- P06 / INDEPENDENT
-- TASK: Return all rows with sales_rep IS NOT NULL and prove their count. Then show every order with a rep_label that uses Unassigned only for display.
-- VALIDATE: IS NOT NULL count = 29. Source sales_rep for O1030 remains NULL.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G07 / DE02-07 - Arithmetic expressions and safe calculations
-- GUIDED: Calculate gross_sales and net_sales for all orders. Manually verify O1002.
-- CHECK: O1002 gross = 1350; net = 1282.50.


-- P07 / INDEPENDENT
-- TASK: Calculate discount_value = gross_sales - net_sales and validate two orders manually.
-- VALIDATE: For every row with discount_pct > 0, discount_value > 0 and net_sales <= gross_sales. Save two manual checks.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G08 / DE02-08 - Aggregate functions
-- GUIDED: Return row count, total qty, average price, min/max price and gross sales for all rows.
-- CHECK: 30 rows; total qty 105; average unit_price about 666.33; gross sales 50000.


-- P08 / INDEPENDENT
-- TASK: For Completed orders only, return order count, total qty and total net_sales in one summary row.
-- VALIDATE: Completed order count = 27; total qty = 100; total net_sales = 42984.50.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G09 / DE02-09 - GROUP BY and grouped grain
-- GUIDED: Build Completed order count and gross sales by region.
-- CHECK: East 8 / 12800; North 5 / 9310; South 7 / 12010; West 7 / 10930.


-- P09 / INDEPENDENT
-- TASK: Build Completed order count, qty and net_sales by payment_method and state the result grain.
-- VALIDATE: 3 result rows; grouped net total reconciles to 42984.50.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G10 / DE02-10 - HAVING after aggregation
-- GUIDED: Group all rows by region and keep groups with SUM(qty) >= 25.
-- CHECK: East 29, North 27, West 25; South is excluded.


-- P10 / INDEPENDENT
-- TASK: For Completed orders only, return payment methods whose total qty is at least 25.
-- VALIDATE: Cash 39 and UPI 39 qualify; Card 22 does not.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G11 / DE02-11 - CASE for business categories
-- GUIDED: Bucket all orders into High >=2500, Medium >=1500, otherwise Small, then count each bucket.
-- CHECK: High 3; Medium 14; Small 13.


-- P11 / INDEPENDENT
-- TASK: Create fulfillment_group: Completed -> Closed; Pending -> Open; otherwise Other. Count each group.
-- VALIDATE: Counts across the three groups sum to 30 and source status values remain unchanged.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G12 / DE02-12 - String and date basics
-- GUIDED: Run the date-range/text query for July 10 through July 12 inclusive.
-- CHECK: 6 rows; every order_year = 2026 and order_month = 7.


-- P12 / INDEPENDENT
-- TASK: Return product labels as UPPER(product) and extract day-of-month for orders on July 13-15. Keep original product beside the transformed value.
-- VALIDATE: Only July 13, 14 and 15 rows appear; transformed output is traceable to original text.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G13 / DE02-13 - Simple subqueries and IN/EXISTS awareness
-- GUIDED: Find Completed orders whose net_sales is above the average Completed net_sales. Run the inner average query alone first.
-- CHECK: Average Completed net_sales is about 1592.02; 13 orders are above it.


-- P13 / INDEPENDENT
-- TASK: Use IN with a subquery to return orders whose region belongs to a region whose all-status SUM(qty) is at least 25. State what the inner query returns.
-- VALIDATE: The inner set is East, North, West; no South order appears in the outer result.
-- YOUR SQL / NOTES BELOW


-- ============================================================
-- G14 / DE02-14 - Debugging and validation workflow
-- GUIDED: Run the wrong-business-rule query, compare its eligibility count with Completed-only count, repair the filter, then reconcile grouped gross_sales to a separate Completed overall total.
-- CHECK: Completed-only count = 27. Completed grouped gross total reconciles to 45050. A query that includes Pending is not equivalent even if the numbers look plausible.


-- P14 / INDEPENDENT
-- TASK: Take a deliberately wrong query that uses OR without parentheses, diagnose why a Pending row leaks into the output, repair it, and save before/after row counts plus the corrected English rule.
-- VALIDATE: The corrected query has the intended status and regions only. A separate COUNT/control query supports the result.
-- YOUR SQL / NOTES BELOW


