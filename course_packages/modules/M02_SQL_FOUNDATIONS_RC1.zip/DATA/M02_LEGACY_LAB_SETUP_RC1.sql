-- ZERO TO JOB-READY DATA ENGINEER 2026
-- Stage 02 - SQL Foundations - MySQL 8+
-- Safe reset: this script creates ONLY the course database below.

DROP DATABASE IF EXISTS stage02_retail_lab;
CREATE DATABASE stage02_retail_lab;
USE stage02_retail_lab;

CREATE TABLE sales_orders (
    order_id VARCHAR(10) PRIMARY KEY,
    order_date DATE NOT NULL,
    customer_id VARCHAR(10) NOT NULL,
    region VARCHAR(20) NOT NULL,
    category VARCHAR(30) NOT NULL,
    product VARCHAR(50) NOT NULL,
    qty INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    discount_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
    payment_method VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL,
    sales_rep VARCHAR(30) NULL
);

INSERT INTO sales_orders
(order_id, order_date, customer_id, region, category, product, qty, unit_price, discount_pct, payment_method, status, sales_rep)
VALUES
('O1001', '2026-07-01', 'C001', 'East', 'Accessories', 'Keyboard', 2, 850, 0.0, 'UPI', 'Completed', 'Asha'),
('O1002', '2026-07-01', 'C002', 'West', 'Accessories', 'Mouse', 3, 450, 0.05, 'Card', 'Completed', 'Rohit'),
('O1003', '2026-07-02', 'C003', 'North', 'Accessories', 'USB Cable', 5, 220, 0.0, 'Cash', 'Completed', 'Asha'),
('O1004', '2026-07-02', 'C004', 'South', 'Accessories', 'Keyboard', 1, 850, 0.1, 'UPI', 'Completed', 'Meera'),
('O1005', '2026-07-03', 'C005', 'East', 'Accessories', 'Mouse', 4, 450, 0.0, 'Card', 'Completed', 'Rohit'),
('O1006', '2026-07-03', 'C006', 'West', 'Office', 'Laptop Stand', 2, 1200, 0.1, 'UPI', 'Completed', 'Asha'),
('O1007', '2026-07-04', 'C007', 'North', 'Accessories', 'USB Cable', 8, 220, 0.05, 'Cash', 'Completed', 'Meera'),
('O1008', '2026-07-04', 'C008', 'South', 'Accessories', 'Keyboard', 2, 850, 0.0, 'Card', 'Completed', 'Rohit'),
('O1009', '2026-07-05', 'C009', 'East', 'Accessories', 'Mouse', 2, 450, 0.0, 'UPI', 'Completed', 'Asha'),
('O1010', '2026-07-05', 'C010', 'West', 'Office', 'Laptop Stand', 1, 1200, 0.0, 'Card', 'Completed', 'Meera'),
('O1011', '2026-07-06', 'C011', 'North', 'Accessories', 'Keyboard', 1, 850, 0.0, 'Cash', 'Pending', 'Rohit'),
('O1012', '2026-07-06', 'C012', 'North', 'Accessories', 'Mouse', 3, 450, 0.05, 'UPI', 'Completed', 'Asha'),
('O1013', '2026-07-07', 'C013', 'South', 'Accessories', 'USB Cable', 6, 220, 0.0, 'UPI', 'Completed', 'Meera'),
('O1014', '2026-07-07', 'C014', 'East', 'Accessories', 'Keyboard', 2, 850, 0.1, 'Card', 'Completed', 'Rohit'),
('O1015', '2026-07-08', 'C015', 'West', 'Accessories', 'Mouse', 5, 450, 0.0, 'UPI', 'Completed', 'Asha'),
('O1016', '2026-07-08', 'C016', 'North', 'Office', 'Laptop Stand', 2, 1200, 0.05, 'Card', 'Completed', 'Meera'),
('O1017', '2026-07-09', 'C017', 'South', 'Accessories', 'USB Cable', 7, 220, 0.0, 'Cash', 'Completed', 'Rohit'),
('O1018', '2026-07-09', 'C018', 'East', 'Accessories', 'Keyboard', 1, 850, 0.0, 'UPI', 'Completed', 'Asha'),
('O1019', '2026-07-10', 'C019', 'West', 'Accessories', 'Mouse', 2, 450, 0.1, 'Card', 'Completed', 'Meera'),
('O1020', '2026-07-10', 'C020', 'South', 'Office', 'Laptop Stand', 3, 1200, 0.15, 'UPI', 'Completed', 'Rohit'),
('O1021', '2026-07-11', 'C021', 'East', 'Accessories', 'USB Cable', 10, 220, 0.05, 'Cash', 'Completed', 'Asha'),
('O1022', '2026-07-11', 'C022', 'West', 'Accessories', 'Keyboard', 2, 850, 0.0, 'Card', 'Cancelled', 'Meera'),
('O1023', '2026-07-12', 'C023', 'North', 'Accessories', 'Mouse', 6, 450, 0.1, 'UPI', 'Completed', 'Rohit'),
('O1024', '2026-07-12', 'C024', 'South', 'Office', 'Laptop Stand', 1, 1200, 0.0, 'Card', 'Completed', 'Asha'),
('O1025', '2026-07-13', 'C025', 'East', 'Accessories', 'Keyboard', 3, 850, 0.05, 'UPI', 'Completed', 'Meera'),
('O1026', '2026-07-13', 'C026', 'West', 'Accessories', 'USB Cable', 9, 220, 0.0, 'Cash', 'Completed', 'Rohit'),
('O1027', '2026-07-14', 'C027', 'North', 'Office', 'Laptop Stand', 2, 1200, 0.1, 'UPI', 'Pending', 'Asha'),
('O1028', '2026-07-14', 'C028', 'South', 'Accessories', 'Mouse', 4, 450, 0.05, 'Card', 'Completed', 'Meera'),
('O1029', '2026-07-15', 'C029', 'East', 'Accessories', 'USB Cable', 5, 220, 0.0, 'UPI', 'Completed', 'Rohit'),
('O1030', '2026-07-15', 'C030', 'West', 'Accessories', 'Keyboard', 1, 850, 0.0, 'Card', 'Completed', NULL);

-- Verification queries: expected 30 rows and one missing sales_rep.
SELECT DATABASE() AS current_database;
SHOW TABLES;
SELECT COUNT(*) AS total_rows FROM sales_orders;
SELECT COUNT(*) - COUNT(sales_rep) AS missing_sales_rep FROM sales_orders;
