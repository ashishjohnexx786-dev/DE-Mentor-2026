DROP TABLE IF EXISTS practical_orders;
CREATE TABLE practical_orders(order_id TEXT PRIMARY KEY, region TEXT, qty INTEGER, unit_price REAL, discount_pct REAL, status TEXT, sales_rep TEXT);
INSERT INTO practical_orders VALUES
('A01','East',2,500,0.10,'Completed','R1'),('A02','West',5,200,0.00,'Completed','R2'),('A03','East',1,900,0.05,'Cancelled','R1'),('A04','North',3,400,0.10,'Completed',NULL),('A05','South',4,250,0.20,'Completed','R3'),('A06','West',2,700,0.05,'Completed','R2'),('A07','North',1,1600,0.00,'Completed','R4'),('A08','South',6,150,0.00,'Completed','R3');
