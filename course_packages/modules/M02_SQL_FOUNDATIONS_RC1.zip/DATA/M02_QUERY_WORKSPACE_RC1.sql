-- Stage 02 SQL Foundations - Query Workspace
-- RULE: type your query under each task. Do not open the Review Pack until you save a genuine attempt.
USE stage02_retail_lab;

-- DE02-01 Setup check
-- Q1. Show the current database.


-- Q2. Count all rows in sales_orders.


-- DE02-02 Relational basics / NULL
-- Q3. Count how many rows have a missing sales_rep.


-- DE02-03 SELECT / DISTINCT / aliases
-- Q4. Return order_id, order_date, region, product and qty for all rows.


-- Q5. Return the distinct regions.


-- Q6. Create a calculated column gross_sales = qty * unit_price and alias it gross_sales.


-- DE02-04 WHERE
-- Q7. Return only Completed orders from East where qty >= 3.


-- Q8. Return orders dated from 2026-07-10 through 2026-07-12 inclusive.


-- Q9. Return the row(s) where sales_rep is missing.


-- DE02-05 ORDER BY / LIMIT
-- Q10. Show the 5 highest gross_sales orders.


-- DE02-06 Aggregates
-- Q11. Return total order rows, total quantity, average unit price and total gross sales.


-- DE02-07 GROUP BY
-- Q12. Return order count, total qty and gross sales by region.


-- DE02-08 HAVING
-- Q13. Return regions whose total quantity is at least 25.


-- DE02-09 CASE
-- Q14. Add order_size: High if gross_sales >= 2500, Medium if >= 1500, otherwise Small.


-- MIXED PRACTICE
-- Q15. Completed-order gross sales by region, highest first.


-- Q16. Completed orders by payment_method: order count, total qty and gross sales.


-- Q17. Return only groups from Q16 whose total qty is at least 25.


-- STAGE 02 INDEPENDENT CHECKPOINT
-- C1. Distinct status values.


-- C2. Count Completed orders only.


-- C3. Top 3 orders by gross_sales.


-- C4. Completed gross sales by region, highest first.


-- C5. Regions with SUM(qty) >= 25 across all statuses.


-- C6. Bucket every order with CASE: High >=2500, Medium >=1500, else Small.


-- C7. Explain in a SQL comment: WHERE filters _____; HAVING filters _____.

