DROP TABLE IF EXISTS retest_tickets;
CREATE TABLE retest_tickets(ticket_id TEXT PRIMARY KEY, team TEXT, priority TEXT, minutes_open INTEGER, resolved INTEGER, owner TEXT);
INSERT INTO retest_tickets VALUES
('T01','Billing','High',180,1,'A'),('T02','Tech','Medium',90,1,'B'),('T03','Billing','Low',40,1,'A'),('T04','Tech','High',300,0,NULL),('T05','Account','Medium',120,1,'C'),('T06','Account','High',240,0,'C'),('T07','Billing','Medium',75,1,'D'),('T08','Tech','Low',30,1,'B');
