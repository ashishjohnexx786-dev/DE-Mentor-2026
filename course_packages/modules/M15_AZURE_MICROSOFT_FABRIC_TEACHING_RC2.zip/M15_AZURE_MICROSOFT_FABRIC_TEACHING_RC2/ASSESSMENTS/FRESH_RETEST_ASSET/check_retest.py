from pathlib import Path
import json,re,sys
B=Path(__file__).parent; C=[]
def ck(n,c):C.append((n,bool(c)))
def t(n):return (B/n).read_text(encoding='utf-8')
r=json.loads(t('result_summary.json')); ck('silver rows',r.get('silver_rows')==4); ck('distinct assets',r.get('distinct_asset_ids')==4); ck('total',r.get('total_maintenance_cost')==2010); ck('site totals',r.get('site_totals')=={'North':900,'South':750,'West':360})
j=t('fabric_job.py').lower(); ck('delta','delta' in j); ck('merge','merge' in j and 'asset_id' in j); ck('medallion',all(x in j for x in ['bronze','silver','gold']))
s=t('queries.sql').lower(); ck('read only','select' in s and not any(x in s for x in ['delete ','drop ','truncate ','update '])); ck('controls','count' in s and 'sum' in s and 'site' in s)
p=json.loads(t('pipeline_plan.json')); ck('pipeline',len(p.get('activities',[]))>=3); ck('parameter','run_date' in p.get('parameters',[])); ck('secret policy',any(x in p.get('secret_policy','').lower() for x in ['managed','secret','connection']))
rr=t('reasoning.md').lower(); ck('least privilege','least privilege' in rr); ck('rerun','rerun' in rr or 'idempot' in rr); ck('monitor','monitor' in rr and 'fresh' in rr); ck('cost','cost' in rr); ck('recovery','recover' in rr or 'failure' in rr)
ev=t('runtime_evidence.md').lower(); ck('runtime evidence',len(ev)>80 and 'fabric' in ev)
for n,c in C:print(('PASS' if c else 'FAIL'),n)
print(f'{sum(c for _,c in C)}/{len(C)} passed');sys.exit(0 if all(c for _,c in C) else 1)
