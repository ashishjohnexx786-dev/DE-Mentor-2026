# COMPLETE: maintenance asset Bronze/Silver/Gold Delta plus deterministic asset_id MERGE and rerun-safe controls.
