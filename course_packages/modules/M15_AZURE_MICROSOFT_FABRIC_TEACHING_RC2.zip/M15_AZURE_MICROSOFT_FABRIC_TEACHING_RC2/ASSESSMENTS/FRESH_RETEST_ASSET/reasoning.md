# Reasoning
Explain least privilege, raw preservation, asset_id merge precedence, rerun safety, monitoring/freshness, cost and recovery.
