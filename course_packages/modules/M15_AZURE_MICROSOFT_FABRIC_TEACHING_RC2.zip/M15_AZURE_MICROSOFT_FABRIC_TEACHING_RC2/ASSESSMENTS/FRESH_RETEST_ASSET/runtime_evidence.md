# Real Fabric runtime evidence
Record workspace/lakehouse/notebook/pipeline/SQL and rerun evidence. No credentials.
