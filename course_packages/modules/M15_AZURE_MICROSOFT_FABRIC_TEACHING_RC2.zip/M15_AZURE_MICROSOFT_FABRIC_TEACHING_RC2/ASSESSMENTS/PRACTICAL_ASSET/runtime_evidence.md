# Real Fabric runtime evidence
Record workspace/lakehouse, notebook run, pipeline run ID/status, SQL results, rerun evidence, and permission/monitoring evidence. Do not paste credentials.
