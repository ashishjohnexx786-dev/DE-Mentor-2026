# COMPLETE THIS in your Fabric notebook/project.
# Required: raw preservation, Bronze/Silver/Gold Delta, deterministic sale_id incremental MERGE, rerun-safe controls.
# Your solution must contain a Delta write pattern and an explicit MERGE/upsert strategy.
