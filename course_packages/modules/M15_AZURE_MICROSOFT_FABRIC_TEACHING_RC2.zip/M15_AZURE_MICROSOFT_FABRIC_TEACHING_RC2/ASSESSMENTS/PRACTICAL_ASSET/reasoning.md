# Reasoning
Explain least privilege, why raw is preserved, incremental/rerun behavior, monitoring/freshness, one cost control, and one safe failure/recovery decision.
