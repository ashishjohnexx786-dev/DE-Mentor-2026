from pathlib import Path
import json, re, sys
B=Path(__file__).parent; checks=[]
def ck(n,c): checks.append((n,bool(c)))
def t(n): return (B/n).read_text(encoding='utf-8')
r=json.loads(t('result_summary.json')); ck('silver rows',r.get('silver_rows')==6); ck('distinct ids',r.get('distinct_sale_ids')==6); ck('total amount',r.get('total_amount')==930); ck('region totals',r.get('region_totals')=={'North':300,'South':230,'West':90,'East':310})
job=t('fabric_job.py').lower(); ck('delta implementation', 'delta' in job); ck('merge implementation', 'merge' in job and 'sale_id' in job); ck('medallion', all(x in job for x in ['bronze','silver','gold']))
sql=t('queries.sql').lower(); ck('read-only sql', 'select' in sql and not any(x in sql for x in ['delete ','drop ','truncate ','update '])); ck('sql controls','count' in sql and 'sum' in sql and 'region' in sql)
p=json.loads(t('pipeline_plan.json')); acts=p.get('activities',[]); ck('pipeline has 3 stages',len(acts)>=3); ck('pipeline parameter','run_date' in p.get('parameters',[])); ck('no embedded secret','password' not in json.dumps(p).lower() and 'token' not in json.dumps(p).lower()); ck('secret policy', any(x in p.get('secret_policy','').lower() for x in ['managed','secret','connection']))
reason=t('reasoning.md').lower(); ck('least privilege reasoning','least privilege' in reason); ck('rerun reasoning','rerun' in reason or 'idempot' in reason); ck('monitoring/freshness', 'monitor' in reason and 'fresh' in reason); ck('cost reasoning','cost' in reason); ck('recovery reasoning','recover' in reason or 'failure' in reason)
ev=t('runtime_evidence.md').lower(); ck('runtime evidence section', len(ev)>100 and 'fabric' in ev)
# secret scan
alltext='\n'.join(p.read_text(errors='ignore') for p in B.iterdir() if p.is_file() and p.suffix in {'.py','.md','.json','.sql'})
ck('no real-looking secret assignment', re.search(r'(?i)(password|token|secret)\s*=\s*["\'][A-Za-z0-9+/=_-]{12,}',alltext) is None)
for n,c in checks: print(('PASS' if c else 'FAIL'),n)
print(f'{sum(c for _,c in checks)}/{len(checks)} passed'); sys.exit(0 if all(c for _,c in checks) else 1)
