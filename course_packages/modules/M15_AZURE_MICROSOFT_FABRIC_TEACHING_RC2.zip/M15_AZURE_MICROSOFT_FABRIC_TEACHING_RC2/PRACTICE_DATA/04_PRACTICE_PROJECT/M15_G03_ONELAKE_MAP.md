# G03 OneLake / Lakehouse map
Raw source -> `Files/raw/sales/` (preserved).
Bronze/Silver/Gold -> registered Delta tables under the lakehouse Tables experience.
A trusted customer master owned elsewhere should be evaluated for a shortcut/shared governed access before copying.
A raw CSV in Files is not automatically a managed SQL table.
