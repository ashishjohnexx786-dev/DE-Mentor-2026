# Run in a Fabric notebook attached to the course lakehouse.
from pyspark.sql import functions as F
raw = spark.read.option("header", True).option("inferSchema", True).csv("Files/raw/sales/sales_history.csv")
print("RAW_ROWS", raw.count())
(raw.write.format("delta").mode("overwrite").saveAsTable("bronze_sales"))
print("BRONZE_ROWS", spark.table("bronze_sales").count())
