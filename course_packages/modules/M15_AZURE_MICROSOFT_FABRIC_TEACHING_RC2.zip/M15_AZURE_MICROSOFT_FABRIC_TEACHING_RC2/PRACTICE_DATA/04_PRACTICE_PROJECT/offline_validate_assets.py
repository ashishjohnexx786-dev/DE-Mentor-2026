from pathlib import Path
import json, re, subprocess, sys
B=Path(__file__).parent
checks=[]
def ck(name,cond): checks.append((name,bool(cond)))
def text(name): return (B/name).read_text(encoding='utf-8')
ck('G01 requirements before services', all(x in text('M15_G01_CLOUD_DECISION.md').lower() for x in ['sla','sensitivity','cost']))
j=json.loads(text('M15_G02_WORKSPACE_ITEMS.json')); ck('G02 no broad admin', all(not x.get('admin') for x in j['identity_matrix'])); ck('G02 secret rule', 'no real' in j['secret_rule'].lower())
ck('G03 Files vs Tables', all(x in text('M15_G03_ONELAKE_MAP.md') for x in ['Files/raw','Delta','not automatically']))
g4=text('M15_G04_LAKEHOUSE_IO.py'); ck('G04 Delta write', 'format("delta")' in g4 and 'saveAsTable("bronze_sales")' in g4)
g5=text('M15_G05_SPARK_TRANSFORM.py'); ck('G05 Silver validity', all(x in g5 for x in ['amount','>= 0','region','silver_sales'])); ck('G05 Gold aggregate', 'groupBy("region")' in g5 and 'gold_sales_by_region' in g5)
sql=text('M15_G06_SQL_ENDPOINT.sql').lower(); ck('G06 read only', 'select' in sql and not any(x in sql for x in ['delete ','drop ','truncate ','update '])); ck('G06 reconciliation', 'sum(amount)' in sql and 'count(distinct sale_id)' in sql)
p=json.loads(text('M15_G07_PIPELINE_PLAN.json')); names=[a['name'] for a in p['activities']]; ck('G07 dependencies', names==['copy_raw','transform_notebook','validate_controls'] and p['activities'][1]['depends_on']==['copy_raw']); ck('G07 parameter', 'run_date' in p['parameters']); ck('G07 secret policy', 'do not embed' in p['secret_policy'].lower())
g8=text('M15_G08_MEDALLION_INCREMENTAL.py'); ck('G08 MERGE', '.merge(' in g8 and 'sale_id' in g8 and 'whenMatchedUpdateAll' in g8 and 'whenNotMatchedInsertAll' in g8); ck('G08 deterministic dedupe', 'row_number' in g8 and 'partitionBy("sale_id")' in g8)
g9=text('M15_G09_SECURITY_MONITORING.md').lower(); ck('G09 monitoring evidence', all(x in g9 for x in ['run id','loaded rows','rejected rows','freshness','cost'])); ck('G09 least privilege', 'read gold only' in g9 and 'no workspace admin' in g9)
g10=text('M15_G10_END_TO_END_RUNBOOK.md').lower(); ck('G10 end to end', all(x in g10 for x in ['bronze','silver','gold','incremental','replay','failure','least privilege'])); ck('G10 cross cloud', all(x in g10 for x in ['s3','cloud storage','redshift','bigquery']))
from offline_cloud_simulator import simulate
r=simulate(); ck('offline final row count',r['silver_rows']==6); ck('offline total',abs(r['total_amount']-930)<1e-9); ck('offline region totals',r['region_totals']=={'North':300.0,'South':230.0,'West':90.0,'East':310.0})
for n,c in checks: print(('PASS' if c else 'FAIL'),n)
print(f'{sum(c for _,c in checks)}/{len(checks)} passed')
sys.exit(0 if all(c for _,c in checks) else 1)
