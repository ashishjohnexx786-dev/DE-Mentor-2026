from pathlib import Path
import csv, json
BASE=Path(__file__).parent
def read(name):
    with open(BASE/'data'/name,newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def valid(r):
    try: return bool(r['sale_id'] and r['region'] and float(r['amount'])>=0)
    except: return False
def simulate():
    base={r['sale_id']:r for r in read('sales_history.csv') if valid(r)}
    for r in read('sales_incremental.csv'):
        if valid(r): base[r['sale_id']]=r
    total=sum(float(r['amount']) for r in base.values())
    by={}
    for r in base.values(): by[r['region']]=by.get(r['region'],0)+float(r['amount'])
    return {'silver_rows':len(base),'distinct_sale_ids':len(base),'total_amount':total,'region_totals':by}
if __name__=='__main__': print(json.dumps(simulate(),indent=2,sort_keys=True))
