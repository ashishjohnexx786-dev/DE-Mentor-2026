# G10 End-to-end Fabric runbook
1. Land immutable raw input.
2. Create Bronze Delta.
3. Validate and build Silver.
4. Build Gold consumer output.
5. Run SQL endpoint reconciliation.
6. Apply incremental batch with deterministic MERGE.
7. Replay the same batch and prove stable key count/total.
8. Inject one safe schema/quality failure and record run/error evidence before repair.
9. Confirm least privilege and monitoring evidence.
10. Translate concepts: OneLake/ADLS ~ S3/Cloud Storage; Fabric Spark ~ managed Spark/Databricks; Fabric Warehouse ~ Redshift/BigQuery conceptually; Fabric Pipelines ~ managed orchestration/data movement. Exact features are not identical.
