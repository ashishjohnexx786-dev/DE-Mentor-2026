# G01 Cloud responsibility map
Workload: 20 GB nightly internal sales batch; daily SLA.
Learner: separate business requirements from service choices. Record SLA, data sensitivity, storage, compute, identity, monitoring, recovery, and cost responsibilities. Microsoft manages service infrastructure; the data team still owns data correctness, configuration, permissions, monitoring, recovery design, and cost decisions.
Transfer: state what changes if the data becomes regulated.
