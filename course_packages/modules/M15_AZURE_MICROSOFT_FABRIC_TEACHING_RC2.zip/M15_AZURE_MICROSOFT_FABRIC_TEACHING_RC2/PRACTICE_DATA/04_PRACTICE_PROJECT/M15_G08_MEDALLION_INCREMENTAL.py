# Fabric/Delta notebook pattern. Apply deterministic precedence before MERGE.
from delta.tables import DeltaTable
from pyspark.sql import functions as F, Window
updates = spark.read.option("header", True).option("inferSchema", True).csv("Files/raw/sales/sales_incremental.csv")
valid = updates.filter(F.col("sale_id").isNotNull() & F.col("region").isNotNull() & (F.col("amount") >= 0))
w = Window.partitionBy("sale_id").orderBy(F.col("sale_date").desc())
deduped = valid.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")
target = DeltaTable.forName(spark, "silver_sales")
(target.alias("t").merge(deduped.alias("s"), "t.sale_id = s.sale_id")
 .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute())
print("DISTINCT_IDS", spark.table("silver_sales").select("sale_id").distinct().count())
