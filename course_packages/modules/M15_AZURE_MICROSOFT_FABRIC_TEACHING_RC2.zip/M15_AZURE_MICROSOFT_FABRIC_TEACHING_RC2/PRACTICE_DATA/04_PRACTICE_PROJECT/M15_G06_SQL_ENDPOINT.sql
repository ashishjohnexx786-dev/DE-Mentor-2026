-- Read-only validation queries for the Lakehouse SQL analytics endpoint.
SELECT COUNT(*) AS silver_rows FROM dbo.silver_sales;
SELECT COUNT(DISTINCT sale_id) AS distinct_sales, SUM(amount) AS total_amount FROM dbo.silver_sales;
SELECT region, COUNT(DISTINCT sale_id) AS sales_count, SUM(amount) AS total_amount FROM dbo.silver_sales GROUP BY region ORDER BY region;
