from pyspark.sql import functions as F
bronze = spark.table("bronze_sales")
# Explicit validity rule: required id/region and non-negative amount.
silver = bronze.filter(F.col("sale_id").isNotNull() & F.col("region").isNotNull() & (F.col("amount") >= 0))
(silver.write.format("delta").mode("overwrite").saveAsTable("silver_sales"))
gold = silver.groupBy("region").agg(F.countDistinct("sale_id").alias("sales_count"), F.sum("amount").alias("total_amount"))
(gold.write.format("delta").mode("overwrite").saveAsTable("gold_sales_by_region"))
print("SILVER_ROWS", silver.count())
print("GOLD_ROWS", gold.count())
