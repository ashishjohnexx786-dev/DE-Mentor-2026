# G09 Security + monitoring
Identity matrix: analyst = read Gold only; pipeline identity = only required source/raw/table actions; no workspace admin by default.
Evidence to save from a real run: workspace/item, run ID, status, duration, source rows, loaded rows, rejected rows, freshness timestamp, and one measured cost/performance hypothesis.
Never store a real token/password in notebook source, JSON or Git.
