M15 Azure / Microsoft Fabric for Data Engineering TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf
Cloud access is optional for core conceptual mastery. Use the supplied offline Fabric simulator/assets first. If you have Fabric access, collect live runtime evidence separately; do not buy/activate paid capacity merely because a lesson says Fabric.
Fabric UI/capabilities can evolve. The book focuses on transferable concepts and the supplied project records simulated vs live evidence separately.
