M04 CURRENT LEARNER BOOK - RC5 POST-DEPLOY SEMANTIC REPAIR

The 2026-09-11 RC5 learner book supersedes the RC4 learner-book semantic acceptance.
Use 01_LESSONS first. It now follows the explicit 16-stage beginner-first teacher route and makes external source links visibly discoverable.
All protected review / fresh retry rules remain attempt-first. Whole-course FINAL still requires runtime/device evidence.

--- Historical module instructions retained below ---

ZERO TO JOB-READY DATA ENGINEER 2026 - M04 PYTHON FOUNDATIONS - CANONICAL MODULE FREEZE

COUNT: 16 formal lessons, DE04-01 through DE04-16.
STUDY LOOP: VIDEO FIRST -> CLOSE VIDEO -> SOLO TEACHING BOOK -> GUIDED REPRODUCTION -> INDEPENDENT TASK -> VALIDATE -> EXPLAIN IN YOUR OWN WORDS -> PROTECTED REVIEW ONLY AFTER A SAVED ATTEMPT -> FRESH CHANGED RETRY IF WEAK -> EVIDENCE / MASTERY
SETUP: Python first use belongs to M04. Python stable baseline verified 2026-09-10: 3.14.7. pandas is first required at DE04-11; stable baseline verified 2026-09-10: 3.0.5. WSL + Git remain M06.
ASSESSMENT: review is attempt-gated; fresh retests are changed tasks; failed attempts are preserved; module-practical pass is competency-based, not percentage-inferred.
MENTOR: per-module route/state contract is included, but the live standalone Mentor will be rebuilt only after whole-course content freeze.
STATUS: MODULE FREEZE QA PASS. Not whole-course FINAL. Whole-course runtime/device/browser/cache/source audit remains mandatory.
