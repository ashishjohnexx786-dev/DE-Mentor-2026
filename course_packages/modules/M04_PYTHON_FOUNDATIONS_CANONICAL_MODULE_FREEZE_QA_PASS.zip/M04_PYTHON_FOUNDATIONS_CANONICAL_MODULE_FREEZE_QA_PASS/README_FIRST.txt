ZERO TO JOB-READY DATA ENGINEER 2026 - M04 PYTHON FOUNDATIONS - CANONICAL MODULE FREEZE

COUNT: 16 formal lessons, DE04-01 through DE04-16.
STUDY LOOP: VIDEO FIRST -> CLOSE VIDEO -> SOLO TEACHING BOOK -> GUIDED REPRODUCTION -> INDEPENDENT TASK -> VALIDATE -> EXPLAIN IN YOUR OWN WORDS -> PROTECTED REVIEW ONLY AFTER A SAVED ATTEMPT -> FRESH CHANGED RETRY IF WEAK -> EVIDENCE / MASTERY
SETUP: Python first use belongs to M04. Python stable baseline verified 2026-09-10: 3.14.7. pandas is first required at DE04-11; stable baseline verified 2026-09-10: 3.0.5. WSL + Git remain M06.
ASSESSMENT: review is attempt-gated; fresh retests are changed tasks; failed attempts are preserved; module-practical pass is competency-based, not percentage-inferred.
MENTOR: per-module route/state contract is included, but the live standalone Mentor will be rebuilt only after whole-course content freeze.
STATUS: MODULE FREEZE QA PASS. Not whole-course FINAL. Whole-course runtime/device/browser/cache/source audit remains mandatory.
