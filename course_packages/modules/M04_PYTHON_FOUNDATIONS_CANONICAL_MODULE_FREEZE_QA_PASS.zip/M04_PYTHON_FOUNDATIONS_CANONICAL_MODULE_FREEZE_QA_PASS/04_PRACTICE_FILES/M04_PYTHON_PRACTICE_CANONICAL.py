# M04 PYTHON FOUNDATIONS - CANONICAL PRACTICE WORKSPACE
# Save each genuine attempt before opening the matching protected review.
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RETAIL = ROOT / "M04_RETAIL_ORDERS_CANONICAL.csv"
RETEST = ROOT / "M04_RETEST_SHIPMENTS_CANONICAL.csv"

# DE04-01..DE04-12: create clearly labelled sections below or separate p01..p12 files.
# DE04-13/14: use M04_CODING_DRILLS_CANONICAL.py + visible tests.
# DE04-15: add stack/queue/search/sort work below.
# DE04-16: use ../05_MODULE_PRACTICAL/M04_CHECKPOINT_TODO.py.

# IMPORTANT: do not overwrite a failed first attempt with the repaired version.
