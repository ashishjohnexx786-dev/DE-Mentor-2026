"""DE04-08 helper module - complete the TODOs during the guided lab."""

def gross_sales(qty, unit_price):
    # TODO: return qty * unit_price
    raise NotImplementedError("Complete gross_sales")

def order_label(order_id, region):
    # TODO: return a stable label such as "O1 | East"
    raise NotImplementedError("Complete order_label")
