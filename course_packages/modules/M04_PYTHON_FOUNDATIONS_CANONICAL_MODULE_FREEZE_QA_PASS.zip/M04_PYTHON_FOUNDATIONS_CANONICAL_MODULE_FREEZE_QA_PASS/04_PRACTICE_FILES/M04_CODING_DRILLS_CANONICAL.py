# DE04-13/14/15 CODING DRILLS - NO SOLUTIONS BEFORE A SAVED ATTEMPT

def reverse_words(text):
    """Return words in reverse order; define/document extra-space behavior."""
    raise NotImplementedError

def count_vowels(text):
    """Return count of a/e/i/o/u, case-insensitive."""
    raise NotImplementedError

def word_counts(text):
    """Return a case-insensitive word-frequency dictionary."""
    raise NotImplementedError

def first_duplicate(ids):
    """Return first ID encountered for the second time, else None."""
    raise NotImplementedError

def sales_by_region(rows):
    """Rows contain region and sales; return totals by region."""
    raise NotImplementedError

def linear_search(values, target):
    """Return first matching index, else -1."""
    raise NotImplementedError
