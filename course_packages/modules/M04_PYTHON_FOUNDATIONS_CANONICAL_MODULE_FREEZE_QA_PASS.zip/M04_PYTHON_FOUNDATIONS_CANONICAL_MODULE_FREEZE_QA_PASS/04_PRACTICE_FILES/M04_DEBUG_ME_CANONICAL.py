# DE04-09 DEBUGGING LAB - intentionally broken input behavior.
orders = [
    {"id": "O1", "qty": 2, "price": 850},
    {"id": "O2", "qty": "3", "price": 450},
    {"id": "O3", "qty": 5, "price": None},
]

def order_sales(order):
    return order["qty"] * order["price"]

total = 0
for order in orders:
    total += order_sales(order)

print("Total sales:", total)

# 1) Run unchanged and SAVE the first traceback.
# 2) Fix one failure at a time.
# 3) Decide explicitly how missing price is handled; never silently guess.
# 4) Keep valid input working and expected invalid input visible.
