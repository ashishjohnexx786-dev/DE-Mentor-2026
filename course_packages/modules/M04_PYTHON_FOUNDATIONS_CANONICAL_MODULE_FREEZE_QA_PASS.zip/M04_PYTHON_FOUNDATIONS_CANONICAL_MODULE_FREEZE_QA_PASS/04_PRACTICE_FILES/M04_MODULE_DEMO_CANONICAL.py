from stage04_helpers import gross_sales, order_label

print(order_label("O2001", "East"))
print(gross_sales(2, 850))
