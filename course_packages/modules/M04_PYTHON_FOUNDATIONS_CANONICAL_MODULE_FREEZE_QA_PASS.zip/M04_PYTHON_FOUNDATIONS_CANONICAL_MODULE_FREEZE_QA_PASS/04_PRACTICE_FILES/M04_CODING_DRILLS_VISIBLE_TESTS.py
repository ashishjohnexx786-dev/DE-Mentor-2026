# Visible contract tests. These do not reveal implementations.
from M04_CODING_DRILLS_CANONICAL import (reverse_words, count_vowels, word_counts, first_duplicate, sales_by_region, linear_search)

def run():
    assert reverse_words("data moves fast") == "fast moves data"
    assert count_vowels("Data Engineering") == 7
    assert word_counts("East west EAST") == {"east": 2, "west": 1}
    assert first_duplicate(["A","B","C","B","B"]) == "B"
    assert first_duplicate(["A","B"]) is None
    assert sales_by_region([{"region":"East","sales":10},{"region":"West","sales":5},{"region":"East","sales":7}]) == {"East":17,"West":5}
    assert linear_search([4,9,2],9) == 1
    assert linear_search([4,9,2],7) == -1
    print("VISIBLE TESTS PASS")

if __name__ == "__main__":
    run()
