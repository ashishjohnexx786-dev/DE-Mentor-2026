# DE04-16 FRESH CHANGED CHECKPOINT - use only if assigned after Review R16.
from pathlib import Path
import json

REQUIRED_COLUMNS = {"shipment_id","ship_date","hub","category","cartons","unit_cost","status","coordinator"}

def load_and_validate(path: Path):
    raise NotImplementedError

def build_delivered_summary(data):
    # TODO: shipment_value, Delivered-only hub totals, top 3, missing coordinator.
    raise NotImplementedError

def write_summary(summary, output_path: Path):
    raise NotImplementedError

def main():
    pass

if __name__ == "__main__":
    main()
