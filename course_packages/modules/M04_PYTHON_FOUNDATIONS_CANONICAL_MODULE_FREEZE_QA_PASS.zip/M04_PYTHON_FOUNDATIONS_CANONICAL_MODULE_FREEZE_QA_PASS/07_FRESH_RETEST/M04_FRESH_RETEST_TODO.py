# M04 TARGETED FRESH RETEST WORKSPACE
# Use only the changed competency assigned after review. Preserve the first attempt separately.

# DE04-13 example assigned task: implement normalize_words(text).
# DE04-14 example assigned tasks: implement count_statuses(values) and unique_repeated_batch_ids(values).
# Other lesson-specific changed prompts are in M04_FRESH_RETEST_CANONICAL.pdf.
