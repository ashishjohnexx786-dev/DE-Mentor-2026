# M04 MODULE PRACTICAL - FIRST ATTEMPT
# Keep protected Review R16 closed until this attempt and evidence are saved.
from pathlib import Path
import json

REQUIRED_COLUMNS = {"order_id","order_date","region","product","qty","unit_price","status","sales_rep"}

def load_and_validate(path: Path):
    # TODO: load the CSV, prove required columns exist, return your data object.
    raise NotImplementedError

def build_completed_summary(data):
    # TODO: calculate sales, filter Completed, regional totals, top 3, missing sales_rep.
    raise NotImplementedError

def write_summary(summary, output_path: Path):
    # TODO: deterministic JSON; do not overwrite raw input.
    raise NotImplementedError

def main():
    # TODO: wire functions, print useful run evidence, fail clearly on bad input.
    pass

if __name__ == "__main__":
    main()
