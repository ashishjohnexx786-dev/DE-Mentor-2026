# DE19-02 Guided - GitHub and project portfolio final polish

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Pinned repo -> README -> architecture -> setup -> test/evidence -> failure/recovery -> limitations.

## Follow once
Teacher example only: audit a sample repo and mark one missing setup step, one weak evidence link and one secret-risk item. Repair the navigation, not the project with fake screenshots.

## Expected result
A completed portfolio audit with concrete repairs and a clear order for which repos should be public/pinned.

## Validation
README route works from clean state; architecture and evidence are findable; no secret/PII leakage; claims match real runtime/static truth.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-02.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
