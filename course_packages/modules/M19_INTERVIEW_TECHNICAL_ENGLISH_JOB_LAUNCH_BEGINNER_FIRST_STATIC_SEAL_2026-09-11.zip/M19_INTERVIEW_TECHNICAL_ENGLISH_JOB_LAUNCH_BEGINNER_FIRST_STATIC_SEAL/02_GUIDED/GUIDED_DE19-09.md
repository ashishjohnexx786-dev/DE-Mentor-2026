# DE19-09 Guided - Architecture/system-design defense for junior roles

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Requirements -> scale/latency -> source contracts -> storage/compute -> orchestration -> correctness -> security -> observability -> failure modes -> cost/operability.

## Follow once
Teacher example only: start batch-first for a daily reporting SLA; add streaming only when the urgent-event SLA actually requires it.

## Expected result
A requirements-led diagram/decision narrative with failure modes, controls, trade-offs and revisit triggers.

## Validation
Every major component maps to a requirement; batch/stream split is justified; correctness/security/recovery are covered; at least one simpler alternative is discussed.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-09.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
