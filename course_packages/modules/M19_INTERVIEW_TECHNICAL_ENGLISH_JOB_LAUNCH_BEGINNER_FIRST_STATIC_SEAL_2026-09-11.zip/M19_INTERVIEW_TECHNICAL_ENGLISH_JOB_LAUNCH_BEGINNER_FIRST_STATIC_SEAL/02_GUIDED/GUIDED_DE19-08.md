# DE19-08 Guided - Project walkthrough interview

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Problem -> sources -> architecture -> grain -> quality -> idempotency -> orchestration -> failure/recovery -> security -> limitations -> 10x change.

## Follow once
Teacher example only: give a 90-second mini walkthrough of one architecture diagram, then answer "what can fail?" with evidence and recovery rather than buzzwords.

## Expected result
A concise project defense with evidence pointers and honest limitations, followed by changed-project retest.

## Validation
All 10 defense categories are covered; technical claims point to evidence; one failure/recovery and one limitation are explicit; runtime truth is honest.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-08.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
