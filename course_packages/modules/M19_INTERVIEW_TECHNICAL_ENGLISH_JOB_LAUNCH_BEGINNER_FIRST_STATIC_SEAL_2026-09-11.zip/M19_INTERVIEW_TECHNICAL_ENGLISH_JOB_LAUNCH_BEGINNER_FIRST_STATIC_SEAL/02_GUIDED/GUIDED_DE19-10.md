# DE19-10 Guided - Behavioral answers and career-transition story

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Context -> responsibility -> action -> result -> verification -> reflection.

## Follow once
Teacher example only: turn "I struggled with SQL" into a specific learning/repair story with a failed query, diagnosis, changed practice and later proof - without claiming employment.

## Expected result
A small story bank you can deliver naturally, including a truthful non-tech-to-DE transition explanation.

## Validation
Stories are factual; responsibility is clear; action contains decisions; result/verification is concrete; reflection is specific; no invented employment.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-10.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
