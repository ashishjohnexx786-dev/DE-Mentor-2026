# DE19-11 Guided - Technical English: explain code, failures and decisions clearly

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Object -> change -> why -> check -> failure risk.

## Follow once
Teacher example only: explain a LEFT JOIN in plain English before using "cardinality"; then add one validation sentence about row counts.

## Expected result
Short recorded explanations that are technically correct, structured and understandable without reading.

## Validation
Listener can identify object/change/reason/check/risk; technical meaning is correct; correction is calm; no reading from script.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-11.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
