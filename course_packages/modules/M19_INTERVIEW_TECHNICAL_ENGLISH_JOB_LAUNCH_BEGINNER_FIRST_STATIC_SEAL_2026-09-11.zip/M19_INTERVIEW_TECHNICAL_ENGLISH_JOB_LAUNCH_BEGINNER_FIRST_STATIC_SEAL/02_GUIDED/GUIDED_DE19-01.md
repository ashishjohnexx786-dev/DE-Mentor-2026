# DE19-01 Guided - Truthful one-page Data Engineer resume

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Evidence -> action -> system -> validation/result.

## Follow once
Teacher example only: take an inflated bullet such as "Built enterprise-scale pipelines". Narrow it to the exact project, technology and proof you actually have. Keep internal evidence tags until the claim survives checking.

## Expected result
A truthful one-page draft. Each technical bullet has an internal evidence path and executed/measured status before the internal tags are removed.

## Validation
Every technical claim maps to evidence; no fake employment/degree/certification; strongest bullets can be defended in under 60 seconds.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-01.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
