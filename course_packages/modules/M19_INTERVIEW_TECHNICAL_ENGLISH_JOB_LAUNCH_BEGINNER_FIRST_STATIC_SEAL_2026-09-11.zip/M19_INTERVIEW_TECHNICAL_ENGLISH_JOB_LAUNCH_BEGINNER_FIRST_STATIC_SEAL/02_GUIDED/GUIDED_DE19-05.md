# DE19-05 Guided - SQL interview drills

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Question -> state grain -> write query -> inspect duplicates/nulls -> independent count/total -> explain trade-off.

## Follow once
Teacher example only: before typing a top-2-per-region query, say "one row per selected order" and choose a deterministic tie-breaker.

## Expected result
Timed SQL answers plus a one-line grain statement and at least one independent validation for each important result.

## Validation
Queries answer intended grain; join/window behavior is explainable; important counts/totals reconcile; tie handling is deterministic.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-05.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
