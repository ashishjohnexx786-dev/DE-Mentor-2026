# DE19-12 Guided - Application tracker, feedback loop and weekly repair cycle

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Targeted role -> truthful application -> screen -> assessment -> technical -> final -> offer -> diagnose stage -> one repair experiment.

## Follow once
Teacher example only: if screens are strong but assessments fail, changing the resume is not the first experiment; practice the assessment competency and compare the next batch.

## Expected result
An application tracker plus weekly review rule that produces one evidence-based experiment rather than many simultaneous changes.

## Validation
Stage data is honest; bottleneck is derived from evidence; experiment targets that stage; success criterion is stated before the next batch.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-12.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
