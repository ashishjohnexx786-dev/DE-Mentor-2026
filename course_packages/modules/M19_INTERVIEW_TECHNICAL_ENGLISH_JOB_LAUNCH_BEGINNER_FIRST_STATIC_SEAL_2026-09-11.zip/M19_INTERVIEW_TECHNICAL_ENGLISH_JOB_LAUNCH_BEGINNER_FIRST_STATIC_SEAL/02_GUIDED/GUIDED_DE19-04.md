# DE19-04 Guided - Degree-aware job targeting: apply/skip rules

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
APPLY when core work matches and hard requirements are met; MAYBE when gaps are preferred/trainable; SKIP when a clear hard gate excludes you.

## Follow once
Teacher example only: compare two postings with identical stacks where one says "degree preferred" and the other says "B.Tech required". The classification can change even though the technologies do not.

## Expected result
A repeatable classification method and a tracker that records why each role was applied to, held for review or skipped.

## Validation
Each decision quotes/paraphrases a requirement; no invented eligibility; core job work matches your demonstrated stack for APPLY roles.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-04.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
