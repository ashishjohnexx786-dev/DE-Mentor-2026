# DE19-07 Guided - Data-engineering concepts and troubleshooting drills

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Symptom -> blast radius -> first evidence -> likely layer -> smallest safe test -> repair -> rerun boundary -> reconciliation -> prevention.

## Follow once
Teacher example only: DAG is green but mart total is low. Check source arrival/stage counts/filter boundaries before clearing state or rerunning everything.

## Expected result
Structured incident answers that name evidence, hypothesis, safe diagnostic, repair boundary, validation and prevention.

## Validation
Diagnosis starts from evidence; safe test is bounded; repair matches likely cause; rerun boundary is explicit; output is reconciled; prevention is plausible.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-07.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
