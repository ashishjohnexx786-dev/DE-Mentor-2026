# DE19-14 Guided - Combined SQL + Python interview simulation

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Save first attempt -> classify misses -> protected review -> targeted repair -> close review -> changed mixed mock -> defend without notes.

## Follow once
Teacher example only: after a SQL miss caused by join multiplication, repair cardinality reasoning and test it on changed tables; do not simply rerun the same answer.

## Expected result
A complete first mixed attempt, diagnosis, targeted repairs where needed, and a changed mixed retest with no unresolved critical failure.

## Validation
First evidence is preserved; each miss has a diagnosis; changed retest is genuinely different; SQL/Python/troubleshooting/project explanation are independently usable; no critical failure remains.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-14.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
