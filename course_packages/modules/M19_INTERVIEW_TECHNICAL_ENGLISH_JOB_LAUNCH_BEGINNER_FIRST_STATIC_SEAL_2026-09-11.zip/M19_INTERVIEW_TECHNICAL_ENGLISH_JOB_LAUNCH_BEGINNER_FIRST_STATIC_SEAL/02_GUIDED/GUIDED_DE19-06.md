# DE19-06 Guided - Python interview drills

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Input contract -> transform -> explicit failure path -> deterministic output -> edge-case tests -> practical complexity.

## Follow once
Teacher example only: parse three tiny records, deliberately include one malformed numeric, and choose whether to reject/quarantine rather than silently converting it.

## Expected result
Readable functions with explicit invalid-input behavior and small tests for happy, malformed, duplicate and empty cases where relevant.

## Validation
Functions behave deterministically; invalid values are handled explicitly; edge cases are tested; you can explain code and practical complexity.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-06.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
