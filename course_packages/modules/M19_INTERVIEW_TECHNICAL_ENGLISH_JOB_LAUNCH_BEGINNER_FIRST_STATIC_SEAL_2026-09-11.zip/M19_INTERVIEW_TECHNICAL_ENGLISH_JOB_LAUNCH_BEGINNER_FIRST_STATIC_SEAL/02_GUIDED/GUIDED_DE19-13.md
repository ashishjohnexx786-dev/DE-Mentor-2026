# DE19-13 Guided - Timed coding test: arrays, strings and hash-map problems

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Restate contract -> examples -> choose data structure -> implement -> edge cases -> complexity -> verbal explanation.

## Follow once
Teacher example only: count characters with a dictionary, then explain why one pass plus lookups is clearer than nested scans.

## Expected result
Working solutions to the packaged tasks from a blank file plus explanations of data structure and practical complexity.

## Validation
Correct outputs on normal and edge cases; deterministic behavior where ties exist; complexity explanation is reasonable; code can be explained without notes.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-13.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
