# DE19-03 Guided - LinkedIn/professional profile without overclaiming

Purpose: follow one small reasoning pattern with support. This is not a final answer to copy.

## CREATE vs FILL
FILL the supplied practice asset and CREATE your learner-owned output.

## Teacher pattern
Target role + defensible stack + strongest proof + current availability.

## Follow once
Teacher example only: replace an inflated title such as "Data Engineer | 3 years" with role-target wording that does not imply employment you did not have.

## Expected result
A headline, About draft and Featured plan that are coherent, specific and defensible.

## Validation
No invented title/employment/years; stack names match demonstrated work; strongest proof is one click away; wording can be spoken naturally.

## Exact route
After the guided pass, close this file. Open `03_INDEPENDENT/INDEPENDENT_DE19-03.md`. Save a genuine first attempt in the lesson evidence folder before protected Review.
