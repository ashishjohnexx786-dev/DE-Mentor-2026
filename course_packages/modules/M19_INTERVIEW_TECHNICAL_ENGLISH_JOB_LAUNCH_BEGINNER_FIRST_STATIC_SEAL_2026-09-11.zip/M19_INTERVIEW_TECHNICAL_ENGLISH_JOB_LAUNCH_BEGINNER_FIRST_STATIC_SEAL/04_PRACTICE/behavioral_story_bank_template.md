# Behavioral story bank

For each story: Context | Responsibility | Action | Result | Verification | Reflection

## Story 1
Context:
Responsibility:
Action:
Result:
Verification:
Reflection:
