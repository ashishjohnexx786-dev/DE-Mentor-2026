# DE19-11 Independent - Technical English: explain code, failures and decisions clearly

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Use `technical_english_recording_log.csv` to record several 60-120 second explanations; note one repair after listening back.

## Expected result
Short recorded explanations that are technically correct, structured and understandable without reading.

## Validate independently
Listener can identify object/change/reason/check/risk; technical meaning is correct; correction is calm; no reading from script.

## Evidence rule
Copy `07_EVIDENCE/DE19-11/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
