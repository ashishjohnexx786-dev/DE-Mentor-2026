# DE19-01 Independent - Truthful one-page Data Engineer resume

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Use your own M18 evidence and `resume_evidence_map.csv` to draft the resume. Do not copy the teacher example as your final wording.

## Expected result
A truthful one-page draft. Each technical bullet has an internal evidence path and executed/measured status before the internal tags are removed.

## Validate independently
Every technical claim maps to evidence; no fake employment/degree/certification; strongest bullets can be defended in under 60 seconds.

## Evidence rule
Copy `07_EVIDENCE/DE19-01/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
