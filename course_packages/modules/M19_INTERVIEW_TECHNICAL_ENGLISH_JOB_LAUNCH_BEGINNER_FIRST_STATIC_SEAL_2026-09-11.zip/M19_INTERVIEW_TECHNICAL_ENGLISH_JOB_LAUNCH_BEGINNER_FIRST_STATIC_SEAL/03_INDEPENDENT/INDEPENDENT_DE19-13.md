# DE19-13 Independent - Timed coding test: arrays, strings and hash-map problems

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Complete `coding_mock_a.py` closed-book, then do the changed retest from a blank file.

## Expected result
Working solutions to the packaged tasks from a blank file plus explanations of data structure and practical complexity.

## Validate independently
Correct outputs on normal and edge cases; deterministic behavior where ties exist; complexity explanation is reasonable; code can be explained without notes.

## Evidence rule
Copy `07_EVIDENCE/DE19-13/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
