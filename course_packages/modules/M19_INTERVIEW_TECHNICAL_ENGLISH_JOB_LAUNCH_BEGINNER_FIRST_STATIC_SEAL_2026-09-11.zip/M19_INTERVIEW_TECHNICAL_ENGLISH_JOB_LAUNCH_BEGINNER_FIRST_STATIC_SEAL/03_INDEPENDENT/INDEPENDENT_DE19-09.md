# DE19-09 Independent - Architecture/system-design defense for junior roles

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Solve `system_design_scenario.md` from blank notes; then defend the changed ClinicBridge retest scenario without copying the first boxes.

## Expected result
A requirements-led diagram/decision narrative with failure modes, controls, trade-offs and revisit triggers.

## Validate independently
Every major component maps to a requirement; batch/stream split is justified; correctness/security/recovery are covered; at least one simpler alternative is discussed.

## Evidence rule
Copy `07_EVIDENCE/DE19-09/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
