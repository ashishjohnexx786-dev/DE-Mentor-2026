# DE19-12 Independent - Application tracker, feedback loop and weekly repair cycle

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Fill `application_funnel.csv` and `job_targeting_tracker.csv` with a simulated or real batch, clearly labeling simulation if no applications have yet been sent.

## Expected result
An application tracker plus weekly review rule that produces one evidence-based experiment rather than many simultaneous changes.

## Validate independently
Stage data is honest; bottleneck is derived from evidence; experiment targets that stage; success criterion is stated before the next batch.

## Evidence rule
Copy `07_EVIDENCE/DE19-12/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
