# DE19-10 Independent - Behavioral answers and career-transition story

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Use `behavioral_prompts.md` and `behavioral_story_bank_template.md` to prepare at least five distinct truthful stories.

## Expected result
A small story bank you can deliver naturally, including a truthful non-tech-to-DE transition explanation.

## Validate independently
Stories are factual; responsibility is clear; action contains decisions; result/verification is concrete; reflection is specific; no invented employment.

## Evidence rule
Copy `07_EVIDENCE/DE19-10/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
