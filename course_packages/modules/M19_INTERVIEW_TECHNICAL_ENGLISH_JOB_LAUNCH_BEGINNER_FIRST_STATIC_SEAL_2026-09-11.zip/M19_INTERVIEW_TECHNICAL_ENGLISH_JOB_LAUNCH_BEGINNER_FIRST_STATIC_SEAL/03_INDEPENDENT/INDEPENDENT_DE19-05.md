# DE19-05 Independent - SQL interview drills

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Complete `sql_mock_questions.md` against `sql_mock_setup.sql` closed-book; save SQL, outputs and validation notes.

## Expected result
Timed SQL answers plus a one-line grain statement and at least one independent validation for each important result.

## Validate independently
Queries answer intended grain; join/window behavior is explainable; important counts/totals reconcile; tie handling is deterministic.

## Evidence rule
Copy `07_EVIDENCE/DE19-05/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
