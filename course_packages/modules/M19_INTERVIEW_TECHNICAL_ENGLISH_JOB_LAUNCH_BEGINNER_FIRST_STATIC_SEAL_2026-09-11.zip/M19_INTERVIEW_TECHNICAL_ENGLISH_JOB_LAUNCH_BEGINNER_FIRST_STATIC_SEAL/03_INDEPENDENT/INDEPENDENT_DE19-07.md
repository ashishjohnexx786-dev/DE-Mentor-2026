# DE19-07 Independent - Data-engineering concepts and troubleshooting drills

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Work through `troubleshooting_drills.md`; write the first three evidence checks before proposing any destructive action.

## Expected result
Structured incident answers that name evidence, hypothesis, safe diagnostic, repair boundary, validation and prevention.

## Validate independently
Diagnosis starts from evidence; safe test is bounded; repair matches likely cause; rerun boundary is explicit; output is reconciled; prevention is plausible.

## Evidence rule
Copy `07_EVIDENCE/DE19-07/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
