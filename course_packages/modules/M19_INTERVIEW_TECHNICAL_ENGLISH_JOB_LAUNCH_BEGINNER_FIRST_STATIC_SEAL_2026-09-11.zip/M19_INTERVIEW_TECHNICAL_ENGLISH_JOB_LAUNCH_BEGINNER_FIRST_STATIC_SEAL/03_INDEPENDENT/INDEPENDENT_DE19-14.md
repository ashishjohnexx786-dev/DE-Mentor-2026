# DE19-14 Independent - Combined SQL + Python interview simulation

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Run `combined_mock_b.md` under its time box, then create/use the changed DE19-14 retest without reusing first answers.

## Expected result
A complete first mixed attempt, diagnosis, targeted repairs where needed, and a changed mixed retest with no unresolved critical failure.

## Validate independently
First evidence is preserved; each miss has a diagnosis; changed retest is genuinely different; SQL/Python/troubleshooting/project explanation are independently usable; no critical failure remains.

## Evidence rule
Copy `07_EVIDENCE/DE19-14/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
