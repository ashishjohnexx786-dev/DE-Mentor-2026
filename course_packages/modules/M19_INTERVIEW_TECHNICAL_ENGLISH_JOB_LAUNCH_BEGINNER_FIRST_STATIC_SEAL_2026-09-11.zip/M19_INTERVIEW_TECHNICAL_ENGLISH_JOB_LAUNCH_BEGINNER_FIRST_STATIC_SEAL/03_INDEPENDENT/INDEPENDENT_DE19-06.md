# DE19-06 Independent - Python interview drills

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Complete `python_mock.py` from blank implementations. Add your own small assertions/examples and save first failure before repair.

## Expected result
Readable functions with explicit invalid-input behavior and small tests for happy, malformed, duplicate and empty cases where relevant.

## Validate independently
Functions behave deterministically; invalid values are handled explicitly; edge cases are tested; you can explain code and practical complexity.

## Evidence rule
Copy `07_EVIDENCE/DE19-06/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
