# DE19-03 Independent - LinkedIn/professional profile without overclaiming

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Create your profile draft in `professional_profile_draft_template.md`; tie the Featured section to strongest M18 evidence.

## Expected result
A headline, About draft and Featured plan that are coherent, specific and defensible.

## Validate independently
No invented title/employment/years; stack names match demonstrated work; strongest proof is one click away; wording can be spoken naturally.

## Evidence rule
Copy `07_EVIDENCE/DE19-03/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
