# DE19-04 Independent - Degree-aware job targeting: apply/skip rules

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Classify a set of roles in `job_targeting_tracker.csv`; document the exact apply/skip reason rather than "good/bad fit".

## Expected result
A repeatable classification method and a tracker that records why each role was applied to, held for review or skipped.

## Validate independently
Each decision quotes/paraphrases a requirement; no invented eligibility; core job work matches your demonstrated stack for APPLY roles.

## Evidence rule
Copy `07_EVIDENCE/DE19-04/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
