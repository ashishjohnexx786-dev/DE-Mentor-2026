# DE19-02 Independent - GitHub and project portfolio final polish

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Audit P01/P02/P03/CAP using `project_portfolio_audit.csv`; repair failed items before calling a repo portfolio-ready.

## Expected result
A completed portfolio audit with concrete repairs and a clear order for which repos should be public/pinned.

## Validate independently
README route works from clean state; architecture and evidence are findable; no secret/PII leakage; claims match real runtime/static truth.

## Evidence rule
Copy `07_EVIDENCE/DE19-02/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
