# DE19-08 Independent - Project walkthrough interview

Changed task: use your own evidence or the packaged changed scenario. Guided and Review stay closed.

## Task
Use `project_defense_questions.md` on your strongest M18 project; record or write answers without the project book open.

## Expected result
A concise project defense with evidence pointers and honest limitations, followed by changed-project retest.

## Validate independently
All 10 defense categories are covered; technical claims point to evidence; one failure/recovery and one limitation are explicit; runtime truth is honest.

## Evidence rule
Copy `07_EVIDENCE/DE19-08/attempt_template.json` to `attempt.json` only when you actually start. Preserve the first attempt. If weak, open only the matching Review page after saving evidence.

## Critical failure rule
Fabricated claims/evidence, copied protected answers presented as your work, unsafe destructive technical advice, or an unresolved lesson-specific critical error blocks mastery.
