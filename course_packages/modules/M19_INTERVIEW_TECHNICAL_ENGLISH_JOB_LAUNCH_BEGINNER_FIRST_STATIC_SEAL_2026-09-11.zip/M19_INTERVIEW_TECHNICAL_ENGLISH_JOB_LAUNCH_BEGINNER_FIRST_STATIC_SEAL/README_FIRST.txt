M19 - INTERVIEW / TECHNICAL ENGLISH / JOB LAUNCH - BEGINNER-FIRST STATIC SEAL CANDIDATE

Canonical route: M18 -> M19 -> G07.
Start with 01_LEARNER/00_START_HERE_M19.pdf.
14 canonical lessons preserved. Every lesson uses the 16-stage beginner-first teaching contract across three pages.
Practice-led design preserved: external videos are not required by default; guided/internal/prior-module evidence is the source.
Independent first attempt must be saved before protected Review/reference answers.
Failure loop: saved attempt -> targeted teaching repair -> changed micro-proof -> validation -> reassessment.
No percentage shortcut. Original attempts remain append-only.
Static package does not claim live employer responses, interview passes, profile publication or external job eligibility.
Production Mentor/GitHub remain intentionally untouched in this rebuild wave.
