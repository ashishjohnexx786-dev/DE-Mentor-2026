# DE19-13 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 42
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-13.md`
Protected Review page: 15
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-13.md`
Expected artifact: timed coding solutions + edge-case tests + explanation notes
Next: DE19-14
