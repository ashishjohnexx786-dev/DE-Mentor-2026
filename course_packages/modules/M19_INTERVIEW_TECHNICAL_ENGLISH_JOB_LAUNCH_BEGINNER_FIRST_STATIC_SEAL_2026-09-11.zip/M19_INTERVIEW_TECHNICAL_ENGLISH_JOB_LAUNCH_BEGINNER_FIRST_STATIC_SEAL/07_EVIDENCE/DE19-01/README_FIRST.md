# DE19-01 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 6
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-01.md`
Protected Review page: 3
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-01.md`
Expected artifact: learner-created one-page resume + completed internal evidence map
Next: DE19-02
