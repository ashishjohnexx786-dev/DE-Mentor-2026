# DE19-07 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 24
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-07.md`
Protected Review page: 9
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-07.md`
Expected artifact: incident diagnosis notes for all drills + one changed retry
Next: DE19-08
