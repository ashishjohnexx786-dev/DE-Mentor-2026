# DE19-08 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 27
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-08.md`
Protected Review page: 10
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-08.md`
Expected artifact: project walkthrough recording/notes + evidence pointers
Next: DE19-09
