# DE19-12 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 39
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-12.md`
Protected Review page: 14
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-12.md`
Expected artifact: application tracker + weekly funnel-review procedure
Next: DE19-13
