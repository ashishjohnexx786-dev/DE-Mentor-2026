from pathlib import Path
import json,sys
root=Path(sys.argv[1]); lid=sys.argv[2]
routes=json.load(open(root/'00_ADMIN/M19_ROUTE_MAP.json',encoding='utf-8'))
route=next((r for r in routes if r['lesson_id']==lid),None)
if not route:
 print(json.dumps({'status':'UNKNOWN_LESSON','lesson_id':lid},indent=2)); sys.exit(3)
p=root/route['evidence_path']
if not p.exists():
 print(json.dumps({'status':'NO_ATTEMPT_SAVED','expected_path':route['evidence_path']},indent=2)); sys.exit(2)
d=json.load(open(p,encoding='utf-8'))
checks={
 'lesson_id_matches':d.get('lesson_id')==lid,
 'first_attempt_saved':bool(str(d.get('first_attempt_path','')).strip()),
 'validation_recorded':len(str(d.get('validation_performed','')).strip())>=15,
 'failure_or_uncertainty_recorded':bool(str(d.get('main_uncertainty_or_failure','')).strip()),
 'fresh_retest_saved':bool(str(d.get('fresh_retest_path','')).strip()),
 'explain_back':len(str(d.get('explain_back_summary','')).strip())>=30,
 'runtime_truth':bool(str(d.get('runtime_truth','')).strip()),
 'critical_failure_resolved':str(d.get('critical_failure_unresolved','')).strip().lower() in ('none','no','resolved','n/a')
}
missing=[k for k,v in checks.items() if not v]
print(json.dumps({'status':'EVIDENCE_STRUCTURALLY_COMPLETE_FOR_REVIEW' if not missing else 'INCOMPLETE','lesson_id':lid,'checks':checks,'missing':missing,'note':'Structure only. Technical/human review decides mastery.'},indent=2))
sys.exit(0 if not missing else 2)
