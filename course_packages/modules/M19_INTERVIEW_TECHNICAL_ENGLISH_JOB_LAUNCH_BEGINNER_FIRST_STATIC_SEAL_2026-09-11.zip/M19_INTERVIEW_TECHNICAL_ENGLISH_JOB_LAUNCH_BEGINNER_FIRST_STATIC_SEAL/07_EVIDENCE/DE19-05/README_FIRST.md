# DE19-05 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 18
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-05.md`
Protected Review page: 7
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-05.md`
Expected artifact: timed SQL solution file + validation evidence
Next: DE19-06
