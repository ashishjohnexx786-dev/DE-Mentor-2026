# DE19-09 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 30
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-09.md`
Protected Review page: 11
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-09.md`
Expected artifact: architecture sketch/ADR-style notes + defense recording
Next: DE19-10
