# DE19-03 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 12
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-03.md`
Protected Review page: 5
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-03.md`
Expected artifact: headline + About + Featured plan
Next: DE19-04
