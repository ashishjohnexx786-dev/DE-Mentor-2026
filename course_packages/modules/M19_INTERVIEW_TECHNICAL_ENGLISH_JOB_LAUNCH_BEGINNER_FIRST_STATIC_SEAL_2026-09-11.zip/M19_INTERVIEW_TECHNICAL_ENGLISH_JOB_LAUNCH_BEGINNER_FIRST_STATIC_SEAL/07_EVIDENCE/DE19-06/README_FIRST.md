# DE19-06 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 21
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-06.md`
Protected Review page: 8
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-06.md`
Expected artifact: completed Python mock + test/output evidence
Next: DE19-07
