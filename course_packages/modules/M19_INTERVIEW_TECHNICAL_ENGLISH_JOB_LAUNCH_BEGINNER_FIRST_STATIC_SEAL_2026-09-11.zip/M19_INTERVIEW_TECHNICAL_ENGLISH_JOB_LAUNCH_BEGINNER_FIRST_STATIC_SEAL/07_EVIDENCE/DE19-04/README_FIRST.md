# DE19-04 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 15
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-04.md`
Protected Review page: 6
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-04.md`
Expected artifact: degree-aware job-targeting tracker with APPLY/MAYBE/SKIP rationale
Next: DE19-05
