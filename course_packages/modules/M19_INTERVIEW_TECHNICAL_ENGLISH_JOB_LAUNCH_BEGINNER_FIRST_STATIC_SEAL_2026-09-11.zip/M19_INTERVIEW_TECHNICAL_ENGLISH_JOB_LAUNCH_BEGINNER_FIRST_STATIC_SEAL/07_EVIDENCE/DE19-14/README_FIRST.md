# DE19-14 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 45
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-14.md`
Protected Review page: 16
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-14.md`
Expected artifact: timed mixed-mock evidence + repair log + changed retest evidence
Next: G07
