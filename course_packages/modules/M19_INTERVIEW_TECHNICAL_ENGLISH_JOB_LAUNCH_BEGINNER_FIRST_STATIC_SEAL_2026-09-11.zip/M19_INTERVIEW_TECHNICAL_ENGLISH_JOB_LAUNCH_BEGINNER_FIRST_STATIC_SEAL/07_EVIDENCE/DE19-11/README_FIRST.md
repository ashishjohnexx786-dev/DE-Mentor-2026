# DE19-11 evidence

Do not create `attempt.json` until a genuine first attempt begins.

Teaching Book start page: 36
Independent: `03_INDEPENDENT/INDEPENDENT_DE19-11.md`
Protected Review page: 13
Fresh retest: `06_FRESH_RETEST/RETEST_DE19-11.md`
Expected artifact: recordings + self-review log
Next: DE19-12
