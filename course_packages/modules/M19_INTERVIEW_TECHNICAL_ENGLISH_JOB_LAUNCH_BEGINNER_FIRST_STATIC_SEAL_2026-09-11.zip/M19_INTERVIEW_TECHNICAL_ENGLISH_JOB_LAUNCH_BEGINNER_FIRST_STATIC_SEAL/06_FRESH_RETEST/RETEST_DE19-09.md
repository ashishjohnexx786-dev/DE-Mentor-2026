# DE19-09 Fresh Changed Retest - Architecture/system-design defense for junior roles

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Erase tool names temporarily. Write five requirements and three failure risks. Re-add only components that satisfy a stated need. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Every major component maps to a requirement; batch/stream split is justified; correctness/security/recovery are covered; at least one simpler alternative is discussed.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-10`.
