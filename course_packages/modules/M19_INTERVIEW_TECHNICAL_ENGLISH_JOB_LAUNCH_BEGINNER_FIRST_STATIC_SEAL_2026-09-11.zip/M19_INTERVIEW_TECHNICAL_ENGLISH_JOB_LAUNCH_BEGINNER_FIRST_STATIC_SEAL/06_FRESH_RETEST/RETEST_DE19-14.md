# DE19-14 Fresh Changed Retest - Combined SQL + Python interview simulation

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Classify each miss precisely. Repair only the smallest weak competency with one short drill, then close all help and test it in changed context. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
First evidence is preserved; each miss has a diagnosis; changed retest is genuinely different; SQL/Python/troubleshooting/project explanation are independently usable; no critical failure remains.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `G07`.
