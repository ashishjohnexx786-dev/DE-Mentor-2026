# DE19-04 Fresh Changed Retest - Degree-aware job targeting: apply/skip rules

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Read the posting twice: first only hard requirements, then preferred skills. Mark each line REQUIRED/PREFERRED/UNCLEAR before deciding. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Each decision quotes/paraphrases a requirement; no invented eligibility; core job work matches your demonstrated stack for APPLY roles.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-05`.
