# DE19-07 Fresh Changed Retest - Data-engineering concepts and troubleshooting drills

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
If stuck, name the last known-good boundary and the first bad boundary. Ask what evidence can distinguish source, transform, state, orchestration or serving failure. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Diagnosis starts from evidence; safe test is bounded; repair matches likely cause; rerun boundary is explicit; output is reconciled; prevention is plausible.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-08`.
