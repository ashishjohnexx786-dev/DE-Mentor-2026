# DE19-06 Fresh Changed Retest - Python interview drills

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Write the input/output contract in plain English first. Add one tiny failing example. Fix the smallest behavior, then rerun previous passing cases. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Functions behave deterministically; invalid values are handled explicitly; edge cases are tested; you can explain code and practical complexity.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-07`.
