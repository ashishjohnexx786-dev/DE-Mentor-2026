# DE19-05 Fresh Changed Retest - SQL interview drills

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Stop coding. Restate the question and grain. Inspect source keys. Build the query in named stages; run row-count/total checks after each grain change. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Queries answer intended grain; join/window behavior is explainable; important counts/totals reconcile; tie handling is deterministic.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-06`.
