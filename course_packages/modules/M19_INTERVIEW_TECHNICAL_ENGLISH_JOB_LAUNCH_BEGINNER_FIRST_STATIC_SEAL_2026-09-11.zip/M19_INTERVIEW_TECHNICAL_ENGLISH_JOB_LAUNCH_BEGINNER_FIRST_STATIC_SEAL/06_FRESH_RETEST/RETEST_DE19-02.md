# DE19-02 Fresh Changed Retest - GitHub and project portfolio final polish

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Clone or copy the project to a clean folder. Follow only the README. Every place you get stuck becomes a specific documentation/setup repair. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
README route works from clean state; architecture and evidence are findable; no secret/PII leakage; claims match real runtime/static truth.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-03`.
