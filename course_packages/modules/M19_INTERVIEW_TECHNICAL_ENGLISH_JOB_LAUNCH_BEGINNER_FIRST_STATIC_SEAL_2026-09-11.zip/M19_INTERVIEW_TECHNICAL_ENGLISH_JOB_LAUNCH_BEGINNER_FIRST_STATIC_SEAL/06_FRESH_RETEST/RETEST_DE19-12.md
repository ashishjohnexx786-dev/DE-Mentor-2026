# DE19-12 Fresh Changed Retest - Application tracker, feedback loop and weekly repair cycle

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Summarize the last meaningful batch by stage. Pick the earliest repeated drop-off. Change one variable for the next batch and define what result would support the hypothesis. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Stage data is honest; bottleneck is derived from evidence; experiment targets that stage; success criterion is stated before the next batch.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-13`.
