# DE19-03 Fresh Changed Retest - LinkedIn/professional profile without overclaiming

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Underline every claim. If you cannot point to project evidence or a real fact about yourself, rewrite it more narrowly. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
No invented title/employment/years; stack names match demonstrated work; strongest proof is one click away; wording can be spoken naturally.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-04`.
