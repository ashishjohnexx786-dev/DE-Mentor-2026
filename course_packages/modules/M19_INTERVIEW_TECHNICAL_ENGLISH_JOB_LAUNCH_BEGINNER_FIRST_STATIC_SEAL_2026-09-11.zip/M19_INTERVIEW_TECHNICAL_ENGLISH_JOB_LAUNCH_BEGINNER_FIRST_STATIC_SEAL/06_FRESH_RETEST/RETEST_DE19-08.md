# DE19-08 Fresh Changed Retest - Project walkthrough interview

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Return to the M18 evidence index. For each section, choose one concrete artifact you can show. If you cannot show it, narrow the claim. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
All 10 defense categories are covered; technical claims point to evidence; one failure/recovery and one limitation are explicit; runtime truth is honest.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-09`.
