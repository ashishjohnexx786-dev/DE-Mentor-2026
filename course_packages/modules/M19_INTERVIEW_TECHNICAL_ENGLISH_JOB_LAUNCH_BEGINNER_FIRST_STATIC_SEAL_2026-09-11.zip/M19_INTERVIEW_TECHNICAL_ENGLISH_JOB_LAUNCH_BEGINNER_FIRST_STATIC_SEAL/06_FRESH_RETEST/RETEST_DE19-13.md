# DE19-13 Fresh Changed Retest - Timed coding test: arrays, strings and hash-map problems

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Use a tiny hand-worked example. State what information must be remembered while scanning. That usually reveals whether a set/dict is useful. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Correct outputs on normal and edge cases; deterministic behavior where ties exist; complexity explanation is reasonable; code can be explained without notes.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-14`.
