# DE19-11 Fresh Changed Retest - Technical English: explain code, failures and decisions clearly

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Stop, say "Let me restate that simply," name the object, then complete the five-part model. Technical precision matters more than sophisticated vocabulary. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Listener can identify object/change/reason/check/risk; technical meaning is correct; correction is calm; no reading from script.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-12`.
