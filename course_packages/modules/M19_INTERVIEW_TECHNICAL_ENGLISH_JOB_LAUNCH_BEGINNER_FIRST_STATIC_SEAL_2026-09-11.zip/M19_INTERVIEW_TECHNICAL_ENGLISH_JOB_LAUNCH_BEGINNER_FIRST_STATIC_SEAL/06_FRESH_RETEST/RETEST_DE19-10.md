# DE19-10 Fresh Changed Retest - Behavioral answers and career-transition story

Use the same competency on changed data/example/wording. Do not copy first-attempt sentences/code.

## Changed transfer
Choose a smaller real event. Write only six one-line fields using the model. Then speak from those anchors instead of memorizing prose. Then solve a changed version of the independent task using a different example, dataset condition, project or prompt.

## Revalidate
Stories are factual; responsibility is clear; action contains decisions; result/verification is concrete; reflection is specific; no invented employment.

## Append-only rule
Keep attempt-01 and first failure. Save retry evidence as a new artifact/attempt record. No aggregate number or percentage creates mastery.

## Next route
If the changed retest is independently usable with no unresolved critical failure, continue to `DE19-11`.
