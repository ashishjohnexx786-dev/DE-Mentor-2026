# DE19-11 Guided - Technical English: explain code, failures and decisions clearly

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Explain one SQL query and one pipeline failure in plain English using object -> change -> why -> check -> failure risk.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: State what the object is, what changed, why, how you checked it, and one way it can fail.
