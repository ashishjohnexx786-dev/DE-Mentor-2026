# DE19-07 Guided - Data-engineering concepts and troubleshooting drills

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Use the troubleshooting ladder on two supplied incidents: symptom -> evidence -> likely layer -> safe test -> repair -> reconcile.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Symptom -> blast radius -> first evidence -> likely layer -> smallest safe test -> repair -> rerun boundary -> reconciliation -> prevention.
