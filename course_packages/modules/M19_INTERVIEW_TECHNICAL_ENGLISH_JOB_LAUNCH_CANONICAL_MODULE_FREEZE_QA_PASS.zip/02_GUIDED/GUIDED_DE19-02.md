# DE19-02 Guided - GitHub and project portfolio final polish

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Audit a sample repo for README, architecture, clean setup, tests, failure/recovery, secrets and honest limitations.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Pinned repo -> README -> architecture -> setup -> test/evidence -> failure/recovery -> limitations.
