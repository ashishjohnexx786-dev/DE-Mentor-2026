# DE19-04 Guided - Degree-aware job targeting: apply/skip rules

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Classify 6 sample postings as APPLY/MAYBE/SKIP from required vs preferred degree/experience/stack.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: APPLY when core work matches and hard requirements are met; MAYBE when a gap is preferred/trainable; SKIP when a hard legal/degree/experience requirement clearly excludes you.
