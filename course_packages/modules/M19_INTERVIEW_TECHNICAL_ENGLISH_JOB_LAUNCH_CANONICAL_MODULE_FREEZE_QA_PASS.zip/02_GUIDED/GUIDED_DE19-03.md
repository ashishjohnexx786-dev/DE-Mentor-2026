# DE19-03 Guided - LinkedIn/professional profile without overclaiming

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Turn three exaggerated profile claims into defensible headline/About statements tied to evidence.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Target role + defensible stack + strongest proof + current availability. Keep claims narrow enough to defend in a live interview.
