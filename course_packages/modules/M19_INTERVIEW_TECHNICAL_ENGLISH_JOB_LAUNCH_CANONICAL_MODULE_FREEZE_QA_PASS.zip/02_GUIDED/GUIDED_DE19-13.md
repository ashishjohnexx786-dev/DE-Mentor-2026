# DE19-13 Guided - Timed coding test: arrays, strings and hash-map problems

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Work one teacher example for counting/frequency, latest-per-key and pair-sum; explain chosen data structures.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Restate contract -> examples -> choose data structure -> implement -> edge cases -> complexity -> verbal explanation.
