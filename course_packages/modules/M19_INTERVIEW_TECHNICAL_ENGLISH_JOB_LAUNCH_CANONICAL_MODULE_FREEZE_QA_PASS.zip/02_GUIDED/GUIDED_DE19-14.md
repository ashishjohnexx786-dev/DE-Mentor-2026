# DE19-14 Guided - Combined SQL + Python interview simulation

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Practice a 30-minute mini-mix: one SQL window, one Python validation, one troubleshooting answer, one project explanation.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Save first attempt -> classify misses -> open review -> repair exact competency -> close review -> fresh changed mixed mock -> defend without notes.
