# DE19-10 Guided - Behavioral answers and career-transition story

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Turn one vague behavioral answer into Context -> Responsibility -> Action -> Result -> Verification -> Reflection.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Context -> responsibility -> action -> result -> verification -> reflection. Use course/project facts if you do not yet have professional DE experience.
