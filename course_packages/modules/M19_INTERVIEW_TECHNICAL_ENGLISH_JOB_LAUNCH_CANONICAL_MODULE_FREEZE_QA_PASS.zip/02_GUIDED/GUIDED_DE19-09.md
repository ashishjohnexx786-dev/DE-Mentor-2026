# DE19-09 Guided - Architecture/system-design defense for junior roles

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Sketch a simple batch-first marketplace design and identify the exact requirement that would justify streaming.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Requirements -> scale/latency -> source contracts -> storage/compute -> orchestration -> correctness -> security -> observability -> failure modes -> cost/operability.
