# DE19-01 Guided - Truthful one-page Data Engineer resume

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Map 4 sample resume bullets to real M18 evidence paths; rewrite one inflated bullet into a truthful action-system-validation bullet.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Evidence -> action -> system -> validation/result. Example: Built a Python ingestion pipeline that quarantines invalid rows and proved idempotent reruns with unchanged trusted counts.
