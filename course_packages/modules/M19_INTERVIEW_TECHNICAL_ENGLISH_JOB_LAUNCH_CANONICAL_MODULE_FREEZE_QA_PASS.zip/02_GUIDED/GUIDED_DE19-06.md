# DE19-06 Guided - Python interview drills

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Implement one small parser with explicit invalid-row accounting and test happy + malformed cases.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Input contract -> transform -> explicit failure path -> deterministic output -> edge-case tests -> complexity at a practical level.
