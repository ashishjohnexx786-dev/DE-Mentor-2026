# DE19-12 Guided - Application tracker, feedback loop and weekly repair cycle

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Diagnose four sample funnels and choose exactly one repair experiment for each.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Targeted role -> truthful application -> screen -> assessment -> technical -> final -> offer. Record stage-specific failure patterns and run one repair experiment per batch.
