# DE19-08 Guided - Project walkthrough interview

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Walk through the teacher mini-project using problem -> grain -> quality -> rerun -> failure -> limitation.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Problem -> sources -> architecture -> grain -> quality -> idempotency -> orchestration -> failure/recovery -> security -> limitations -> 10x change.
