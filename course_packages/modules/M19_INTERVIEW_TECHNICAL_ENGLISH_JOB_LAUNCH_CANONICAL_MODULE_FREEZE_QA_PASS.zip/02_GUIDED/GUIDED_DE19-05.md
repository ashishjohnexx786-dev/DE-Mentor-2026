# DE19-05 Guided - SQL interview drills

Teacher purpose: practise the reasoning pattern once with support.

Guided task - Northstar Retail:
Solve two guided SQL questions on the packaged orders data, stating grain and one validation query.

Validation:
- factual/technical claims are supportable;
- one observable check or evidence path exists;
- you can explain the result without reading.

Teacher model to use: Question -> state grain -> write query -> inspect duplicates/nulls -> validate with an independent count/total -> explain trade-off.
