# DE19-05 Independent - SQL interview drills

Changed task - CareRoute Logistics / your own M18 evidence:
Run sql_mock_setup.sql in SQLite-compatible tooling and complete all four sql_mock_questions.md tasks closed-book.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
