# DE19-07 Independent - Data-engineering concepts and troubleshooting drills

Changed task - CareRoute Logistics / your own M18 evidence:
Answer all troubleshooting_drills.md cases. For at least four, state persisted state that must be protected before rerun.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
