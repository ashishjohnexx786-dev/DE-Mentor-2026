# DE19-13 Independent - Timed coding test: arrays, strings and hash-map problems

Changed task - CareRoute Logistics / your own M18 evidence:
Complete coding_mock_a.py in 45 minutes. Test at least 3 cases/function and state time/space complexity.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
