# DE19-09 Independent - Architecture/system-design defense for junior roles

Changed task - CareRoute Logistics / your own M18 evidence:
Complete system_design_scenario.md. State scale/latency assumptions, failure boundaries, recovery, security, observability and one cost trade-off.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
