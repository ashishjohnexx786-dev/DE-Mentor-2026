# DE19-06 Independent - Python interview drills

Changed task - CareRoute Logistics / your own M18 evidence:
Complete python_mock.py: parsing/quarantine, deterministic latest-state merge and numeric summary with explicit invalid-value behavior.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
