# DE19-10 Independent - Behavioral answers and career-transition story

Changed task - CareRoute Logistics / your own M18 evidence:
Answer all behavioral_prompts.md using truthful course/life evidence only; record two answers aloud.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
