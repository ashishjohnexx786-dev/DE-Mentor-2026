# DE19-14 Independent - Combined SQL + Python interview simulation

Changed task - CareRoute Logistics / your own M18 evidence:
Complete combined_mock_b.md in 90 minutes closed-book. Save first attempt and classify every miss before Review.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
