# DE19-08 Independent - Project walkthrough interview

Changed task - CareRoute Logistics / your own M18 evidence:
Answer project_defense_questions.md for your strongest M18 project without reading its README. Point to exact evidence paths.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
