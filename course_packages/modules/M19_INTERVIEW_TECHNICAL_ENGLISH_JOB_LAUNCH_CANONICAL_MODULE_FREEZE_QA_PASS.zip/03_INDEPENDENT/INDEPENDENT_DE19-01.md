# DE19-01 Independent - Truthful one-page Data Engineer resume

Changed task - CareRoute Logistics / your own M18 evidence:
Draft your own one-page DE resume. Every technical bullet gets an internal evidence path and executed/measured flag before you remove the internal tags.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
