# DE19-04 Independent - Degree-aware job targeting: apply/skip rules

Changed task - CareRoute Logistics / your own M18 evidence:
Collect 10 real or saved postings into job_targeting_tracker.csv and justify eligibility without inventing qualifications.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
