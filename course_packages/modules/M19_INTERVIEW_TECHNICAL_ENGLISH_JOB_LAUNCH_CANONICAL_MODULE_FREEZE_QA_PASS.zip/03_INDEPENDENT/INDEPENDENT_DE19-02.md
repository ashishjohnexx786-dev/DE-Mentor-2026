# DE19-02 Independent - GitHub and project portfolio final polish

Changed task - CareRoute Logistics / your own M18 evidence:
Audit P01/P02/P03/Capstone using project_portfolio_audit.csv. Any failed item becomes a repair before the repo is pinned.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
