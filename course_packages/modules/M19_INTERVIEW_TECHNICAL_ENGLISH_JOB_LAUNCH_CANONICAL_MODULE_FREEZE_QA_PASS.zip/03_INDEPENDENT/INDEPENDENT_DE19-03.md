# DE19-03 Independent - LinkedIn/professional profile without overclaiming

Changed task - CareRoute Logistics / your own M18 evidence:
Write your headline, About and Featured plan. Remove any claim you cannot defend from a repository, output or recorded result.

Attempt rules:
- Guided and Review closed.
- Save the first attempt before opening Review.
- Record one likely failure/objection and one independent validation.
- Critical fail: fabricated qualification/employment/production evidence, copied answer presented as your own, or unsafe technical advice.
