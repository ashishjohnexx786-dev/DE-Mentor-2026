# DE19-05 Fresh Retest - SQL interview drills

Fresh changed task - ClinicBridge Operations:
Create a fresh SQL set by changing one region/status/month threshold and solve without copying the first queries; preserve deterministic ranking and validation.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
