# DE19-14 Fresh Retest - Combined SQL + Python interview simulation

Fresh changed task - ClinicBridge Operations:
Build a changed 75-minute mixed mock using different SQL filters/window, shipment JSON, a stale mart incident and a different M18 project defense. Do not repeat Mock B.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
