# DE19-07 Fresh Retest - Data-engineering concepts and troubleshooting drills

Fresh changed task - ClinicBridge Operations:
Fresh incidents: stale watermark with equal timestamps; duplicate file after partial success; leaked credential after rotation; skew introduced by one customer. Diagnose without reusing first wording.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
