# DE19-04 Fresh Retest - Degree-aware job targeting: apply/skip rules

Fresh changed task - ClinicBridge Operations:
Reclassify 5 changed postings where one requirement changes from preferred to required or vice versa; explain why the decision changes.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
