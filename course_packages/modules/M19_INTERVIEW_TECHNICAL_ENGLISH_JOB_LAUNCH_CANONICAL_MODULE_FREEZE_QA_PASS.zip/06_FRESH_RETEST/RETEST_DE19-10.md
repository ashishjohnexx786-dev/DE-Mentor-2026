# DE19-10 Fresh Retest - Behavioral answers and career-transition story

Fresh changed task - ClinicBridge Operations:
Fresh prompts: biggest wrong assumption; time you simplified a design; time you received criticism. Use different evidence stories from first attempt.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
