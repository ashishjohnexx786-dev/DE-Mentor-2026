# DE19-03 Fresh Retest - LinkedIn/professional profile without overclaiming

Fresh changed task - ClinicBridge Operations:
Rewrite the profile for a junior/associate DE role at a different company style: one product company and one services/consulting company.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
