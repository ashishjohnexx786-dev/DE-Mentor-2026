# DE19-09 Fresh Retest - Architecture/system-design defense for junior roles

Fresh changed task - ClinicBridge Operations:
Changed case: clinic receives hourly files plus urgent events, 400k/day, 5-minute alert SLA, daily reconciled reporting. Redesign from requirements, not from your previous boxes.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
