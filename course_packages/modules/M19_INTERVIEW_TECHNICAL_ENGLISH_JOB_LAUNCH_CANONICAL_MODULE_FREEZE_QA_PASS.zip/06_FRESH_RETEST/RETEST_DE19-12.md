# DE19-12 Fresh Retest - Application tracker, feedback loop and weekly repair cycle

Fresh changed task - ClinicBridge Operations:
Changed funnel: many screens but few assessment passes; another: technical rounds but no finals. Design one experiment per funnel and what evidence would confirm improvement.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
