# DE19-06 Fresh Retest - Python interview drills

Fresh changed task - ClinicBridge Operations:
Redo the same competencies on shipment records with shipment_id/event_time/cost instead of order fields; add one duplicate and one malformed numeric.

Transfer rule: use the same reasoning framework but different data/example/wording. Validate again. No aggregate number can create mastery.
