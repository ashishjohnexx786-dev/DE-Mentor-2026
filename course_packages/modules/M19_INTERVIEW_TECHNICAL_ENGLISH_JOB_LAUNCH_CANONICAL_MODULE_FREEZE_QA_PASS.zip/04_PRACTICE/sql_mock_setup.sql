DROP TABLE IF EXISTS orders;
CREATE TABLE orders(order_id TEXT, customer_id TEXT, region TEXT, order_date TEXT, status TEXT, amount REAL);
INSERT INTO orders VALUES
('O1','C1','East','2026-07-01','Completed',500),('O2','C1','East','2026-07-03','Completed',700),('O3','C2','East','2026-07-04','Cancelled',900),('O4','C3','West','2026-07-02','Completed',300),('O5','C3','West','2026-08-02','Completed',450),('O6','C4','North','2026-08-03','Completed',800),('O7','C4','North','2026-08-04','Completed',600),('O8','C5','North','2026-08-05','Completed',200);
DROP TABLE IF EXISTS contacts;
CREATE TABLE contacts(customer_id TEXT, contact_type TEXT);
INSERT INTO contacts VALUES ('C1','email'),('C1','phone'),('C3','email'),('C4','email'),('C4','phone');
