# Complete these functions without external solutions.
def parse_orders(lines):
    """Return (valid_rows, error_count). Each line is JSON; order_id required."""
    raise NotImplementedError

def latest_by_id(records):
    """records: dicts with id, updated_at, value. Keep deterministic latest per id."""
    raise NotImplementedError

def summarize_amount(rows):
    """Return sum of numeric amount; reject invalid numeric values explicitly."""
    raise NotImplementedError
