# SQL Mock A - 45 minutes
1. Return the top 2 Completed orders per region by amount; break ties by order_id. State output grain.
2. Return monthly Completed sales and month-over-month absolute change.
3. Show customers with Completed sales >= 1000. Explain WHERE vs HAVING.
4. Diagnose why joining orders to contacts can multiply order rows; write two validation queries.
