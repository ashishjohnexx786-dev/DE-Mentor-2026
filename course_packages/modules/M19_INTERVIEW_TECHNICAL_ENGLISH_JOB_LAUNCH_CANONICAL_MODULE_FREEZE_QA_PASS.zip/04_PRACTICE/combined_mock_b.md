# Combined Mock B - 90 minutes
SQL 1 (12m): top 2 Completed orders per region, deterministic ranking.
SQL 2 (12m): monthly Completed sales + MoM change.
SQL 3 (11m): diagnose join multiplication.
Python 1 (15m): parse NDJSON, quarantine invalid JSON/missing order_id.
Python 2 (15m): merge incremental events to latest current state; prove rerun unchanged.
Troubleshooting (10m): orchestration green but today's mart total is 30% low. Diagnose safely.
Project defense (10m): strongest M18 project - architecture, failure/recovery, trade-off.
Buffer 5m.
