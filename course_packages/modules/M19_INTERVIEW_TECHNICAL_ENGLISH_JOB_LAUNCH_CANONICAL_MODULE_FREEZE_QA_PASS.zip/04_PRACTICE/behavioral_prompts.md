# Behavioral Prompts
Tell me about: a difficult bug; a wrong assumption; a failure you repaired; choosing a simpler tool; receiving criticism; handling ambiguity; learning something hard; explaining a technical issue to a nontechnical person. Use truthful course/life evidence; do not invent employment.
