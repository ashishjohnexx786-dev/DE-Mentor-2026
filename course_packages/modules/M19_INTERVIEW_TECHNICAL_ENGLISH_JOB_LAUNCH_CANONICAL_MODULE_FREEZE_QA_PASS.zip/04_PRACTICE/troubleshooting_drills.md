# Troubleshooting Drills
1. DAG green, mart total 30% low.
2. Same source file delivered twice.
3. Incremental job missed rows sharing the same timestamp.
4. Spark job slowed after a hot key appeared.
5. Kafka consumer lag rises but broker is healthy.
6. Delta MERGE duplicates a business key after retry.
7. Fabric pipeline fails after a schema addition.
8. Secret appeared in a public commit.
9. Backfill corrected July but corrupted August current state.
10. PostgreSQL query suddenly scans far more rows.
