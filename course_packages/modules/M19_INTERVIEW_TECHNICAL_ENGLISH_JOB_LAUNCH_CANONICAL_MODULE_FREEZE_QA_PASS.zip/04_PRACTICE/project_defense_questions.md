# M18 Project Defense Questions
1 problem/business user? 2 source grains? 3 trusted output grain? 4 quality gate? 5 rerun/idempotency? 6 one failure and recovery? 7 orchestration boundary? 8 security/PII? 9 biggest limitation? 10 what changes at 10x?
