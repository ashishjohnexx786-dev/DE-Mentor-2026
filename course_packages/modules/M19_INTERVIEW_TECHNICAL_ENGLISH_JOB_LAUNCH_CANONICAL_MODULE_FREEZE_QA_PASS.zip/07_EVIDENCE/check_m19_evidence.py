from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'07_EVIDENCE'
lessons=['DE19-01', 'DE19-02', 'DE19-03', 'DE19-04', 'DE19-05', 'DE19-06', 'DE19-07', 'DE19-08', 'DE19-09', 'DE19-10', 'DE19-11', 'DE19-12', 'DE19-13', 'DE19-14']
missing=[]
for lid in lessons:
 p=root/f'{lid}_EVIDENCE.md'
 if not p.exists(): missing.append(f'{lid}:file') ; continue
 txt=p.read_text().strip()
 required=['First attempt path:','Validation performed:','Fresh retest path:','Explain-back summary:','Critical failure unresolved?']
 if any(k not in txt for k in required): missing.append(f'{lid}:fields')
 # template-only values are not pass evidence
 for k in ['First attempt path:','Validation performed:','Fresh retest path:','Explain-back summary:']:
  line=next((x for x in txt.splitlines() if x.startswith(k)),k)
  if not line[len(k):].strip(): missing.append(f'{lid}:blank:{k}')
 crit=next((x for x in txt.splitlines() if x.startswith('Critical failure unresolved?')), '')
 if 'NO' not in crit.upper(): missing.append(f'{lid}:critical')
print('PASS' if not missing else 'INCOMPLETE')
for x in missing: print(x)
sys.exit(0 if not missing else 2)
