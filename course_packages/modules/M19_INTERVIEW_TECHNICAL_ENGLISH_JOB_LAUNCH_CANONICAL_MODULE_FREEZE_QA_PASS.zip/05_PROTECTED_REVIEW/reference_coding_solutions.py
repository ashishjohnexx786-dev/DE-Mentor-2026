from collections import Counter

def first_unique(s):
    c=Counter(s)
    return next((ch for ch in s if c[ch]==1),None)

def dedupe_latest(records):
    best={}
    for rec in records:
        i,ts,val=rec
        if i not in best or ts>best[i][1] or (ts==best[i][1] and val>best[i][2]): best[i]=rec
    return [best[k] for k in sorted(best)]

def pair_sum(values,target):
    seen={}
    for i,x in enumerate(values):
        need=target-x
        if need in seen:return (seen[need],i)
        seen[x]=i
    return None
