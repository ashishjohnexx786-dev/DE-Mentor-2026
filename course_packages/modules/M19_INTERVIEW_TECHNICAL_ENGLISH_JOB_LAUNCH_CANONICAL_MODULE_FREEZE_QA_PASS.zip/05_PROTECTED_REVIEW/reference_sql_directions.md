# Protected SQL Review - open only after saved attempt
Q1: filter Completed, use ROW_NUMBER() OVER(PARTITION BY region ORDER BY amount DESC, order_id), keep rn<=2.
Q2: aggregate by month first, then LAG(month_sales) over chronological month.
Q3: WHERE is row eligibility; HAVING is group eligibility.
Q4: compare count(*) and count(distinct order_id) before/after join; preaggregate/deduplicate contacts only if business contract justifies it.
