# P02 exact phase route

Workspace: `03_PROJECT_WORKSPACES/P02_ANALYTICS_ENGINEERING_PLATFORM`

For each phase: Project Book -> learner build -> attempt.json -> checker -> protected Review only after saved attempt -> changed retry if needed -> next phase.

## P02-01 - Read the analytics-engineering brief and define outputs
- Project Book start page: 6
- Evidence: `evidence/P02-01/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 3
- Next: P02-02

## P02-02 - Profile billing/customer sources and state grains
- Project Book start page: 9
- Evidence: `evidence/P02-02/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 4
- Next: P02-03

## P02-03 - Design facts, dimensions, keys and serving grain
- Project Book start page: 12
- Evidence: `evidence/P02-03/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 5
- Next: P02-04

## P02-04 - Create dbt project, sources and dependency graph
- Project Book start page: 15
- Evidence: `evidence/P02-04/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 6
- Next: P02-05

## P02-05 - Build thin staging models with explicit contracts
- Project Book start page: 18
- Evidence: `evidence/P02-05/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 7
- Next: P02-06

## P02-06 - Build dimensional marts without fan-out
- Project Book start page: 21
- Evidence: `evidence/P02-06/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 8
- Next: P02-07

## P02-07 - Add data tests and critical quality gates
- Project Book start page: 24
- Evidence: `evidence/P02-07/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 9
- Next: P02-08

## P02-08 - Implement incremental model/update behavior
- Project Book start page: 27
- Evidence: `evidence/P02-08/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 10
- Next: P02-09

## P02-09 - Preserve history with snapshot/SCD reasoning
- Project Book start page: 30
- Evidence: `evidence/P02-09/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 11
- Next: P02-10

## P02-10 - Add orchestration and reproducible run order
- Project Book start page: 33
- Evidence: `evidence/P02-10/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 12
- Next: P02-11

## P02-11 - Inject duplicate/relationship/partial-run failures
- Project Book start page: 36
- Evidence: `evidence/P02-11/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 13
- Next: P02-12

## P02-12 - Document lineage, runbook, limitations and evidence
- Project Book start page: 39
- Evidence: `evidence/P02-12/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 14
- Next: P02-13

## P02-13 - Clean-clone build and analytics-platform defense
- Project Book start page: 42
- Evidence: `evidence/P02-13/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 15
- Next: P03-01
