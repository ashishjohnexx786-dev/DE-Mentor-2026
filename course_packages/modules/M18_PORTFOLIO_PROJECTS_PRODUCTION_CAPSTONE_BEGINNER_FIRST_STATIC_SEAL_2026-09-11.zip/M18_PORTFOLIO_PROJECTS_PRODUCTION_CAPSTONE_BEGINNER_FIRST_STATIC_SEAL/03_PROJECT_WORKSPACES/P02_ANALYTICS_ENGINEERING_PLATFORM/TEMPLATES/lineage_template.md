# Lineage

source.billing -> stg_billing -> fct_revenue -> mart_daily_revenue

State grain and validation at every arrow.
