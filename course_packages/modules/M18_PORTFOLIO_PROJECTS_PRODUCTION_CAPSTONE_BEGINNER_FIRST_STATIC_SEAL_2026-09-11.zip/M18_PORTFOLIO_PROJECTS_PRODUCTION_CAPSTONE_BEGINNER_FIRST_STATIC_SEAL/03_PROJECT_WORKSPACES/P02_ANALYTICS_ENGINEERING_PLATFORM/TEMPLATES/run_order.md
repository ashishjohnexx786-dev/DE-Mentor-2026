1. source/profile
2. staging
3. tests
4. marts
5. reconciliation
6. publish
