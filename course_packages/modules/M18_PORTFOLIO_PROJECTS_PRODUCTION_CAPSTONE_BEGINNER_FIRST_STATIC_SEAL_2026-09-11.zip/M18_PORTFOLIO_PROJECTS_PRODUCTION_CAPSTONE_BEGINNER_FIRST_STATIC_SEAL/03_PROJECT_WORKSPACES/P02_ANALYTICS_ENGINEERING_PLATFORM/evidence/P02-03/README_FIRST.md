# P02-03

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 12
Protected Review page: 5
Artifact contract: p02_phase_artifact + evidence note
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: PHASE CHECK P02-03: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P02-04
