# P02-08

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 27
Protected Review page: 10
Artifact contract: state ledger/watermark + rerun/backfill evidence
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.
Changed/failure test: Replay the same batch/event plus one late/changed record; detect duplicate/logical-state corruption if implementation is unsafe.
Next: P02-09
