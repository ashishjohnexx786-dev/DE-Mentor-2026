# P02-04

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 15
Protected Review page: 6
Artifact contract: models/SQL/dbt + lineage + row-count controls
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.
Changed/failure test: PHASE CHECK P02-04: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P02-05
