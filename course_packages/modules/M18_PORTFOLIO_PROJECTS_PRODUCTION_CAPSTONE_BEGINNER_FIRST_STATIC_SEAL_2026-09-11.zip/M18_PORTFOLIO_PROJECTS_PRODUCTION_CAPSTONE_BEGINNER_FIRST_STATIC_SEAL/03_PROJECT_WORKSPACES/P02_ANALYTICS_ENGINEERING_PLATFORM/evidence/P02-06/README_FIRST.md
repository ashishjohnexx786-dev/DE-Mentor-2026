# P02-06

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 21
Protected Review page: 8
Artifact contract: models/SQL/dbt + lineage + row-count controls
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.
Changed/failure test: Inject one duplicate dimension/reference key or one-to-many fan-out risk and prove the validation catches it.
Next: P02-07
