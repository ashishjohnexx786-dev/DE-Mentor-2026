# P02-10

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 33
Protected Review page: 12
Artifact contract: DAG/workflow + run log + dependency evidence
Validation: Run dependency path end-to-end; prove failed task does not falsely advance downstream state; rerun only required work.
Changed/failure test: Force an upstream task failure/partial run; prove downstream publish does not falsely succeed and rerun is bounded.
Next: P02-11
