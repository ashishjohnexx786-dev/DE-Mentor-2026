# P02-01

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 6
Protected Review page: 3
Artifact contract: business_questions.md + assumptions.md
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: PHASE CHECK P02-01: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P02-02
