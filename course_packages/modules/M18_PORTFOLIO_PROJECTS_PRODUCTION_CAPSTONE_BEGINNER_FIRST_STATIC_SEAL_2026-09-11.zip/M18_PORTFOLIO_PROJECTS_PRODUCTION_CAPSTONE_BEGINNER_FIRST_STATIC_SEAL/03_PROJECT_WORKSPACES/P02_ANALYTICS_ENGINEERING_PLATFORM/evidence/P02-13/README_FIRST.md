# P02-13

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 42
Protected Review page: 15
Artifact contract: clean-clone transcript/log + frozen evidence bundle
Validation: Rebuild from documented clean state using only declared dependencies/config; reviewer can reproduce declared outputs.
Changed/failure test: PHASE CHECK P02-13: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P03-01
