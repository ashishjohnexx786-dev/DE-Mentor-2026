# P02-12

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 39
Protected Review page: 14
Artifact contract: README.md + runbook.md + evidence_index.md
Validation: Reviewer can locate every evidence artifact and challenge one design trade-off; learner explains limitation and recovery path without reading a script.
Changed/failure test: PHASE CHECK P02-12: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P02-13
