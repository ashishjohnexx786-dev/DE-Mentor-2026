# P02-02

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 9
Protected Review page: 4
Artifact contract: source_profile/ + grain_key_defects.md
Validation: Record row counts, grain, keys, null/duplicate/schema defects; independently sample-check at least one finding.
Changed/failure test: Replay the same batch/event plus one late/changed record; detect duplicate/logical-state corruption if implementation is unsafe.
Next: P02-03
