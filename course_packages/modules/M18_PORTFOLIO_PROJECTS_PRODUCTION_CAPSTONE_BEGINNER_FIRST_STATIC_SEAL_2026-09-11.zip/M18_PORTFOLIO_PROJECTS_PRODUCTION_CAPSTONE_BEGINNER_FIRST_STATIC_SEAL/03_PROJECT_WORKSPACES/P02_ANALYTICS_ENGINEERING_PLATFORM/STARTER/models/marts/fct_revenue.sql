-- P02-06 learner implementation
-- TODO: one row per accepted invoice; prove customer join does not fan out.
select * from {{ ref('stg_billing') }} where 1=0
