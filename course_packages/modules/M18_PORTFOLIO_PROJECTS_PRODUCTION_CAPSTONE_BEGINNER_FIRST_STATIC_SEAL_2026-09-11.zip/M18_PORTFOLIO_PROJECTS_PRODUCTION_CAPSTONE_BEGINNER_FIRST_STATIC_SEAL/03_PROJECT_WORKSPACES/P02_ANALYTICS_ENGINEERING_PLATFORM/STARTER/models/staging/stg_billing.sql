-- P02-05 learner implementation
-- TODO: select typed, contract-aligned billing columns; do not aggregate in staging.
select * from {{ source('raw', 'billing') }} where 1=0
