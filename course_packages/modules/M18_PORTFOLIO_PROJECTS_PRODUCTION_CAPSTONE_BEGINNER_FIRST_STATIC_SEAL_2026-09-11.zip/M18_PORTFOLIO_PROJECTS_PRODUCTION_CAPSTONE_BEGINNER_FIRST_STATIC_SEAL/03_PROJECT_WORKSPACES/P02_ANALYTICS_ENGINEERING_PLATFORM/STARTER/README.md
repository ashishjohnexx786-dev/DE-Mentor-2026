# P02 learner repository starter

Build in phase order. dbt runtime is useful when available; the course does not claim it ran in this build environment. Do not open `SEALED_FAILURE_PACK` before P02-11.
