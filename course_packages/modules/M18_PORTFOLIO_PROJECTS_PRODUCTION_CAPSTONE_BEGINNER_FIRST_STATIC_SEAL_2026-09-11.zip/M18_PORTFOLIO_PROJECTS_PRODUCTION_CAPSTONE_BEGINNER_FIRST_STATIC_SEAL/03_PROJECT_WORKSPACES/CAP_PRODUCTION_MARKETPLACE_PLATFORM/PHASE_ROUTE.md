# CAP exact phase route

Workspace: `03_PROJECT_WORKSPACES/CAP_PRODUCTION_MARKETPLACE_PLATFORM`

For each phase: Project Book -> learner build -> attempt.json -> checker -> protected Review only after saved attempt -> changed retry if needed -> next phase.

## CAP-01 - Read capstone requirements and write source contracts
- Project Book start page: 6
- Evidence: `evidence/CAP-01/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 3
- Next: CAP-02

## CAP-02 - Design architecture and record major ADRs
- Project Book start page: 9
- Evidence: `evidence/CAP-02/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 4
- Next: CAP-03

## CAP-03 - Build multi-source ingestion and raw evidence
- Project Book start page: 12
- Evidence: `evidence/CAP-03/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 5
- Next: CAP-04

## CAP-04 - Implement critical quality, quarantine and reconciliation
- Project Book start page: 15
- Evidence: `evidence/CAP-04/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 6
- Next: CAP-05

## CAP-05 - Build trusted warehouse/dbt serving layer
- Project Book start page: 18
- Evidence: `evidence/CAP-05/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 7
- Next: CAP-06

## CAP-06 - Orchestrate dependencies, retries and bounded backfills
- Project Book start page: 21
- Evidence: `evidence/CAP-06/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 8
- Next: CAP-07

## CAP-07 - Use Spark/Delta where scale justifies it
- Project Book start page: 24
- Evidence: `evidence/CAP-07/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 9
- Next: CAP-08

## CAP-08 - Design Fabric deployment, access and secret boundaries
- Project Book start page: 27
- Evidence: `evidence/CAP-08/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 10
- Next: CAP-09

## CAP-09 - Add CI/CD, monitoring, alerts and runbook
- Project Book start page: 30
- Evidence: `evidence/CAP-09/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 11
- Next: CAP-10

## CAP-10 - Open incident pack, diagnose and recover safely
- Project Book start page: 33
- Evidence: `evidence/CAP-10/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 12
- Next: CAP-11

## CAP-11 - Reproduce from clean state and freeze evidence bundle
- Project Book start page: 36
- Evidence: `evidence/CAP-11/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 13
- Next: CAP-12

## CAP-12 - Final technical defense and Gate 7 readiness
- Project Book start page: 39
- Evidence: `evidence/CAP-12/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 14
- Next: M19 DE19-01
