import csv,json,sqlite3,pathlib,sys
p=pathlib.Path(sys.argv[1])
out={}
for f in p.rglob('*.csv'):
 try:
  rows=list(csv.DictReader(open(f,encoding='utf-8')))
  out[str(f.relative_to(p))]={'rows':len(rows),'columns':list(rows[0].keys()) if rows else []}
 except Exception as e: out[str(f.relative_to(p))]={'error':repr(e)}
for f in p.rglob('*.json'):
 try:
  x=json.load(open(f,encoding='utf-8')); out[str(f.relative_to(p))]={'json_type':type(x).__name__}
 except Exception as e: out[str(f.relative_to(p))]={'error':repr(e)}
for f in p.rglob('*.db'):
 try:
  con=sqlite3.connect(f); tables=[r[0] for r in con.execute("select name from sqlite_master where type='table'")]; out[str(f.relative_to(p))]={'tables':tables}; con.close()
 except Exception as e: out[str(f.relative_to(p))]={'error':repr(e)}
print(json.dumps(out,indent=2))
