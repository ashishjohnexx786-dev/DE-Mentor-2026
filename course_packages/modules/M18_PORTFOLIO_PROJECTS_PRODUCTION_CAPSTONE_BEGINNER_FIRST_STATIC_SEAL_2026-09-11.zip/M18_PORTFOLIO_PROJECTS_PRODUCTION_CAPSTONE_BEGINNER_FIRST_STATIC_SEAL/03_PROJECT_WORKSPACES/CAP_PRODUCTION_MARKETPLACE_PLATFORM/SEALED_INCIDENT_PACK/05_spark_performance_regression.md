One seller/hub key becomes hot and a distributed join slows. Diagnose with plan/distribution evidence before changing tuning.
