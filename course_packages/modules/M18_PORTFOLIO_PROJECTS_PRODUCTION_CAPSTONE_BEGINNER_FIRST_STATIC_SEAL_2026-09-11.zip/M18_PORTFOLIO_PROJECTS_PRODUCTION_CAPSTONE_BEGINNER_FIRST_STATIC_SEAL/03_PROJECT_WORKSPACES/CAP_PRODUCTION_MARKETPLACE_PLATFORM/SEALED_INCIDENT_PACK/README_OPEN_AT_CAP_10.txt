STOP. Open only after CAP-09 evidence is saved. Eight incidents; no solution keys. Preserve first-failure evidence.
