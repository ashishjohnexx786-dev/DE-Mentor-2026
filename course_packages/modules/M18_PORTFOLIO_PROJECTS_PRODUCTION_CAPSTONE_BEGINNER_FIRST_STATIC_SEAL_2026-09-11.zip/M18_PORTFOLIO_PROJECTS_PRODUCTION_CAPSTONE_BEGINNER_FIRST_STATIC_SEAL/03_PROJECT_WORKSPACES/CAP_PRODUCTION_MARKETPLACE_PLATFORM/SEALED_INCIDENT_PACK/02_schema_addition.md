Orders adds nullable promo_code. Raw must preserve it; trusted schema change must be explicit and compatible.
