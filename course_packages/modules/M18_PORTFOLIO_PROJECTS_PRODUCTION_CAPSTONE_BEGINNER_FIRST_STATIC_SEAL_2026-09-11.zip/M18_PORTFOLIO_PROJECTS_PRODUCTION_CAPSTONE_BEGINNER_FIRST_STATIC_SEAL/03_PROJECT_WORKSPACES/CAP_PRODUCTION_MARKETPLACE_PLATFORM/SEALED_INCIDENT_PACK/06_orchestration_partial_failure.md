Ingestion and quality succeed; publish task fails. Recover from persisted safe state without repeating unsafe side effects.
