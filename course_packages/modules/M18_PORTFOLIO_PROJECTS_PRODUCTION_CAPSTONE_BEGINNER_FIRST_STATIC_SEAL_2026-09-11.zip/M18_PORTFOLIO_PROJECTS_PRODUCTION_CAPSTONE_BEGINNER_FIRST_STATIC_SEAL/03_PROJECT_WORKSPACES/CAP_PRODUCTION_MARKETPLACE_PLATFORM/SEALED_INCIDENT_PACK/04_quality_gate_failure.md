A required-key/data test fails after ingestion. Gold publish must remain blocked until repaired and reconciled.
