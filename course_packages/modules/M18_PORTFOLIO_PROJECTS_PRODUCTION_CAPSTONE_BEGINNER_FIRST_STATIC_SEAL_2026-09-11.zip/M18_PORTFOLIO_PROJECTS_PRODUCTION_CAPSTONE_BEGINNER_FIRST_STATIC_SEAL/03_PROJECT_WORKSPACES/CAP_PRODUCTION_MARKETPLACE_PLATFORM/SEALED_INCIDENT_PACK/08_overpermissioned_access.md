An analyst role can read raw buyer_email and write trusted tables. Redesign to least privilege and prove the corrected boundary.
