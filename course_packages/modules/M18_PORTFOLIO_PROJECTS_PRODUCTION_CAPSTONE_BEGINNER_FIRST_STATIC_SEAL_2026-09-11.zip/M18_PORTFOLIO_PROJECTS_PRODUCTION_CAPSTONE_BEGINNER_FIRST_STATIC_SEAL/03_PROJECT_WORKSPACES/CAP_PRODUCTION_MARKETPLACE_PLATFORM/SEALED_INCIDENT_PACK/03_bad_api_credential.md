Seller API credential is invalid/expired. Fail closed; do not publish a falsely complete snapshot or expose a secret in logs.
