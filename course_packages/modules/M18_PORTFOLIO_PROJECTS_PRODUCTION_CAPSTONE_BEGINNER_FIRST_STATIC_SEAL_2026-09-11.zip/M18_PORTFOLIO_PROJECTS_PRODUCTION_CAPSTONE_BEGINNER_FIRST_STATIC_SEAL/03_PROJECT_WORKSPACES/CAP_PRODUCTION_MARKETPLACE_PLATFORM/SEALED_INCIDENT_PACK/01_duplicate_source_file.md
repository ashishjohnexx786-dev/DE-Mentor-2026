A previously processed daily file is redelivered with the same business content under a new filename. Prove raw retention and trusted idempotency.
