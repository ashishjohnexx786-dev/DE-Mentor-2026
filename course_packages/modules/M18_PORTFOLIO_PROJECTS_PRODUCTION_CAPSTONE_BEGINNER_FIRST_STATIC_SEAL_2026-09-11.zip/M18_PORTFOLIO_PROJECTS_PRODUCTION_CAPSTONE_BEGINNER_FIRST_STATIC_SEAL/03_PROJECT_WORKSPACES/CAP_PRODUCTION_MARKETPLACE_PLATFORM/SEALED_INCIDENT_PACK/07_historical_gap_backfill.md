A two-day historical gap is discovered after newer data exists. Backfill a bounded range without corrupting newer state.
