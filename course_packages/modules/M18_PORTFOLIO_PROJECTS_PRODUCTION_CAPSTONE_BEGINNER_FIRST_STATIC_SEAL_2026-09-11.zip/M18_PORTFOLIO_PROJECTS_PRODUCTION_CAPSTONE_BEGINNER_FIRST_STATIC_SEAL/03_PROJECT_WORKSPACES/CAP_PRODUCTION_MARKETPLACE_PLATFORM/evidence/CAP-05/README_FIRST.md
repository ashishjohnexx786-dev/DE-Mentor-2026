# CAP-05

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 18
Protected Review page: 7
Artifact contract: models/SQL/dbt + lineage + row-count controls
Validation: State output grain; test key/cardinality; reconcile critical measures to an independent control query.
Changed/failure test: PHASE CHECK CAP-05: one changed-input or broken-assumption test must be run and documented before mastery.
Next: CAP-06
