# CAP-03

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 12
Protected Review page: 5
Artifact contract: raw/landing evidence + run_metadata.json
Validation: Source rows/events reconcile to raw + quarantine + deliberate duplicate handling; raw evidence remains replayable.
Changed/failure test: PHASE CHECK CAP-03: one changed-input or broken-assumption test must be run and documented before mastery.
Next: CAP-04
