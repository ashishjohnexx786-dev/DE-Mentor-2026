# CAP-06

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 21
Protected Review page: 8
Artifact contract: cap_phase_artifact + evidence note
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: PHASE CHECK CAP-06: one changed-input or broken-assumption test must be run and documented before mastery.
Next: CAP-07
