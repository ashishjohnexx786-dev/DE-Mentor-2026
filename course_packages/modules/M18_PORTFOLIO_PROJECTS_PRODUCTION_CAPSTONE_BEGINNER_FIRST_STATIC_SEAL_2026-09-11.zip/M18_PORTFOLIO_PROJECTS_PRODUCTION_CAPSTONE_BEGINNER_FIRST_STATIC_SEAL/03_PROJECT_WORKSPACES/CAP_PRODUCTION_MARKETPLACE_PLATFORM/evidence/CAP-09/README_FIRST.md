# CAP-09

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 30
Protected Review page: 11
Artifact contract: README.md + runbook.md + evidence_index.md
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: PHASE CHECK CAP-09: one changed-input or broken-assumption test must be run and documented before mastery.
Next: CAP-10
