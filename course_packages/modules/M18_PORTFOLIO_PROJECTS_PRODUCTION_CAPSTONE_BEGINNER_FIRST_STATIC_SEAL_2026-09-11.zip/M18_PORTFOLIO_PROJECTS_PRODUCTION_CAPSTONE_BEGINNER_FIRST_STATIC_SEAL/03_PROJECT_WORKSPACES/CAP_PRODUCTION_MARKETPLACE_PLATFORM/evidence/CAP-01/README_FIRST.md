# CAP-01

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 6
Protected Review page: 3
Artifact contract: source_contracts.md
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: Add/remove/change one field according to supplied compatibility rule; quarantine/fail safely rather than silently corrupt.
Next: CAP-02
