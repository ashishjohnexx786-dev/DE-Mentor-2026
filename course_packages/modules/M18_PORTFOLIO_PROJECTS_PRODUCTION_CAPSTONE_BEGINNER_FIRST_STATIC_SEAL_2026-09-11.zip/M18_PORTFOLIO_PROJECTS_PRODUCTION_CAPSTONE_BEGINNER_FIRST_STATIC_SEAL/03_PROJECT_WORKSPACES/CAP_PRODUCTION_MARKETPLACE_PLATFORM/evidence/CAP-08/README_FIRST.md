# CAP-08

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 27
Protected Review page: 10
Artifact contract: Fabric deployment design + connection/access/secret boundary notes
Validation: Map identities/connections/access/secret boundaries; prove no plaintext secret or broad unsafe access is required.
Changed/failure test: PHASE CHECK CAP-08: one changed-input or broken-assumption test must be run and documented before mastery.
Next: CAP-09
