# CAP-11

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 36
Protected Review page: 13
Artifact contract: state ledger/watermark + rerun/backfill evidence
Validation: Run same input twice and prove trusted logical result is stable; then add a changed/new record and prove only intended state changes.
Changed/failure test: Replay the same batch/event plus one late/changed record; detect duplicate/logical-state corruption if implementation is unsafe.
Next: CAP-12
