# CAP-12

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 39
Protected Review page: 14
Artifact contract: defense_notes.md + reviewer checklist
Validation: Reviewer can locate every evidence artifact and challenge one design trade-off; learner explains limitation and recovery path without reading a script.
Changed/failure test: PHASE CHECK CAP-12: one changed-input or broken-assumption test must be run and documented before mastery.
Next: M19 DE19-01
