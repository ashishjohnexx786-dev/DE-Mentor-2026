# CAP-04

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 15
Protected Review page: 6
Artifact contract: tests/ + reconciliation report + quarantine evidence
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: PHASE CHECK CAP-04: one changed-input or broken-assumption test must be run and documented before mastery.
Next: CAP-05
