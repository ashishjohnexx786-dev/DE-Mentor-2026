# M18 Production Capstone learner starter

Do not open `SEALED_INCIDENT_PACK` until CAP-10. Build from source contracts and evidence gates; a starter file existing is not evidence of completion.
