def test_replace_with_real_publish_gate():
    assert True  # placeholder: replace during CAP-04/CAP-09
