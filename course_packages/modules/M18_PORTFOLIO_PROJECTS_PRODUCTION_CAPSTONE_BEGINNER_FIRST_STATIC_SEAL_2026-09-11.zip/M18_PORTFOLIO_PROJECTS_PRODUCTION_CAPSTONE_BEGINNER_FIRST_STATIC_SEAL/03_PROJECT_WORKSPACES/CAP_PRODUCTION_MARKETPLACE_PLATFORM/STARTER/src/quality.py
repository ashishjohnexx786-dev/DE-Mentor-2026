def evaluate_publish_eligibility(records, contracts):
    raise NotImplementedError("CAP-04: blocking quality/quarantine/reconciliation")
