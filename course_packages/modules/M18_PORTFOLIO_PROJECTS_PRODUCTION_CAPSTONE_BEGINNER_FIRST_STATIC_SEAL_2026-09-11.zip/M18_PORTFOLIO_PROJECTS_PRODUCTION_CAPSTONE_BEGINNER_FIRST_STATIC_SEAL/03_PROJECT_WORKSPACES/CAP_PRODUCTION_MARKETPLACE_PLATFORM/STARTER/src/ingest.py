"""Capstone learner starter - no complete implementation."""

def ingest_sources(config):
    raise NotImplementedError("CAP-03: preserve raw evidence and source/run metadata")
