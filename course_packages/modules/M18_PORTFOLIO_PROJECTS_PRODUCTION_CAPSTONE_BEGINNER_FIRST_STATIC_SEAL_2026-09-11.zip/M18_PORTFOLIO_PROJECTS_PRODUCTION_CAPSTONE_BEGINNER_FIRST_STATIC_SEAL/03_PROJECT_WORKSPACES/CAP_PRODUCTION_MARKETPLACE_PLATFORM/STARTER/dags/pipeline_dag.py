"""CAP-06 orchestration skeleton. Add dependencies/retries/backfill boundaries on learner machine."""
TASKS=["ingest","quality","transform","publish","monitor"]
