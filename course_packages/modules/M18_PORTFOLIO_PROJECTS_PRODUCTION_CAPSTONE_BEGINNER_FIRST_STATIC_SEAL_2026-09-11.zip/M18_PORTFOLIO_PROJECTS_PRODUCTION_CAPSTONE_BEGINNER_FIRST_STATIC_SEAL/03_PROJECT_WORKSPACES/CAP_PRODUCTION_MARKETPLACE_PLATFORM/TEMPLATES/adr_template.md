# ADR-NNN: Decision title

## Context
## Options considered
## Decision
## Consequences / trade-offs
## Failure/recovery implication
## Evidence that would make us revisit
