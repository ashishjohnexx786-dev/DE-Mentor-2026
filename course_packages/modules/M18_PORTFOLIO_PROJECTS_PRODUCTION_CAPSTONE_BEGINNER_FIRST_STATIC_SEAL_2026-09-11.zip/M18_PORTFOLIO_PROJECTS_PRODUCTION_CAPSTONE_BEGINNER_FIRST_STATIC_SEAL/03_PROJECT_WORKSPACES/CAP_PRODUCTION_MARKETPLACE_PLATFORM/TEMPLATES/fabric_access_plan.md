# Fabric deployment/access design

Identity -> permission -> data boundary -> secret location -> monitoring -> rollback/recovery
