# P03 exact phase route

Workspace: `03_PROJECT_WORKSPACES/P03_SCALABLE_LAKEHOUSE_PIPELINE`

For each phase: Project Book -> learner build -> attempt.json -> checker -> protected Review only after saved attempt -> changed retry if needed -> next phase.

## P03-01 - Read the scalable-lakehouse brief and define scale risks
- Project Book start page: 6
- Evidence: `evidence/P03-01/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 3
- Next: P03-02

## P03-02 - Profile event schema, grain, keys and timestamps
- Project Book start page: 9
- Evidence: `evidence/P03-02/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 4
- Next: P03-03

## P03-03 - Create Spark environment and explicit schemas
- Project Book start page: 12
- Evidence: `evidence/P03-03/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 5
- Next: P03-04

## P03-04 - Build deterministic distributed transformations
- Project Book start page: 15
- Evidence: `evidence/P03-04/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 6
- Next: P03-05

## P03-05 - Join reference data and validate cardinality
- Project Book start page: 18
- Evidence: `evidence/P03-05/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 7
- Next: P03-06

## P03-06 - Reason about partitions, shuffle and skew
- Project Book start page: 21
- Evidence: `evidence/P03-06/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 8
- Next: P03-07

## P03-07 - Write Parquet with justified partition strategy
- Project Book start page: 24
- Evidence: `evidence/P03-07/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 9
- Next: P03-08

## P03-08 - Apply Delta-style incremental merge/idempotency
- Project Book start page: 27
- Evidence: `evidence/P03-08/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 10
- Next: P03-09

## P03-09 - Define Bronze/Silver/Gold lakehouse contracts
- Project Book start page: 30
- Evidence: `evidence/P03-09/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 11
- Next: P03-10

## P03-10 - Handle schema evolution and supplied failure cases
- Project Book start page: 33
- Evidence: `evidence/P03-10/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 12
- Next: P03-11

## P03-11 - Inspect plans/performance and prove equivalent results
- Project Book start page: 36
- Evidence: `evidence/P03-11/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 13
- Next: P03-12

## P03-12 - Map the design to Fabric/cloud deployment
- Project Book start page: 39
- Evidence: `evidence/P03-12/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 14
- Next: P03-13

## P03-13 - Clean rerun, reconcile outputs and defend trade-offs
- Project Book start page: 42
- Evidence: `evidence/P03-13/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 15
- Next: CAP-01
