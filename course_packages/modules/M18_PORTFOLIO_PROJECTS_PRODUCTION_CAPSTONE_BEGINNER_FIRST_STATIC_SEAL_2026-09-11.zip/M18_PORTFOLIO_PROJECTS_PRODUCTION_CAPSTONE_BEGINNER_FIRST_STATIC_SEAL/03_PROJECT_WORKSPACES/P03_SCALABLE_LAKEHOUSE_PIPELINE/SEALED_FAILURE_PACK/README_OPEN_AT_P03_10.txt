STOP. Open only after your first P03 lakehouse attempt is saved. These are changed inputs, not solutions.
