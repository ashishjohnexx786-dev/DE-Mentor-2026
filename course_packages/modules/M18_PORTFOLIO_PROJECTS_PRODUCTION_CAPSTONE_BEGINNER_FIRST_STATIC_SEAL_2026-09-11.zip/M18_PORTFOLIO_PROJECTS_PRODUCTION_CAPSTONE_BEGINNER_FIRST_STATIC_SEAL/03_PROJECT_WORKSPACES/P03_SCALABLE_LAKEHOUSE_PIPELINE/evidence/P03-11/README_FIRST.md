# P03-11

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 36
Protected Review page: 13
Artifact contract: Spark job/notebook + explain plan + partition/performance evidence
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.
Changed/failure test: PHASE CHECK P03-11: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P03-12
