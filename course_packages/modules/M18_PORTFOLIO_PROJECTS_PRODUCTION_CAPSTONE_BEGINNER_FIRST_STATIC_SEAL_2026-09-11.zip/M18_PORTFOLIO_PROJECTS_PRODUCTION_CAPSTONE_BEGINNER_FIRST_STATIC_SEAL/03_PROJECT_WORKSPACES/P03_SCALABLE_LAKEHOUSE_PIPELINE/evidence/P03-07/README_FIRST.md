# P03-07

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 24
Protected Review page: 9
Artifact contract: Spark job/notebook + explain plan + partition/performance evidence
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.
Changed/failure test: Supply skewed/unbalanced input and require correctness-preserving diagnosis; optimization is secondary to invariant safety.
Next: P03-08
