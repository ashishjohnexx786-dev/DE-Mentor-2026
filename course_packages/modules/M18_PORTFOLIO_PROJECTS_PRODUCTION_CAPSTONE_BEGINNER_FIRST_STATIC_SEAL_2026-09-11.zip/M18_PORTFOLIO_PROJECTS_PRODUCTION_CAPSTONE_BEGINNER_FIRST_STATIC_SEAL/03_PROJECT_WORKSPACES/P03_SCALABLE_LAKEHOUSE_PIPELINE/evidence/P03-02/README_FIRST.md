# P03-02

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 9
Protected Review page: 4
Artifact contract: source_profile/ + grain_key_defects.md
Validation: Record row counts, grain, keys, null/duplicate/schema defects; independently sample-check at least one finding.
Changed/failure test: Add/remove/change one field according to supplied compatibility rule; quarantine/fail safely rather than silently corrupt.
Next: P03-03
