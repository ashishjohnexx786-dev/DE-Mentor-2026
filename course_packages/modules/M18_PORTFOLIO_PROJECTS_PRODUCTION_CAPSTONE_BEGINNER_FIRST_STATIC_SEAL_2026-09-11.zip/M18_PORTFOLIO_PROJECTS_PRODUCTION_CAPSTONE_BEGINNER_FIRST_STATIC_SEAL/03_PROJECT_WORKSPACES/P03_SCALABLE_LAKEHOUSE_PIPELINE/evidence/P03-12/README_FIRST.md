# P03-12

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 39
Protected Review page: 14
Artifact contract: Fabric deployment design + connection/access/secret boundary notes
Validation: Map identities/connections/access/secret boundaries; prove no plaintext secret or broad unsafe access is required.
Changed/failure test: PHASE CHECK P03-12: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P03-13
