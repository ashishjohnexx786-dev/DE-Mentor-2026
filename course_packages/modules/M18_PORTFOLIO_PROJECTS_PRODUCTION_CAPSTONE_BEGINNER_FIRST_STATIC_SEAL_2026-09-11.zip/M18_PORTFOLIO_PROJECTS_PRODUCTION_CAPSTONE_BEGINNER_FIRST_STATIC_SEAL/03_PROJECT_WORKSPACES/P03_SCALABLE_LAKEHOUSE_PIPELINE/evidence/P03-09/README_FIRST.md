# P03-09

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 30
Protected Review page: 11
Artifact contract: source_contracts.md
Validation: Read outputs back, verify schema/counts/keys, and prove partition/schema-evolution behavior on a changed input.
Changed/failure test: Add/remove/change one field according to supplied compatibility rule; quarantine/fail safely rather than silently corrupt.
Next: P03-10
