# P03-05

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 18
Protected Review page: 7
Artifact contract: p03_phase_artifact + evidence note
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: Inject one duplicate dimension/reference key or one-to-many fan-out risk and prove the validation catches it.
Next: P03-06
