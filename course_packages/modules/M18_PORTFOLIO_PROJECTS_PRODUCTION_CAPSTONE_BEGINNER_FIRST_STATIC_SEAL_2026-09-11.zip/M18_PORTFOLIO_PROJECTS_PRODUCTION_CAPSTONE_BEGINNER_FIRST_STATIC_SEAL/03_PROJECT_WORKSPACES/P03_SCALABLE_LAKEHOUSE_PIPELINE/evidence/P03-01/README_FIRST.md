# P03-01

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 6
Protected Review page: 3
Artifact contract: business_questions.md + assumptions.md
Validation: Read outputs back, verify schema/counts/keys, and prove partition/schema-evolution behavior on a changed input.
Changed/failure test: PHASE CHECK P03-01: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P03-02
