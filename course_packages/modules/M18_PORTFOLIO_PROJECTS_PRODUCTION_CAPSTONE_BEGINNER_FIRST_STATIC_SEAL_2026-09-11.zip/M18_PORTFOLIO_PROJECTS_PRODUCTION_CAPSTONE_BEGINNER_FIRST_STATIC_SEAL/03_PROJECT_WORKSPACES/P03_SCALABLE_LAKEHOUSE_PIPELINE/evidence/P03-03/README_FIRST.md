# P03-03

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 12
Protected Review page: 5
Artifact contract: Spark job/notebook + explain plan + partition/performance evidence
Validation: Compare output to small trusted control result; inspect plan/partitions; justify performance choice without changing correctness.
Changed/failure test: Add/remove/change one field according to supplied compatibility rule; quarantine/fail safely rather than silently corrupt.
Next: P03-04
