# P03-10

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 33
Protected Review page: 12
Artifact contract: first-failure evidence + root_cause.md + repair + fresh retry evidence
Validation: Save first failing evidence before repair; identify root cause; apply smallest safe repair; fresh retry must pass all prior controls.
Changed/failure test: MANDATORY SUPPLIED FAILURE: capture first failure, diagnose, repair, fresh retry; do not overwrite original evidence.
Next: P03-11
