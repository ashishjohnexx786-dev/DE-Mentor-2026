# Fabric deployment translation

## OneLake/Lakehouse
- 
## Pipeline/notebook responsibility
- 
## Identity/secret boundary
- 
## Monitoring
- 
## What is still unexecuted locally/cloud
- 
