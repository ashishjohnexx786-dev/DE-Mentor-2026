# P03 learner repository starter

Use Spark/Delta when your learner machine supports the pinned environment. This package does not claim Spark/Delta runtime execution. Do not open the failure pack before P03-10.
