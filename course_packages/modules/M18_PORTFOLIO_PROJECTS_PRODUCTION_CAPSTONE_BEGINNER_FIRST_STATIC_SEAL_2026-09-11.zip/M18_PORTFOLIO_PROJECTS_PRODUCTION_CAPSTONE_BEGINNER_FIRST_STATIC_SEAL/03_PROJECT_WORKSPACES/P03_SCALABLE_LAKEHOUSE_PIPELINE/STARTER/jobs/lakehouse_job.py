"""P03 learner Spark/Delta starter. Intentionally incomplete."""

def explicit_schema():
    raise NotImplementedError("P03-03: define StructType explicitly")

def build_silver(events, hubs):
    raise NotImplementedError("P03-04/05: deterministic transform + cardinality-safe join")

def merge_incremental(current, incoming):
    raise NotImplementedError("P03-08: define key/order/idempotency semantics")
