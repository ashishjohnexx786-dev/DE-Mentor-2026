# P01-05

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 18
Protected Review page: 7
Artifact contract: ingestion code + validation/quarantine outputs
Validation: Source rows/events reconcile to raw + quarantine + deliberate duplicate handling; raw evidence remains replayable.
Changed/failure test: PHASE CHECK P01-05: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P01-06
