# P01-08

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 27
Protected Review page: 10
Artifact contract: tests/ + reconciliation report + quarantine evidence
Validation: Define expected invariant before execution, run task, compare actual vs expected, and save one independent control check.
Changed/failure test: PHASE CHECK P01-08: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P01-09
