# P01-03

Do not rename `attempt_template.json` to `attempt.json` until you begin a genuine attempt.

Book page: 12
Protected Review page: 5
Artifact contract: architecture.md/diagram + ADRs
Validation: Trace every source to trusted/serving output; identify one failure boundary and replay/recovery path.
Changed/failure test: PHASE CHECK P01-03: one changed-input or broken-assumption test must be run and documented before mastery.
Next: P01-04
