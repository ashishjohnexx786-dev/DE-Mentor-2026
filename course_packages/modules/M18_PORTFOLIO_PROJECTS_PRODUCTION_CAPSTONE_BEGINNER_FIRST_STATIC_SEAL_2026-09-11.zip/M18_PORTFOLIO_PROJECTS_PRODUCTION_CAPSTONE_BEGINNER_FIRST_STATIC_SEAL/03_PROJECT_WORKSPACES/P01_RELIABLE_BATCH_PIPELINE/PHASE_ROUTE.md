# P01 exact phase route

Workspace: `03_PROJECT_WORKSPACES/P01_RELIABLE_BATCH_PIPELINE`

For each phase: Project Book -> learner build -> attempt.json -> checker -> protected Review only after saved attempt -> changed retry if needed -> next phase.

## P01-01 - Read the batch-pipeline brief and define business questions
- Project Book start page: 6
- Evidence: `evidence/P01-01/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 3
- Next: P01-02

## P01-02 - Profile every source; state grain, keys and defects
- Project Book start page: 9
- Evidence: `evidence/P01-02/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 4
- Next: P01-03

## P01-03 - Draw architecture and create the repository scaffold
- Project Book start page: 12
- Evidence: `evidence/P01-03/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 5
- Next: P01-04

## P01-04 - Preserve raw landing evidence and source/run metadata
- Project Book start page: 15
- Evidence: `evidence/P01-04/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 6
- Next: P01-05

## P01-05 - Build ingestion with validation and quarantine
- Project Book start page: 18
- Evidence: `evidence/P01-05/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 7
- Next: P01-06

## P01-06 - Add incremental state and rerun-safe identity
- Project Book start page: 21
- Evidence: `evidence/P01-06/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 8
- Next: P01-07

## P01-07 - Build trusted PostgreSQL/dbt-style transformations
- Project Book start page: 24
- Evidence: `evidence/P01-07/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 9
- Next: P01-08

## P01-08 - Add tests and source-to-target reconciliation
- Project Book start page: 27
- Evidence: `evidence/P01-08/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 10
- Next: P01-09

## P01-09 - Automate the repeatable run/orchestration path
- Project Book start page: 30
- Evidence: `evidence/P01-09/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 11
- Next: P01-10

## P01-10 - Inject failure, diagnose, repair and prove recovery
- Project Book start page: 33
- Evidence: `evidence/P01-10/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 12
- Next: P01-11

## P01-11 - Finish README, runbook, architecture and evidence index
- Project Book start page: 36
- Evidence: `evidence/P01-11/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 13
- Next: P01-12

## P01-12 - Clean-clone rerun and project defense
- Project Book start page: 39
- Evidence: `evidence/P01-12/attempt.json` (create only when genuine attempt starts)
- Protected Review page: 14
- Next: P02-01
