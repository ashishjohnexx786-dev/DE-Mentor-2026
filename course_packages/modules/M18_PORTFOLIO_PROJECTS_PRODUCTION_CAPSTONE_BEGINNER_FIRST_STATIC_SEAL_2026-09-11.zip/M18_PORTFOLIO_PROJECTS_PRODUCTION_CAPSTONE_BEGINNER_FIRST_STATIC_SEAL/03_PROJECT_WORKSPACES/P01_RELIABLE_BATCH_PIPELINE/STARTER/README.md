# P01 learner repository starter

Start at P01-01. Do not open `SEALED_INCIDENT_PACK` until P01-10. The starter contains structure, not a completed pipeline.

Expected build areas: `src/`, `tests/`, `raw/`, `quarantine/`, `trusted/`, `state/`, `evidence/`.
