def test_replace_with_your_first_real_contract_test():
    # Replace this placeholder during P01-08. A green placeholder is not mastery.
    assert True
