"""P01 learner starter. Implement one phase at a time; no final solution is supplied."""
from pathlib import Path

def land_raw(source_path: Path, raw_dir: Path):
    raise NotImplementedError("P01-04: preserve bytes + run/source metadata")

def validate_orders(rows, known_customer_ids):
    raise NotImplementedError("P01-05: return accepted + quarantined with reasons")

def update_state(state_path: Path, accepted_rows):
    raise NotImplementedError("P01-06: design rerun-safe identity/state")

def publish_trusted(accepted_rows, target):
    raise NotImplementedError("P01-07: publish trusted output without double counting")
