# P01 Architecture

Source -> Raw -> Validation/Quarantine -> Trusted -> Serving

## Failure boundaries
- 

## Recovery/replay rule
- 
