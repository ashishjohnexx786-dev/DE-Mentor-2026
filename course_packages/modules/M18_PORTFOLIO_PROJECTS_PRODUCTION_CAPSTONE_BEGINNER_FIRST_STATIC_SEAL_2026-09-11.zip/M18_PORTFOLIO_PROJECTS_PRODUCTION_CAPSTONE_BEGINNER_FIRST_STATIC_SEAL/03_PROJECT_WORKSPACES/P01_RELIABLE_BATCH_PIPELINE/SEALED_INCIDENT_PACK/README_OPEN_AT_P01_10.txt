STOP. Open only after the first end-to-end attempt is saved. These are failure inputs, not solutions.
