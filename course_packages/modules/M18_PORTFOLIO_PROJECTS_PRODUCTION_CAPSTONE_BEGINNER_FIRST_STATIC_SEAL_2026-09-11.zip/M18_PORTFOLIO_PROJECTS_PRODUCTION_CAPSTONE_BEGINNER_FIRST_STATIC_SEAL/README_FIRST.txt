M18 - PORTFOLIO PROJECTS / PRODUCTION CAPSTONE - BEGINNER-FIRST STATIC SEAL CANDIDATE

Start: 00_START_HERE -> 01_PROJECT_HANDBOOK -> project books/workspaces.
Canonical projects/phases preserved: P01 12, P02 13, P03 13, CAP 12 = 50 phases.
Every phase now uses the 16-stage beginner-first teaching contract across three pages.
Starters remain intentionally incomplete; no solved project implementation is supplied.
Protected Review opens only after saved matching attempt. Original/failed attempts remain append-only.
Evidence checker proves structure only, not technical mastery.
Static package does NOT claim live PostgreSQL/dbt/Airflow/Docker/Spark/Delta/Fabric/GitHub Actions.
Canonical exit: M18 -> M19 -> G07.
Production Mentor/GitHub remain untouched in this rebuild wave.
