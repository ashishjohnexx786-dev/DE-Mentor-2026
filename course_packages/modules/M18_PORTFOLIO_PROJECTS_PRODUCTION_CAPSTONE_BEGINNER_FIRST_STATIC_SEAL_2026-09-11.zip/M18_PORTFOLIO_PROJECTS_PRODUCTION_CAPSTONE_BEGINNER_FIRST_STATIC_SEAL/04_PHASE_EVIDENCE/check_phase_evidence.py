import json,sys,pathlib
root=pathlib.Path(sys.argv[1]); phase=sys.argv[2]
mp=json.load(open(root/'CONTROL/M18_PHASE_ARTIFACT_MAP.json',encoding='utf-8'))
if phase not in mp:
 print(json.dumps({'status':'UNKNOWN_PHASE','phase':phase},indent=2)); sys.exit(3)
p=root/mp[phase]['evidence_path']
if not p.exists():
 print(json.dumps({'status':'NO_ATTEMPT_SAVED','expected_path':str(p.relative_to(root))},indent=2)); sys.exit(2)
d=json.load(open(p,encoding='utf-8'))
checks={
 'phase_id_matches':d.get('phase_id')==phase,
 'artifact_paths_recorded':len(d.get('artifact_paths',[]))>=1,
 'expected_invariant':bool(d.get('validation',{}).get('expected_invariant')),
 'actual_result':bool(d.get('validation',{}).get('actual_result')),
 'independent_control':bool(d.get('validation',{}).get('independent_control')),
 'changed_or_failure_test':bool(d.get('changed_or_failure_test',{}).get('change_injected')),
 'fresh_retry_or_first_result':bool(d.get('changed_or_failure_test',{}).get('fresh_retry_result') or d.get('changed_or_failure_test',{}).get('first_result')),
 'runtime_truth':bool(d.get('runtime_truth',{}).get('executed') or d.get('runtime_truth',{}).get('not_executed') or d.get('runtime_truth',{}).get('simulated_or_static')),
 'explain_back':len(str(d.get('explain_back','')).strip())>=30,
 'critical_failure_resolved':str(d.get('unresolved_critical_failure','')).strip().lower() in ('none','no','resolved','n/a')
}
missing=[k for k,v in checks.items() if not v]
print(json.dumps({'status':'EVIDENCE_STRUCTURALLY_COMPLETE_FOR_REVIEW' if not missing else 'INCOMPLETE','phase':phase,'checks':checks,'missing':missing,'note':'Structure only. Human/technical review decides correctness and mastery.'},indent=2))
sys.exit(0 if not missing else 2)
