-- M07 bulk-load + role boundary teaching lab.
-- VERIFY current_database() = stage07_de before running.
SELECT current_database();

CREATE TABLE IF NOT EXISTS source.stg_customers (
    customer_id text,
    customer_name text,
    region text,
    segment text
);

-- Load PRACTICE_DATA/stage07_postgres_lab/customers.csv using ONE approach:
-- A) psql terminal:
-- \copy source.stg_customers FROM 'customers.csv' WITH (FORMAT csv, HEADER true)
-- B) pgAdmin: right-click source.stg_customers -> Import/Export Data -> Import CSV with Header.
-- Do not paste \copy into pgAdmin Query Tool; it is a psql client command.

SELECT COUNT(*) AS staging_rows FROM source.stg_customers;

-- Optional role practice if your local account has permission:
-- CREATE ROLE stage07_reader NOLOGIN;
-- GRANT USAGE ON SCHEMA warehouse TO stage07_reader;
-- GRANT SELECT ON ALL TABLES IN SCHEMA warehouse TO stage07_reader;
