M07 POSTGRESQL + DATA MODELING - TEACHING RC2
START: 00_START_HERE_TEACHING_RC2.pdf
Reuse PostgreSQL; do not reinstall.
Create/use dedicated stage07_de and verify current_database() before destructive setup.
Learner Book -> Guided -> close guidance -> Independent -> evidence -> Review only after attempt.
