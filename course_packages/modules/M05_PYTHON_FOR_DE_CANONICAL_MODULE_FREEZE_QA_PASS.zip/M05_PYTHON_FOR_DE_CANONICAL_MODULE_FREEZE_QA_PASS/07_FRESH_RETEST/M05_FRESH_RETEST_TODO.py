"""Changed-domain retest scaffold. This is not the original practical and does not erase it."""
# Use data/retest/shipments_retest.csv + carriers_retest.csv + local /shipments endpoint.
# Complete only after targeted repair assigns a fresh retry.
raise SystemExit('TODO: complete the assigned changed retest; preserve the original attempt separately.')
