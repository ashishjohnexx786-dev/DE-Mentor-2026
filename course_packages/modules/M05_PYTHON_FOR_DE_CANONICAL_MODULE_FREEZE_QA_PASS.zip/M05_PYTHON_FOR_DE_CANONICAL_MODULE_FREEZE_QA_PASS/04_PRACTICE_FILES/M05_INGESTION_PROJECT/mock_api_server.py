from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json

TOKEN='TRAINING_TOKEN'
ORDERS=[{"order_id": "ORD-001", "order_date": "2026-08-01", "customer_id": "C001", "product": "Keyboard", "qty": 2, "unit_price": 850, "status": "Completed"}, {"order_id": "ORD-002", "order_date": "2026-08-01", "customer_id": "C002", "product": "Mouse", "qty": 3, "unit_price": 450, "status": "Completed"}, {"order_id": "ORD-003", "order_date": "2026-08-02", "customer_id": "C003", "product": "USB Cable", "qty": 5, "unit_price": 220, "status": "Completed"}, {"order_id": "ORD-004", "order_date": "2026-08-02", "customer_id": "C004", "product": "Laptop Stand", "qty": 1, "unit_price": 1200, "status": "Pending"}, {"order_id": "ORD-005", "order_date": "2026-08-03", "customer_id": "C001", "product": "Mouse", "qty": 4, "unit_price": 450, "status": "Completed"}, {"order_id": "ORD-006", "order_date": "2026-08-03", "customer_id": "C002", "product": "Laptop Stand", "qty": 2, "unit_price": 1200, "status": "Completed"}, {"order_id": "ORD-007", "order_date": "2026-08-04", "customer_id": "C003", "product": "Keyboard", "qty": 1, "unit_price": 850, "status": "Completed"}, {"order_id": "ORD-008", "order_date": "2026-08-04", "customer_id": "C004", "product": "USB Cable", "qty": 8, "unit_price": 220, "status": "Completed"}, {"order_id": "ORD-009", "order_date": "2026-08-05", "customer_id": "C001", "product": "Laptop Stand", "qty": 2, "unit_price": 1200, "status": "Completed"}, {"order_id": "ORD-010", "order_date": "2026-08-05", "customer_id": "C002", "product": "Keyboard", "qty": 3, "unit_price": 850, "status": "Completed"}, {"order_id": "ORD-011", "order_date": "2026-08-06", "customer_id": "C003", "product": "Mouse", "qty": 2, "unit_price": 450, "status": "Cancelled"}, {"order_id": "ORD-012", "order_date": "2026-08-06", "customer_id": "C004", "product": "USB Cable", "qty": 6, "unit_price": 220, "status": "Completed"}]
SHIPMENTS=[{"shipment_id": "S5001", "ship_date": "2026-08-15", "carrier_id": "CR01", "hub": "East", "units": 3, "unit_value": 820, "status": "Delivered", "coordinator": "Nina"}, {"shipment_id": "S5002", "ship_date": "2026-08-15", "carrier_id": "CR02", "hub": "West", "units": 2, "unit_value": 1250, "status": "Delivered", "coordinator": "Arun"}, {"shipment_id": "S5003", "ship_date": "2026-08-15", "carrier_id": "CR03", "hub": "North", "units": 5, "unit_value": 410, "status": "In Transit", "coordinator": "Mira"}, {"shipment_id": "S5004", "ship_date": "2026-08-16", "carrier_id": "CR04", "hub": "South", "units": 4, "unit_value": 620, "status": "Delivered", "coordinator": "Kabir"}, {"shipment_id": "S5005", "ship_date": "2026-08-16", "carrier_id": "CR01", "hub": "East", "units": 0, "unit_value": 900, "status": "Delivered", "coordinator": "Nina"}, {"shipment_id": "S5006", "ship_date": "bad-date", "carrier_id": "CR03", "hub": "North", "units": 2, "unit_value": 780, "status": "Delivered", "coordinator": "Mira"}, {"shipment_id": "S5007", "ship_date": "2026-08-17", "carrier_id": "", "hub": "West", "units": 1, "unit_value": 1350, "status": "Delivered", "coordinator": "Arun"}, {"shipment_id": "S5008", "ship_date": "2026-08-17", "carrier_id": "CR99", "hub": "East", "units": 3, "unit_value": 700, "status": "Delivered", "coordinator": ""}, {"shipment_id": "S5010", "ship_date": "2026-08-18", "carrier_id": "CR04", "hub": "South", "units": 2, "unit_value": 540, "status": "UNKNOWN", "coordinator": "Kabir"}, {"shipment_id": "S5011", "ship_date": "2026-08-19", "carrier_id": "CR03", "hub": "North", "units": 3, "unit_value": 960, "status": "Delivered", "coordinator": "Mira"}, {"shipment_id": "S5011", "ship_date": "2026-08-19", "carrier_id": "CR03", "hub": "North", "units": 3, "unit_value": 960, "status": "Delivered", "coordinator": "Mira"}]
STATE={'fail_once':0,'rate_limit_once':0}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return
    def send_json(self, code, payload, extra=None):
        body=json.dumps(payload).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(body)))
        if extra:
            for k,v in extra.items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path=='/health': return self.send_json(200,{'status':'ok'})
        if u.path=='/missing': return self.send_json(404,{'error':'not_found'})
        if u.path not in ['/orders','/shipments']: return self.send_json(404,{'error':'not_found'})
        if self.headers.get('Authorization') != f'Bearer {TOKEN}': return self.send_json(401,{'error':'unauthorized'})
        if q.get('fail')==['1']: return self.send_json(500,{'error':'training_server_failure'})
        if q.get('fail_once')==['1'] and STATE['fail_once']==0:
            STATE['fail_once']+=1; return self.send_json(503,{'error':'transient_once'})
        if q.get('rate_limit_once')==['1'] and STATE['rate_limit_once']==0:
            STATE['rate_limit_once']+=1; return self.send_json(429,{'error':'rate_limited_once'},{'Retry-After':'1'})
        data=ORDERS if u.path=='/orders' else SHIPMENTS
        page=max(1,int(q.get('page',['1'])[0])); per=max(1,min(10,int(q.get('per_page',['4'])[0])))
        start=(page-1)*per; items=data[start:start+per]
        next_page=page+1 if start+per<len(data) else None
        payload={'items':items,'page':page,'per_page':per,'next_page':next_page,'total':len(data)}
        if q.get('bad_payload')==['1']: payload.pop('items',None)
        return self.send_json(200,payload)

def main():
    print('M05 local training API: http://127.0.0.1:8765  token=TRAINING_TOKEN')
    HTTPServer(('127.0.0.1',8765),Handler).serve_forever()

if __name__=='__main__': main()
