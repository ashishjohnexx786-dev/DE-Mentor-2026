# M05 Python for Data Engineering - learner project

This is a learner scaffold, not a completed solution. Protected reviews are outside this folder.

## Study rule
Assigned video/support route -> close it -> SOLO Teaching Book -> guided reproduction -> independent task -> validate -> explain in your own words -> only then protected Review if needed -> changed retry -> save evidence.

## Tool timing
- Python already exists from M04.
- pandas was first installed at M04 DE04-11; verify it rather than reinstalling blindly.
- Install **Pydantic** at DE05-07 only.
- Start the bundled stdlib HTTP server at DE05-08; **requests** is first installed at DE05-09.
- Reuse the M03 PostgreSQL install at DE05-12; install **SQLAlchemy + psycopg** only then.
- Install **pytest** at DE05-14 only.
- Do not install WSL/Git here (M06). Do not install Docker/Airflow here (M10).
- `requirements_final.txt` is an end-state reproducibility record, not a start-of-module install command.

Use only fake `TRAINING_TOKEN` in course practice. Never place real credentials in source, screenshots, logs or submitted evidence.
