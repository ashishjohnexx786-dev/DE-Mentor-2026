from src.order_utils import gross_sales, normalize_product

def test_gross_sales():
    assert gross_sales(2, '850') == 1700

def test_normalize_product():
    assert normalize_product('  USB   Cable ') == 'USB Cable'
