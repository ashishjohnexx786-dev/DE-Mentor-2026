from decimal import Decimal

def gross_sales(qty, unit_price):
    return Decimal(str(qty)) * Decimal(str(unit_price))

def normalize_product(value):
    return " ".join(str(value).strip().split())
