"""M05 learner scaffold. Fill TODOs during the named lessons; do not search for a finished solution."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parents[1]

def preserve_source(source: Path, destination: Path):
    # TODO DE05-01/03: copy bytes without transformation; return receipt controls.
    raise NotImplementedError

def profile_batch(path: Path):
    # TODO DE05-04: observed pre-transform profile only.
    raise NotImplementedError

def validate_and_split(path: Path):
    # TODO DE05-05/07: return accepted, rejected + named reasons; account for every row.
    raise NotImplementedError

def transform(accepted):
    # TODO DE05-06: explicit grain/cardinality controls and deterministic transforms.
    raise NotImplementedError

def write_outputs(result, out_dir: Path):
    # TODO DE05-03/15: deterministic paths, atomic/safe state where applicable.
    raise NotImplementedError

if __name__ == '__main__':
    print('M05 scaffold: complete through the lesson route; no solution is bundled.')
