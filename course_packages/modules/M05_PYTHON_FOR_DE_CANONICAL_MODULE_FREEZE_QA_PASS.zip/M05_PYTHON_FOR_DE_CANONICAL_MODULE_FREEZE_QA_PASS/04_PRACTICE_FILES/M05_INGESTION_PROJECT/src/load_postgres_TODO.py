"""Complete at DE05-12. Reuse the existing M03 PostgreSQL install; do not introduce Docker."""
import os

def load_rows(rows, run_id):
    # TODO: read DATABASE_URL from environment, use SQLAlchemy 2.0 transaction, reconcile after load.
    raise NotImplementedError
