M05 CURRENT LEARNER BOOK - RC5 POST-DEPLOY SEMANTIC REPAIR

The 2026-09-11 RC5 learner book supersedes the RC4 learner-book semantic acceptance.
Use 01_LESSONS first. It now follows the explicit 16-stage beginner-first teacher route and makes external source links visibly discoverable.
All protected review / fresh retry rules remain attempt-first. Whole-course FINAL still requires runtime/device evidence.

--- Historical module instructions retained below ---

ZERO TO JOB-READY DATA ENGINEER 2026 - M05 PYTHON FOR DATA ENGINEERING - MODULE FREEZE QA PASS

Canonical count: 15 lessons DE05-01..DE05-15.
This package was regenerated from the canonical lesson registry; the old Freeze-1 package and the prior M05 INTERNAL_QA candidate are references only.
Locked study loop: VIDEO FIRST when assigned -> close source -> SOLO TEACHING BOOK -> guided -> independent -> validate -> explain -> protected Review only after saved attempt -> changed retry if weak -> evidence/mastery.
No percentage can infer mastery. Failed attempts remain in history. G03 remains sealed until M04 + M05 + M06.
No WSL/Git/Docker/Airflow install occurs in M05. PostgreSQL is reused from M03 only at DE05-12.
Course-wide FINAL/Mentor/device/runtime QA is still pending after all modules and Gates are rebuilt.
