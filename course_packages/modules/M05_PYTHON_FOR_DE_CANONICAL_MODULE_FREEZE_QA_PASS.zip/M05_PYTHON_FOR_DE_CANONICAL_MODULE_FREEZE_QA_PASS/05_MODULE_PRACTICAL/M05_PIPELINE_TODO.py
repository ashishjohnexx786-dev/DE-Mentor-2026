"""Independent M05 practical scaffold. No completed solution is bundled."""
# Use data/practical/orders_practical.csv + customers_practical.csv and the local /orders endpoint.
# Prove C1-C9 from the practical PDF with saved evidence.
raise SystemExit('TODO: build after saving your practical plan; protected review remains closed.')
