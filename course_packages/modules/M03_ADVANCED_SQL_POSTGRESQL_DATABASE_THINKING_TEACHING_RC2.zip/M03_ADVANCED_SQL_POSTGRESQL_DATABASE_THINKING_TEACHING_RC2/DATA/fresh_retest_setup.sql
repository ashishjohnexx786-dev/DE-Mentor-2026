DROP TABLE IF EXISTS events; DROP TABLE IF EXISTS members;
CREATE TABLE members(member_id TEXT PRIMARY KEY, member_name TEXT, plan TEXT);
CREATE TABLE events(event_id TEXT PRIMARY KEY, member_id TEXT, event_ts TEXT, event_type TEXT, amount REAL);
INSERT INTO members VALUES ('M1','Ana','Gold'),('M2','Ben','Silver'),('M3','Cara','Gold'),('M4','Dev','Bronze');
INSERT INTO events VALUES ('E1','M1','2026-08-01 10:00','payment',500),('E2','M1','2026-08-05 09:00','support',0),('E3','M2','2026-08-02 11:00','payment',300),('E4','M3','2026-08-03 12:00','payment',500),('E5','M3','2026-08-09 08:00','payment',500),('E6','M4','2026-08-04 14:00','support',0),('E7','M2','2026-08-10 16:00','support',0);
