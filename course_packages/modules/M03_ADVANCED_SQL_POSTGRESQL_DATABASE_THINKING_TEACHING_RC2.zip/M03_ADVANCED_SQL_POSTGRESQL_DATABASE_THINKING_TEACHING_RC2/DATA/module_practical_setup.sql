DROP TABLE IF EXISTS returns; DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS customers;
CREATE TABLE customers(customer_id TEXT PRIMARY KEY, customer_name TEXT, region TEXT);
CREATE TABLE orders(order_id TEXT PRIMARY KEY, customer_id TEXT, order_date TEXT, status TEXT, net_sales REAL);
CREATE TABLE returns(return_id TEXT PRIMARY KEY, order_id TEXT, return_date TEXT);
INSERT INTO customers VALUES ('C1','Asha Retail','East'),('C2','Bharat Stores','West'),('C3','City Mart','East'),('C4','Delta Shop','North');
INSERT INTO orders VALUES ('O1','C1','2026-08-01','Completed',1200),('O2','C1','2026-08-05','Completed',800),('O3','C2','2026-08-02','Completed',1500),('O4','C3','2026-08-03','Cancelled',700),('O5','C3','2026-08-07','Completed',1100),('O6','C4','2026-08-04','Completed',900),('O7','C4','2026-08-08','Completed',1300);
INSERT INTO returns VALUES ('R1','O2','2026-08-10'),('R2','O5','2026-08-12');
