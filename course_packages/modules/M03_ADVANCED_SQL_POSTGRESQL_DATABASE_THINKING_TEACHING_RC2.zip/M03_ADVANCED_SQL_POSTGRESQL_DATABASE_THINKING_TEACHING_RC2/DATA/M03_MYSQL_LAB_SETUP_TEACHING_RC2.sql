-- M03 MYSQL LAB SETUP - TEACHING RC2
-- PURPOSE: supply predictable practice data for DE03-01 through DE03-10 and integrated MySQL practice.
-- BEFORE RUNNING:
-- 1) Open MySQL Workbench.
-- 2) Connect to your local MySQL server used in M02.
-- 3) Open a new SQL tab.
-- 4) Paste/run this entire setup script.
-- 5) At the bottom, confirm the verification counts: 30 orders, 30 customers,
--    15 contacts, 5 returns, 10 tickets.
-- SAFE RESET: this script drops/creates ONLY stage03_retail_lab.
-- If your verification counts differ, STOP before doing lesson queries.

-- ZERO TO JOB-READY DATA ENGINEER 2026
-- Stage 03 - Advanced SQL + Database Thinking
-- MySQL 8+ required for window functions.
-- Safe reset: this script drops/creates ONLY stage03_retail_lab.

DROP DATABASE IF EXISTS stage03_retail_lab;
CREATE DATABASE stage03_retail_lab;
USE stage03_retail_lab;

CREATE TABLE customers (
    customer_id VARCHAR(10) PRIMARY KEY,
    customer_name VARCHAR(60) NOT NULL,
    home_region VARCHAR(20) NOT NULL,
    tier VARCHAR(20) NOT NULL
);

INSERT INTO customers VALUES
('C001','Aarav Traders','East','Silver'),
('C002','Maya Stores','West','Gold'),
('C003','Ravi Retail','North','Gold'),
('C004','Neha Mart','South','Bronze'),
('C005','Sona Shop','East','Silver'),
('C006','Kiran Enterprises','West','Gold'),
('C007','Om Retail','North','Bronze'),
('C008','Tara Stores','South','Silver'),
('C009','Riya Shop','East','Bronze'),
('C010','Dev Traders','West','Gold'),
('C011','Kabir Bazaar','North','Silver'),
('C012','Ravi Wholesale','North','Gold'),
('C013','Anaya Mart','South','Silver'),
('C014','Kabir Stores','East','Gold'),
('C015','Ishita Retail','West','Silver'),
('C016','Vikram Mart','North','Gold'),
('C017','Pooja Shop','South','Bronze'),
('C018','Nitin Traders','East','Silver'),
('C019','Meera Stores','West','Bronze'),
('C020','Saanvi Retail','South','Gold'),
('C021','Arjun Market','East','Silver'),
('C022','Diya Shop','West','Bronze'),
('C023','Reyansh Mart','North','Gold'),
('C024','Aditi Stores','South','Silver'),
('C025','Vihaan Traders','East','Gold'),
('C026','Sara Retail','West','Silver'),
('C027','Yash Mart','North','Bronze'),
('C028','Ira Stores','South','Gold'),
('C029','Mohan Shop','East','Silver'),
('C030','Noor Traders','West','Gold');

CREATE TABLE sales_orders (
    order_id VARCHAR(10) PRIMARY KEY,
    order_date DATE NOT NULL,
    customer_id VARCHAR(10) NOT NULL,
    region VARCHAR(20) NOT NULL,
    category VARCHAR(30) NOT NULL,
    product VARCHAR(50) NOT NULL,
    qty INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    discount_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
    payment_method VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL,
    sales_rep VARCHAR(30) NULL,
    CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO sales_orders
(order_id,order_date,customer_id,region,category,product,qty,unit_price,discount_pct,payment_method,status,sales_rep)
VALUES
('O1001','2026-07-01','C001','East','Accessories','Keyboard',2,850,0.00,'UPI','Completed','Asha'),
('O1002','2026-07-01','C002','West','Accessories','Mouse',3,450,0.05,'Card','Completed','Rohit'),
('O1003','2026-07-02','C003','North','Accessories','USB Cable',5,220,0.00,'Cash','Completed','Asha'),
('O1004','2026-07-02','C004','South','Accessories','Keyboard',1,850,0.10,'UPI','Completed','Meera'),
('O1005','2026-07-03','C005','East','Accessories','Mouse',4,450,0.00,'Card','Completed','Rohit'),
('O1006','2026-07-03','C006','West','Office','Laptop Stand',2,1200,0.10,'UPI','Completed','Asha'),
('O1007','2026-07-04','C007','North','Accessories','USB Cable',8,220,0.05,'Cash','Completed','Meera'),
('O1008','2026-07-04','C008','South','Accessories','Keyboard',2,850,0.00,'Card','Completed','Rohit'),
('O1009','2026-07-05','C009','East','Accessories','Mouse',2,450,0.00,'UPI','Completed','Asha'),
('O1010','2026-07-05','C010','West','Office','Laptop Stand',1,1200,0.00,'Card','Completed','Meera'),
('O1011','2026-07-06','C011','North','Accessories','Keyboard',1,850,0.00,'Cash','Pending','Rohit'),
('O1012','2026-07-06','C012','North','Accessories','Mouse',3,450,0.05,'UPI','Completed','Asha'),
('O1013','2026-07-07','C013','South','Accessories','USB Cable',6,220,0.00,'UPI','Completed','Meera'),
('O1014','2026-07-07','C014','East','Accessories','Keyboard',2,850,0.10,'Card','Completed','Rohit'),
('O1015','2026-07-08','C015','West','Accessories','Mouse',5,450,0.00,'UPI','Completed','Asha'),
('O1016','2026-07-08','C016','North','Office','Laptop Stand',2,1200,0.05,'Card','Completed','Meera'),
('O1017','2026-07-09','C017','South','Accessories','USB Cable',7,220,0.00,'Cash','Completed','Rohit'),
('O1018','2026-07-09','C018','East','Accessories','Keyboard',1,850,0.00,'UPI','Completed','Asha'),
('O1019','2026-07-10','C019','West','Accessories','Mouse',2,450,0.10,'Card','Completed','Meera'),
('O1020','2026-07-10','C020','South','Office','Laptop Stand',3,1200,0.15,'UPI','Completed','Rohit'),
('O1021','2026-07-11','C021','East','Accessories','USB Cable',10,220,0.05,'Cash','Completed','Asha'),
('O1022','2026-07-11','C022','West','Accessories','Keyboard',2,850,0.00,'Card','Cancelled','Meera'),
('O1023','2026-07-12','C023','North','Accessories','Mouse',6,450,0.10,'UPI','Completed','Rohit'),
('O1024','2026-07-12','C024','South','Office','Laptop Stand',1,1200,0.00,'Card','Completed','Asha'),
('O1025','2026-07-13','C025','East','Accessories','Keyboard',3,850,0.05,'UPI','Completed','Meera'),
('O1026','2026-07-13','C026','West','Accessories','USB Cable',9,220,0.00,'Cash','Completed','Rohit'),
('O1027','2026-07-14','C027','North','Office','Laptop Stand',2,1200,0.10,'UPI','Pending','Asha'),
('O1028','2026-07-14','C028','South','Accessories','Mouse',4,450,0.05,'Card','Completed','Meera'),
('O1029','2026-07-15','C029','East','Accessories','USB Cable',5,220,0.00,'UPI','Completed','Rohit'),
('O1030','2026-07-15','C030','West','Accessories','Keyboard',1,850,0.00,'Card','Completed',NULL)
;

CREATE TABLE customer_contacts (
    customer_id VARCHAR(10) NOT NULL,
    contact_type VARCHAR(20) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    PRIMARY KEY (customer_id, contact_type),
    CONSTRAINT fk_contacts_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO customer_contacts VALUES
('C001','Primary','9870000001'),
('C001','Billing','9870000101'),
('C002','Primary','9870000002'),
('C003','Primary','9870000003'),
('C003','Billing','9870000103'),
('C003','Warehouse','9870000203'),
('C004','Primary','9870000004'),
('C005','Primary','9870000005'),
('C005','Billing','9870000105'),
('C006','Primary','9870000006'),
('C007','Primary','9870000007'),
('C008','Primary','9870000008'),
('C009','Primary','9870000009'),
('C010','Primary','9870000010'),
('C010','Billing','9870000110');

CREATE TABLE returns (
    return_id VARCHAR(10) PRIMARY KEY,
    order_id VARCHAR(10) NOT NULL,
    return_date DATE NOT NULL,
    reason VARCHAR(40) NOT NULL,
    return_qty INT NOT NULL,
    CONSTRAINT fk_returns_order FOREIGN KEY (order_id) REFERENCES sales_orders(order_id)
);

INSERT INTO returns VALUES
('R001','O1002','2026-07-04','Damaged',1),
('R002','O1007','2026-07-08','Wrong item',2),
('R003','O1015','2026-07-12','Changed mind',1),
('R004','O1023','2026-07-15','Damaged',1),
('R005','O1026','2026-07-16','Late delivery',2);

CREATE TABLE support_tickets (
    ticket_id VARCHAR(10) PRIMARY KEY,
    customer_id VARCHAR(10) NOT NULL,
    created_at DATETIME NOT NULL,
    status VARCHAR(20) NOT NULL,
    topic VARCHAR(30) NOT NULL,
    CONSTRAINT fk_ticket_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO support_tickets VALUES
('T001','C001','2026-07-01 09:15:00','Open','Delivery'),
('T002','C001','2026-07-05 13:30:00','Closed','Payment'),
('T003','C003','2026-07-02 10:00:00','Closed','Product'),
('T004','C003','2026-07-07 11:45:00','Open','Delivery'),
('T005','C003','2026-07-12 17:20:00','Closed','Returns'),
('T006','C005','2026-07-03 08:30:00','Closed','Payment'),
('T007','C005','2026-07-10 16:10:00','Open','Delivery'),
('T008','C010','2026-07-06 12:00:00','Closed','Product'),
('T009','C010','2026-07-11 09:40:00','Closed','Returns'),
('T010','C020','2026-07-10 14:00:00','Open','Delivery');

-- Verification. Expected: 30 orders, 30 customers, 15 contacts, 5 returns, 10 tickets.
SELECT DATABASE() AS current_database;
SELECT COUNT(*) AS orders FROM sales_orders;
SELECT COUNT(*) AS customers FROM customers;
SELECT COUNT(*) AS contacts FROM customer_contacts;
SELECT COUNT(*) AS returns_count FROM returns;
SELECT COUNT(*) AS tickets FROM support_tickets;
