-- M03 QUERY WORKSPACE - TEACHING RC2
-- This file is deliberately explicit about WHAT you are expected to produce.
-- It does NOT contain the independent solutions.
-- Save a copy of this file as your own attempt.

USE stage03_retail_lab;

-- ============================================================
-- DE03-01 / P01 - SAFE LEFT JOIN
-- Starting tables: sales_orders, customers
-- Business question: keep every Completed West order even if customer details are missing.
-- Output: order_id, customer_id, customer_name, tier, net_sales.
-- Before SQL: write your intended output grain as a comment.
-- Self-check: eligible-order count before join must equal result distinct order_id count.
-- ============================================================


-- ============================================================
-- DE03-02 / P02 - CARDINALITY AUDIT
-- Starting tables: sales_orders, customer_contacts
-- Deliver:
--   1) base order row count
--   2) joined row count
--   3) distinct order_id count after join
--   4) list of order_ids that appear more than once
-- Self-check anchors: 30 base orders, 35 joined rows, 30 distinct order_ids.
-- Do NOT use DISTINCT to hide the multiplication.
-- ============================================================


-- ============================================================
-- DE03-03 / P03 - UNION ALL ACTIVITY STREAM
-- Completed orders -> event_id, customer_id, event_date, event_type='Order'
-- Tickets          -> event_id, customer_id, event_date, event_type='Ticket'
-- Use UNION ALL and sort by event_date,event_id.
-- Self-check: 27 Order + 10 Ticket = 37 total events.
-- ============================================================


-- DE03-04 / P04
-- Return raw name, cleaned uppercase name, and name-region-tier label.
-- Validate source rows are unchanged.


-- DE03-05 / P05
-- Join returns to orders; calculate days_to_return = return_date - order_date.
-- Sort longest first. Save one sentence defining the time basis.
-- Self-check max = 4 days.


-- DE03-06 / P06
-- Find Completed orders with net_sales above the average Completed-order net_sales.
-- Save the INNER average query separately before nesting it.
-- Self-check average ~1592.02; final rows = 13.


-- DE03-07 / P07
-- Refactor P06 into exactly two meaningful CTEs.
-- Put a -- grain: comment above each CTE.


-- DE03-08 / P08
-- For every Completed order show net_sales + regional average + above/below flag.
-- Self-check final row count remains 27.


-- DE03-09 / P09
-- Latest support ticket per customer using ROW_NUMBER.
-- Tie-break with ticket_id.
-- Self-check 5 final rows; C003->T005, C010->T009.


-- DE03-10 / P10
-- Use LAG to return each order date plus previous order date for the same customer.
-- Explain why first event per customer has NULL previous date.


-- DE03-10 / P11
-- All-order return rate by region.
-- BEFORE SQL write:
--   denominator = distinct orders per region
--   numerator   = distinct returned orders per region
-- Self-check:
-- East 0/8, North 2/7, South 0/7, West 3/8.


-- ============================================================
-- DE03-15 INTEGRATED CHALLENGE - CLOSED BOOK
-- Top 2 Completed, NON-RETURNED orders in each region by net_sales.
-- Include: order_id, region, customer_name, net_sales, rank_in_region.
-- Tie-break deterministically with order_id.
-- Validation anchors AFTER your attempt only:
-- East  O1025/O1021
-- North O1016/O1012
-- South O1020/O1028
-- West  O1006/O1010
-- ============================================================


-- DE03-16 TIMED INTERVIEW SET - 45 MINUTES IF READY
-- Q1 Which region has the highest Completed net_sales?
-- Q2 Which customers have at least 2 support tickets?
-- Q3 Latest support ticket per customer.
-- Q4 Top non-NULL sales_rep by Completed net_sales.
-- Save SQL + validation + one spoken/written explanation.
