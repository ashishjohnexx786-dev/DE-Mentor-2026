-- M03 POSTGRESQL SCHEMA LAB - TEACHING RC2
-- Use only when you reach DE03-11.
-- Official Windows installer: https://www.postgresql.org/download/windows/
-- Official current docs: https://www.postgresql.org/docs/current/

-- STEP 0 - Open pgAdmin, connect to the PostgreSQL server, select your practice database,
-- then open Query Tool. Confirm the Query Tool is attached to the database you intend to use.

-- STEP 1 - Inspect schema lookup behavior.
SHOW search_path;
SELECT current_database(), current_schema();

-- STEP 2 - Create a dedicated training schema.
CREATE SCHEMA IF NOT EXISTS training;

-- STEP 3 - Create a schema-qualified table.
DROP TABLE IF EXISTS training.orders;
CREATE TABLE training.orders (
    order_id INTEGER PRIMARY KEY,
    customer_name TEXT NOT NULL,
    amount NUMERIC(10,2) NOT NULL CHECK (amount >= 0),
    status TEXT NOT NULL CHECK (status IN ('Pending','Completed','Cancelled'))
);

-- STEP 4 - Insert valid rows.
INSERT INTO training.orders(order_id, customer_name, amount, status) VALUES
(1, 'Aman', 500.00, 'Completed'),
(2, 'Riya', 800.00, 'Pending'),
(3, 'Neha', 350.00, 'Completed');

-- STEP 5 - Verify.
SELECT * FROM training.orders ORDER BY order_id;
SELECT COUNT(*) AS expected_three_rows FROM training.orders;

-- STEP 6 - CONSTRAINT TEST. Run this ON PURPOSE and expect an error.
-- If PostgreSQL rejects it, the CHECK constraint is doing its job.
-- INSERT INTO training.orders VALUES (4, 'Invalid Example', -50.00, 'Completed');

-- STEP 7 - Your independent schema.
CREATE SCHEMA IF NOT EXISTS practice;

DROP TABLE IF EXISTS practice.students;
CREATE TABLE practice.students (
    student_id INTEGER PRIMARY KEY,
    student_name TEXT NOT NULL,
    score INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100)
);

-- You insert 3 valid rows yourself here.

-- STEP 8 - Search path awareness.
SHOW search_path;
-- practice.students works because it is explicitly schema-qualified even if practice
-- is not first in search_path.

-- STEP 9 - Optional safe transaction demonstration.
BEGIN;
UPDATE training.orders SET amount = amount + 10 WHERE order_id = 1;
SELECT * FROM training.orders WHERE order_id = 1;
ROLLBACK;
SELECT * FROM training.orders WHERE order_id = 1;
-- After ROLLBACK, the amount should be back to its original value.

-- STEP 10 - Plan/index reasoning on a tiny table.
EXPLAIN SELECT * FROM training.orders WHERE order_id = 2;
-- The PRIMARY KEY already creates an index for order_id.
-- On tiny tables, PostgreSQL may choose a sequential scan for other predicates.
