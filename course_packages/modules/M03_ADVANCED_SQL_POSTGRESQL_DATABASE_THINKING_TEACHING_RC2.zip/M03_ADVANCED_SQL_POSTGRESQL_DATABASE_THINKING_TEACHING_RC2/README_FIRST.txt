M03 ADVANCED SQL + POSTGRESQL / DATABASE THINKING - TEACHING RC2

START:
1. 00_START_HERE_TEACHING_RC2.pdf
2. 01_LEARNER_BOOK_TEACHING_RC2.pdf
3. Run DATA/M03_MYSQL_LAB_SETUP_TEACHING_RC2.sql for DE03-01 through DE03-10.
4. Use 02_GUIDED_LABS_TEACHING_RC2.pdf.
5. Close guidance for 03_INDEPENDENT_PRACTICE_TEACHING_RC2.pdf.
6. At DE03-11 only, install/open PostgreSQL and use DATA/M03_POSTGRESQL_SCHEMA_LAB_TEACHING_RC2.sql.
7. Use REVIEW_AFTER_ATTEMPT only after a genuine saved attempt.

TEACHING RULE:
The learner is assumed to know only what earlier modules have explicitly taught.
A task must never require the learner to guess the starting asset, expected output,
validation method, evidence, or meaning of a new term.
