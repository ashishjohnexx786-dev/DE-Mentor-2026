#!/usr/bin/env python3
import json, time, argparse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
TOKEN='m08-demo-token'
RECORDS=[
 {'id':'A1','value':11},{'id':'A2','value':22},{'id':'A3','value':33},
 {'id':'A4','value':44},{'id':'A5','value':55},{'id':'A6','value':66},{'id':'A7','value':77}]
class Handler(BaseHTTPRequestHandler):
    counters={'page2':0,'page3':0}
    def log_message(self, fmt, *args): pass
    def send_json(self, code, obj, headers=None):
        body=json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body)))
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        p=urlparse(self.path); q=parse_qs(p.query)
        if p.path=='/health': return self.send_json(200,{'status':'ok'})
        if p.path=='/slow': time.sleep(0.25); return self.send_json(200,{'status':'slow-ok'})
        if self.headers.get('Authorization')!='Bearer '+TOKEN: return self.send_json(401,{'error':'missing_or_bad_token'})
        if p.path!='/records': return self.send_json(404,{'error':'not_found'})
        page=int(q.get('page',['1'])[0]); per=3
        if page==2 and Handler.counters['page2']==0:
            Handler.counters['page2']+=1; return self.send_json(429,{'error':'rate_limited'},{'Retry-After':'0'})
        if page==3 and Handler.counters['page3']==0:
            Handler.counters['page3']+=1; return self.send_json(503,{'error':'temporary_unavailable'})
        start=(page-1)*per; items=RECORDS[start:start+per]; nxt=page+1 if start+per<len(RECORDS) else None
        return self.send_json(200,{'items':items,'next_page':nxt,'page':page})
def run(port):
    srv=ThreadingHTTPServer(('127.0.0.1',port),Handler); print(f'LISTENING {srv.server_address[1]}',flush=True); srv.serve_forever()
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--port',type=int,default=8765); a=ap.parse_args(); run(a.port)
