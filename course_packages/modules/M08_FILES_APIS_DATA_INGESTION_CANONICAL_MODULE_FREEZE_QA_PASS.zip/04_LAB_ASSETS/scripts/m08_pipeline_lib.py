#!/usr/bin/env python3
from pathlib import Path
import csv,json,hashlib,sqlite3,shutil
from datetime import datetime,timezone

def parse_dt(s):
    return datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(timezone.utc)
def sha256_file(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for ch in iter(lambda:f.read(65536),b''): h.update(ch)
    return h.hexdigest()
def defensive_csv(path):
    accepted=[]; quarantine=[]
    with open(path,newline='',encoding='utf-8') as f:
        for r in csv.DictReader(f):
            try: datetime.strptime(r['ship_date'],'%Y-%m-%d'); float(r['weight_kg']); accepted.append(r)
            except Exception as e: quarantine.append({'row':r,'reason':type(e).__name__})
    return accepted,quarantine
def flatten_json(path):
    obj=json.load(open(path,encoding='utf-8')); out=[]
    for e in obj['events']:
        out.append({'event_id':e['event_id'],'shipment_id':e['shipment']['id'],'region':e['shipment']['region'],'scan_type':e['scan']['type'],'event_time':e['scan']['event_time'],'device_id':e['device']['id']})
    return out
def db_extract(path,start,end):
    con=sqlite3.connect(path); q='SELECT order_id,updated_at,status,amount FROM orders WHERE updated_at>=? AND updated_at<? ORDER BY updated_at,order_id'; rows=con.execute(q,(start,end)).fetchall(); con.close(); return rows
def land_batch(batch_dir,landing_dir):
    Path(landing_dir).mkdir(parents=True,exist_ok=True); meta=[]
    for p in sorted(Path(batch_dir).glob('*.csv')):
        dest=Path(landing_dir)/p.name
        digest=sha256_file(p)
        if not dest.exists(): shutil.copy2(p,dest)
        if sha256_file(dest)!=digest: raise RuntimeError('landing overwrite/hash mismatch')
        with open(p,encoding='utf-8') as f: rows=sum(1 for _ in f)-1
        meta.append({'source_file':p.name,'bytes':p.stat().st_size,'sha256':digest,'business_rows':rows})
    return meta
def incremental(path,state,limit=None):
    cursor=tuple(state.get('cursor',['','']))
    rows=list(csv.DictReader(open(path,encoding='utf-8'))); rows.sort(key=lambda r:(r['updated_at'],r['record_id']))
    new=[r for r in rows if (r['updated_at'],r['record_id'])>cursor]
    if limit is not None: new=new[:limit]
    new_state=dict(state)
    if new: new_state['cursor']=[new[-1]['updated_at'],new[-1]['record_id']]
    return new,new_state
def apply_cdc(path):
    state={}; count=0
    for line in open(path,encoding='utf-8'):
        e=json.loads(line); count+=1
        if e['op'] in ('c','r','u'): state[e['key']]=e['after']
        elif e['op']=='d': state.pop(e['key'],None)
        else: raise ValueError('unknown CDC op')
    return count,state
def drift_quarantine(path):
    accepted=[]; bad=[]
    for r in csv.DictReader(open(path,encoding='utf-8')):
        try:
            amount=float(r['amount']); dt=parse_dt(r['event_time']);
            accepted.append({**r,'amount':amount,'event_time_utc':dt.isoformat().replace('+00:00','Z')})
        except Exception as e: bad.append({'row':r,'reason':type(e).__name__})
    return accepted,bad
def late_stats(path,tolerance_seconds=600):
    rows=json.load(open(path,encoding='utf-8')); late=[]
    for r in rows:
        sec=(parse_dt(r['arrived_at'])-parse_dt(r['event_time'])).total_seconds()
        if sec>tolerance_seconds: late.append((r['event_id'],int(sec)))
    return len(rows),late
