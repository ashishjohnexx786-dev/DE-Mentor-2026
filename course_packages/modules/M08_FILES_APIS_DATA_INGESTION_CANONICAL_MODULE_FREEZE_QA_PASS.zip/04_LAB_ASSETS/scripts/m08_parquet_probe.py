#!/usr/bin/env python3
from pathlib import Path
import argparse, struct, json

def probe(path):
    p=Path(path); b=p.read_bytes()
    if len(b)<12: raise ValueError('too small to be a valid Parquet file')
    if b[:4]!=b'PAR1' or b[-4:]!=b'PAR1': raise ValueError('PAR1 magic missing')
    footer_len=struct.unpack('<I',b[-8:-4])[0]
    start=len(b)-8-footer_len
    if start<4: raise ValueError('invalid footer length')
    out={'file':p.name,'bytes':len(b),'magic_start':b[:4].decode(),'magic_end':b[-4:].decode(),'footer_metadata_bytes':footer_len,'footer_start_offset':start}
    try:
        import pyarrow.parquet as pq
        pf=pq.ParquetFile(p)
        out['pyarrow_available']=True; out['rows']=pf.metadata.num_rows; out['row_groups']=pf.metadata.num_row_groups; out['schema']=str(pf.schema_arrow)
    except ImportError:
        out['pyarrow_available']=False; out['reader_note']='Install pyarrow on the learner PC for schema/row-group inspection; do not fabricate those values.'
    return out
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('path'); a=ap.parse_args(); print(json.dumps(probe(a.path),indent=2))
