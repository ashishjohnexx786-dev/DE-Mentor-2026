#!/usr/bin/env python3
import argparse, json, time, random
from urllib.request import Request, urlopen
from urllib.error import HTTPError

def fetch_all(base_url, token, timeout=1.0, max_retries=3):
    page=1; rows=[]; retries=[]
    while page:
        attempts=0
        while True:
            req=Request(f'{base_url}/records?page={page}',headers={'Authorization':f'Bearer {token}'})
            try:
                with urlopen(req,timeout=timeout) as r:
                    if r.status>=400: raise RuntimeError(f'bad status {r.status}')
                    payload=json.loads(r.read().decode('utf-8'))
                rows.extend(payload['items']); page=payload['next_page']; break
            except HTTPError as e:
                if e.code not in (429,500,502,503,504) or attempts>=max_retries: raise
                attempts+=1; retries.append({'page':page,'status':e.code,'attempt':attempts})
                time.sleep(min(0.02*(2**(attempts-1))+random.uniform(0,0.005),0.05))
    return rows,retries
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--base-url',default='http://127.0.0.1:8765'); ap.add_argument('--token',default='m08-demo-token'); a=ap.parse_args()
    rows,retries=fetch_all(a.base_url,a.token); print(json.dumps({'records':len(rows),'ids':[r['id'] for r in rows],'retry_events':retries},indent=2))
