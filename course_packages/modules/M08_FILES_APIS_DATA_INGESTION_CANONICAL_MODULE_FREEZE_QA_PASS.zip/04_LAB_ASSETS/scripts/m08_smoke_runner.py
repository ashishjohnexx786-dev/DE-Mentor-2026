#!/usr/bin/env python3
from pathlib import Path
import json, tempfile, subprocess, sys, time, socket, importlib.util
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError
BASE=Path(__file__).resolve().parents[1]
SCRIPTS=BASE/'scripts'; IN=BASE/'normal/input'; OUT=BASE/'normal/output'
sys.path.insert(0,str(SCRIPTS))
from m08_pipeline_lib import *
from m08_api_client_guided import fetch_all

def free_port():
    s=socket.socket(); s.bind(('127.0.0.1',0)); p=s.getsockname()[1]; s.close(); return p

def main():
    result={}
    a,q=defensive_csv(IN/'parcel_shipments.csv'); result['csv']={'seen':len(a)+len(q),'accepted':len(a),'quarantine':len(q)}
    j=flatten_json(IN/'tracking_events.json'); result['json_events']=len(j)
    db=db_extract(IN/'source_extract.db','2026-09-01T10:00:00Z','2026-09-01T12:30:00Z'); result['db_extract_rows']=len(db)
    meta=land_batch(IN/'batch',OUT/'landing'); result['batch']={'files':len(meta),'rows':sum(x['business_rows'] for x in meta),'hashes_unique':len({x['sha256'] for x in meta})}
    s={}; r1,s=incremental(IN/'incremental_source.csv',s,limit=5); r2,s=incremental(IN/'incremental_source.csv',s); r3,s2=incremental(IN/'incremental_source.csv',s)
    result['incremental']={'first':len(r1),'second':len(r2),'rerun':len(r3),'final_cursor':s['cursor'],'state_stable_on_empty':s==s2}
    c,state=apply_cdc(IN/'cdc_events.jsonl'); result['cdc']={'events':c,'current_entities':len(state),'keys':sorted(state)}
    da,dq=drift_quarantine(IN/'drift_events.csv'); result['drift']={'seen':len(da)+len(dq),'accepted':len(da),'quarantine':len(dq),'utc_values':sum(x['event_time_utc'].endswith('Z') for x in da)}
    lt,late=late_stats(IN/'late_events.json'); result['late']={'seen':lt,'late_count':len(late),'late_ids':[x[0] for x in late]}
    # Parquet low-level probe
    import m08_parquet_probe as pp
    pq=pp.probe(IN/'alltypes_plain.snappy.parquet'); result['parquet']={k:pq[k] for k in ['bytes','magic_start','magic_end','footer_metadata_bytes','footer_start_offset','pyarrow_available']}
    # API server + auth/status/retries/timeout
    port=free_port(); proc=subprocess.Popen([sys.executable,str(SCRIPTS/'m08_local_api_server.py'),'--port',str(port)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        line=proc.stdout.readline().strip(); base=f'http://127.0.0.1:{port}'; result['api_listening']=line
        try: urlopen(f'{base}/records?page=1',timeout=1); result['api_auth_401']=False
        except HTTPError as e: result['api_auth_401']=(e.code==401)
        rows,retries=fetch_all(base,'m08-demo-token',timeout=1,max_retries=3); result['api']={'records':len(rows),'ids':[x['id'] for x in rows],'retries':len(retries),'retry_statuses':[x['status'] for x in retries]}
        try: urlopen(f'{base}/slow',timeout=0.05); result['api_timeout']=False
        except Exception as e: result['api_timeout']=True
    finally:
        proc.terminate();
        try: proc.wait(timeout=2)
        except: proc.kill()
    # checkpoint crash rule simulation
    state={'cursor':['2026-09-01T10:10:00Z','I005']}; candidate={'cursor':['2026-09-01T10:10:00Z','I006']}
    durable_ok=False
    try:
        raise RuntimeError('simulated destination failure before commit')
    except RuntimeError:
        pass
    result['checkpoint_not_advanced_on_failed_commit']=(state['cursor']!=candidate['cursor'] and state['cursor']==['2026-09-01T10:10:00Z','I005'])
    # idempotent identity
    ids=[sha256_file(p) for p in sorted((IN/'batch').glob('*.csv'))]; result['idempotency']={'unique_hashes':len(set(ids)),'rerun_destination_files':len(list((OUT/'landing').glob('*.csv')))}
    # integration controls
    result['integration']={'batch_rows':result['batch']['rows'],'incremental_rows':len(r1)+len(r2),'cdc_current_entities':result['cdc']['current_entities'],'quarantined_rows':result['csv']['quarantine']+result['drift']['quarantine']}
    OUT.mkdir(parents=True,exist_ok=True); (OUT/'M08_SMOKE_RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
