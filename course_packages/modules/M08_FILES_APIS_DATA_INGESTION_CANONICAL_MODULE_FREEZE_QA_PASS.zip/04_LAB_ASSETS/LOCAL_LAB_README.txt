M08 LOCAL LAB
1) Use Python 3.11+; this package was QA-run on Python 3.13.5.
2) Local API: python scripts/m08_local_api_server.py --port 8765
3) In another terminal: python scripts/m08_api_client_guided.py --base-url http://127.0.0.1:8765
4) Full QA smoke: python scripts/m08_smoke_runner.py
5) Parquet low-level probe works without extra packages. Install pyarrow on your learner PC for schema/row-group inspection.
6) Docker is intentionally not required in M08; Docker/Airflow begins in M10.
