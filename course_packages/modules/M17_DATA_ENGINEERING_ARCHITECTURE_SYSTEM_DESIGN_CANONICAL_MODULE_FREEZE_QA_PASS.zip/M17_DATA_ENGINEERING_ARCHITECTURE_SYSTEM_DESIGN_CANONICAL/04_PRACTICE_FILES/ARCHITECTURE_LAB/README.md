# M17 Architecture Lab

1. Read the matching requirements file.
2. Copy `architecture_decision_template.json` into your evidence folder.
3. Fill it from your own reasoning.
4. Run `python evaluate_evidence.py your_file.json`.
5. A structural PASS is **not** architecture mastery. Defend decisions, rejected alternatives, risks and changed constraints before Review.
