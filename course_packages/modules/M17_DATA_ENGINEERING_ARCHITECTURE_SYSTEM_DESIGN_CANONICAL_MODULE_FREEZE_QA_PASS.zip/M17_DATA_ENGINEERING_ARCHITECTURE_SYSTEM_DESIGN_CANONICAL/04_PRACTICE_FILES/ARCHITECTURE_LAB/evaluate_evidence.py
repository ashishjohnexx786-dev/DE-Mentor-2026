import json, sys
from pathlib import Path

def nonempty(x):
    if isinstance(x,str): return bool(x.strip())
    if isinstance(x,list): return bool(x) and all(nonempty(v) for v in x)
    if isinstance(x,dict): return bool(x) and all(nonempty(v) for v in x.values())
    return x is not None

def evaluate(doc):
    missing=[]
    required_top=['scenario','requirements_summary','decisions','failure_domains','security_controls','scale_plan','cost_plan','governance','advanced_concepts','defense']
    for k in required_top:
        if k not in doc or not nonempty(doc[k]): missing.append(k)
    if len(doc.get('decisions',[]))<3: missing.append('decisions>=3')
    for i,d in enumerate(doc.get('decisions',[])):
        for k in ['area','decision','why','rejected_alternative','tradeoff']:
            if not nonempty(d.get(k)): missing.append(f'decisions[{i}].{k}')
    for i,f in enumerate(doc.get('failure_domains',[])):
        for k in ['failure','blast_radius','detect','contain','recover','validate']:
            if not nonempty(f.get(k)): missing.append(f'failure_domains[{i}].{k}')
    cp=doc.get('cost_plan',{})
    if len(cp.get('drivers',[]))<2: missing.append('cost_plan.drivers>=2')
    if len(cp.get('guardrails',[]))<2: missing.append('cost_plan.guardrails>=2')
    concepts={x.get('concept') for x in doc.get('advanced_concepts',[])}
    for c in ['CDC','Data Contracts','Vault','Data Mesh','Kubernetes']:
        if c not in concepts: missing.append('advanced_concept:'+c)
    return sorted(set(missing))

if __name__=='__main__':
    p=Path(sys.argv[1]); doc=json.loads(p.read_text()); missing=evaluate(doc)
    out={'status':'EVIDENCE_COMPLETE_FOR_HUMAN_ARCHITECTURE_REVIEW' if not missing else 'INCOMPLETE','missing':missing,'note':'This checker proves required evidence is present. It does NOT prove the architecture choice is correct; human/Review defense still required.'}
    print(json.dumps(out,indent=2)); raise SystemExit(0 if not missing else 2)
