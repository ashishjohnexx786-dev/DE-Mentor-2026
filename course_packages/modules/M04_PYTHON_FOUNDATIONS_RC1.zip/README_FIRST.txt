ZERO TO JOB-READY DATA ENGINEER 2026
M04 - Python Foundations
Release Candidate RC1

STUDY ORDER
1. Open 00_START_HERE_RC1.pdf.
2. Study one lesson in 01_LEARNER_BOOK_RC1.pdf.
3. Complete the matching guided lab before independent practice.
4. Save evidence before opening any REVIEW_AFTER_ATTEMPT file.
5. Complete four cluster checkpoints, Module Practical, and Fresh Retest only when routed.
6. Record evidence in 09_COMPLETION_RECORD_RC1.pdf.

Core rule: LEARN -> DO -> CHECK -> SAVE -> PASS.
