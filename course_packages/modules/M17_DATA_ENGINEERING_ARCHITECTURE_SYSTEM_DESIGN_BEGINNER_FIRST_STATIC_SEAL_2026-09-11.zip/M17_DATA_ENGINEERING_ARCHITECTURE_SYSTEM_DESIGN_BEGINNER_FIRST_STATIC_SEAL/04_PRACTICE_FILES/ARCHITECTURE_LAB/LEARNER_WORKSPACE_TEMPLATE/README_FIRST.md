M17 LEARNER WORKSPACE - READ FIRST

CREATE vs FILL
- CREATE: start a new learner evidence file from blank.
- FILL: copy a provided blank template here, then fill the copy.
- NEVER edit authoritative requirements or the master architecture_decision_template.json.

NORMAL ROUTE
Teaching Book -> Guided BookBox -> MetroMart attempt -> save -> validate -> explain -> evidence.
Only if weak/uncertain: Review -> repair note -> changed CareLink retry -> validate -> reassess.
FleetStream practical after lesson competencies are complete.

APPEND-ONLY
Original attempt files never get overwritten after help is opened. Use repair/retry folders for later work.

RUNTIME TRUTH
The local checker validates structural completeness only. It does not prove live cloud/runtime behavior.
