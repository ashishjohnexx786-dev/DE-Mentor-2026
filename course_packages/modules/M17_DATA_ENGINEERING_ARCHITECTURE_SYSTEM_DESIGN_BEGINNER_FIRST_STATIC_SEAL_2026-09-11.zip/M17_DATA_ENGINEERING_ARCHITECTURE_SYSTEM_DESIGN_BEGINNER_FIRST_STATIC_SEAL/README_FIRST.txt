STANDALONE ZERO-TO-JOB-READY DATA ENGINEER 2026 - M17
BEGINNER-FIRST PROFESSIONAL INSTITUTE REBUILD

This package preserves the authoritative 10-lesson M17 curriculum and expands the learner teaching/routes.
Start: 00_START_HERE/M17_START_HERE.pdf
Teacher: 01_TEACHING_BOOK/M17_TEACHING_BOOK.pdf

Assessment domains:
- BookBox = guided teacher demonstration
- MetroMart = independent proof
- CareLink = changed repair/retest
- FleetStream = integrated module practical

Protection:
Saved attempt -> targeted repair -> changed micro-proof -> validation -> reassessment. Original attempts append-only.

Next after M17 evidence: G06 Gate A. Gate A pass ends the family; B/C are remediation-only.

IMPORTANT: Static-content seal is not whole-course FINAL and is not live cloud/device/runtime certification. Production Mentor/GitHub are intentionally untouched by this M17 rebuild.
