# M15-P02 - P02 Least Privilege

Scenario/task
Design access for an analyst who only needs Gold read and a service identity that needs project-scoped ingestion/write. Explain why neither needs broad workspace admin. State the secret-handling rule.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
