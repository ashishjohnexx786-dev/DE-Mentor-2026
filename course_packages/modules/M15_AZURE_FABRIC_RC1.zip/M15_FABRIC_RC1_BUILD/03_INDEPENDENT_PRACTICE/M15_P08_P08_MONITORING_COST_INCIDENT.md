# M15-P08 - P08 Monitoring Cost Incident

Scenario/task
Spark runtime doubles while input volume stays flat. Define the run/file/partition/shuffle/capacity evidence you inspect before buying more capacity, and write one measurable hypothesis.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
