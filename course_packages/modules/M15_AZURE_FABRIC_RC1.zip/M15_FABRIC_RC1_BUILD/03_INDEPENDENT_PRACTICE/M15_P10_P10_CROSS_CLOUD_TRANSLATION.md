# M15-P10 - P10 Cross Cloud Translation

Scenario/task
Translate the Fabric project into AWS and GCP architectural concepts for storage, Spark, warehouse and orchestration. Include caveats that feature equivalence is approximate.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
