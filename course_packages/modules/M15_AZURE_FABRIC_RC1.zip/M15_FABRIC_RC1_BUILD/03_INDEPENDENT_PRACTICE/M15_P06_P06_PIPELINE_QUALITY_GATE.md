# M15-P06 - P06 Pipeline Quality Gate

Scenario/task
A Copy activity is green but the source file is empty. Define business success checks, source/loaded/rejected controls, freshness, and alert/retry behavior. Green transport status must not equal business success.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
