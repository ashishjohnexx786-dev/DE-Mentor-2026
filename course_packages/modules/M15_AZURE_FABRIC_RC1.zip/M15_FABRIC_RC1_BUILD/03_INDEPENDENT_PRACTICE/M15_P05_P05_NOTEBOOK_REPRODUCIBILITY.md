# M15-P05 - P05 Notebook Reproducibility

Scenario/task
A notebook only works after cells are run in random order. Define a clean-session execution contract: config -> read -> validate -> transform -> write -> reconcile. Specify evidence that proves reproducibility.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
