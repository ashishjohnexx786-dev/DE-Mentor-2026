# M15-P01 - P01 Cloud Responsibility Split

Scenario/task
Move a daily on-prem pipeline to Fabric. Separate Microsoft-managed responsibilities from data-team responsibilities. Include SLA, data correctness, permissions, monitoring, recovery and cost. Reject the claim that managed means no operational responsibility.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
