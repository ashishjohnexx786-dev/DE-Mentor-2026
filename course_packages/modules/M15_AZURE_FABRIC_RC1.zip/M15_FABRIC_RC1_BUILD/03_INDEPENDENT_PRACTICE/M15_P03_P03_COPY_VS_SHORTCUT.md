# M15-P03 - P03 Copy Vs Shortcut

Scenario/task
A governed customer master already exists in another workspace. Decide copy vs shortcut/shared governed access. Document ownership, lifecycle, permission and availability trade-offs.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
