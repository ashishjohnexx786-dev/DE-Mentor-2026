# M15-P07 - P07 Incremental Cloud Load

Scenario/task
A 20 TB table receives 2 GB daily changes and late corrections. Define business key, watermark/lookback, deterministic MERGE, rerun and backfill behavior. Explain why full reload is not the default.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
