# M15-P04 - P04 Lakehouse Vs Warehouse

Scenario/task
Choose lakehouse, warehouse, or a combination for (a) SQL-heavy BI structured data and (b) Spark + mixed-file engineering. Explain workload reasons rather than declaring one universally superior.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
