# M15-P09 - P09 Dev Test Prod

Scenario/task
Design Git + deployment + environment-specific config and validation for notebook/pipeline promotion. Include rollback and explain why direct production edits fail the control.

Required evidence
- Decision or implementation artifact.
- Validation/check evidence.
- One failure mode and safe response.
- 3-5 sentence explanation without notes.
