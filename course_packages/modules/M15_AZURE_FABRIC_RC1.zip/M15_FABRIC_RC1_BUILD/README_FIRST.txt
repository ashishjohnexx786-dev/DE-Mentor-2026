M15 - Azure + Microsoft Fabric Data Engineering | RC1

Study order:
1. 00_START_HERE
2. 01_LESSONS
3. 02_GUIDED_LABS + 04_PRACTICE_PROJECT
4. 03_INDEPENDENT_PRACTICE
5. 05_QUIZZES
6. 06_MODULE_TEST
7. 07_REVIEW_AND_REPAIR only after attempt
8. 08_FRESH_RETEST

This is a CONDITIONAL RC. Offline controls validate data logic, code/config structure, SQL, security rules, rerun reasoning and assessment contracts. A genuine Microsoft Fabric workspace runtime test is still mandatory before course-wide FINAL.

Do not paste real tokens, passwords or connection strings into course files.
