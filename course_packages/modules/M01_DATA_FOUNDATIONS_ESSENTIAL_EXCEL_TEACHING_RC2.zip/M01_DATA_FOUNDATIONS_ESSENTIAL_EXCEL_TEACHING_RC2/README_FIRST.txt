M01 DATA FOUNDATIONS + ESSENTIAL EXCEL - BEGINNER-FIRST TEACHING RC2

START: M01_MODULE_INDEX_TEACHING_RC2.pdf

LOCKED CHANGE
The teaching style now applies EVERYWHERE, not only the Learner Book.
- Learner Book explains from zero.
- Guided Labs give exact starting asset, actions, expected result and evidence.
- Independent Practice is closed-guidance but never vague.
- Checkpoints state the starting files and pass rule.
- Practical/Retest attempts explain the scenario and required deliverables without revealing the answers.
- Reviews explain how to diagnose the earliest failed step.
- The Excel workbook contains START_HERE, TASK_GUIDE and concrete independent-practice asset sheets.
- Quick Reference remains short because it is revision, not teaching.

Do not use Review material before a saved attempt.
