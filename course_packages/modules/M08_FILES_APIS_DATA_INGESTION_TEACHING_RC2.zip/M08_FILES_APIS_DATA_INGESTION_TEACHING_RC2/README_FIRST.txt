M08 - Files APIs Data Ingestion - TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf.
Learner Book -> Guided -> close guidance -> Independent -> evidence -> Review only after attempt.
Reuse the M05 Python environment. Install only requirements.txt in the supplied Stage 08 project when needed. The API/database sources are local training services; no paid cloud service is required.
Python/project tests can be executed locally. Internet/public APIs are intentionally not required for the core labs, so contracts remain stable.
