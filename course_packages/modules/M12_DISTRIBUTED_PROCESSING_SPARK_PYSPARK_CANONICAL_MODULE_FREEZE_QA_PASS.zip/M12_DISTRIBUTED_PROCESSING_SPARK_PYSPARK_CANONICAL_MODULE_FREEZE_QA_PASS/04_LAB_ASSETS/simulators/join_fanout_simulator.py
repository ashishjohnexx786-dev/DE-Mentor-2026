#!/usr/bin/env python3
import csv,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
orders=list(csv.DictReader(open(root/'normal/orders.csv',newline='',encoding='utf-8')))
good=list(csv.DictReader(open(root/'normal/customers.csv',newline='',encoding='utf-8')))
bad=list(csv.DictReader(open(root/'normal/customers_with_duplicate.csv',newline='',encoding='utf-8')))
def join_count(dim):
    by={}
    for d in dim: by.setdefault(d['customer_id'],[]).append(d)
    out=[]
    for o in orders:
        for d in by.get(o['customer_id'],[]): out.append((o,d))
    return len(out),round(sum(float(o['amount']) for o,d in out),2)
print(json.dumps({'simulator_only':True,'source_order_rows':len(orders),'source_amount':round(sum(float(x['amount']) for x in orders),2),'good_join_rows':join_count(good)[0],'good_join_amount':join_count(good)[1],'bad_join_rows':join_count(bad)[0],'bad_join_amount':join_count(bad)[1],'duplicate_dimension_key':'C02'},indent=2))
