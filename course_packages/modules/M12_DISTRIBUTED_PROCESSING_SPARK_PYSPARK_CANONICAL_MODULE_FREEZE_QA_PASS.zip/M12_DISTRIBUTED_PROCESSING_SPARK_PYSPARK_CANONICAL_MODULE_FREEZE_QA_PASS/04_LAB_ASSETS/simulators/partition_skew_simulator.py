#!/usr/bin/env python3
import csv,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader(open(root/'normal/orders.csv',newline='',encoding='utf-8')))
# classroom deterministic hash-like bucketing; this is NOT Spark partitioning.
buckets={i:[] for i in range(4)}
for r in rows: buckets[sum(map(ord,r['region']))%4].append(r['order_id'])
counts={str(k):len(v) for k,v in buckets.items()}
region_counts={}
for r in rows: region_counts[r['region']]=region_counts.get(r['region'],0)+1
print(json.dumps({'simulator_only':True,'rows':len(rows),'bucket_counts':counts,'region_counts':region_counts,'largest_region_rows':max(region_counts.values()),'note':'Models distribution/skew reasoning only; does not reproduce Spark hash partitioner.'},indent=2))
