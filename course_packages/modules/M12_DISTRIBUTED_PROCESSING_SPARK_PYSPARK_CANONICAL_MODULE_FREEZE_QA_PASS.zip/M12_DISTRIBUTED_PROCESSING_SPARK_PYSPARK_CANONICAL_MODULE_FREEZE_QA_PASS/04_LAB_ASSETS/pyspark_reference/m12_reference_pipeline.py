#!/usr/bin/env python3
"""M12 reference pipeline for PySpark 4.2.0. Requires learner-machine PySpark runtime."""
from pathlib import Path
from pyspark.sql import SparkSession, functions as F, types as T
from pyspark.sql.functions import broadcast
ROOT=Path(__file__).resolve().parents[1]
spark=(SparkSession.builder.master("local[2]").appName("m12-course")
       .config("spark.driver.memory","2g")
       .config("spark.sql.shuffle.partitions","4")
       .config("spark.sql.adaptive.enabled","true").getOrCreate())
order_schema=T.StructType([
 T.StructField("order_id",T.StringType(),False),T.StructField("customer_id",T.StringType(),False),
 T.StructField("region",T.StringType(),False),T.StructField("category",T.StringType(),False),
 T.StructField("qty",T.IntegerType(),False),T.StructField("amount",T.DoubleType(),False)])
orders=spark.read.option("header",True).schema(order_schema).csv(str(ROOT/'normal/orders.csv'))
customers=spark.read.option("header",True).option("inferSchema",True).csv(str(ROOT/'normal/customers.csv'))
assert orders.count()==16
assert abs(orders.agg(F.sum('amount')).first()[0]-3770.0)<1e-9
agg=orders.groupBy('region').agg(F.sum('amount').alias('amount')).orderBy('region')
joined=orders.join(broadcast(customers),'customer_id','left')
assert joined.count()==orders.count()
assert joined.filter(F.col('segment').isNull()).count()==0
orders.createOrReplaceTempView('orders')
sql=spark.sql('SELECT region, SUM(amount) amount FROM orders GROUP BY region ORDER BY region')
assert agg.collect()==sql.collect()
print('orders',orders.count(),'joined',joined.count(),'regions',agg.count())
print('partitions',orders.rdd.getNumPartitions())
orders.explain(mode='formatted')
out=ROOT/'normal/out_parquet'
orders.write.mode('overwrite').partitionBy('region').parquet(str(out))
readback=spark.read.parquet(str(out)).filter(F.col('region')=='East').select('order_id','amount')
print('east_rows',readback.count())
spark.stop()
