#!/usr/bin/env python3
from pyspark.sql import SparkSession, functions as F
from pyspark.testing.utils import assertDataFrameEqual
spark=SparkSession.builder.master('local[2]').appName('m12-test').getOrCreate()
def add_net(df): return df.withColumn('net',F.col('qty')*F.col('unit_price'))
actual=add_net(spark.createDataFrame([(2,10.0),(3,5.0)],['qty','unit_price'])).select('net').orderBy('net')
expected=spark.createDataFrame([(15.0,),(20.0,)],['net']).orderBy('net')
assertDataFrameEqual(actual,expected)
spark.stop()
