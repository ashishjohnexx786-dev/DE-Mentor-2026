# M12 runtime QA boundary

- Current teaching baseline: Apache Spark/PySpark 4.2.0.
- Build environment: OpenJDK 21.0.11 present. PySpark package absent. Attempted `python -m pip install pyspark==4.2.0`, but package-index network/DNS was unavailable, so no Spark runtime was executed here.
- Executed here: pure-Python partition/skew reasoning simulator, join fan-out/reconciliation simulator, Python AST checks, deterministic fixture controls, PDF/render/package QA.
- NOT claimed here: SparkSession, executors, real Spark partitions, jobs/stages/tasks, Spark UI, Spark EXPLAIN output, Parquet pruning by Spark, AQE adaptation, Spark cache, broadcast runtime or PySpark test execution.
- Learner-machine requirement: Java 17+, PySpark 4.2.0; run the bundled reference pipeline + tests under local[2] and save version/plan/UI/output evidence.
- M13 owns deeper Delta Lake runtime; M14 owns Kafka.
