M06 CANONICAL MODULE FREEZE - QA PASS

Start: 00_START_HERE/M06_START_HERE_CANONICAL_FREEZE.pdf

This is a module-level freeze, NOT the whole-course FINAL release. The final standalone Mentor and final device/browser/runtime checks occur after M00-M19 and all seven Gate families are frozen.
