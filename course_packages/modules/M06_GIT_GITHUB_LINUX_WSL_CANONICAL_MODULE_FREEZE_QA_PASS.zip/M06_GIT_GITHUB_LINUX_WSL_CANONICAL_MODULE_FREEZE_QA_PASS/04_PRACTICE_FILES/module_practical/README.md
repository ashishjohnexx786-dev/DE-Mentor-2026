# M06 module_practical

Run: `./scripts/run_pipeline.sh`

Validate row count and status/state counts against the bundled controls.
