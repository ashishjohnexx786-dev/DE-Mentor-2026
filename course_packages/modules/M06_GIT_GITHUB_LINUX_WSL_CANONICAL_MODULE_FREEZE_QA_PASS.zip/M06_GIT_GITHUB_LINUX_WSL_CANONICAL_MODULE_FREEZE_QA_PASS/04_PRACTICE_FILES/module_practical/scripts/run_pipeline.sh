#!/usr/bin/env bash
set -u
INPUT=${INPUT_FILE:-data/raw/jobs.csv}
if [[ ! -f "$INPUT" ]]; then
  echo "missing input: $INPUT" >&2
  exit 2
fi
python3 src/pipeline.py "$INPUT"
rc=$?
exit "$rc"
