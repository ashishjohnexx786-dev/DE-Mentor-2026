# M06 fresh_retest

Run: `./scripts/run_pipeline.sh`

Validate row count and status/state counts against the bundled controls.
