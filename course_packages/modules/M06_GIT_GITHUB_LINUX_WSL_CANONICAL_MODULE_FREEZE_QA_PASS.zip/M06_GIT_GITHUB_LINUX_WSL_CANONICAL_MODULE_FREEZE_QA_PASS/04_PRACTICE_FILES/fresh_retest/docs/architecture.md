Pipeline: raw CSV -> Python validation -> terminal evidence.
Owner: learner.
