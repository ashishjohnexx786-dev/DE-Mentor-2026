#!/usr/bin/env python3
import csv, sys
from collections import Counter
path = sys.argv[1] if len(sys.argv)>1 else 'data/raw/orders.csv'
with open(path, newline='', encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
status_col = 'status' if rows and 'status' in rows[0] else 'state'
counts=Counter(r[status_col] for r in rows)
print('rows=', len(rows))
for k in sorted(counts): print(f'{k}={counts[k]}')
