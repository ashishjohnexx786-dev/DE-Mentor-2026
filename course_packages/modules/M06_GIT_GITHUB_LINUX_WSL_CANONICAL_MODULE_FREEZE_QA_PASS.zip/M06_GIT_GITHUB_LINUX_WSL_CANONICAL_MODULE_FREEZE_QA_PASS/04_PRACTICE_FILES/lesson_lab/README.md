# M06 lesson_lab

Run: `./scripts/run_pipeline.sh`

Validate row count and status/state counts against the bundled controls.
