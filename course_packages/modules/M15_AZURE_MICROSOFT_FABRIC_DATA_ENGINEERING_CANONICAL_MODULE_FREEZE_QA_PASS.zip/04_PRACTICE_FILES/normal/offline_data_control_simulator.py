from pathlib import Path
import csv,json
from decimal import Decimal
from datetime import datetime
ROOT=Path(__file__).parent
rows=list(csv.DictReader(open(ROOT/'base.csv')))
ups=list(csv.DictReader(open(ROOT/'incremental.csv')))
state_name={"normal":"Completed","retest":"Closed","practical":"Done"}[ROOT.name]
good=[];q=[]
for r in rows:
    try: datetime.fromisoformat(r['event_date']); Decimal(r['value'])
    except: q.append((r['id'],'bad_date_or_value')); continue
    if not r['entity_id']: q.append((r['id'],'missing_entity')); continue
    if r['state']!=state_name: q.append((r['id'],'business_state')); continue
    good.append(r)
state={r['id']:r for r in good}; before=sum(Decimal(r['value']) for r in state.values()); u=i=0
for r in ups:
    if r['id'] in state:u+=1
    else:i+=1
    state[r['id']]=r
after=sum(Decimal(r['value']) for r in state.values()); state2=dict(state)
for r in ups: state2[r['id']]=r
out={'IMPORTANT':'OFFLINE DATA-CONTROL SIMULATOR ONLY - NOT MICROSOFT FABRIC RUNTIME.','raw_rows':len(rows),'silver_accepted':len(good),'quarantined':len(q),'quarantine_ids':[x[0] for x in q],'silver_value_total':str(before),'merge_updates':u,'merge_inserts':i,'post_merge_rows':len(state),'post_merge_value_total':str(after),'rerun_idempotent':state2==state}
(ROOT/'observed_controls.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
