from pathlib import Path
p = Path("incoming/inventory_today.csv")
print(p.read_text())
