from pathlib import Path
p = Path("data/daily_orders.csv")
print(p.read_text())
