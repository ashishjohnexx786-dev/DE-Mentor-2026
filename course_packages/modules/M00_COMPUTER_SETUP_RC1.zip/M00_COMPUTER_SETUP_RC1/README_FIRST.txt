M00 COMPUTER, SETUP & LEARNING FOUNDATIONS - RC1

START: 00_START_HERE/M00_START_HERE.pdf

Study order:
1. Start Here
2. Learner Book
3. Guided Labs
4. Independent Practice
5. Module Practical
6. Review/Repair only after a saved attempt
7. Fresh Retest only if needed
8. Quick Reference and Completion Record

Important: DOWNLOAD_ME_FIRST.zip is an intentional practice asset for the ZIP/extraction lesson. It is not a duplicate course package.

This is a Release Candidate module, not the final full-course release.
