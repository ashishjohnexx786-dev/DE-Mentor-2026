A retailer provides customers/products/orders/order_items files. Build a governed PostgreSQL analytical database that can be recreated and validated.

Use only synthetic/course data. Save the first attempt before any review.
