-- DE07-04: Transactions + UPSERT
-- Run each block intentionally.

-- A. ROLLBACK demo: value should return to original after rollback.
BEGIN;
UPDATE source.customers
SET region='South', updated_at=now()
WHERE customer_id='C001';

SELECT customer_id, region
FROM source.customers
WHERE customer_id='C001';

ROLLBACK;

SELECT customer_id, region
FROM source.customers
WHERE customer_id='C001';

-- B. COMMIT demo using a harmless name correction, then change it back if you want.
BEGIN;
UPDATE source.customers
SET customer_name='Aarav Traders Pvt Ltd', updated_at=now()
WHERE customer_id='C001';
COMMIT;

-- C. UPSERT demo: same customer_id can update existing attributes atomically.
INSERT INTO source.customers(customer_id,customer_name,region,segment)
VALUES ('C001','Aarav Traders Pvt Ltd','East','Enterprise')
ON CONFLICT (customer_id) DO UPDATE SET
  customer_name=EXCLUDED.customer_name,
  region=EXCLUDED.region,
  segment=EXCLUDED.segment,
  updated_at=now()
RETURNING customer_id,customer_name,region,segment;
