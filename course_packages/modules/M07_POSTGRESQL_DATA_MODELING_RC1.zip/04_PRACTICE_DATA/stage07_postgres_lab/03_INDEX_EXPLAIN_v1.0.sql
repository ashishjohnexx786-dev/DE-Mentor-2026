-- DE07-05: Index + EXPLAIN awareness
-- The table is intentionally tiny, so PostgreSQL may still prefer a sequential scan.
-- That is NOT a failure. The learning goal is to read evidence rather than demand "Index Scan".

EXPLAIN
SELECT *
FROM source.orders
WHERE customer_id='C003';

CREATE INDEX IF NOT EXISTS idx_orders_customer_id
ON source.orders(customer_id);

EXPLAIN
SELECT *
FROM source.orders
WHERE customer_id='C003';

-- Inspect existing indexes:
SELECT schemaname, tablename, indexname
FROM pg_indexes
WHERE schemaname IN ('source','warehouse')
ORDER BY schemaname,tablename,indexname;
