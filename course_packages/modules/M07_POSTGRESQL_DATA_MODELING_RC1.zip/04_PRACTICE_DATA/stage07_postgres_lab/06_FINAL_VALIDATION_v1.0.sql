-- STAGE 07 FINAL VALIDATION
SELECT COUNT(*) AS fact_rows,
       SUM(qty) AS total_qty,
       SUM(gross_sales) AS total_revenue
FROM warehouse.fact_sales;
-- Expected: 12, 30, 14130.00

SELECT COUNT(*) AS cancelled_fact_rows
FROM warehouse.fact_sales
WHERE order_id='O1005';
-- Expected: 0

SELECT order_id,line_no,COUNT(*)
FROM warehouse.fact_sales
GROUP BY order_id,line_no
HAVING COUNT(*)<>1;
-- Expected: 0 rows

SELECT COUNT(*) AS orphan_customers
FROM warehouse.fact_sales f
LEFT JOIN warehouse.dim_customer c ON c.customer_key=f.customer_key
WHERE c.customer_key IS NULL;
-- Expected: 0

SELECT COUNT(*) AS orphan_products
FROM warehouse.fact_sales f
LEFT JOIN warehouse.dim_product p ON p.product_key=f.product_key
WHERE p.product_key IS NULL;
-- Expected: 0

SELECT c.region, SUM(f.gross_sales) AS revenue
FROM warehouse.fact_sales f
JOIN warehouse.dim_customer c ON c.customer_key=f.customer_key
GROUP BY c.region
ORDER BY c.region;
-- Expected:
-- East 3710.00
-- North 2390.00
-- South 1750.00
-- West 6280.00
