-- STAGE 07 - INDEPENDENT SQL WORKSPACE
-- Save your first attempt before opening the Review Pack.

-- DE07-02 DDL
-- Create source.suppliers:
-- supplier_id text PK
-- supplier_name text NOT NULL
-- country text NOT NULL
-- active boolean NOT NULL DEFAULT true
-- rating numeric(3,2) CHECK rating between 0 and 5

-- DE07-03 Constraints
-- Try one valid supplier, then deliberately test:
-- A) duplicate primary key
-- B) NULL supplier_name
-- C) rating = 6
-- Record the constraint error. Do not "fix" by removing the constraint.

-- DE07-04 Transaction
-- Change C002 region inside BEGIN, inspect it, then ROLLBACK and prove the old value returns.
-- Then perform one UPSERT on C002.

-- DE07-05 EXPLAIN
-- Explain a lookup by source.orders.customer_id before/after idx_orders_customer_id.
-- Write only evidence you observe.

-- DE07-06 Normalization awareness
-- Write 3 problems you would get if customer_name/region were copied into every source.order_items row.

-- DE07-07 Star schema + grain
-- Write one sentence defining fact_sales grain.
-- Query revenue by region from the star schema.
-- Query revenue by product category.

-- DE07-08 Surrogate keys / RI
-- Show customer_id + customer_key from dim_customer.
-- Explain why fact_sales stores customer_key instead of customer_name.
-- Try inserting a fact row with a nonexistent product_key inside a transaction; ROLLBACK after observing FK failure.

-- DE07-09 SCD
-- Run 04_SCD2_LAB_v1.0.sql.
-- Explain why changing the existing C003 row in-place would destroy history.

-- DE07-10 INTEGRATED MODEL CHECK - CLOSED BOOK
-- 1) fact row count
-- 2) total qty
-- 3) total revenue
-- 4) cancelled O1005 must contribute zero rows to fact_sales
-- 5) no orphan fact foreign keys
-- 6) one row per (order_id,line_no)
-- 7) revenue by region reconciles to total revenue
