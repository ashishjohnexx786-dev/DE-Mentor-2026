M10 - Docker Airflow - TEACHING RC2
START with 00_START_HERE_TEACHING_RC2.pdf.
Learner Book -> Guided -> close guidance -> Independent -> evidence -> Review only after attempt.
Verify Docker first with docker version/info. Reuse Git/Python/PostgreSQL knowledge. The training Airflow compose uses apache/airflow:3.3.0. Do not install a separate global Airflow Python environment for these Docker labs.
Static/offline validators are included from the original project. Live Docker/Compose/Airflow behavior must still be smoke-tested on the learner PC before marking runtime competencies complete.
