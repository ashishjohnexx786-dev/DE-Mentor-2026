# M16 runtime boundary RC1

- Local Python / pytest / PyYAML / policy / secret / quality / PII / observability / incident controls may be executed in isolated QA copies.
- A workflow YAML file is NOT a hosted GitHub Actions run.
- `id-token: write` permits a workflow to request an OIDC token; it does not itself grant arbitrary cloud resource write access. Cloud trust + cloud role permissions remain separate.
- Current GitHub OIDC trust must be scoped to actual current token claims; newer repositories may use immutable owner/repository identifiers in the default subject.
- Terraform stable release at 2026-09-11 audit: 1.16.2. A Terraform file is not CLI/cloud execution.
- Real GitHub Actions/OIDC/environment protection and real Terraform CLI/cloud target remain PENDING unless genuinely observed.
- M16 -> M17 -> G06.
