M16 DataOps, CI/CD, Security & Observability - BEGINNER_FIRST_RC1
Clean learner-facing rebuild from authoritative frozen source. Production Mentor is not modified here. G06 remains locked until M17.
