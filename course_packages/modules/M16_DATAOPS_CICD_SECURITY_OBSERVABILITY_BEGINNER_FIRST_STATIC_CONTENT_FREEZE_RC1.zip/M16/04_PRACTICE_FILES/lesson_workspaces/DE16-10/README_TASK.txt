M16 DE16-10 - PII, encryption and masking

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-10/attempt.md. Build a four-column PII treatment table: field, business need, allowed viewers, protection/minimization. Include email, phone, order ID and region.

Expected evidence:
curated masking/search proof + PII treatment table. Never save real personal data in the course evidence.

Validate:
Every retained sensitive field has a stated purpose and access boundary. Your local curated output proves at least one real masking control.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
