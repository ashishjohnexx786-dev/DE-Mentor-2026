M16 DE16-01 - Production mindset

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-01/attempt.md. Draw your own production-readiness chain for a parcel pipeline and classify at least six existing project artifacts as pre-deploy, deploy, post-deploy or recovery evidence. Do not copy the diagram above.

Expected evidence:
attempt.md + actual local run output. Live cloud/CI evidence is not required for this lesson.

Validate:
Your attempt names a risk, an observable signal, an owner/action and a preserved evidence file for each major stage. Re-run the good pipeline and record the actual exit/result path.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
