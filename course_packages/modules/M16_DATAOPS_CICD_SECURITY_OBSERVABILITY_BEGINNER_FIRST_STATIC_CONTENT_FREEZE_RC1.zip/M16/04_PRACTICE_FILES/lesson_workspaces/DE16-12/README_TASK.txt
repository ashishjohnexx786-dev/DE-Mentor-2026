M16 DE16-12 - Observability for data pipelines

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-12/attempt.md. Design five alerts for ParcelPulse with signal, threshold, severity, owner and first response. Include at least one data-health alert not based on job status.

Expected evidence:
healthy/stale observed JSON + alert matrix. Preserve expected non-zero stale run as valid evidence.

Validate:
Your alert set covers status, freshness, volume/quality and latency, and each page has an actionable response rather than a vague “investigate.”

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
