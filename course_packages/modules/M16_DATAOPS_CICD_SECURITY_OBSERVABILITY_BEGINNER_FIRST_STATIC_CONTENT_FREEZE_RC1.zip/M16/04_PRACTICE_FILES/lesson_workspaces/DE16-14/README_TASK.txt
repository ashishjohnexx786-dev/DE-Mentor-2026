M16 DE16-14 - Terraform and IaC foundations

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-14/attempt.md. Explain every supplied Terraform file, write the safe command order, identify three state/credential risks, and record whether real CLI execution is OBSERVED or PENDING.

Expected evidence:
attempt.md + actual Terraform CLI outputs if available. PENDING is correct when the CLI/cloud target is absent.

Validate:
No real apply is required for course artifact QA. A runtime claim includes actual terraform version and command output; otherwise it stays PENDING. Your design keeps state and credentials out of source control.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
