M16 DE16-02 - Testing strategy for data engineering

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-02/attempt.md. Classify all 9 existing tests by layer/risk and propose two missing tests: one fast local test and one integration/live check. Do not copy the labels from the guided example.

Expected evidence:
pytest output + attempt.md risk coverage. Do not fabricate live integration results.

Validate:
Every proposed test names the failure it catches, controlled input/setup, observable pass/fail signal, and whether it can run locally.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
