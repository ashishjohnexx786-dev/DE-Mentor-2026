M16 DE16-06 - Dev, test and prod environments

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-06/attempt.md. Build a three-column dev/test/prod matrix for target, data, identity, secrets, alerting and approval. State why each is same or different.

Expected evidence:
attempt.md + local policy check output; cloud environment configuration only if genuinely observed.

Validate:
Targets are distinct, secrets are referenced rather than literal, and your matrix preserves the same correctness controls across environments.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
