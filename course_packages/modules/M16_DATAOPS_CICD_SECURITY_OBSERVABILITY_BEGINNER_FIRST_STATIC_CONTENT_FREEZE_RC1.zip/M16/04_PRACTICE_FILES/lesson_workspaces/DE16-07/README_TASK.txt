M16 DE16-07 - Deployment, releases and rollback

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-07/attempt.md. Write a release/rollback decision tree for a failed post-deploy quality check, including when you would roll forward instead.

Expected evidence:
release decision + actual local manifest/plan inspection. Live deployment remains pending.

Validate:
The decision tree preserves evidence, names a known-good target, protects durable data, and ends with post-recovery validation.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
