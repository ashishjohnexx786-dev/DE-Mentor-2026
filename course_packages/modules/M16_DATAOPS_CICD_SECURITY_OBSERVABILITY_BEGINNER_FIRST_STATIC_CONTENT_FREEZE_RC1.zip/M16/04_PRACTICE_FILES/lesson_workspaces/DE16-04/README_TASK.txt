M16 DE16-04 - Continuous Integration fundamentals

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-04/attempt.md. Draw the current CI workflow as a five-box flow, list what each check blocks, and name two failures it cannot detect before deployment.

Expected evidence:
local parity command outputs + workflow reading note. Hosted GitHub run remains separate runtime evidence.

Validate:
Your flow matches ci.yml exactly, permissions remain least-privilege, and live GitHub execution is labeled PENDING unless you observed a real run.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
