M16 DE16-13 - Incidents, runbooks and root cause

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-13/attempt.md. Write a runbook for a post-deploy data-quality failure with detection, owner, containment, recovery, validation, two hypotheses and evidence needed for RCA.

Expected evidence:
generated incident record + independent runbook; do not overwrite the original incident evidence.

Validate:
The runbook does not claim an unproven cause, preserves failed evidence, and requires post-recovery data health checks before closure.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
