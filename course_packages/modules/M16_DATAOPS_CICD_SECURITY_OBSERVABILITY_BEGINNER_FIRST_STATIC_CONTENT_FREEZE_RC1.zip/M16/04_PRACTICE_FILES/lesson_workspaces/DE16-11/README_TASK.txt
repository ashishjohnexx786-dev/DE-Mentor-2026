M16 DE16-11 - Metadata, lineage and governance

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-11/attempt.md. Draw the ParcelPulse lineage from memory, then add an owner, grain, classification, freshness target and one impact-analysis question for every node.

Expected evidence:
attempt.md lineage + catalog interpretation. Live Purview scanning remains optional/live-platform evidence only.

Validate:
Your graph has directional upstream/downstream edges and the metadata is sufficient for another engineer to find the owner and understand the row meaning.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
