M16 DE16-03 - Automated quality gates

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-03/attempt.md. Design five quality rules for a new delivery feed: at least three blockers and two warnings. Include evidence, owner and recovery for each. Run both supplied gate commands and record observed controls.

Expected evidence:
good/bad gate outputs + attempt.md; preserve the failing bad run as valid test evidence.

Validate:
No percentage/average can override a failed blocker. Your policy makes severity explicit and the observed bad dataset deliberately fails.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
