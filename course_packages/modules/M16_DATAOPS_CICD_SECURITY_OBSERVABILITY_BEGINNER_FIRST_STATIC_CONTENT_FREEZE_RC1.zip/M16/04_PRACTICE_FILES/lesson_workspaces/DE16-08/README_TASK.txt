M16 DE16-08 - Secrets and credential safety

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-08/attempt.md. Write a six-step incident response for an accidentally committed API key and design a safer authentication replacement. Use fake names only.

Expected evidence:
clean scanner output + fake-detection proof + response design; never include real secret values.

Validate:
Your first containment includes revoke/rotate, no real value is saved, and the prevention plan covers storage, scanning, permissions and short-lived identity where supported.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
