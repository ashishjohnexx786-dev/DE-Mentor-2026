M16 DE16-05 - GitHub Actions for data projects

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-05/attempt.md. Annotate both workflow files: trigger, platform permissions, environment, OIDC request, missing cloud login/trust pieces. Propose a least-privilege trust scope without inventing a real credential.

Expected evidence:
workflow annotation + trust-design note. Real GitHub OIDC token/cloud login remains live-runtime pending.

Validate:
Your note says id-token: write only permits token request; cloud access still depends on trust policy and role permissions. Live workflow/OIDC proof is PENDING unless actually observed.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
