M16 DE16-09 - RBAC and least privilege

CREATE: attempt.md in this folder.
DO NOT create a fake live-runtime result. DO NOT overwrite a failed attempt. DO NOT copy the worked answer.

Independent task:
CREATE lesson_workspaces/DE16-09/attempt.md. Design roles for analyst-reader, pipeline-service and production-deployer for a new parcel region. Include one explicit denied action per role.

Expected evidence:
role matrix + local policy output. Real cloud role assignments only if genuinely configured.

Validate:
No role has wildcard actions, prod scope is narrow, and risky powers are separated. Local policy_checks.py remains green.

If repair is assigned later, preserve attempt.md and CREATE retry.md after the protected Review.
