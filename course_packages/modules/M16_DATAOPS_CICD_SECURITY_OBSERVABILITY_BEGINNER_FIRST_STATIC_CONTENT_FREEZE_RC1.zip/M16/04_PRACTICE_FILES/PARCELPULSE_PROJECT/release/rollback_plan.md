# ParcelPulse rollback plan

Trigger rollback when a blocking post-deploy health check fails and the new release is the likely cause.

1. Freeze further deployments.
2. Preserve failed-run evidence and candidate version.
3. Restore v1.4.0 application/config artifact.
4. Do not reverse data changes blindly; inspect migration compatibility first.
5. Rerun quality, reconciliation, freshness and PII checks.
6. Record incident owner and follow-up action.
