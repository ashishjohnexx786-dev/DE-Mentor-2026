from pathlib import Path
import sys, tempfile, json, csv, yaml
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from pipeline import run
from secret_scan import scan
from observability import observe
from policy_checks import check
from incident import incident

def test_good_quality_gate_controls(tmp_path):
    m=run(ROOT/'data/orders_good.csv',tmp_path)
    assert m=={'input_rows':8,'accepted_rows':8,'rejected_rows':0,'accepted_amount':990.0,'blocking_failures':0}

def test_bad_quality_gate_blocks(tmp_path):
    m=run(ROOT/'data/orders_bad.csv',tmp_path)
    assert m['input_rows']==8 and m['accepted_rows']==5 and m['rejected_rows']==3 and m['blocking_failures']==3

def test_curated_output_does_not_publish_raw_email(tmp_path):
    run(ROOT/'data/orders_good.csv',tmp_path)
    txt=(tmp_path/'curated_orders.csv').read_text()
    assert 'alice@example.com' not in txt and 'a***@example.com' in txt

def test_secret_scanner_blocks_fake_secret(tmp_path):
    (tmp_path/'bad.txt').write_text('token = ' + 'DEMO' + '-TOKEN-' + '1234567890ABCDEF')
    assert scan(tmp_path)

def test_normal_project_has_no_secret_hits():
    assert scan(ROOT)==[]

def test_observability_healthy_and_stale():
    healthy=observe(ROOT/'data/orders_good.csv','2026-09-10T09:45:00',30)
    stale=observe(ROOT/'data/orders_good.csv','2026-09-10T12:45:00',30)
    assert healthy['healthy'] is True and stale['healthy'] is False

def test_policy_checks_least_privilege_and_env_separation():
    assert check(ROOT)==[]

def test_incident_record_has_recovery_and_unknown_root_cause(tmp_path):
    r=incident(out=tmp_path/'incident.json')
    assert r['owner'] and r['rollback_target']=='v1.4.0' and r['root_cause_status'].startswith('unknown')

def test_ci_yaml_has_pull_request_and_read_permission():
    wf=yaml.safe_load((ROOT/'.github/workflows/ci.yml').read_text())
    # PyYAML may parse unquoted 'on' as boolean in YAML 1.1; direct text check protects the learning file.
    txt=(ROOT/'.github/workflows/ci.yml').read_text()
    assert 'pull_request:' in txt and 'contents: read' in txt
