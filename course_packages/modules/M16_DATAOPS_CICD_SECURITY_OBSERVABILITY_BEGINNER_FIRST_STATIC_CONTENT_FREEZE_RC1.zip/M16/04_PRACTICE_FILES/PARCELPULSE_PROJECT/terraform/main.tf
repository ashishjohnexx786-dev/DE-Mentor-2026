terraform {
  required_version = ">= 1.16.0, < 2.0.0"
}

resource "terraform_data" "pipeline_contract" {
  input = {
    name        = var.pipeline_name
    environment = var.environment
    owner       = var.owner
  }
}
