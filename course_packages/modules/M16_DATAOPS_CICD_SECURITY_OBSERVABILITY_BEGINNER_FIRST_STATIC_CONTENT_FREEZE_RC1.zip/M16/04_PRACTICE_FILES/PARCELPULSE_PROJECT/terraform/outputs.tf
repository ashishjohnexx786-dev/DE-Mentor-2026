output "pipeline_contract" {
  value = terraform_data.pipeline_contract.output
}
