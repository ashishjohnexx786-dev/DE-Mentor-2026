variable "pipeline_name" {
  type    = string
  default = "parcelpulse"
}

variable "environment" {
  type    = string
  default = "dev"
  validation {
    condition     = contains(["dev", "test", "prod"], var.environment)
    error_message = "environment must be dev, test, or prod"
  }
}

variable "owner" {
  type    = string
  default = "data-platform"
}
