# M16 ParcelPulse practice project

Use only after the matching lesson tells you to open it.

Local commands from this folder:

```bash
python -m pytest -q
python src/policy_checks.py .
python src/secret_scan.py .
python src/quality_gate.py data/orders_good.csv evidence/good
python src/quality_gate.py data/orders_bad.csv evidence/bad   # expected non-zero exit
python src/observability.py data/orders_good.csv 2026-09-10T09:45:00 30
python src/incident.py post_deploy_quality_failed
```

Do not put real credentials in this project. Live GitHub Actions and Terraform CLI proof are separate runtime checks.
