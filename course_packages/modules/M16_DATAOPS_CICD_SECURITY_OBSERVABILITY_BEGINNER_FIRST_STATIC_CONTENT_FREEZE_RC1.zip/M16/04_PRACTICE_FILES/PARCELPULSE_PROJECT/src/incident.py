import json, sys
from pathlib import Path

def incident(symptom='post_deploy_quality_failed', out='evidence/incident.json'):
    record={'severity':'SEV2','symptom':symptom,'owner':'data-platform-oncall','containment':'freeze further deployment and preserve failed evidence','rollback_target':'v1.4.0','validation':['quality gate','row reconciliation','freshness','PII scan'],'root_cause_status':'unknown - investigate; do not guess','follow_up':'add regression test for confirmed cause'}
    p=Path(out); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(record,indent=2),encoding='utf-8'); return record
if __name__=='__main__': print(json.dumps(incident(sys.argv[1] if len(sys.argv)>1 else 'post_deploy_quality_failed'),indent=2))
