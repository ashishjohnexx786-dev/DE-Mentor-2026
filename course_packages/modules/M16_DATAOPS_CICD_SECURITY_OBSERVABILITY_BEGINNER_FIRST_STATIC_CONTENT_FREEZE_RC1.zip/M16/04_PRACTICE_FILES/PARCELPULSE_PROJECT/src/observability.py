import csv, json, sys
from datetime import datetime, timezone
from pathlib import Path

def observe(csv_path, reference_time, sla_minutes, rejected_rows=0, latency_ms=120):
    with open(csv_path,encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f))
    times=[datetime.fromisoformat(r['event_time']) for r in rows if r.get('event_time')]
    ref=datetime.fromisoformat(reference_time)
    freshest=max(times) if times else None
    age=(ref-freshest).total_seconds()/60 if freshest else None
    m={'row_count':len(rows),'freshest_event_time':freshest.isoformat() if freshest else None,'freshness_age_minutes':round(age,1) if age is not None else None,'freshness_sla_minutes':sla_minutes,'rejected_rows':rejected_rows,'latency_ms':latency_ms}
    m['healthy']=bool(rows) and rejected_rows==0 and age is not None and age<=sla_minutes
    return m
if __name__=='__main__':
    m=observe(sys.argv[1],sys.argv[2],float(sys.argv[3])); print(json.dumps(m,indent=2)); raise SystemExit(0 if m['healthy'] else 2)
