import sys, json
from pathlib import Path
from pipeline import run
if __name__=='__main__':
    inp=sys.argv[1]; out=sys.argv[2] if len(sys.argv)>2 else 'evidence/gate'
    m=run(inp,out)
    print(json.dumps(m,indent=2))
    raise SystemExit(1 if m['blocking_failures'] else 0)
