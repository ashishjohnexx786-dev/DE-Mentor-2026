from pathlib import Path
import csv, json, re

def mask_email(email):
    if not email or '@' not in email: return ''
    local, domain = email.split('@',1)
    return (local[:1] + '***@' + domain) if local else '***@' + domain

def evaluate(rows):
    seen=set(); accepted=[]; rejected=[]
    for r in rows:
        reasons=[]
        oid=(r.get('order_id') or '').strip(); email=(r.get('email') or '').strip()
        try: amount=float(r.get('amount',''))
        except Exception: amount=None
        if not oid: reasons.append('missing_order_id')
        if oid in seen: reasons.append('duplicate_order_id')
        if oid: seen.add(oid)
        if not email or '@' not in email: reasons.append('invalid_email')
        if amount is None or amount <= 0: reasons.append('nonpositive_amount')
        if reasons:
            rejected.append({'order_id':oid,'reasons':reasons})
        else:
            accepted.append({'order_id':oid,'masked_email':mask_email(email),'amount':round(amount,2),'event_time':r.get('event_time','')})
    return accepted,rejected

def run(input_csv, out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    with open(input_csv,encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f))
    accepted,rejected=evaluate(rows)
    with open(out/'curated_orders.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['order_id','masked_email','amount','event_time']); w.writeheader(); w.writerows(accepted)
    metrics={'input_rows':len(rows),'accepted_rows':len(accepted),'rejected_rows':len(rejected),'accepted_amount':round(sum(x['amount'] for x in accepted),2),'blocking_failures':len(rejected)}
    (out/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    (out/'rejected.json').write_text(json.dumps(rejected,indent=2),encoding='utf-8')
    return metrics
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('input'); p.add_argument('--out',default='evidence/run')
    a=p.parse_args(); print(json.dumps(run(a.input,a.out),indent=2))
