from pathlib import Path
import re, sys, json
PATTERNS=[re.compile(r'DEMO-TOKEN-[A-Za-z0-9]{12,}'), re.compile(r'(?i)(api[_-]?key|password)\s*[:=]\s*["\'][A-Za-z0-9_\-]{16,}["\']')]
SKIP={'.git','.pytest_cache','__pycache__','evidence'}
def scan(root):
    hits=[]
    for p in Path(root).rglob('*'):
        if not p.is_file() or any(x in p.parts for x in SKIP): continue
        if p.suffix.lower() in {'.png','.jpg','.jpeg','.pdf','.zip','.pyc'}: continue
        try: text=p.read_text(encoding='utf-8')
        except Exception: continue
        for i,line in enumerate(text.splitlines(),1):
            if any(rx.search(line) for rx in PATTERNS): hits.append({'file':str(p),'line':i})
    return hits
if __name__=='__main__':
    hits=scan(sys.argv[1] if len(sys.argv)>1 else '.')
    print(json.dumps(hits,indent=2)); raise SystemExit(1 if hits else 0)
