from pathlib import Path
import json, sys, yaml

def check(root):
    root=Path(root); problems=[]
    roles=json.loads((root/'security/roles.json').read_text())['roles']
    for role in roles:
        if any(a=='*' or a.endswith(':*') for a in role['actions']): problems.append('wildcard permission in '+role['name'])
    cfgs=[yaml.safe_load((root/f'config/{x}.yml').read_text()) for x in ['dev','test','prod']]
    if len({c['target'] for c in cfgs}) != 3: problems.append('environment targets not distinct')
    wf=yaml.safe_load((root/'.github/workflows/ci.yml').read_text())
    perms=wf.get('permissions',{})
    if perms.get('contents')!='read': problems.append('CI contents permission must be read')
    for k,v in perms.items():
        if v=='write': problems.append('unexpected CI write permission '+str(k))
    return problems
if __name__=='__main__':
    p=check(sys.argv[1] if len(sys.argv)>1 else '.'); print(json.dumps(p,indent=2)); raise SystemExit(1 if p else 0)
