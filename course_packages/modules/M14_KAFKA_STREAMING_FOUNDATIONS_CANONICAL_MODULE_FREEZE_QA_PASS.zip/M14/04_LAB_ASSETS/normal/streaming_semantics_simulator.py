#!/usr/bin/env python3
"""Course-owned Kafka semantics simulator. NOT a broker."""
from pathlib import Path
import csv,json,hashlib,sys
ROOT=Path(__file__).resolve().parent; IN=ROOT/'input/events.csv'; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
with IN.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
P=3
parts={str(i):[] for i in range(P)}
def partition(key): return int(hashlib.sha256(key.encode()).hexdigest()[:8],16)%P
for r in rows:
    p=partition(r['key']); e=dict(r);e['partition']=p;e['offset']=len(parts[str(p)]);parts[str(p)].append(e)
# prove key sticks to one partition and order is only defined per partition
key_parts={k:sorted({e['partition'] for pp in parts.values() for e in pp if e['key']==k}) for k in sorted({r['key'] for r in rows})}
# group g1 consumes 4 events then crashes before committing event #4; restart replays from committed offset
flat=[]
for p in range(P): flat += parts[str(p)]
flat=sorted(flat,key=lambda e:(e['partition'],e['offset']))
committed={str(p):0 for p in range(P)}; processed=[]
for e in flat[:4]:
    processed.append(e['event_id'])
    # commit all except final processed event to model crash after side effect, before offset commit
    if e is not flat[3]: committed[str(e['partition'])]=e['offset']+1
# restart from committed positions
replay=[]
for p in range(P): replay += [e for e in parts[str(p)] if e['offset']>=committed[str(p)]]
replay=sorted(replay,key=lambda e:(e['partition'],e['offset']))
# idempotent external sink keyed by event_id handles replay duplicates
sink={}
for eid in processed+[e['event_id'] for e in replay]: sink[eid]=1
# consumer group assignment capacity: partitions cap active parallel consumers
assign={f'consumer-{i+1}':[] for i in range(4)}
for p in range(P): assign[f'consumer-{p+1}'].append(p)
# schema compatibility classroom rule: v2 may add field; removing required v1 field is incompatible
schema={'1':['event_id','key','event_type','value'],'2':['event_id','key','event_type','value','schema_version']}
# lag: high water = partition length, committed position = above
lag={str(p):len(parts[str(p)])-committed[str(p)] for p in range(P)}
report={'IMPORTANT':'CLASSROOM SIMULATOR ONLY - NOT APACHE KAFKA.',
 'events':len(rows),'partitions':P,'partition_sizes':{k:len(v) for k,v in parts.items()},'key_partitions':key_parts,
 'within_partition_offsets_monotonic':all([e['offset'] for e in v]==list(range(len(v))) for v in parts.values()),
 'processed_before_crash':processed,'committed_positions':committed,'replayed_after_restart':[e['event_id'] for e in replay],
 'processing_attempts':len(processed)+len(replay),'unique_sink_events':len(sink),'duplicates_suppressed':len(processed)+len(replay)-len(sink),'duplicate_side_effect_prevented':len(processed)+len(replay)>len(sink),
 'consumer_group_assignment':assign,'idle_consumers':sum(not v for v in assign.values()),
 'schema_versions':schema,'additive_v2_compatible':True,'drop_required_field_compatible':False,
 'lag_by_partition':lag,'total_lag':sum(lag.values())}
(OUT/'controls.json').write_text(json.dumps(report,indent=2));
(OUT/'partition_log.json').write_text(json.dumps(parts,indent=2)); print(json.dumps(report,indent=2))
