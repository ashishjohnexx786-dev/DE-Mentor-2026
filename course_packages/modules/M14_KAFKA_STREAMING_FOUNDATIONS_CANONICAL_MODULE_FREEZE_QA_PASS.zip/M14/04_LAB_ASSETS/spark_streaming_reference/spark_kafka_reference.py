# Spark 4.2 reference; requires the spark-sql-kafka connector package at runtime.
df=(spark.readStream.format('kafka').option('kafka.bootstrap.servers','localhost:9092').option('subscribe','m14-events').option('startingOffsets','earliest').load())
parsed=df.selectExpr('CAST(key AS STRING) key','CAST(value AS STRING) value','topic','partition','offset','timestamp')
q=(parsed.writeStream.format('console').option('checkpointLocation','/tmp/m14-checkpoint').outputMode('append').start())
q.awaitTermination()
