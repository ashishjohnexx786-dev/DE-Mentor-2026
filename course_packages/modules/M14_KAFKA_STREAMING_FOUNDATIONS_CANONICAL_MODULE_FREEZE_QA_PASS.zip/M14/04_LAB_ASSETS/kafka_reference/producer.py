from confluent_kafka import Producer
import json
p=Producer({'bootstrap.servers':'localhost:9092','enable.idempotence':True,'acks':'all'})
for i in range(5): p.produce('m14-events',key=f'C{i%2}',value=json.dumps({'event_id':f'E{i}','value':i}))
p.flush()
