from confluent_kafka import Consumer
c=Consumer({'bootstrap.servers':'localhost:9092','group.id':'m14-lab','auto.offset.reset':'earliest','enable.auto.commit':False})
c.subscribe(['m14-events'])
seen=0
while seen<5:
 m=c.poll(2.0)
 if m is None: continue
 if m.error(): raise RuntimeError(m.error())
 print(m.topic(),m.partition(),m.offset(),m.key(),m.value()); seen+=1; c.commit(message=m,asynchronous=False)
c.close()
