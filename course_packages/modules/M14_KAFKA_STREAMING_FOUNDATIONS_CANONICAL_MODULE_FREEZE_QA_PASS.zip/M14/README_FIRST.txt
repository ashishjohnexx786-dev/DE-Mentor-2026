M14 Kafka + Streaming Foundations canonical rebuild. Start with 00_START_HERE. Review only after saved attempt. Live Kafka runtime is not claimed by artifact QA. After M14: G05.
