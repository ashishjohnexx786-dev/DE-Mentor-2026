M00 COMPUTER, SETUP & LEARNING FOUNDATIONS - TEACHING RC2

START HERE:
00_START_HERE/M00_MODULE_INDEX.pdf

IMPORTANT CHANGE
The old checkpoint-style Learner Book has been replaced.
01_LESSONS/M00_LEARNER_BOOK.pdf is now the actual teacher: plain-English explanation, analogies, exact clicks/commands, expected results, why-it-worked explanations, mistakes, independent mini-tasks and teach-back checks.

STUDY ORDER
1. M00_MODULE_INDEX.pdf
2. M00_LEARNER_BOOK.pdf lessons 1-2
3. Guided Lab G01
4. Lessons 3-4 + G02
5. Lessons 5-6 + G03
6. Lessons 7-8 + G04
7. Independent Practice
8. Module Practical
9. Only if needed: Repair Pack -> Fresh Retest

RULE
Do not use the Repair Pack as the teacher. Do not mark a lesson mastered just because you read it.
