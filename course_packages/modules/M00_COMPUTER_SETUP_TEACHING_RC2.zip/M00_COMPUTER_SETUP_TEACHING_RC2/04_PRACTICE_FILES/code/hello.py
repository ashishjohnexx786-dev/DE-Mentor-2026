print("Hello from M00 practice")
