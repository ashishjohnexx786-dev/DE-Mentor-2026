print("practice")
